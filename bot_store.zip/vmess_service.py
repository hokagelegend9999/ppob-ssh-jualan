import paramiko
import uuid
import datetime
import base64
import json
import time

# ==========================================
# KONFIGURASI SERVER (IP, USER, PASSWORD)
# ==========================================
# Isi credential VPS Singapore dan Indo Anda di sini
SERVER_LIST = {
    "sg": {
        "ip": "206.189.158.119",          # GANTI IP VPS SG
        "user": "root",
        "pass": "azzam2016", # GANTI PASSWORD VPS SG
        "domain": "sg.hokage.web.id" # Domain SG
    },
    "indo": {
        "ip": "103.150.226.10",          # GANTI IP VPS INDO
        "user": "root",
        "pass": "azzam2016", # GANTI PASSWORD VPS INDO
        "domain": "id.hokagelegend.net" # Domain INDO
    }
}

# --- PATH DI VPS TARGET (Sesuai script installer umumnya) ---
CONFIG_JSON = "/etc/xray/config.json"
DB_VMESS = "/etc/vmess/.vmess.db"
LIMIT_IP_DIR = "/etc/hokage/limit/vmess/ip"
CLASH_DIR = "/var/www/html"

def get_ssh_client(ip, user, password):
    """Membuka koneksi SSH ke VPS Target"""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(ip, username=user, password=password, timeout=10)
    return client

def create_vmess_user(username, quota_gb, masa_aktif_hari, location):
    """
    Membuat user Vmess via SSH ke server target (SG/Indo).
    """
    client = None
    try:
        # 1. Ambil Data Server Berdasarkan Lokasi
        target = SERVER_LIST.get(location)
        if not target:
            return False, "Lokasi Server tidak ditemukan di Config.", {}

        domain = target['domain']
        u_uuid = str(uuid.uuid4())
        
        # Hitung Expired Date
        today = datetime.datetime.now()
        exp_date = today + datetime.timedelta(days=int(masa_aktif_hari))
        exp_str = exp_date.strftime("%Y-%m-%d") # Format: 2025-12-15
        
        # 2. Buka Koneksi SSH
        client = get_ssh_client(target['ip'], target['user'], target['pass'])

        # --- 3. SIAPKAN COMMAND LINUX UNTUK DIKIRIM ---
        # Kita gunakan command SED yang sama, tapi dikirim via SSH string
        
        # String yang akan disisipkan ke JSON
        # Perlu escaping ekstra untuk dijalankan via remote shell
        entry_content = f'### {username} {exp_str}\\n}},{{"id": "{u_uuid}","alterId": 0,"email": "{username}"'
        
        commands = []
        
        # A. Command Manipulasi Config.json (TLS & GRPC)
        # Hati-hati dengan kutip satu (') dan dua (") saat kirim command SSH
        commands.append(f"sed -i '/#vmess$/a\{entry_content}' {CONFIG_JSON}")
        commands.append(f"sed -i '/#vmessgrpc$/a\{entry_content}' {CONFIG_JSON}")
        
        # B. Command Update Database .vmess.db
        # Format: ### user exp uuid quota_bytes iplimit
        if quota_gb == "Unlimited": quota_bytes = 0
        else: quota_bytes = int(quota_gb) * 1024 * 1024 * 1024
        
        entry_db = f"### {username} {exp_str} {u_uuid} {quota_bytes} 2"
        
        commands.append(f"sed -i '/\\b{username}\\b/d' {DB_VMESS}") # Hapus user lama jika ada
        commands.append(f"echo '{entry_db}' >> {DB_VMESS}")         # Tambah baru
        
        # C. Command Limit IP
        commands.append(f"mkdir -p {LIMIT_IP_DIR}")
        commands.append(f"echo '2' > {LIMIT_IP_DIR}/{username}")
        
        # D. Restart Xray
        commands.append("systemctl restart xray")

        # --- 4. EKSEKUSI SEMUA COMMAND ---
        full_command = " && ".join(commands) # Gabung jadi satu baris biar efisien
        stdin, stdout, stderr = client.exec_command(full_command)
        
        # Cek Error
        err = stderr.read().decode()
        if err and "sed" not in err: # Sed kadang ngeluarin warning bukan error
             print(f"SSH Warning/Error: {err}")

        # --- 5. GENERATE LINK VMESS (LOGIC LOKAL DI BOT) ---
        # Link 1: WS TLS
        json_tls = {
            "v": "2", "ps": username, "add": domain, "port": "443", "id": u_uuid,
            "aid": "0", "net": "ws", "path": "/vmess", "type": "none", 
            "host": domain, "tls": "tls"
        }
        
        # Link 2: WS Non-TLS
        json_ntls = {
            "v": "2", "ps": username, "add": domain, "port": "80", "id": u_uuid,
            "aid": "0", "net": "ws", "path": "/vmess", "type": "none", 
            "host": domain, "tls": "none"
        }
        
        # Link 3: GRPC
        json_grpc = {
            "v": "2", "ps": username, "add": domain, "port": "443", "id": u_uuid,
            "aid": "0", "net": "grpc", "path": "vmess-grpc", "type": "none", 
            "host": domain, "tls": "tls"
        }

        # Encode ke Base64
        link_tls = "vmess://" + base64.b64encode(json.dumps(json_tls).encode()).decode()
        link_ntls = "vmess://" + base64.b64encode(json.dumps(json_ntls).encode()).decode()
        link_grpc = "vmess://" + base64.b64encode(json.dumps(json_grpc).encode()).decode()

        # --- 6. BUAT FILE CLASH (Opsional di VPS) ---
        # Kita kirim command lagi untuk buat file clash di VPS target
        clash_content = f"""- name: Vmess-{username}-WS TLS
  type: vmess
  server: {domain}
  port: 443
  uuid: {u_uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: {domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: {domain}"""
      
        # Trik echo multiline via SSH agak ribet, kita pakai printf sederhana atau base64 decode di server sana
        # Untuk keamanan, kita skip step clash file remote dulu agar tidak error quote, 
        # Format openclash sudah kita generate linknya di bot (vmess-username.txt)
        
        client.close()

        # --- 7. RETURN DATA ---
        result_data = {
            'username': username,
            'uuid': u_uuid,
            'link_tls': link_tls,
            'link_ntls': link_ntls,
            'link_grpc': link_grpc,
            'domain': domain
        }
        
        return True, "Sukses", result_data

    except Exception as e:
        if client: client.close()
        return False, f"SSH Error: {str(e)}", {}