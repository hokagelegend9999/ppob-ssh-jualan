import threading
import time
import requests
import re
from bot_init import bot
from config import (
    ADMIN_ID, 
    OKECONNECT_MEMBER_ID, 
    OKECONNECT_PIN, 
    OKECONNECT_PASSWORD
)
from database import (
    check_and_downgrade_resellers,
    get_connection,
    update_transaction_status,
    update_saldo
)

# =========================================================
#  THREAD 1: AUTO DOWNGRADE RESELLER
# =========================================================
def auto_check_reseller_loop():
    print("✅ Background Task: Auto Downgrade Reseller Berjalan...")
    time.sleep(10)
    while True:
        try:
            korban = check_and_downgrade_resellers()
            for uid in korban:
                try:
                    bot.send_message(uid, f"⚠️ <b>PERINGATAN</b>\nStatus Reseller dicabut karena target tidak tercapai.", parse_mode='HTML')
                    bot.send_message(ADMIN_ID, f"📉 Downgrade ID {uid}")
                except: pass
            time.sleep(21600) # 6 Jam
        except Exception as e: 
            print(f"⚠️ Error Reseller Check: {e}")
            time.sleep(60)

# =========================================================
#  THREAD 2: AUTO CEK STATUS PPOB (OKECONNECT)
# =========================================================
CHECK_INTERVAL = 15  # Cek setiap 15 detik

def check_pending_transactions_loop():
    print("✅ Background Task: Monitoring Transaksi Pending Berjalan...")
    time.sleep(15)
    while True:
        try:
            conn = get_connection()
            c = conn.cursor()
            # Ambil TRX yang pending/proses
            pending_trx = c.execute("SELECT user_id, ref_id, code, dest, price, date FROM transactions WHERE (status='pending' OR status='proses')").fetchall()
            conn.close()

            if pending_trx:
                for row in pending_trx:
                    user_id, ref_id, code, dest, price, tgl_trx = row
                    
                    # Cek Provider Berdasarkan Ref ID
                    if ref_id.startswith("TRX"):
                        check_status_okeconnect(user_id, ref_id, code, dest, price)
                    
                    time.sleep(2)
            
            time.sleep(CHECK_INTERVAL)
            
        except Exception as e:
            print(f"⚠️ Error PPOB Check Loop: {e}")
            time.sleep(10)

# --- FUNGSI CEK STATUS OKECONNECT ---
def check_status_okeconnect(user_id, ref_id, code, dest, price):
    url = "https://okeconnect.com/trx"
    payload = {
        'memberID': OKECONNECT_MEMBER_ID, 
        'pin': OKECONNECT_PIN,
        'password': OKECONNECT_PASSWORD,
        'product': code,
        'dest': dest,
        'refID': ref_id,
        'check': '1'
    }
    
    try:
        response = requests.get(url, params=payload, timeout=30)
        respon_text = response.text
        msg_lower = respon_text.lower()
        
        status_final = None
        sn = "-"
        keterangan = respon_text

        if "sukses" in msg_lower or "berhasil" in msg_lower:
            status_final = "sukses"
            try:
                match = re.search(r'(sn|token|vocher)[:\s]+([a-zA-Z0-9\-/]+)', respon_text, re.IGNORECASE)
                sn = match.group(2) if match else respon_text.split()[-1]
            except: sn = "Lihat Keterangan"

        elif "gagal" in msg_lower or "salah tujuan" in msg_lower or "stok kosong" in msg_lower:
            status_final = "gagal"
        elif "transaksi tidak ditemukan" in msg_lower: return 
        elif "proses" in msg_lower or "pending" in msg_lower: return 

        if status_final == "sukses":
            update_transaction_status(ref_id, "sukses", sn)
            try: 
                # ==========================================
                # FORMAT BARU STRUK OKECONNECT SUKSES
                # ==========================================
                struk_sukses = (
                    f"🎉 <b>TRANSAKSI SUKSES</b> 🎉\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🆔 <b>RefID :</b> <code>{ref_id}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🎟️ <b>SN/Token:</b>\n"
                    f"<code>{sn}</code>\n\n"
                    f"📦 <b>Produk :</b> {code}\n"
                    f"📱 <b>Tujuan :</b> <code>{dest}</code>\n"
                    f"💰 <b>Harga  :</b> Rp {int(price):,}\n\n"
                    f"📝 <b>Info Server:</b>\n"
                    f"<i>{keterangan}</i>"
                )
                bot.send_message(user_id, struk_sukses, parse_mode='HTML')
            except: pass
            print(f"✅ [AUTO OKE] SUKSES: {ref_id}")

        elif status_final == "gagal":
            update_transaction_status(ref_id, "gagal", keterangan)
            update_saldo(user_id, price, f"REFUND {code}", f"REF-{ref_id}", dest, "SYSTEM")
            try: bot.send_message(user_id, f"❌ <b>TRANSAKSI GAGAL</b>\n📦 Produk: {code}\n📱 Tujuan: {dest}\n📝 Ket: {keterangan}\n💰 <i>Saldo dikembalikan.</i>", parse_mode='HTML')
            except: pass
            print(f"❌ [AUTO OKE] GAGAL & REFUND: {ref_id}")
            
    except Exception: pass

# =========================================================
#  MAIN STARTER
# =========================================================
def start_background_tasks():
    # MEMATIKAN AUTO DOWNGRADE RESELLER
    # t_reseller = threading.Thread(target=auto_check_reseller_loop)
    # t_reseller.daemon = True
    # t_reseller.start()

    t_ppob = threading.Thread(target=check_pending_transactions_loop)
    t_ppob.daemon = True
    t_ppob.start()