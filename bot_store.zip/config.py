# config.py

# ==========================================
# 1. KONFIGURASI ADMIN
# ==========================================
# Masukkan semua ID Admin di sini
ADMIN_IDS = [
    1469244768,  # ID Utama Anda
    123456789    # ID Cadangan (Ganti/Hapus jika tidak perlu)
]
ADMIN_ID = 1469244768  # ID Telegram Utama (Digunakan untuk validasi owner)

# ==========================================
# 2. KONFIGURASI BOT TELEGRAM
# ==========================================
BOT_TOKEN = "8220710888:AAFBt3GPy6oQ6_Z_XsJjYfGCXWzKJ2xXLWc"

# ==========================================
# 3. KONFIGURASI SERVER (DOMAIN & IP)
# ==========================================
# Server Indonesia
DOMAIN_HOST_ID = "id.hokagelegend.net"

# Server Singapore (Baru)
DOMAIN_HOST_SG = "aws.hokage.web.id" 
# Tips: Jika Anda menggunakan script remote SSH, Anda mungkin perlu menambahkan IP SG disini nanti.

# ==========================================
# 4. KONFIGURASI HARGA (PRICES)
# ==========================================
# Format: "lokasi": {"layanan": {"role": harga}}
# Ini harus cocok dengan yang ada di menus.py
PRICES = {
    # --- HARGA SERVER INDONESIA ---
    "indo": {
        "ssh":  {"user": 13000, "reseller": 8000},
        "xray": {"user": 13000, "reseller": 8000}
    },
    # --- HARGA SERVER SINGAPORE ---
    "sg": {
        "ssh":  {"user": 15000, "reseller": 12000},
        "xray": {"user": 15000, "reseller": 12000}
    }
}

# ==========================================
# 5. KONFIGURASI RESELLER & AUTO UPGRADE
# ==========================================
MIN_TOPUP_AUTO_RESELLER = 50000   # Minimal topup untuk otomatis jadi reseller
BIAYA_DAFTAR_RESELLER = 50000     # Biaya daftar reseller mandiri

# ==========================================
# 6. KONFIGURASI PPOB (ATLANTIC)
# ==========================================
ATLANTIC_API_KEY = "ZTpYGNcRua62zqfgw8C3HBydQ9BWtBPfyPSbj2DCNV7Kizb4GdCPySfWZVofwZnQO89Txxf1R085mpkqu390av9dnXOPP7ERvtWw"
# Note: Pastikan IP VPS Anda sudah di-Whitelist di Dashboard Atlantic!
ATLANTIC_TRANSFER_URL = "https://atlantich2h.com/transfer/create"
ATLANTIC_PROFILE_URL = "https://atlantich2h.com/get_profile"
ATLANTIC_PRICE_URL = "https://atlantich2h.com/layanan/price_list"
ATLANTIC_TRX_URL = "https://atlantich2h.com/transaksi/create"
ATLANTIC_DEPOSIT_STATUS_URL = "https://atlantich2h.com/deposit/status"

# ==========================================
# 7. KONFIGURASI PPOB (OKECONNECT)
# ==========================================
OKECONNECT_MEMBER_ID = "OK2528108" 
OKECONNECT_PIN = "2787" 
OKECONNECT_PASSWORD = "Azzam2016!?"
OKECONNECT_TRX_URL = "https://h2h.okeconnect.com/trx"
OKECONNECT_PRICE_URL = "https://okeconnect.com/harga/json?id=905ccd028329b0a"


# ==========================================
# 9. KONFIGURASI EMAIL (SMTP)
# ==========================================
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465  # SSL
SMTP_EMAIL = "hokagelegend9999@gmail.com"
SMTP_PASSWORD = "jubmsdlcnczhqzpm" # App Password
RECIPIENT_EMAIL = "hokagelegend9999@gmail.com"
WA_ADMIN = "6287726917005"
TG_ADMIN = "HookageLegend"
