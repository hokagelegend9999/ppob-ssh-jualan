import telebot
import logging
from config import BOT_TOKEN

# Inisialisasi Bot
# Tambahkan num_threads=50 agar bot punya banyak pekerja dan tidak mudah stuck
bot = telebot.TeleBot(token=BOT_TOKEN, parse_mode='HTML', num_threads=50)
logging.basicConfig(level=logging.INFO)

# Penyimpanan sementara untuk fitur "View As" (Owner lihat menu User)
TEMP_VIEW = {}