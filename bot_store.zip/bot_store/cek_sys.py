import sqlite3

DB_NAME = "/root/bot_store/store_data.db"
TARGET_REF = "SYS-1768910572" # ID dari screenshot Bapak

def cek_detail_sys():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    print(f"🔍 MEMERIKSA DATA MENTAH UNTUK: {TARGET_REF}")
    print("="*60)
    
    c.execute("SELECT * FROM transactions WHERE ref_id = ?", (TARGET_REF,))
    row = c.fetchone()
    
    if row:
        print(f"🆔 ID DB       : {row['id']}")
        print(f"📅 Date        : {row['date']}")
        print(f"📝 Description : '{row['description']}'") # Cek apakah ini kosong?
        print(f"💾 Code        : '{row['code']}'")        # Cek apakah ini ada isinya?
        print(f"🔗 Ref ID      : {row['ref_id']}")
        print(f"📱 Destination : '{row['destination']}'")
        print(f"🔑 SN          : '{row['sn']}'")
    else:
        print("❌ Data tidak ditemukan!")
        
    conn.close()
    print("="*60)

if __name__ == "__main__":
    cek_detail_sys()
