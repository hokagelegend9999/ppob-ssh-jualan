import threading
import time
import requests
import re
from bot_init import bot
from config import (
    ADMIN_ID, 
    OKECONNECT_MEMBER_ID,  # [FIX] Sudah disesuaikan dengan config.py Anda
    OKECONNECT_PIN, 
    OKECONNECT_PASSWORD,
    ATLANTIC_API_KEY
)
from database import (
    check_and_downgrade_resellers,
    get_connection,
    update_transaction_status,
    update_saldo
)

# =========================================================
#  THREAD 1: AUTO DOWNGRADE RESELLER
# =========================================================
def auto_check_reseller_loop():
    print("✅ Background Task: Auto Downgrade Reseller Berjalan...")
    while True:
        try:
            korban = check_and_downgrade_resellers()
            for uid in korban:
                try:
                    bot.send_message(uid, f"⚠️ <b>PERINGATAN</b>\nStatus Reseller dicabut karena target tidak tercapai.", parse_mode='HTML')
                    bot.send_message(ADMIN_ID, f"📉 Downgrade ID {uid}")
                except: pass
            time.sleep(21600) # 6 Jam
        except Exception as e: 
            print(f"⚠️ Error Reseller Check: {e}")
            time.sleep(60)

# =========================================================
#  THREAD 2: AUTO CEK STATUS PPOB (ATLANTIC & OKE)
# =========================================================
CHECK_INTERVAL = 15  # Cek setiap 15 detik

def check_pending_transactions_loop():
    print("✅ Background Task: Monitoring Transaksi Pending Berjalan...")
    while True:
        try:
            conn = get_connection()
            c = conn.cursor()
            # Ambil TRX (Oke) DAN ATL (Atlantic) yang pending/proses
            pending_trx = c.execute("SELECT user_id, ref_id, code, dest, price, date FROM transactions WHERE (status='pending' OR status='proses')").fetchall()
            conn.close()

            if pending_trx:
                for row in pending_trx:
                    user_id, ref_id, code, dest, price, tgl_trx = row
                    
                    # Cek Provider Berdasarkan Ref ID
                    if ref_id.startswith("TRX"):
                        check_status_okeconnect(user_id, ref_id, code, dest, price)
                    elif ref_id.startswith("ATL"):
                        check_status_atlantic_history(user_id, ref_id, code, dest, price)
                    
                    time.sleep(2)
            
            time.sleep(CHECK_INTERVAL)
            
        except Exception as e:
            print(f"⚠️ Error PPOB Check Loop: {e}")
            time.sleep(10)

# --- FUNGSI CEK STATUS OKECONNECT ---
def check_status_okeconnect(user_id, ref_id, code, dest, price):
    url = "https://okeconnect.com/trx"
    payload = {
        'memberID': OKECONNECT_MEMBER_ID, # [FIX] Menggunakan variabel yang benar
        'pin': OKECONNECT_PIN,
        'password': OKECONNECT_PASSWORD,
        'product': code,
        'dest': dest,
        'refID': ref_id,
        'check': '1'
    }
    
    try:
        response = requests.get(url, params=payload, timeout=30)
        respon_text = response.text
        msg_lower = respon_text.lower()
        
        status_final = None
        sn = "-"
        keterangan = respon_text

        if "sukses" in msg_lower or "berhasil" in msg_lower:
            status_final = "sukses"
            try:
                match = re.search(r'(sn|token|vocher)[:\s]+([a-zA-Z0-9\-/]+)', respon_text, re.IGNORECASE)
                sn = match.group(2) if match else respon_text.split()[-1]
            except: sn = "Lihat Keterangan"

        elif "gagal" in msg_lower or "salah tujuan" in msg_lower or "stok kosong" in msg_lower:
            status_final = "gagal"
        elif "transaksi tidak ditemukan" in msg_lower: return 
        elif "proses" in msg_lower or "pending" in msg_lower: return 

        if status_final == "sukses":
            update_transaction_status(ref_id, "sukses", sn)
            try: bot.send_message(user_id, f"✅ <b>TRANSAKSI SUKSES!</b>\n📦 Produk: {code}\n📱 Tujuan: {dest}\n🔑 <b>SN:</b> <code>{sn}</code>", parse_mode='HTML')
            except: pass
            print(f"✅ [AUTO OKE] SUKSES: {ref_id}")

        elif status_final == "gagal":
            update_transaction_status(ref_id, "gagal", keterangan)
            update_saldo(user_id, price, f"REFUND {code}", f"REF-{ref_id}", dest, "SYSTEM")
            try: bot.send_message(user_id, f"❌ <b>TRANSAKSI GAGAL</b>\n📦 Produk: {code}\n📝 Ket: {keterangan}\n💰 <i>Saldo dikembalikan.</i>", parse_mode='HTML')
            except: pass
            print(f"❌ [AUTO OKE] GAGAL & REFUND: {ref_id}")
            
    except Exception: pass

# --- FUNGSI CEK STATUS ATLANTIC (HISTORY MATCHING - FIXED) ---
def check_status_atlantic_history(user_id, ref_id, code, dest, price):
    print(f"[PPOB] 🔎 Cek Status Atlantic Ref: {ref_id}...")
    
    try:
        url = "https://atlantich2h.com/transaksi/riwayat"
        payload = {'api_key': ATLANTIC_API_KEY, 'type': 'prabayar', 'limit': 50} # Naikkan limit biar trx agak lama kabeck
        
        # Tambahkan headers agar dianggap browser asli (mengurangi risiko diblokir)
        headers = {'User-Agent': 'Mozilla/5.0'}
        
        response = requests.post(url, data=payload, headers=headers, timeout=30)
        
        # [FIX] Cek apakah response sukses (200 OK) dan isinya JSON valid
        if response.status_code != 200:
            print(f"⚠️ Server Atlantic Error: {response.status_code} - {response.text[:100]}")
            return

        try:
            res_json = response.json()
        except ValueError:
            # Jika respon bukan JSON (misal HTML Maintenance)
            print(f"⚠️ Atlantic Respon Bukan JSON: {response.text[:50]}...")
            return

        if res_json.get('status') is True:
            history_data = res_json.get('data', [])
            
            matched_trx = None
            for trx in history_data:
                if trx.get('reff_id') == ref_id:
                    matched_trx = trx
                    break
            
            if matched_trx:
                status_server = str(matched_trx.get('status')).lower()
                sn_server = matched_trx.get('sn')
                
                if status_server == 'success':
                    sn_final = sn_server if sn_server else "Sukses"
                    update_transaction_status(ref_id, "sukses", sn_final)
                    
                    try:
                        bot.send_message(user_id, f"✅ <b>TRANSAKSI SUKSES!</b>\n📦 Produk: {code}\n📱 Tujuan: {dest}\n🔑 <b>SN:</b> <code>{sn_final}</code>", parse_mode='HTML')
                    except: pass
                    print(f"✅ [AUTO ATL] SUKSES: {ref_id} | SN: {sn_final}")
                    
                elif status_server == 'failed':
                    ket = matched_trx.get('message', 'Gagal dari Pusat')
                    update_transaction_status(ref_id, "gagal", ket)
                    
                    update_saldo(user_id, price, f"REFUND {code}", f"REF-{ref_id}", dest, "ATL")
                    
                    try:
                        bot.send_message(user_id, f"❌ <b>TRANSAKSI GAGAL</b>\n📦 Produk: {code}\n📝 Ket: {ket}\n💰 <i>Saldo dikembalikan.</i>", parse_mode='HTML')
                    except: pass
                    print(f"❌ [AUTO ATL] GAGAL & REFUND: {ref_id}")
            else:
                # Jika tidak ada di history Atlantic, kemungkinan transaksi sudah sangat lama (expired) atau gagal request
                pass
        else:
             print(f"⚠️ Atlantic API False: {res_json.get('message')}")

    except Exception as e:
        print(f"⚠️ Error Cek Atlantic: {e}")

# =========================================================
#  MAIN STARTER
# =========================================================
def start_background_tasks():
    t_reseller = threading.Thread(target=auto_check_reseller_loop)
    t_reseller.daemon = True
    t_reseller.start()

    t_ppob = threading.Thread(target=check_pending_transactions_loop)
    t_ppob.daemon = True
    t_ppob.start()