import sqlite3

# Lokasi Database
DB_NAME = "/root/bot_store/store_data.db"

def cek_transaksi_vpn():
    try:
        conn = sqlite3.connect(DB_NAME)
        conn.row_factory = sqlite3.Row # Agar bisa panggil nama kolom
        c = conn.cursor()
        
        print("\n🔍 MENCARI TRANSAKSI VPN (SSH/VMESS/VLESS/TROJAN)...")
        print("="*100)
        print(f"{'ID':<5} | {'TANGGAL':<18} | {'AMOUNT':<10} | {'DESKRIPSI (CODE)':<35} | {'REF ID':<20}")
        print("-" * 100)
        
        # Query mencari keyword VPN di kolom description atau code
        # Kita cek kolom 'description' (lama) dan 'code' (baru)
        query = """
            SELECT id, date, amount, price, description, code, ref_id 
            FROM transactions 
            WHERE 
                description LIKE '%SSH%' OR description LIKE '%VMESS%' OR 
                description LIKE '%VLESS%' OR description LIKE '%TROJAN%' OR
                code LIKE '%SSH%' OR code LIKE '%VMESS%' OR
                code LIKE '%VLESS%' OR code LIKE '%TROJAN%'
            ORDER BY id DESC 
            LIMIT 20
        """
        
        c.execute(query)
        rows = c.fetchall()
        
        if not rows:
            print("❌ Tidak ditemukan transaksi dengan kata kunci VPN/SSH/VMESS.")
        
        for row in rows:
            # Handle kemungkinan kolom kosong
            id_trx = row['id']
            date = row['date']
            
            # Cek Amount (kadang di kolom amount, kadang di price)
            amt = row['amount'] if row['amount'] else row['price']
            
            # Cek Deskripsi (kadang di description, kadang di code)
            desc = row['description'] if row['description'] else row['code']
            
            ref = row['ref_id']
            
            # Bersihkan None
            if amt is None: amt = 0
            if desc is None: desc = "-"
            
            print(f"{id_trx:<5} | {str(date)[:16]:<18} | {str(amt):<10} | {str(desc)[:35]:<35} | {str(ref)[:20]}")

        print("="*100)
        print("👉 Silakan copy hasil di atas dan kirim ke saya.")
        
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        if conn: conn.close()

if __name__ == "__main__":
    cek_transaksi_vpn()
