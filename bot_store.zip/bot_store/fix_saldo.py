import sqlite3

# Sesuaikan path database kamu
DB_NAME = "/root/bot_store/store_data.db"

def fix_database_saldo():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    print("🔄 Menambahkan kolom history saldo...")

    # Tambahkan kolom balance_before & balance_after
    columns = [
        ("balance_before", "INTEGER DEFAULT 0"),
        ("balance_after", "INTEGER DEFAULT 0")
    ]

    for col_name, col_type in columns:
        try:
            c.execute(f"ALTER TABLE transactions ADD COLUMN {col_name} {col_type}")
            print(f"✅ Berhasil tambah kolom: {col_name}")
        except Exception as e:
            if "duplicate" in str(e).lower():
                print(f"ℹ️ Kolom {col_name} sudah ada.")
            else:
                print(f"❌ Gagal {col_name}: {e}")

    conn.commit()
    conn.close()
    print("🎉 Selesai! Lanjut ke langkah update script.")

if __name__ == "__main__":
    fix_database_saldo()
