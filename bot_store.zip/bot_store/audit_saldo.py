import sqlite3

DB_NAME = "store_data.db"

def audit_illegal_balance():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    print("🕵️‍♂️ MEMULAI AUDIT KEAMANAN SALDO...")
    print("="*40)

    # 1. Ambil semua user yang punya saldo > 0
    c.execute("SELECT user_id, first_name, balance FROM users WHERE balance > 0")
    rich_users = c.fetchall()
    
    suspicious_users = []

    for user in rich_users:
        uid, name, current_balance = user
        
        # 2. Hitung Total Deposit SAH (Yang punya ID Valid & Amount Positif)
        # Syarat Sah: Amount > 0 DAN ref_id tidak kosong/-
        query = """
            SELECT SUM(amount) FROM transactions 
            WHERE user_id = ? 
            AND amount > 0 
            AND ref_id != '-' 
            AND ref_id != ''
            AND ref_id IS NOT NULL
        """
        c.execute(query, (uid,))
        res = c.fetchone()
        total_valid_deposit = res[0] if res[0] else 0
        
        # 3. Logika Pengecekan
        # Jika Saldo Sekarang LEBIH BESAR dari Total Deposit Sah, berarti ada "Uang Hantu"
        # (Kecuali dia dapat bonus/transfer, tapi script ini fokus mencari anomali kasar)
        
        if current_balance > total_valid_deposit:
            selisih = current_balance - total_valid_deposit
            print(f"🚨 SUSPECT: {name} (ID: {uid})")
            print(f"   💰 Saldo Sekarang : Rp {current_balance:,}")
            print(f"   ✅ Deposit Sah    : Rp {total_valid_deposit:,} (Bukti ID Lengkap)")
            print(f"   ⚠️ SALDO HANTU    : Rp {selisih:,} (Tanpa Bukti ID)")
            print("-" * 20)
            suspicious_users.append(uid)
            
    if not suspicious_users:
        print("✅ AMAN. Tidak ditemukan user dengan saldo mencurigakan.")
    else:
        print(f"❌ Ditemukan {len(suspicious_users)} user mencurigakan.")
        print("Saran: Cek riwayat mereka manual, lalu potong saldo jika perlu.")

    conn.close()

if __name__ == "__main__":
    audit_illegal_balance()