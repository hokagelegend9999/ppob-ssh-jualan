import sqlite3

DB_NAME = "/root/bot_store/store_data.db"

def fix_description_null():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    print("🔄 Sedang memperbaiki deskripsi transaksi kosong...")
    
    # Salin isi kolom 'code' ke 'description' JIKA 'description' kosong/null
    c.execute("""
        UPDATE transactions 
        SET description = code 
        WHERE (description IS NULL OR description = '' OR description = '-') 
        AND code IS NOT NULL
    """)
    
    updated = c.rowcount
    conn.commit()
    conn.close()
    
    print(f"✅ BERHASIL! {updated} transaksi telah diperbaiki namanya.")
    print("Sekarang riwayat di bot akan tampil benar (SSH/VPN).")

if __name__ == "__main__":
    fix_description_null()
