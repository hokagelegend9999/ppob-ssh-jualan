import telebot
import logging
from config import BOT_TOKEN

# Inisialisasi Bot
# Hapus bagian proxy sampai tutup kurung
bot = telebot.TeleBot(token=BOT_TOKEN, parse_mode='HTML')
logging.basicConfig(level=logging.INFO)

# Penyimpanan sementara untuk fitur "View As" (Owner lihat menu User)
TEMP_VIEW = {}