import sqlite3
import requests
import json

# Konfigurasi
DB_NAME = "/root/bot_store/store_data.db"
# API Key dari config.py Anda
API_KEY = "isRvfcVi2uUCGjwpN7OoFUvxDshDroXlrv0gDICCVmzeGimCg6VhUmRFwwaB6cKP6OTdf4z36bbYwGM8LpgtzkJR1LqsK2pzBT30"
TARGET_REF_ID = "ATL17691891666310575986" # Ref ID Transaksi yang rusak

def fix_transaction():
    print(f"🔄 Sedang mencari data asli untuk Ref: {TARGET_REF_ID} di Atlantic...")
    
    # 1. Ambil History dari Atlantic
    url = "https://atlantich2h.com/transaksi/riwayat"
    payload = {'api_key': API_KEY, 'type': 'prabayar', 'limit': 50}
    headers = {'User-Agent': 'Mozilla/5.0'}
    
    try:
        response = requests.post(url, data=payload, headers=headers, timeout=30)
        res_json = response.json()
        
        if res_json.get('status') is True:
            data_trx = res_json.get('data', [])
            
            # Cari transaksi yang cocok
            found = None
            for t in data_trx:
                if t.get('reff_id') == TARGET_REF_ID:
                    found = t
                    break
            
            if found:
                # Ambil Data Valid
                real_sn = found.get('sn')
                real_status = found.get('status') # success/failed
                real_message = found.get('message')
                
                print(f"✅ DITEMUKAN!")
                print(f"   • Status Asli : {real_status}")
                print(f"   • SN Asli     : {real_sn}")
                
                # Update Database
                conn = sqlite3.connect(DB_NAME)
                c = conn.cursor()
                
                status_db = 'sukses' if str(real_status).lower() == 'success' else 'gagal'
                sn_db = real_sn if real_sn else "Proses Provider"
                
                c.execute("UPDATE transactions SET status=?, sn=?, message=? WHERE ref_id=?", 
                          (status_db, sn_db, real_message, TARGET_REF_ID))
                
                conn.commit()
                conn.close()
                print("🎉 Database BERHASIL diupdate dengan data valid!")
            else:
                print("❌ Transaksi tidak ditemukan di 50 riwayat terakhir Atlantic.")
                print("Mungkin sudah terlalu lama tertimbun transaksi lain.")
                
                # Opsi update manual jika tidak ketemu di history
                print("⚠️ Melakukan Update Manual berdasarkan info Bapak...")
                conn = sqlite3.connect(DB_NAME)
                c = conn.cursor()
                c.execute("UPDATE transactions SET status='sukses', sn='04041700000286869887' WHERE ref_id=?", (TARGET_REF_ID,))
                conn.commit()
                conn.close()
                print("✅ Data diupdate manual ke SN: 04041700000286869887")

        else:
            print(f"❌ Gagal ambil history: {res_json.get('message')}")
            
    except Exception as e:
        print(f"❌ Error Koneksi: {e}")

if __name__ == "__main__":
    fix_transaction()
