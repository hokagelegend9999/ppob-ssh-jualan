import json
import os

def final_sync():
    path_root = "/root/bot_store/me-cli"
    auth_file = os.path.join(path_root, "app/auth.json")
    refresh_file = os.path.join(path_root, "refresh-tokens.json")
    active_file = os.path.join(path_root, "active.number")
    target_num = 6287726917005

    if not os.path.exists(auth_file):
        print("❌ auth.json tidak ditemukan!")
        return

    with open(auth_file, 'r') as f:
        data = json.load(f)
    
    # Ambil token (mendukung berbagai format response)
    token_data = data.get('data', data)
    new_rt = token_data.get('refreshToken') or token_data.get('refresh_token')

    if new_rt:
        # Update refresh-tokens.json
        tokens = []
        if os.path.exists(refresh_file):
            with open(refresh_file, 'r') as f:
                tokens = json.load(f)
        
        found = False
        for t in tokens:
            if str(t.get('number')) == str(target_num):
                t['refresh_token'] = new_rt
                found = True
                break
        
        if not found:
            tokens.append({
                "number": target_num,
                "refresh_token": new_rt,
                "subscriber_id": "00000000",
                "username": "Hokage_Active"
            })

        with open(refresh_file, 'w') as f:
            json.dump(tokens, f, indent=4)
        
        # Set nomor aktif
        with open(active_file, 'w') as f:
            f.write(str(target_num))
            
        print(f"✅ SUKSES: Nomor {target_num} sekarang terdaftar sebagai sesi aktif.")
    else:
        print("❌ Gagal mendapatkan refresh token dari auth.json.")

if __name__ == "__main__":
    final_sync()
