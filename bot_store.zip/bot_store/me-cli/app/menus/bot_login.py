import sys
import os
import time
import json
# Import InlineKeyboardMarkup dkk untuk tombol
from telebot.types import ForceReply, InlineKeyboardMarkup, InlineKeyboardButton

# ==========================================
# 1. SETUP IMPORT & PATH
# ==========================================
SESSION_DIR = "/root/bot_store/sessions"

# Pastikan folder session ada
if not os.path.exists(SESSION_DIR):
    os.makedirs(SESSION_DIR)

try:
    from app.service.auth import AuthInstance
except ImportError:
    print("Warning: AuthInstance not found")

# Variabel Global
request_otp = None
login_with_otp = None

# Prioritaskan CIAM (Direct)
try:
    from app.client.ciam import request_otp, login_with_otp
    print("[INFO] Menggunakan fungsi login DIRECT (app.client.ciam)")
except ImportError:
    try:
        from app.client.login import request_otp, login_with_otp
        print("[INFO] Menggunakan fungsi login WRAPPER (app.client.login)")
    except ImportError:
        print("[CRITICAL] Fungsi Login tidak ditemukan!")

# ==========================================
# 2. HELPER: SIMPAN SESI PER USER
# ==========================================
def save_user_session(chat_id, msisdn):
    """Menyimpan nomor HP ke file khusus milik user ID Telegram tersebut."""
    try:
        file_path = os.path.join(SESSION_DIR, f"{chat_id}.txt")
        with open(file_path, "w") as f:
            f.write(str(msisdn))
        print(f"[SESSION] Disimpan: {chat_id} -> {msisdn}")
    except Exception as e:
        print(f"[ERROR] Gagal simpan sesi: {e}")

def delete_user_session(chat_id):
    """Menghapus file sesi milik user ID Telegram tersebut."""
    try:
        file_path = os.path.join(SESSION_DIR, f"{chat_id}.txt")
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
    except:
        pass
    return False

def logout_process(message, bot):
    try:
        chat_id = message.chat.id
        
        # 1. Bersihkan Memori AuthInstance
        from app.service.auth import AuthInstance
        AuthInstance.clear_session()
        
        # 2. Hapus Sesi Folder (Sessions)
        delete_user_session(chat_id)
        
        # Tombol Kembali
        markup_kembali = InlineKeyboardMarkup()
        markup_kembali.add(InlineKeyboardButton("🏠 Kembali ke Menu Utama", callback_data="run_me_cli"))
        
        # 3. Tampilkan Pesan Logout dengan Tombol
        bot.send_message(
            chat_id, 
            "✅ <b>Berhasil Logout.</b>\nAkun Anda telah dikeluarkan sepenuhnya.", 
            parse_mode='HTML', 
            reply_markup=markup_kembali
        )
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Gagal Logout: {e}")

# ==========================================
# 4. LOGIN PROCESS (DENGAN TOMBOL BATAL)
# ==========================================
def start_login_process(message, bot):
    if request_otp is None:
        return bot.send_message(message.chat.id, "❌ <b>System Error:</b> Fungsi login tidak ditemukan.")

    try:
        chat_id = message.chat.id
        try: bot.delete_message(chat_id, message.message_id)
        except: pass

        # --- [FITUR BARU: TOMBOL BATAL] ---
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("❌ Batal / Kembali", callback_data="run_me_cli"))

        msg = bot.send_message(
            chat_id,
            "🔐 <b>LOGIN XL/AXIS</b>\n\n"
            "Silakan masukkan <b>Nomor HP</b> Anda:\n"
            "Format: <code>628xxx</code>\n\n"
            "<i>(Balas pesan ini dengan nomor HP Anda)</i>",
            parse_mode='HTML',
            reply_markup=markup # Menambahkan tombol batal
        )
        # Register next step tanpa ForceReply agar tombol tetap enak dilihat
        bot.register_next_step_handler(msg, step_request_otp_handler, bot)
        
    except Exception as e:
        chat_id = message if isinstance(message, int) else message.chat.id
        bot.send_message(chat_id, f"❌ Error Start Login: {e}")

def step_request_otp_handler(message, bot):
    try:
        chat_id = message.chat.id
        msisdn = message.text.strip()
        
        # Tombol Batal untuk pesan error
        markup_batal = InlineKeyboardMarkup()
        markup_batal.add(InlineKeyboardButton("❌ Batal", callback_data="run_me_cli"))

        # Cek jika user mengetik command cancel manual
        if msisdn.lower() in ["/start", "batal", "cancel"]:
             bot.send_message(chat_id, "❌ Login Dibatalkan.", reply_markup=markup_batal)
             return

        # Auto fix format 08 -> 628
        if msisdn.startswith("08"): msisdn = "62" + msisdn[1:]
        
        # Validasi Input Angka
        if not msisdn.isdigit() or not msisdn.startswith("62"):
            msg = bot.send_message(
                chat_id, 
                "❌ <b>Format Salah!</b>\nHarus angka diawali 62 (Contoh: 62878xxx).\n\nSilakan input ulang:", 
                parse_mode='HTML',
                reply_markup=markup_batal # Ada tombol batal
            )
            return bot.register_next_step_handler(msg, step_request_otp_handler, bot)

        wait_msg = bot.send_message(chat_id, f"🔄 Meminta OTP ke {msisdn}...", parse_mode='HTML')

        # Request OTP
        try:
            req_status = request_otp(AuthInstance.api_key, msisdn)
        except TypeError:
            req_status = request_otp(msisdn)
        except Exception as e:
            bot.send_message(chat_id, f"❌ Error Request: {e}", reply_markup=markup_batal)
            return

        try: bot.delete_message(chat_id, wait_msg.message_id)
        except: pass

        # Cek Status Request
        is_success = False
        if req_status is True: is_success = True
        elif isinstance(req_status, dict) and req_status.get("status") == True: is_success = True

        if is_success:
            # Tombol Batal saat input OTP
            markup_otp = InlineKeyboardMarkup()
            markup_otp.add(InlineKeyboardButton("❌ Batal Login", callback_data="run_me_cli"))

            msg = bot.send_message(
                chat_id, 
                f"✅ <b>OTP Terkirim!</b>\nNomor: <code>{msisdn}</code>\n\nMasukkan <b>KODE OTP</b> (6 digit):", 
                parse_mode='HTML', 
                reply_markup=markup_otp
            )
            bot.register_next_step_handler(msg, step_verify_otp_handler, bot, msisdn)
        else:
            # Tombol Batal saat Gagal Request
            bot.send_message(
                chat_id, 
                "❌ <b>Gagal Request OTP.</b>\nCek nomor atau coba lagi nanti.",
                parse_mode='HTML',
                reply_markup=markup_batal
            )
            
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ System Error: {e}")

def step_verify_otp_handler(message, bot, msisdn):
    try:
        chat_id = message.chat.id
        otp_code = message.text.strip()
        
        markup_batal = InlineKeyboardMarkup()
        markup_batal.add(InlineKeyboardButton("❌ Batal", callback_data="run_me_cli"))

        # Check for cancel command
        if otp_code.lower() in ["/start", "batal", "cancel"]:
             bot.send_message(chat_id, "❌ Login Dibatalkan.", reply_markup=markup_batal)
             return

        if len(otp_code) < 4:
            msg = bot.send_message(
                chat_id, 
                "❌ Kode OTP terlalu pendek. Ulangi:", 
                reply_markup=markup_batal
            )
            return bot.register_next_step_handler(msg, step_verify_otp_handler, bot, msisdn)

        wait_msg = bot.send_message(chat_id, "⏳ Verifikasi OTP...", parse_mode='HTML')

        # --- LOGIN EXECUTION ---
        login_data = None
        try:
            # Ensure msisdn is clean
            clean_msisdn = msisdn.replace("+", "").strip()
            
            # Try login with AuthInstance first if possible
            if hasattr(AuthInstance, 'api_key') and AuthInstance.api_key:
                 login_data = login_with_otp(AuthInstance.api_key, clean_msisdn, otp_code)
            else:
                 login_data = login_with_otp(clean_msisdn, otp_code)
                 
        except TypeError:
            # Fallback for different function signatures
            try:
                login_data = login_with_otp(msisdn, otp_code)
            except Exception as e:
                print(f"[LOGIN] Error Type 2: {e}")
        except Exception as e:
            print(f"[LOGIN] Error verifying: {e}")
        
        try: bot.delete_message(chat_id, wait_msg.message_id)
        except: pass

        # --- VALIDATION ---
        is_login_success = False
        
        # Check various success responses
        if login_data is True:
            is_login_success = True
        elif isinstance(login_data, dict):
            if "refresh_token" in login_data or "data" in login_data:
                is_login_success = True
            elif "status" in login_data and login_data["status"] == True:
                is_login_success = True
                
        elif isinstance(login_data, str) and len(login_data) > 20:
            is_login_success = True

        if is_login_success:
            # SAVE SESSION IMMEDIATELY
            save_user_session(chat_id, msisdn)
            
            # Add token to AuthInstance
            try:
                # If login_data is a dict containing tokens, pass it to AuthInstance
                # This is crucial for the "User Not Found" fix - we manually inject the token
                if isinstance(login_data, dict) and "refresh_token" in login_data:
                     # Access internal Auth class method to save token without request
                     if hasattr(AuthInstance, 'add_refresh_token'):
                         AuthInstance.add_refresh_token(int(msisdn), login_data["refresh_token"])
            except Exception as e:
                print(f"[LOGIN] Failed to auto-add token: {e}")
            
            # Try to set active user
            try:
                AuthInstance.set_active_user(int(msisdn))
            except: pass
            
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🚀 Buka Menu Paket", callback_data="run_me_cli"))
            
            bot.send_message(
                chat_id, 
                f"✅ <b>LOGIN BERHASIL!</b>\n👤 User: <code>{msisdn}</code>\n\n"
                f"Sesi Anda telah disimpan aman.", 
                parse_mode='HTML', 
                reply_markup=markup
            )
        else:
            # Parse error message if available
            err_msg = "OTP Salah atau Kadaluarsa."
            if isinstance(login_data, dict) and "error" in login_data:
                err_msg = f"Server Response: {login_data['error']}"
            elif isinstance(login_data, dict) and "message" in login_data:
                err_msg = f"Server Response: {login_data['message']}"
                
            bot.send_message(
                chat_id, 
                f"❌ <b>Login Gagal.</b>\n{err_msg}\n\nSilakan coba request OTP ulang.",
                reply_markup=markup_batal
            )

    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error Verifikasi: {e}")

def handle_login_callbacks(call, bot):
    if call.data == "auth_req_otp":
        start_login_process(call.message, bot)