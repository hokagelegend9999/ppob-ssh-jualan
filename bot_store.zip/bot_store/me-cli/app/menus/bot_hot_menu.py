import requests
import json
import html
import traceback
import os
import time
import re
from random import randint
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# --- CONFIG ADMIN ---
try:
    from config import ADMIN_ID
except ImportError:
    ADMIN_ID = "1469244768"

# Import Module
try:
    from app.client.engsel import get_family, get_addons, get_package_details, get_package
    from app.service.auth import AuthInstance
    from app.service.decoy import DecoyInstance 
    from app.type_dict import PaymentItem
    from app.client.purchase.balance import settlement_balance
except ImportError as e:
    print(f"Import Error di bot_hot_menu: {e}")

# Global Cache
SEARCH_CACHE = {}

# ==========================================
# HELPER FUNCTIONS
# ==========================================
def format_quota_byte(size):
    try:
        size = float(size)
        if size >= 1024**3: return f"{size / (1024**3):.2f} GB"
        if size >= 1024**2: return f"{size / (1024**2):.2f} MB"
        if size >= 1024: return f"{size / 1024:.2f} KB"
        return f"{size} B"
    except:
        return "0 B"

def display_html(text):
    if not text: return ""
    text = html.unescape(str(text))
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
    clean_text = re.sub(r'<[^>]+>', '', text) 
    return clean_text.strip()

def get_item_prop(item, prop):
    if isinstance(item, dict): return item.get(prop)
    return getattr(item, prop, None)

# --- FUNGSI CEK SALDO (DISESUAIKAN DENGAN DATABASE.PY) ---
def check_user_balance(user_id, min_amount):
    db_path = "/root/bot_store/store_data.db"
    
    # 1. Cek SQLite (Primary)
    try:
        import sqlite3
        if os.path.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            # Gunakan kolom 'balance' sesuai database.py
            cursor.execute("SELECT balance FROM users WHERE user_id = ?", (str(user_id),))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                saldo = int(row[0])
                print(f"[DEBUG] Saldo DB User {user_id}: {saldo}")
                return saldo >= min_amount
    except Exception as e:
        print(f"[DEBUG] Gagal baca DB: {e}")

    # 2. Fallback JSON (Secondary)
    possible_paths = ["users.json", "/root/bot_store/users.json", "/root/bot_store/me-cli/users.json"]
    for p in possible_paths:
        if os.path.exists(p):
            try:
                with open(p, 'r') as f: data = json.load(f)
                str_id = str(user_id)
                if str_id in data:
                    # JSON Anda pakai 'credit', DB pakai 'balance'
                    c = data[str_id].get('credit', 0) 
                    if c >= min_amount: return True
            except: pass
            
    return False

# --- FUNGSI POTONG SALDO + CATAT RIWAYAT (FIXED) ---
def cut_user_balance(user_id, amount, description="Pembelian Paket"):
    db_path = "/root/bot_store/store_data.db"
    
    try:
        import sqlite3
        import time
        from datetime import datetime
        
        if os.path.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # 1. Ambil Saldo Awal
            cursor.execute("SELECT balance FROM users WHERE user_id = ?", (str(user_id),))
            row = cursor.fetchone()
            
            if not row:
                conn.close()
                return False
                
            saldo_awal = int(row[0])
            
            # Cek apakah saldo cukup
            if saldo_awal < amount:
                conn.close()
                return False
            
            # 2. Hitung Saldo Akhir
            saldo_akhir = saldo_awal - amount
            
            # 3. Update Saldo User
            cursor.execute("UPDATE users SET balance = ? WHERE user_id = ?", (saldo_akhir, str(user_id)))
            
            # 4. Buat Data Riwayat
            ref_id = f"HOT-{int(time.time())}" 
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # --- PERBAIKAN NAMA KOLOM DISINI ---
            # Menggunakan saldo_before dan saldo_after sesuai database.py
            cursor.execute("""
                INSERT INTO transactions 
                (user_id, ref_id, amount, status, description, sn, saldo_before, saldo_after, date) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                str(user_id),       # user_id
                ref_id,             # ref_id
                -amount,            # amount (negatif)
                "sukses",           # status
                description,        # description
                "Masa Aktif 30 Hari", # sn
                saldo_awal,         # saldo_before
                saldo_akhir,        # saldo_after
                now                 # date
            ))
            
            conn.commit()
            conn.close()
            print(f"[INFO] Sukses potong saldo & catat riwayat user {user_id}")
            return True
            
    except Exception as e:
        print(f"[ERROR] Gagal Database Transaction: {e}")
        try: conn.close()
        except: pass

    return False

# ==========================================
# CORE LOGIC
# ==========================================
def fetch_package_data(api_key, tokens, family_code, variant_code, order_num):
    try:
        detail = get_package_details(
            api_key, tokens, family_code, variant_code, order_num, 
            None, None 
        )
        return detail
    except Exception as e:
        print(f"[DEBUG] Error fetch_package_data: {e}")
        return None

# ==========================================
# MENU HANDLERS
# ==========================================
def menu_hot1_bot(chat_id, message_id, bot):
    bot.send_message(chat_id, "⚠️ Menu ini telah dinonaktifkan.")

def handle_hot1_selection(call, bot):
    pass

def menu_hot2_bot(chat_id, message_id, bot):
    try:
        # --- TAMBAHKAN PENGECEKAN LOGIN DI SINI ---
        tokens = AuthInstance.get_active_tokens()
        if not tokens or not tokens.get("access_token"):
            text_login = (
                "⚠️ <b>AKSES DITOLAK</b>\n\n"
                "Pembelian <b>MASA AKTIF XL 30 HARI</b> memerlukan akses OTP.\n"
                "Silakan login terlebih dahulu melalui menu Login OTP."
            )
            markup_login = InlineKeyboardMarkup()
            # Sesuaikan callback_data login dengan menu utama Anda (misal: 'menu_login')
            markup_login.add(InlineKeyboardButton("🔐 Login OTP Sekarang", callback_data="menu_login"))
            markup_login.add(InlineKeyboardButton("🔙 Kembali", callback_data="admin_panel"))
            
            try: 
                bot.edit_message_text(text_login, chat_id, message_id, parse_mode='HTML', reply_markup=markup_login)
            except: 
                bot.send_message(chat_id, text_login, parse_mode='HTML', reply_markup=markup_login)
            return
        # --- AKHIR PENGECEKAN ---

        markup = InlineKeyboardMarkup(row_width=1)
        markup.add(InlineKeyboardButton("⚡ XL Masa Aktif / Akrab", callback_data="hot2_direct_family"))
        markup.add(InlineKeyboardButton("👉 Input Family Code Lain", callback_data="hot2_input_family"))
        markup.add(InlineKeyboardButton("🔙 Kembali ke Admin Panel", callback_data="admin_panel"))
        
        text = "✅ <b>MASA AKTIF 30 HARI XL</b>\n\nSilakan pilih menu di bawah:"
        
        try: bot.edit_message_text(text, chat_id, message_id, parse_mode='HTML', reply_markup=markup)
        except: bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        bot.send_message(chat_id, f"❌ Gagal memuat menu: {e}")

# ==========================================
# HANDLER BARU: DIRECT FAMILY SEARCH
# ==========================================
def handle_direct_family_search(call, bot):
    # --- TAMBAHKAN VALIDASI DI SINI ---
    tokens = AuthInstance.get_active_tokens()
    if not tokens or not tokens.get("access_token"):
        bot.answer_callback_query(call.id, "⚠️ Anda harus LOGIN OTP terlebih dahulu!", show_alert=True)
        # Opsional: Arahkan ke menu login
        return 
    # --- END VALIDASI ---

    HARDCODED_FAMILY_CODE = "f4fd69c7-12a4-4047-a1f2-f4072a7c543e"
    execute_family_search(call.message, bot, HARDCODED_FAMILY_CODE)

# ==========================================
# SHARED SEARCH LOGIC
# ==========================================
def execute_family_search(message, bot, family_code):
    try:
        api_key = AuthInstance.api_key or os.getenv("API_KEY") or "fa37fd88-f4bb-422d-b857-7c18280f9086"
        tokens = AuthInstance.get_active_tokens()
        if not tokens:
            bot.send_message(message.chat.id, "❌ Anda harus login OTP untuk mencari paket ini.")
            return
        markup_back = InlineKeyboardMarkup()
        markup_back.add(InlineKeyboardButton("🔙 Kembali", callback_data="menu_hot2"))

        try:
            msg_wait = bot.edit_message_text(f"🔄 Menyiapkan paket...", message.chat.id, message.message_id, parse_mode='HTML')
        except:
            msg_wait = bot.send_message(message.chat.id, f"🔄 Menyiapkan paket...", parse_mode='HTML')
        
        fam_data = get_family(api_key, tokens, family_code)
        
        if not fam_data:
            bot.edit_message_text("🔄 Token expired. Refreshing...", message.chat.id, msg_wait.message_id)
            if AuthInstance.renew_active_user_token():
                tokens = AuthInstance.get_active_tokens()
                fam_data = get_family(api_key, tokens, family_code)
        
        if not fam_data or "package_variants" not in fam_data:
            bot.edit_message_text(
                f"❌ <b>Paket tidak ditemukan!</b>", 
                message.chat.id, 
                msg_wait.message_id,
                parse_mode='HTML',
                reply_markup=markup_back
            )
            return

        chat_id = message.chat.id
        SEARCH_CACHE[chat_id] = {
            "family_code": family_code,
            "data": fam_data,
            "selected_variant": None
        }

        markup = InlineKeyboardMarkup(row_width=1)
        variants = fam_data.get("package_variants", [])
        
        target_code = "f4fd69c7-12a4-4047-a1f2-f4072a7c543e"
        count = 1
        found_target = False

        for v_idx, variant in enumerate(variants):
            options = variant.get("package_options", [])
            for o_idx, option in enumerate(options):
                name = option.get("name", "Paket")
                price = option.get("price", 0)
                
                if family_code == target_code:
                    if count == 19:
                        markup.add(InlineKeyboardButton(f"🚀 BELI SEKARANG", callback_data=f"fam_sel|{v_idx}|{o_idx}"))
                        found_target = True
                else:
                    markup.add(InlineKeyboardButton(f"{count}. {name} - Rp {price}", callback_data=f"fam_sel|{v_idx}|{o_idx}"))
                
                count += 1

        markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="menu_hot2"))
        
        msg_text = f"✅ Paket Siap Dibeli."
        if family_code == target_code and not found_target:
            msg_text = "❌ <b>Gagal:</b> Paket target (No. 19) tidak ditemukan dalam list."

        bot.edit_message_text(
            msg_text, 
            message.chat.id, 
            msg_wait.message_id, 
            parse_mode='HTML', 
            reply_markup=markup
        )

    except Exception as e:
        traceback.print_exc()
        bot.send_message(message.chat.id, f"❌ System Error: {e}")

# ==========================================
# FLOW INPUT FAMILY CODE
# ==========================================
def prompt_family_code_input(call, bot):
    try:
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Batal", callback_data="menu_hot2"))
        msg = bot.send_message(call.message.chat.id, "📩 <b>Silakan kirimkan Family Code:</b>", parse_mode='HTML', reply_markup=markup)
        bot.register_next_step_handler(msg, process_family_code_input, bot)
    except Exception as e:
        bot.send_message(call.message.chat.id, f"Error: {e}")

def process_family_code_input(message, bot):
    try:
        raw_text = message.text or ""
        family_code = re.sub(r'\s+', '', raw_text)
        if len(family_code) < 10:
            bot.send_message(message.chat.id, "❌ Format Family Code tidak valid.")
            return
        execute_family_search(message, bot, family_code)
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error: {e}")

# ==========================================
# DETAIL & PAYMENT PREP
# ==========================================
def handle_family_list_selection(call, bot):
    try:
        chat_id = call.message.chat.id
        if chat_id not in SEARCH_CACHE:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔙 Kembali Menu Utama", callback_data="menu_hot2"))
            bot.send_message(chat_id, "❌ Sesi pencarian kadaluarsa.", reply_markup=markup)
            return

        data = call.data.split("|")
        v_idx = int(data[1])
        o_idx = int(data[2])
        
        cached = SEARCH_CACHE[chat_id]
        fam_data = cached["data"]
        
        target_variant = fam_data["package_variants"][v_idx]
        target_option = target_variant["package_options"][o_idx]
        
        SEARCH_CACHE[chat_id]["selected_variant"] = {
            "family_code": cached["family_code"],
            "variant_code": target_variant["package_variant_code"],
            "order": target_option["order"],
            "name": target_option["name"],
            "price": target_option["price"]
        }

        api_key = AuthInstance.api_key or os.getenv("API_KEY")
        tokens = AuthInstance.get_active_tokens()
        bot.answer_callback_query(call.id, "🔄 Mengambil detail lengkap...")

        full_detail = fetch_package_data(api_key, tokens, cached["family_code"], target_variant["package_variant_code"], target_option["order"])
        
        if not full_detail:
             if AuthInstance.renew_active_user_token():
                tokens = AuthInstance.get_active_tokens()
                full_detail = fetch_package_data(api_key, tokens, cached["family_code"], target_variant["package_variant_code"], target_option["order"])

        if not full_detail:
            bot.send_message(chat_id, "❌ Gagal mengambil detail paket.")
            return

        opt = full_detail.get("package_option") or {}
        
        msg = f"📦 <b>MASA AKTIF XL 30 HARI</b>\n"
        msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        msg += f"💰 <b>Harga:</b> Rp 5000 (potong saldo)\n"
        msg += f"⏳ <b>Masa Aktif:</b> 30 Day\n"
        msg += f"💎 <b>Poin:</b> {opt.get('point')}\n"
        msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        msg += f"🎁 <b>BENEFIT PAKET:</b>\n"
        msg += f"- Shared Quota: 0 GB\n"
        msg += f"- Personal Local Quota: 0 GB\n"
        msg += f"- Call: 0\n"
        msg += f"\n📝 <b>DESKRIPSI:</b>\n"
        msg += "DENGAN MEMBELI PAKET XL MASA AKTIF TERSEBUT MAKA SALDO KAMU AKAN DI POTONG SEBESAR Rp.5000\n"

        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🚀 BELI SEKARANG (AUTO DECOY)", callback_data="pay_fam|BALANCE_DECOY"))
        markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="menu_hot2"))

        try: bot.edit_message_text(msg, chat_id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except: bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=markup)

    except Exception as e:
        traceback.print_exc()
        bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def execute_payment_logic(bot, call, payment_items, use_decoy, overwrite_amount):
    try:
        api_key = AuthInstance.api_key or os.getenv("API_KEY")
        tokens = AuthInstance.get_active_tokens()
        
        markup_back = InlineKeyboardMarkup()
        markup_back.add(InlineKeyboardButton("🔙 Kembali Menu Utama", callback_data="menu_hot2"))
        
        max_retries = 3
        retry_count = 0
        
        bot.answer_callback_query(call.id, "🚀 Memproses...")
        status_msg = bot.send_message(call.message.chat.id, f"⏳ <b>Memulai Transaksi...</b>\nMohon tunggu...", parse_mode='HTML')

        while retry_count < max_retries:
            # 1. LOGIKA FIX NOMINAL (MENCEGAH MALFORMED)
            # Jika server minta 0, kita paksa kirim 1 atau nominal decoy terkecil (misal 78000)
            # agar body tidak malformed.
            if overwrite_amount is not None and overwrite_amount <= 0:
                # [FIX] Jika terdeteksi 0, coba kirim nominal minimal (misal 78000 atau biarkan None)
                final_exec_amount = 78000 if use_decoy else None 
            else:
                final_exec_amount = overwrite_amount

            print(f"[DEBUG] Retry {retry_count+1}: ExecAmount={final_exec_amount}, Decoy={use_decoy}")

            res = settlement_balance(
                api_key, tokens, payment_items, "BUY_PACKAGE", 
                False, final_exec_amount, 0, -1
            )
            
            if res is None:
                bot.edit_message_text("❌ Error: API Null.", call.message.chat.id, status_msg.message_id, reply_markup=markup_back)
                break

            # --- CEK SUKSES ---
            if isinstance(res, dict) and (res.get("status") == "SUCCESS" or res.get("code") == "00"):
                user_id = str(call.from_user.id)
                if user_id != str(ADMIN_ID):
                    cut_user_balance(call.from_user.id, 5000, "Beli Masa Aktif XL 30 Hari")
                
                # Ambil total bayar asli dari response server
                paid_total = res.get("data", {}).get("total_amount", final_exec_amount or 0)
                
                msg_succ = (
                    "✨ <b>TRANSAKSI BERHASIL</b> ✨\n"
                    "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                    "📦 <b>Paket:</b> XL Masa Aktif 30 Hari\n"
                    f"💸 <b>Total Bayar:</b> Rp {paid_total:,}\n"
                    "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
                    "🎉 <b>SELAMAT!</b> Masa aktif berhasil diperpanjang."
                )
                bot.edit_message_text(msg_succ, call.message.chat.id, status_msg.message_id, parse_mode='HTML', reply_markup=markup_back)
                break
            
            # --- LOGIKA PENYESUAIAN HARGA (V2) ---
            err_msg = str(res.get("message", ""))
            if "Bizz-err.Amount.Total" in err_msg:
                try:
                    # Ambil angka dari error: "Bizz-err.Amount.Total = 78000"
                    match = re.search(r"Total\s*=\s*(\d+)", err_msg)
                    if match:
                        valid_amt = int(match.group(1))
                        
                        # [PENTING] Jika server minta 0, kita paksa nominal decoy yang valid (misal 78000)
                        if valid_amt == 0:
                            valid_amt = 78000 
                            
                        bot.edit_message_text(f"⚠️ Menyesuaikan Harga ke Rp {valid_amt}...", call.message.chat.id, status_msg.message_id)
                        
                        overwrite_amount = valid_amt
                        retry_count += 1
                        time.sleep(1)
                        continue 
                except: pass

            # Error Decoy
            if ("InvalidProduct" in err_msg or "MAIN_PACKAGE_NOT_SHOW" in err_msg) and use_decoy:
                bot.edit_message_text("⚠️ Decoy Konflik. Mengulang...", call.message.chat.id, status_msg.message_id)
                if len(payment_items) > 1: payment_items.pop()
                use_decoy = False
                retry_count += 1
                time.sleep(1)
                continue
            
            # Gagal Total
            bot.edit_message_text(f"❌ <b>Gagal:</b> {err_msg}", call.message.chat.id, status_msg.message_id, parse_mode='HTML', reply_markup=markup_back)
            break
            
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ System Error: {e}")

def handle_family_payment(call, bot):
    try:
        user_id = str(call.from_user.id)
        chat_id = call.message.chat.id
        
        # 1. Validasi Saldo
        if user_id != str(ADMIN_ID):
            if not check_user_balance(call.from_user.id, 5000):
                return bot.answer_callback_query(call.id, "❌ Saldo tidak cukup!", show_alert=True)
        
        if chat_id not in SEARCH_CACHE or not SEARCH_CACHE[chat_id].get("selected_variant"):
            return bot.send_message(chat_id, "❌ Sesi habis. Silakan cari ulang.")

        sel = SEARCH_CACHE[chat_id]["selected_variant"]
        api_key = AuthInstance.api_key
        tokens = AuthInstance.get_active_tokens()
        
        # 2. Ambil Detail Paket Utama
        detail = fetch_package_data(api_key, tokens, sel["family_code"], sel["variant_code"], sel["order"])
        if not detail: return
        
        opt = detail.get("package_option") or {}
        payment_items = [PaymentItem(
            item_code=str(opt.get("package_option_code", "")),
            product_type="", 
            item_price=sel["price"],
            item_name=str(sel["name"]),
            tax=0,
            token_confirmation=str(detail.get("token_confirmation") or "")
        )]

        # 3. [TEKNIK FIX] - FORCE DECOY XL PASS (Sesuai Log Sukses)
        method = call.data.split("|")[1] 
        if "DECOY" in method:
            try:
                # Log sukses Anda menunjukkan penggunaan 'XL PASS' (enterprise=True)
                # Kita tembak langsung option code XL PASS yang umum digunakan sebagai decoy
                decoy_code = "XL_PASS_1D" # Atau kode yang sesuai dengan XL PASS 1 Day
                
                # Paksa ambil data decoy XL PASS
                from app.client.engsel import get_package
                decoy_detail = get_package(api_key, tokens, decoy_code)
                
                if decoy_detail:
                    d_opt = decoy_detail.get("package_option") or {}
                    payment_items.append(PaymentItem(
                        item_code=str(d_opt.get("package_option_code", "")),
                        product_type="",
                        item_price=d_opt.get("price", 0),
                        item_name="XL PASS DECOY",
                        tax=0,
                        token_confirmation=str(decoy_detail.get("token_confirmation") or "")
                    ))
                    print("[DEBUG] XL PASS Decoy Added successfully.")
            except Exception as e:
                print(f"[DEBUG] Failed to add XL PASS decoy: {e}")

        # 4. Hitung Total & Eksekusi
        overwrite_amount = sum([get_item_prop(i, 'item_price') for i in payment_items])
        execute_payment_logic(bot, call, payment_items, True, overwrite_amount)

    except Exception as e:
        bot.send_message(chat_id, f"Error: {e}")

# ==========================================
# HANDLERS DUMMY
# ==========================================
def handle_hot2_selection(call, bot):
    bot.answer_callback_query(call.id, "Fitur ini telah dipindahkan.")

def handle_hot_payment(call, bot):
    bot.answer_callback_query(call.id, "Fitur ini telah dipindahkan.")