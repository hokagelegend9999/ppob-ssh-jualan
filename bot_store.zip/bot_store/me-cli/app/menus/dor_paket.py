import os
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# Folder penyimpanan sesi per user
SESSION_DIR = "/root/bot_store/sessions"

def menu_dor_non_legal(user_data):
    user_name = user_data.first_name
    user_id = str(user_data.id) 
    
    # Path file sesi user
    user_file_path = os.path.join(SESSION_DIR, f"{user_id}.txt")
    
    status_text = "❌ <b>Belum Login</b>"
    nomor_hp_info = "" 

    try:
        # Cek apakah file sesi ada
        if os.path.exists(user_file_path):
            with open(user_file_path, 'r') as f:
                number = f.read().strip()
            
            if number:
                status_text = "✅ <b>Sudah Login</b>"
                nomor_hp_info = f"\n📱 <b>Nomor:</b> <code>{number}</code>"
            else:
                nomor_hp_info = "\n📱 <b>Nomor:</b> <code>-</code>"
        
    except Exception as e:
        print(f"Error reading session: {e}")

    # Gabungkan Info Tampilan
    status_info = f"👤 User: {user_name}\n{status_text}{nomor_hp_info}"

    markup = InlineKeyboardMarkup(row_width=1)
    
    # --- [MENU UTAMA] ---
    markup.add(InlineKeyboardButton("✅ MASA AKTIF 30 HARI XL", callback_data="hot2_direct_family"))
    
    # --- [TOMBOL BARU: CEK PAKET SAYA] ---
    markup.add(InlineKeyboardButton("📦 Cek Paket Saya", callback_data="check_my_pkg"))
    
    # Tombol Input Family Code
    markup.add(InlineKeyboardButton("👉 Input Family Code Lain", callback_data="hot2_input_family"))
    
    # --- [LOGIN / LOGOUT] ---
    markup.row(
        InlineKeyboardButton("🔐 Login Akun", callback_data="auth_req_otp"),
        InlineKeyboardButton("🚪 Logout", callback_data="auth_logout")
    )
    
    # --- [TOMBOL KEMBALI] ---
    markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="admin_panel"))

    return markup, status_info