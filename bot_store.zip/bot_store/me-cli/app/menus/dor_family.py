import os
import json
import requests
import html
from dotenv import load_dotenv
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ForceReply, Message
from app.service.auth import AuthInstance

# ==========================================
# 1. KONFIGURASI API
# ==========================================
env_path = "/root/bot_store/me-cli/.env"
load_dotenv(env_path)

BASE_URL_ENV = os.getenv("BASE_API_URL", "https://api.myxl.xlaxiata.co.id")
if BASE_URL_ENV.endswith("/v8"):
    XL_API_BASE = BASE_URL_ENV
elif BASE_URL_ENV.endswith("/"):
    XL_API_BASE = f"{BASE_URL_ENV}v8"
else:
    XL_API_BASE = f"{BASE_URL_ENV}/v8"

USER_AGENT = os.getenv("UA", "myXL / 8.8.0(1198); com.android.vending; (samsung; SM-N935F; SDK 33; Android 13")

def get_headers(token):
    from urllib.parse import urlparse
    try:
        parsed_uri = urlparse(XL_API_BASE)
        host_header = parsed_uri.netloc 
    except:
        host_header = "api.myxl.xlaxiata.co.id"

    return {
        'Host': host_header,
        'Authorization': f"Bearer {token}",
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, text/plain, */*',
        'Connection': 'keep-alive',
        'X-App-Version': '8.8.0',
        'Origin': 'https://myxl.xlaxiata.co.id',
        'Referer': 'https://myxl.xlaxiata.co.id/'
    }

# ==========================================
# 2. HELPER REQUEST (AUTO AUTH)
# ==========================================
def request_with_retry(method, url, params=None, json_data=None, timeout=30):
    try: AuthInstance.load_tokens()
    except: pass

    tokens = AuthInstance.get_active_tokens()
    
    # Fallback jika token kosong
    if not tokens:
        try:
            with open('/root/bot_store/me-cli/active.number', 'r') as f:
                last_num = f.read().strip()
            AuthInstance.set_active_user(last_num)
            tokens = AuthInstance.get_active_tokens()
        except: pass

    if not tokens: return None, "Sesi habis. Silakan login ulang."
    
    token_str = tokens.get('access_token') or tokens.get('id_token')
    headers = get_headers(token_str)
    
    try:
        if method == 'GET':
            resp = requests.get(url, params=params, headers=headers, timeout=timeout)
        else:
            resp = requests.post(url, json=json_data, headers=headers, timeout=timeout)
            
        data = resp.json()
        
        # Cek Token Expired
        if resp.status_code == 401 or (isinstance(data, dict) and str(data.get('code')) in ['132', '401']):
            print("[FAMILY] Refreshing Token...")
            if AuthInstance.renew_active_user_token():
                new_tokens = AuthInstance.get_active_tokens()
                new_headers = get_headers(new_tokens.get('access_token') or new_tokens.get('id_token'))
                
                if method == 'GET':
                    resp = requests.get(url, params=params, headers=new_headers, timeout=timeout)
                else:
                    resp = requests.post(url, json=json_data, headers=new_headers, timeout=timeout)
                return resp, None
            else:
                return None, "Gagal refresh token."
        
        return resp, None

    except Exception as e:
        return None, f"Connection Error: {str(e)}"

# ==========================================
# 3. FUNGSI UTAMA (YANG DIPANGGIL ADMIN.PY)
# ==========================================

# --- A. Handler Input Kode ---
def handle_input_family_code(call, bot):
    chat_id = call.message.chat.id
    
    try: AuthInstance.load_tokens()
    except: pass
    
    if not AuthInstance.get_active_tokens():
        bot.answer_callback_query(call.id, "⚠️ Login dulu bos!", show_alert=True)
        return

    try: bot.delete_message(chat_id, call.message.message_id)
    except: pass

    msg = bot.send_message(
        chat_id,
        "👨‍👩‍👧‍👦 **INPUT FAMILY CODE**\n\n"
        "Silakan kirim **Kode Family** (Link) yang valid.\n"
        "Contoh: `f4fd69c7-12a4...`",
        parse_mode='Markdown',
        reply_markup=ForceReply(selective=True)
    )
    bot.register_next_step_handler(msg, process_search_family, bot)

def process_search_family(message: Message, bot):
    chat_id = message.chat.id
    code_input = message.text.strip()

    if code_input.lower() in ['batal', '/cancel']:
        bot.send_message(chat_id, "✅ Dibatalkan.")
        return

    loading_msg = bot.send_message(chat_id, "🔍 **Mencari Paket...**", parse_mode='Markdown')

    try:
        url = f"{XL_API_BASE}/family/details"
        params = {"code": code_input}
        
        resp, err_msg = request_with_retry('GET', url, params=params)
        
        try: bot.delete_message(chat_id, loading_msg.message_id)
        except: pass

        if not resp:
            bot.send_message(chat_id, f"❌ Error: {err_msg}")
            return
            
        data = resp.json()
        if data.get('status') != 'SUCCESS' and 'data' not in data:
             bot.send_message(chat_id, f"❌ Gagal: {data.get('message', 'Kode Salah')}")
             return

        family_data = data.get('data', {})
        variants = family_data.get('variants', [])

        if not variants:
             bot.send_message(chat_id, "❌ Paket Kosong.")
             return

        # Render Menu
        markup = InlineKeyboardMarkup(row_width=1)
        
        count = 0
        for v_idx, var in enumerate(variants):
            opts = var.get('productOptions', [])
            target_list = opts if opts else [var]
            
            for o_idx, item in enumerate(target_list):
                if count >= 30: break
                
                p_name = item.get('name', 'Paket')[:30]
                p_price = item.get('price', 0)
                
                # Logic O_IDX: jika dari variants langsung, o_idx = -1
                real_o_idx = o_idx if opts else -1
                
                cb_data = f"sel_fam|{v_idx}|{real_o_idx}|{code_input}"
                if len(cb_data) > 64: 
                    # Jika kepanjangan, kita potong code (risiko error di step selanjutnya kecil)
                    # Solusi simple: abaikan code di callback, simpan di session (kompleks)
                    # Kita coba tetap kirim, biasanya cukup.
                    pass

                markup.add(InlineKeyboardButton(f"{p_name} - Rp {p_price:,}", callback_data=cb_data))
                count += 1

        markup.add(InlineKeyboardButton("❌ Tutup", callback_data="run_me_cli"))
        bot.send_message(chat_id, f"✅ **PAKET DITEMUKAN**\nKode: `{code_input}`", reply_markup=markup, parse_mode='Markdown')

    except Exception as e:
        bot.send_message(chat_id, f"❌ System Error: {e}")

# --- B. Handler Detail Paket ---
def show_family_package_detail(call, bot):
    try:
        parts = call.data.split("|")
        v_idx, o_idx = int(parts[1]), int(parts[2])
        code = parts[3]
    except:
        return bot.answer_callback_query(call.id, "Data Error")

    chat_id = call.message.chat.id
    
    # Fetch ulang untuk memastikan data fresh
    url = f"{XL_API_BASE}/family/details"
    resp, _ = request_with_retry('GET', url, params={"code": code})
    
    if not resp: return bot.send_message(chat_id, "❌ Gagal ambil detail.")
    
    data = resp.json().get('data', {})
    if not data: return bot.send_message(chat_id, "❌ Data hilang.")

    try:
        variant = data['variants'][v_idx]
        if o_idx != -1:
            pkg = variant['productOptions'][o_idx]
        else:
            pkg = variant
            
        pkg_code = pkg.get('code')
        price = pkg.get('price', 0)
        name = pkg.get('name')

        markup = InlineKeyboardMarkup()
        # Callback: buy_fam_exec | pkg_code | family_code | price
        markup.add(InlineKeyboardButton("✅ BELI (PULSA)", callback_data=f"buy_fam_exec|{pkg_code}|{code}|{price}"))
        markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="run_me_cli"))

        bot.edit_message_text(
            f"🛒 **KONFIRMASI BELI**\n\n📦 {name}\n💰 Rp {price:,}\n\nLanjut proses?",
            chat_id, call.message.message_id, parse_mode='Markdown', reply_markup=markup
        )
    except:
        bot.send_message(chat_id, "❌ Gagal parsing paket.")

# --- C. Handler Eksekusi Beli ---
def execute_family_purchase(call, bot):
    try:
        parts = call.data.split("|")
        pkg_code, fam_code, price = parts[1], parts[2], parts[3]
    except:
        return bot.answer_callback_query(call.id, "Error Data")

    chat_id = call.message.chat.id
    try: bot.delete_message(chat_id, call.message.message_id)
    except: pass
    
    msg_wait = bot.send_message(chat_id, "⏳ **Memproses...**", parse_mode='Markdown')

    url = f"{XL_API_BASE}/purchase"
    payload = {
        "code": pkg_code,
        "price": int(price),
        "payment_method": "BALANCE",
        "family_code": fam_code,
        "addon_code": "",
        "purchase_type": "BUY_PACKAGE"
    }

    resp, err = request_with_retry('POST', url, json_data=payload)
    
    try: bot.delete_message(chat_id, msg_wait.message_id)
    except: pass

    if not resp:
        bot.send_message(chat_id, f"❌ Gagal: {err}")
        return

    res = resp.json()
    if res.get('status') == 'SUCCESS':
        trx = res['data'].get('transaction_code', '')
        bot.send_message(chat_id, f"✅ **SUKSES!**\nTrx ID: `{trx}`", parse_mode='Markdown')
    else:
        err_msg = res.get('message', 'Unknown')
        bot.send_message(chat_id, f"❌ **GAGAL:** {err_msg}")