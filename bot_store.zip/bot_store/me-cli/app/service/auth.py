from typing import Optional
import os
import json
import time
from app.client.ciam import get_new_token
from app.client.engsel import get_profile
from app.util import ensure_api_key

class Auth:
    _instance_ = None
    _initialized_ = False

    def __new__(cls, *args, **kwargs):
        if not cls._instance_:
            cls._instance_ = super().__new__(cls)
        return cls._instance_
    
    def __init__(self):
        if not self._initialized_:
            self.api_key = ensure_api_key()
            # Deteksi path absolut agar tidak salah baca lokasi file
            self.base_dir = "/root/bot_store/me-cli"
            self.DB_FILE = os.path.join(self.base_dir, "refresh-tokens.json")
            self.ACTIVE_FILE = os.path.join(self.base_dir, "active.number")
            
            if not os.path.exists(self.DB_FILE):
                os.makedirs(self.base_dir, exist_ok=True)
                with open(self.DB_FILE, "w") as f: json.dump([], f)

            self.refresh_tokens = []
            self.active_user = None
            self.last_refresh_time = int(time.time())
            self.load_tokens()
            self._initialized_ = True
            
    def load_tokens(self):
        """Reload paksa dari disk"""
        try:
            if os.path.exists(self.DB_FILE):
                with open(self.DB_FILE, "r") as f:
                    data = json.load(f)
                    self.refresh_tokens = data if isinstance(data, list) else []
                    return True
        except Exception as e:
            print(f"[AUTH] Error load: {e}")
        return False

    def set_active_user(self, number: int):
        # Selalu reload setiap kali ganti user
        self.load_tokens()
        
        # Cari user (konversi ke string dan int untuk kecocokan 100%)
        rt_entry = next((rt for rt in self.refresh_tokens if str(rt["number"]) == str(number)), None)
        
        if not rt_entry:
            print(f"[AUTH] No data found for number: {number}")
            return False

        # Gunakan token yang ada
        tokens = {
            "refresh_token": rt_entry["refresh_token"],
            "access_token": rt_entry.get("access_token", ""),
            "id_token": rt_entry.get("id_token", "")
        }

        self.active_user = {
            "number": int(number),
            "subscriber_id": rt_entry.get("subscriber_id", ""),
            "tokens": tokens
        }
        
        self.last_refresh_time = int(time.time())
        print(f"[AUTH] Active user set to: {number}")
        return True

    def get_active_tokens(self) -> Optional[dict]:
        if not self.active_user:
            return None
        return self.active_user["tokens"]

    def renew_active_user_token(self):
        if not self.active_user: return False
        print("[AUTH] Auto-renewing...")
        tokens = get_new_token(self.api_key, self.active_user["tokens"]["refresh_token"], self.active_user["subscriber_id"])
        if tokens:
            self.active_user["tokens"].update(tokens)
            # Update file
            self.load_tokens()
            for rt in self.refresh_tokens:
                if str(rt["number"]) == str(self.active_user["number"]):
                    rt.update(tokens)
                    break
            with open(self.DB_FILE, "w") as f: json.dump(self.refresh_tokens, f, indent=4)
            return True
        return False

    # [FIX] FUNGSI INI HARUS MASUK KE DALAM CLASS (INDENTASI 4 SPASI)
    def clear_session(self):
        """DIPANGGIL SAAT LOGOUT: Benar-benar membersihkan sesi aktif"""
        self.active_user = None
        self.last_refresh_time = None
        
        # Hapus file active.number jika ada agar tidak auto-login saat restart
        if hasattr(self, 'ACTIVE_FILE') and os.path.exists(self.ACTIVE_FILE):
            try:
                os.remove(self.ACTIVE_FILE)
            except:
                pass
        print("[AUTH] Session cleared (Logout).")

# Bagian ini berada di luar class
AuthInstance = Auth()