import time
import uuid
import json
import requests
from datetime import datetime, timezone
from app.client.engsel import send_api_request, intercept_page, BASE_API_URL, UA
from app.client.encrypt import API_KEY, decrypt_xdata, encryptsign_xdata, java_like_timestamp, get_x_signature_payment

# --- FUNGSI 1: CREATE TRANSACTION ID (Logika Sama Persis CLI) ---
def settlement_qris(api_key, tokens, items, payment_for, amount_int):
    # 1. Intercept (Wajib di CLI)
    intercept_page(api_key, tokens, items[0]["item_code"], False)

    # 2. Prepare Targets
    token_confirmation = items[0]["token_confirmation"]
    payment_targets = ";".join([i["item_code"] for i in items])

    # 3. Get Payment Methods
    pm_path = "payments/api/v8/payment-methods-option"
    pm_payload = {
        "payment_type": "PURCHASE",
        "is_enterprise": False,
        "payment_target": items[0]["item_code"],
        "lang": "en",
        "is_referral": False,
        "token_confirmation": token_confirmation
    }
    
    pm_res = send_api_request(api_key, pm_path, pm_payload, tokens["id_token"], "POST")
    if pm_res["status"] != "SUCCESS": 
        print(f"[QRIS] Gagal Payment Method: {pm_res}")
        return None

    token_payment = pm_res["data"]["token_payment"]
    ts_to_sign = pm_res["data"]["timestamp"]

    # 4. Settlement Request (Endpoint Khusus QRIS)
    path = "payments/api/v8/settlement-multipayment/qris"
    
    payload = {
        "akrab": {"akrab_members": [], "akrab_parent_alias": "", "members": []},
        "can_trigger_rating": False,
        "total_discount": 0,
        "coupon": "",
        "payment_for": payment_for,
        "is_enterprise": False,
        "autobuy": {"is_using_autobuy": False},
        "access_token": tokens["access_token"],
        "is_myxl_wallet": False,
        "additional_data": {
            "original_price": items[0]["item_price"],
            "discount_promo": 0
        },
        "total_amount": amount_int,
        "total_fee": 0,
        "is_use_point": False,
        "lang": "en",
        "items": items,
        "verification_token": token_payment,
        "payment_method": "QRIS",
        "timestamp": int(time.time())
    }

    encrypted = encryptsign_xdata(api_key, "POST", path, tokens["id_token"], payload)
    
    # Signature
    xtime = int(encrypted["encrypted_body"]["xtime"])
    sig_time = str(xtime // 1000)
    x_req_at = java_like_timestamp(datetime.fromtimestamp(int(sig_time), tz=timezone.utc))
    
    x_sig = get_x_signature_payment(
        api_key, tokens["access_token"], ts_to_sign, 
        payment_targets, token_payment, "QRIS", payment_for, path
    )

    headers = {
        "host": BASE_API_URL.replace("https://", ""),
        "content-type": "application/json; charset=utf-8",
        "user-agent": UA,
        "x-api-key": API_KEY,
        "authorization": f"Bearer {tokens['id_token']}",
        "x-hv": "v3",
        "x-signature-time": sig_time,
        "x-signature": x_sig,
        "x-request-id": str(uuid.uuid4()),
        "x-request-at": x_req_at,
        "x-version-app": "8.9.0",
    }

    url = f"{BASE_API_URL}/{path}"
    resp = requests.post(url, headers=headers, data=json.dumps(encrypted["encrypted_body"]), timeout=30)
    
    try:
        dec = decrypt_xdata(api_key, json.loads(resp.text))
        if dec["status"] == "SUCCESS":
            return dec["data"]["transaction_code"] # Sukses dapat ID
        else:
            print(f"[QRIS] Gagal Settlement: {dec}")
            return None
    except Exception as e: 
        print(f"[QRIS] Exception: {e}")
        return None

# --- FUNGSI 2: GET QR STRING ---
def get_qris_code(api_key, tokens, transaction_id):
    path = "payments/api/v8/pending-detail"
    payload = {
        "transaction_id": transaction_id,
        "is_enterprise": False,
        "lang": "en",
        "status": ""
    }
    res = send_api_request(api_key, path, payload, tokens["id_token"], "POST")
    
    if res["status"] == "SUCCESS":
        return res["data"]["qr_code"]
    return None