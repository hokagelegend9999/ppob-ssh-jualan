import os
import json
import uuid
import requests
import sys
from datetime import datetime, timezone, timedelta
from typing import Optional

# --- 1. LOAD ENV SECARA PAKSA (Agar API KEY terbaca) ---
env_path = "/root/bot_store/me-cli/.env"
if os.path.exists(env_path):
    try:
        with open(env_path, 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    k, v = line.strip().split('=', 1)
                    os.environ[k.strip()] = v.strip().replace('"', '').replace("'", "")
    except: pass

# --- 2. KONFIGURASI ---
BASE_CIAM_URL = os.environ.get("BASE_CIAM_URL", "https://gede.ciam.xlaxiata.co.id")
BASIC_AUTH = os.environ.get("BASIC_AUTH")
UA = os.environ.get("UA", "myXL/5.8.5 (Android; 13; Samsung SM-G991B; Build/TP1A.220624.014)")

# API KEY CADANGAN (Jaga-jaga jika di env kosong)
FALLBACK_API_KEY = "fa37fd88-f4bb-422d-b857-7c18280f9086"

# Import Module Enkripsi
try:
    from app.client.encrypt import (
        ax_api_signature, load_ax_fp, ax_device_id, java_like_timestamp, ts_gmt7_without_colon
    )
except ImportError:
    sys.path.append(os.getcwd())
    from app.client.encrypt import (
        ax_api_signature, load_ax_fp, ax_device_id, java_like_timestamp, ts_gmt7_without_colon
    )

# Load Fingerprint
try:
    AX_FP = load_ax_fp()
    AX_DEVICE_ID = ax_device_id()
except:
    AX_FP = ""
    AX_DEVICE_ID = ""

# --- 3. FUNGSI ---

def validate_contact(contact: str) -> str:
    contact = str(contact).strip()
    if contact.startswith("08"): contact = "62" + contact[1:]
    elif contact.startswith("8"): contact = "62" + contact
    return contact

def request_otp(contact: str):
    contact = validate_contact(contact)
    url = f"{BASE_CIAM_URL}/realms/xl-ciam/auth/otp"
    
    querystring = {"contact": contact, "contactType": "SMS", "alternateContact": "false"}
    
    now = datetime.now(timezone(timedelta(hours=7)))
    headers = {
        "Accept-Encoding": "gzip, deflate, br", 
        "Authorization": f"Basic {BASIC_AUTH}",
        "Ax-Device-Id": AX_DEVICE_ID, 
        "Ax-Fingerprint": AX_FP, 
        "Ax-Request-At": java_like_timestamp(now),
        "Ax-Request-Device": "samsung", 
        "Ax-Request-Device-Model": "SM-N935F", 
        "Ax-Request-Id": str(uuid.uuid4()),
        "Ax-Substype": "PREPAID", 
        "Content-Type": "application/json", 
        "Host": BASE_CIAM_URL.replace("https://", ""),
        "User-Agent": UA,
    }
    
    try:
        print(f"[LOGIN] Requesting OTP for {contact}...")
        response = requests.get(url, headers=headers, params=querystring, timeout=30)
        
        if response.status_code == 200:
            json_body = response.json()
            if "subscriber_id" in json_body:
                print("✅ OTP Terkirim!")
                return True
            return {"status": "FAILED", "message": json_body.get('error', 'Unknown Error')}
        elif response.status_code == 403:
             return {"status": "FAILED", "message": "IP Blocked by Cloudflare (403)"}
        else:
            return {"status": "FAILED", "message": f"HTTP {response.status_code}"}
            
    except Exception as e:
        print(f"[LOGIN] Exception: {e}")
        return {"status": "ERROR", "message": str(e)}

def login_with_otp(contact: str, code: str):
    contact = validate_contact(contact)
    url = f"{BASE_CIAM_URL}/realms/xl-ciam/protocol/openid-connect/token"
    
    # --- FIX: AMBIL API KEY LANGSUNG DARI ENV DI SINI ---
    current_api_key = os.environ.get("API_KEY")
    if not current_api_key:
        print("⚠️ API KEY tidak ditemukan di ENV, menggunakan Fallback.")
        current_api_key = FALLBACK_API_KEY
    # ----------------------------------------------------

    # Siapkan Waktu
    now_gmt7 = datetime.now(timezone(timedelta(hours=7)))
    ts_for_sign = ts_gmt7_without_colon(now_gmt7)
    ts_header = ts_gmt7_without_colon(now_gmt7 - timedelta(minutes=5))

    # Generate Signature (Pakai API KEY yang pasti ada)
    try:
        signature = ax_api_signature(current_api_key, ts_for_sign, contact, code, "SMS")
    except Exception as e:
        print(f"❌ Gagal membuat signature: {e}")
        return False
    
    payload = f"contactType=SMS&code={code}&grant_type=password&contact={contact}&scope=openid"
    
    headers = {
        "Accept-Encoding": "gzip, deflate, br", 
        "Authorization": f"Basic {BASIC_AUTH}",
        "Ax-Api-Signature": signature, 
        "Ax-Device-Id": AX_DEVICE_ID, 
        "Ax-Fingerprint": AX_FP,
        "Ax-Request-At": ts_header, 
        "Ax-Request-Device": "samsung", 
        "Ax-Request-Device-Model": "SM-N935F",
        "Ax-Request-Id": str(uuid.uuid4()), 
        "Ax-Substype": "PREPAID",
        "Content-Type": "application/x-www-form-urlencoded", 
        "User-Agent": UA,
        "Host": BASE_CIAM_URL.replace("https://", ""),
    }
    
    try:
        print(f"[LOGIN] Verifying OTP {code}...")
        response = requests.post(url, data=payload, headers=headers, timeout=30)

        if response.status_code == 200:
            data = response.json()
            
            # Simpan Token ke auth.json
            current_dir = os.path.dirname(os.path.abspath(__file__))
            app_dir = os.path.dirname(current_dir)
            auth_file = os.path.join(app_dir, "auth.json")
            
            with open(auth_file, "w") as f:
                json.dump(data, f, indent=4)
                
            print(f"✅ Login Sukses! Token tersimpan.")
            
            # Update refresh-tokens.json juga
            try:
                rt_file = "/root/bot_store/me-cli/refresh-tokens.json"
                new_rt = data.get("refresh_token")
                # Kita coba ambil subscriber_id dari response jika ada, atau biarkan update nanti
                # Biasanya login endpoint ini TIDAK mengembalikan profile lengkap, jadi sub_id mungkin null
                
                if os.path.exists(rt_file) and new_rt:
                    with open(rt_file, 'r') as f:
                        tokens_list = json.load(f)
                    
                    found = False
                    for t in tokens_list:
                        if str(t.get("number")) == str(contact):
                            t["refresh_token"] = new_rt
                            # Jangan timpa subscriber_id jika tidak ada di response baru
                            found = True
                            break
                    
                    if not found:
                        tokens_list.append({
                            "number": int(contact),
                            "refresh_token": new_rt,
                            "subscriber_id": "00000000", # Placeholder
                            "username": "NewLogin",
                            "chat_id": 0,
                            "registration_date": datetime.now().strftime("%Y-%m-%d")
                        })
                    
                    with open(rt_file, 'w') as f:
                        json.dump(tokens_list, f, indent=4)
                    
                    # Set Active Number
                    with open("/root/bot_store/me-cli/active.number", "w") as f:
                        f.write(str(contact))

            except Exception as e:
                print(f"⚠️ Gagal update refresh token json: {e}")

            return True
        else:
            print(f"[LOGIN] Gagal: {response.text}")
            return False
            
    except Exception as e:
        print(f"[LOGIN] Error Request: {e}")
        return False