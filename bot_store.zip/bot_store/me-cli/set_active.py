import sys
import os
import json

# --- FIX: LOAD .ENV MANUAL (WAJIB DI ATAS IMPORT LAIN) ---
# Kita baca file .env dan masukkan ke os.environ sebelum modul lain berjalan
env_path = "/root/bot_store/me-cli/.env"
if os.path.exists(env_path):
    print(f"✅ Loading .env manual dari: {env_path}")
    try:
        with open(env_path, 'r') as f:
            for line in f:
                # Abaikan komentar dan baris kosong
                if line.strip() and not line.startswith('#') and '=' in line:
                    key, value = line.strip().split('=', 1)
                    key = key.strip()
                    value = value.strip().replace('"', '').replace("'", "")
                    os.environ[key] = value
    except Exception as e:
        print(f"❌ Gagal baca .env: {e}")
else:
    print(f"❌ File .env tidak ditemukan di: {env_path}")
# ---------------------------------------------------------

# Sekarang baru aman untuk import modul aplikasi
try:
    from app.service.auth import AuthInstance
except ImportError as e:
    print(f"❌ Error Import: {e}")
    sys.exit(1)
except ValueError as e:
    print(f"❌ Error Config: {e}")
    sys.exit(1)

# GANTI NOMOR INI DENGAN SALAH SATU NOMOR DARI refresh-tokens.json
# Saya ambil nomor Anda dari log sebelumnya: 6285931597495 (HookageLegend)
TARGET_NUMBER = 6285931597495

def force_set_active():
    print(f"\n🔄 Mencoba set akun aktif ke: {TARGET_NUMBER}")
    
    # 1. Cek apakah nomor ada di refresh-tokens.json
    json_path = "refresh-tokens.json"
    if not os.path.exists(json_path):
        print(f"❌ File {json_path} tidak ditemukan!")
        return

    try:
        with open(json_path, "r") as f:
            tokens = json.load(f)
            found = False
            for t in tokens:
                if t.get("number") == TARGET_NUMBER:
                    found = True
                    print(f"✅ Nomor ditemukan di database: {t.get('username', 'No Name')}")
                    break
            
            if not found:
                print("❌ Nomor TIDAK ditemukan di refresh-tokens.json!")
                print("Cek kembali daftar nomor di file json tersebut.")
                return
    except Exception as e:
        print(f"❌ Error baca file json: {e}")
        return

    # 2. Paksa AuthInstance untuk load nomor tersebut
    try:
        print("⏳ Sedang me-refresh token akses (mohon tunggu)...")
        # Panggil fungsi set_active_user dari AuthInstance
        # Ini akan menukar refresh token (awet) dengan access token baru (sementara)
        result = AuthInstance.set_active_user(TARGET_NUMBER)
        
        if result is False:
             print("❌ Gagal Refresh Token. Kemungkinan Refresh Token sudah expired/hangus.")
             return

        # Verifikasi
        active = AuthInstance.get_active_user()
        if active and active.get("number") == TARGET_NUMBER:
            print(f"\n🎉 SUKSES BESAR! Akun aktif sekarang: {TARGET_NUMBER}")
            print("➡️  Sekarang restart bot: systemctl restart bot-store")
            print("➡️  Lalu buka menu Paket Hot 2 di Telegram.")
        else:
            print("⚠️ Gagal set active user (Unknown Error).")
            
    except Exception as e:
        print(f"❌ Error saat set active: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Pastikan kita di direktori yang benar
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    force_set_active()