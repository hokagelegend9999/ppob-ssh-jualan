import json
import os
import requests
import sys

# --- CONFIG ---
TARGET_NUMBER = 6285931597495  # Nomor Anda (HookageLegend)
JSON_FILE = "refresh-tokens.json"
BASE_URL = "https://gede.ciam.xlaxiata.co.id/agw/1.0/token"

# Load .env manual untuk Header
env_path = "/root/bot_store/me-cli/.env"
API_KEY_VALUE = "fa37fd88-f4bb-422d-b857-7c18280f9086" # Default fallback
UA = "myXL/5.8.5 (Android; 13; Samsung SM-G991B; Build/TP1A.220624.014)"

if os.path.exists(env_path):
    with open(env_path, 'r') as f:
        for line in f:
            if "API_KEY" in line and "=" in line:
                API_KEY_VALUE = line.split("=")[1].strip().replace('"', '')

def get_headers():
    return {
        "Host": "gede.ciam.xlaxiata.co.id",
        "Connection": "keep-alive",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": UA,
        "Content-Type": "application/json",
        "Origin": "https://my.xl.co.id",
        "Referer": "https://my.xl.co.id/",
        "x-api-key": API_KEY_VALUE
    }

def fix_token():
    print(f"🔧 MEMPERBAIKI SESI UNTUK: {TARGET_NUMBER}")
    
    # 1. BACA JSON
    if not os.path.exists(JSON_FILE):
        print(f"❌ File {JSON_FILE} tidak ditemukan!")
        return

    with open(JSON_FILE, "r") as f:
        tokens = json.load(f)

    target_user = None
    target_index = -1

    for idx, t in enumerate(tokens):
        if t.get("number") == TARGET_NUMBER:
            target_user = t
            target_index = idx
            break
    
    if not target_user:
        print("❌ Nomor tidak ditemukan di JSON.")
        return

    print("✅ Akun ditemukan. Melakukan Refresh Token Manual...")
    refresh_token = target_user.get("refresh_token")

    # 2. REQUEST REFRESH KE SERVER XL (Bypass ciam.py)
    payload = {
        "grantType": "refresh_token",
        "refreshToken": refresh_token
    }

    try:
        resp = requests.post(BASE_URL, json=payload, headers=get_headers(), timeout=30)
        print(f"📡 Status Code: {resp.status_code}")
        
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "SUCCESS" or data.get("message") == "success":
                new_data = data.get("data", {})
                
                # AMBIL DATA PENTING
                new_access_token = new_data.get("accessToken")
                new_refresh_token = new_data.get("refreshToken")
                
                # KITA PERLU SUBSCRIBER ID -> Biasanya ada di Profile
                # Coba ambil profile sekalian
                print("🔄 Mengambil Subscriber ID dari Profile...")
                profile_url = "https://gede.ciam.xlaxiata.co.id/agw/1.0/profile"
                headers_profile = get_headers()
                headers_profile["Authorization"] = f"Bearer {new_access_token}"
                
                resp_prof = requests.get(profile_url, headers=headers_profile, timeout=30)
                sub_id = "00000000" # Default jika gagal
                
                if resp_prof.status_code == 200:
                    prof_data = resp_prof.json()
                    sub_id = prof_data.get("data", {}).get("subscriberId", "00000000")
                    print(f"✅ Subscriber ID Ditemukan: {sub_id}")
                else:
                    print("⚠️ Gagal ambil profil, menggunakan ID dummy.")

                # 3. UPDATE JSON
                tokens[target_index]["refresh_token"] = new_refresh_token
                tokens[target_index]["subscriber_id"] = sub_id
                
                # Simpan kembali ke file
                with open(JSON_FILE, "w") as f:
                    json.dump(tokens, f, indent=4)
                
                print("💾 File refresh-tokens.json berhasil diupdate!")
                
                # Buat file active.number
                with open("active.number", "w") as f:
                    f.write(str(TARGET_NUMBER))
                print("🎯 Active Number diset.")
                
                print("\n🎉 PERBAIKAN SELESAI! SILAKAN RESTART BOT.")

            else:
                print(f"❌ Gagal Refresh: {data}")
        elif resp.status_code == 403:
            print("❌ TERBLOKIR CLOUDFLARE (403).")
            print("Solusi: Anda harus login ulang pakai HP/Laptop, lalu copy auth.json baru.")
        else:
            print(f"❌ Error Server: {resp.text}")

    except Exception as e:
        print(f"❌ Exception: {e}")

if __name__ == "__main__":
    fix_token()
