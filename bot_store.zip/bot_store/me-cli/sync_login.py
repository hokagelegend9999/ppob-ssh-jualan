import json
import os

def final_sync():
    # Path file penting
    path_root = "/root/bot_store/me-cli"
    auth_file = os.path.join(path_root, "app/auth.json")
    refresh_file = os.path.join(path_root, "refresh-tokens.json")
    active_file = os.path.join(path_root, "active.number")

    # Nomor target Anda
    number = 6287726917005 

    if not os.path.exists(auth_file):
        print(f"❌ File {auth_file} tidak ditemukan!")
        return

    try:
        with open(auth_file, 'r') as f:
            auth_data = json.load(f)

        # Ambil token dari root atau data (menghindari KeyError: 'data')
        token_data = auth_data.get('data', auth_data)
        new_rt = token_data.get('refreshToken') or token_data.get('refresh_token')

        if not new_rt:
            print("❌ Gagal menemukan Refresh Token di auth.json")
            return

        # Update refresh-tokens.json
        tokens_list = []
        if os.path.exists(refresh_file):
            with open(refresh_file, 'r') as f:
                tokens_list = json.load(f)

        found = False
        for t in tokens_list:
            if str(t.get('number')) == str(number):
                t['refresh_token'] = new_rt
                t['subscriber_id'] = t.get('subscriber_id', '00000000')
                found = True
                break

        if not found:
            tokens_list.append({
                "number": number,
                "refresh_token": new_rt,
                "subscriber_id": "00000000",
                "username": "Hokage_Active",
                "chat_id": 1469244768
            })

        with open(refresh_file, 'w') as f:
            json.dump(tokens_list, f, indent=4)

        # WAJIB: Set active.number agar bot tahu siapa yang sedang login
        with open(active_file, 'w') as f:
            f.write(str(number))

        print(f"✅ SUKSES: Nomor {number} telah diset sebagai AKTIF.")
        print("🚀 Sekarang silakan restart bot.")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    final_sync()