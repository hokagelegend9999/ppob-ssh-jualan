import sys
import os
import json
import re

# Tambahkan path me-cli
sys.path.append('/root/bot_store/me-cli')

from app.service.auth import AuthInstance
from app.client.engsel import send_api_request

def auto_tembak(telegram_id, pkg_index):
    # 1. Setup Auth
    session_file = f"/root/bot_store/sessions/{telegram_id}.txt"
    if not os.path.exists(session_file):
        print("❌ Sesi tidak ditemukan.")
        return

    with open(session_file, 'r') as f:
        nomor_hp = f.read().strip()

    try:
        AuthInstance.load_tokens()
        if not AuthInstance.set_active_user(int(nomor_hp)):
            print(f"❌ Gagal load user {nomor_hp}")
            return
    except Exception as e:
        print(f"❌ Auth Error: {e}")
        return

    token = AuthInstance.get_active_tokens().get("id_token")
    api_key = AuthInstance.api_key

    # ==========================================
    # 2. DEFINISI KODE PAKET (HARDCODE DARI LOG MANUAL)
    # ==========================================
    
    # Target: Akrab 58.5GB (Dari log manual kamu)
    target_code = "U0NfXzr2UnR1js1JeT-EfFtimD9oqFl5CRVoTbiDia3xKhmKZv6C1mMM0j_zxfd8jKnawHECpHeSanNZKdEkwP5li3E"
    
    # Decoy: XL PASS 1 Day
    decoy_code = "U0NfXzWFvqYv8tWX9b6_n8mkS9p2FlfL__9gS2p_bLE20S_II4MEFfwGQVjfZrqpNj31j_8ewBlCGiYMkWbFWOyUZuY"

    # ==========================================

    def attempt_buy(exec_amount, attempt=1):
        path = "api/v8/prepaid/settlement"
        
        # Kirim KEDUANYA (Target + Decoy) di setiap percobaan
        items_payload = [
            {"code": target_code, "type": "BUY_PACKAGE"},
            {"code": decoy_code, "type": "BUY_PACKAGE"}
        ]

        payload = {
            "is_enterprise": False,
            "migration_type": "NONE",
            "payment_method": "BALANCE",
            "total_amount": exec_amount,
            "items": items_payload
        }
        
        print(f"📡 Try {attempt}: Tembak Harga {exec_amount}...")
        
        try:
            res = send_api_request(api_key, path, payload, token, "POST")
        except Exception as e:
            return {"status": "FAILED", "message": str(e)}
        
        # Cek Error 213 (Auto Adjust)
        if res.get('code') == '213':
            msg = res.get('message', '')
            print(f"⚠️ Respon Server: {msg}")
            
            # Ambil total harga yang diminta server
            match = re.search(r'Total\s*=\s*(\d+)', msg)
            if match:
                new_price = int(match.group(1))
                
                # JIKA SERVER MINTA 0 -> BERARTI PAKET GABISA DIBELI
                if new_price == 0:
                     print("❌ GAGAL TOTAL: Server bilang harga 0 (Paket tidak valid untuk nomor ini).")
                     return res

                if new_price == exec_amount:
                     return res

                print(f"🔄 Mengulang dengan harga: {new_price}")
                return attempt_buy(new_price, attempt=attempt+1)
        
        return res

    # Mulai Tembak (Harga Pancingan 185rb)
    final_res = attempt_buy(185000) 
    
    print("\n" + "="*30)
    print("✅ HASIL AKHIR:")
    print(json.dumps(final_res, indent=2))
    print("="*30)

if __name__ == "__main__":
    # Parameter pkg_index diabaikan karena kita hardcode kodenya
    if len(sys.argv) < 2:
        print("Usage: python3 tembak_otomatis.py [telegram_id] [pkg_index]")
    else:
        # pkg_index dikasih dummy '0' kalau tidak ada argumen ke-3
        idx = sys.argv[2] if len(sys.argv) > 2 else "0"
        auto_tembak(sys.argv[1], idx)