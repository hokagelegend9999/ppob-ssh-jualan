import time
import logging
import os
import json
import socket
import math # Tambahkan import math di sini agar global terisi
from telebot import apihelper 
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton 

# =========================================================
#  🛡️ KONFIGURASI KONEKSI (EDIT DI SINI)
# =========================================================
apihelper.ENABLE_MIDDLEWARE = True 

# 2. SETTING PROXY (PENTING!)
apihelper.proxy = {'https': 'socks5://127.0.0.1:1080'} 

# =========================================================

# BARU SETELAH ITU IMPORT BOT
from bot_init import bot
from database import update_user_activity
from background_tasks import start_background_tasks

# --- IMPORT MODULE HANDLERS ---
import handlers.handlers_ppob       
import handlers.payment
import handlers.users
import handlers.ssh
import handlers.vmess
import handlers.vless
import handlers.trojan
import handlers.nav               
import handlers.admin       
import handlers.handlers_vps
import handlers.digi_handler

# =========================================================
#  📡 AUTO TRACKER
# =========================================================
@bot.middleware_handler(update_types=['message'])
def track_message_activity(bot_instance, message):
    try:
        if message.from_user:
            update_user_activity(message.from_user.id)
    except Exception as e:
        print(f"⚠️ Tracker Error (Message): {e}")

@bot.middleware_handler(update_types=['callback_query'])
def track_callback_activity(bot_instance, call):
    try:
        # Tambahkan pemaksaan import math di sini sebagai jaring pengaman
        global math
        import math
        if call.from_user:
            update_user_activity(call.from_user.id)
    except Exception as e:
        print(f"⚠️ Tracker Error (Callback): {e}")
# =========================================================

if __name__ == "__main__":
    print("🚀 BOT STARTED (VIA WARP 1080)!")
    
    # Cek Status Restart
    if os.path.exists("restart_state.json"):
        try:
            with open("restart_state.json", "r") as f:
                data = json.load(f)
            chat_id = data.get('chat_id')
            msg_id = data.get('message_id')
            try: bot.delete_message(chat_id, msg_id)
            except: pass
            
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))
            bot.send_message(chat_id, "✅ <b>BOT ONLINE KEMBALI!</b>", parse_mode='HTML', reply_markup=markup)
            os.remove("restart_state.json")
        except Exception as e:
            print(f"⚠️ Error restart status: {e}")

    # Background Tasks
    try:
        start_background_tasks()
        print("✅ Background Tasks: Running...")
    except Exception as e:
        print(f"⚠️ Warning Background Tasks: {e}")
    
    # Loop Utama
    while True:
        try:
            print("📡 Menghubungkan ke Telegram...")
            bot.polling(none_stop=True, interval=0, timeout=25)
        except KeyboardInterrupt:
            print("\n⛔ Bot stop manual.")
            break
        except Exception as e:
            # Penanganan Error Spesifik math
            if "math" in str(e).lower():
                print("💡 Memperbaiki library math yang hilang...")
                global math
                import math
            
            logging.error(f"Polling Error: {e}")
            print(f"❌ Koneksi Putus: {e}")
            print("🔄 Reconnecting in 5s...")
            time.sleep(5)