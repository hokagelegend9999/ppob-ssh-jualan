import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot_init import bot
import json
import base64
import paramiko
import urllib.parse
import sqlite3
from config import ADMIN_ID, BIAYA_DAFTAR_RESELLER
from database import (
    get_user_data, add_balance, set_role, set_reseller_start, 
    add_downline_user, get_user_transaction_history, 
    get_reseller_downline_transactions
)
from database import get_reseller_vpn_counts_split, get_vpn_list_by_reseller, get_vpn_detail, DB_NAME
from datetime import datetime

# DATA SERVER (Hanya Indo)
SERVER_DATA = {
    "indo": { 
        "name": "Indonesia Private", 
        "domain": "id.hokagelegend.web.id", 
        "ip": "103.150.226.10", 
        "user": "root", "pass": "azzam2016" 
    }
}

# Helper Progress Bar (Biar Keren)
def make_bar_lite(used, total):
    pct = (used / total) * 10
    fill = int(pct)
    return "■" * fill + "□" * (10 - fill)

# ==========================================
# HANDLER MONITORING RESELLER
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("reseller_mon"))
def reseller_monitor_vps(call):
    try:
        # Format callback: reseller_mon|sg  atau reseller_mon|indo
        lokasi = call.data.split("|")[1]
    except: return

    target = SERVER_DATA.get(lokasi)
    if not target:
        return bot.answer_callback_query(call.id, "❌ Server Error")

    # Notifikasi Loading
    bot.answer_callback_query(call.id, f"⏳ Mengambil Info {lokasi.upper()}...", show_alert=False)
    
    # Pesan Loading Sementara
    bot.edit_message_text(f"⏳ <b>Connecting to {lokasi.upper()}...</b>", call.message.chat.id, call.message.message_id, parse_mode="HTML")

    try:
        # 1. KONEKSI SSH
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=8)

        # 2. COMMAND AMBIL INFO SYSTEM SAJA
        # Kita ambil: OS, Uptime, RAM Used, RAM Total
        cmd = """
        os=$(grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')
        upt=$(uptime -p | sed 's/up //')
        ram_u=$(free -m | awk 'NR==2{print $3}')
        ram_t=$(free -m | awk 'NR==2{print $2}')
        echo "$os|$upt|$ram_u|$ram_t"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8").strip()
        client.close()

        # 3. PARSING DATA
        if "|" in output:
            parts = output.split("|")
            os_name = parts[0]
            uptime = parts[1]
            ram_used = int(parts[2])
            ram_total = int(parts[3])
            
            # Hitung Persentase & Bar
            persen = int((ram_used / ram_total) * 100)
            bar_ram = make_bar_lite(ram_used, ram_total)
            
            # Status Warna (Hijau/Kuning/Merah)
            status_icon = "🟢" if persen < 70 else "🟡" if persen < 90 else "🔴"

            # 4. TAMPILAN DASHBOARD RESELLER
            msg = f"""
<b>📊 SERVER STATUS: {lokasi.upper()}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» SYSTEM HEALTH {status_icon}</b>
<b>RAM Usage :</b> {persen}%
{bar_ram}
<code>{ram_used}MB / {ram_total}MB</code>

<b>» SERVER INFO</b>
<b>Domain   :</b> <code>{target['domain']}</code>
<b>IP Host  :</b> <code>{target['ip']}</code>
<b>OS Distro:</b> {os_name}
<b>Uptime   :</b> {uptime}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Server berjalan normal. Silakan gunakan dengan bijak.</i>
"""
            # Tombol Refresh & Kembali ke Menu Reseller
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 REFRESH STATUS", callback_data=f"reseller_mon|{lokasi}"))
            markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="reseller_my_list")) # Kembali ke menu list akun

            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
        
        else:
            bot.edit_message_text("❌ Gagal membaca data server.", call.message.chat.id, call.message.message_id)

    except Exception as e:
        bot.edit_message_text(f"❌ <b>Koneksi Gagal</b>\nServer mungkin sedang down/restart.\nError: {e}", call.message.chat.id, call.message.message_id, parse_mode="HTML")

# --- 1. DAFTAR RESELLER MANDIRI ---
@bot.callback_query_handler(func=lambda call: call.data == "register_reseller")
def register_reseller_prompt(call):
    uid = call.from_user.id
    user = get_user_data(uid)
    if not user: 
        return bot.answer_callback_query(call.id, "❌ Error: Data user tidak ditemukan.")
    
    current_role = str(user.get('role', 'user')).lower()
    saldo = int(user.get('balance', 0))

    is_owner = (str(uid) == str(ADMIN_ID)) or ('owner' in current_role)
    is_reseller = 'reseller' in current_role

    if is_owner or is_reseller:
        status_label = "OWNER (BOS BESAR)" if is_owner else "RESELLER"
        pesan_kocak = (
            f"✅ <b>STATUS: {status_label}</b>\n"
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"<i>Halo Bos! Status Anda saat ini sudah <b>{status_label}</b>.\n"
            "Jadi tidak perlu daftar lagi ya... Ayo transaksi sebanyak-banyaknya! 🤣</i>"
        )
        markup = InlineKeyboardMarkup()
        back_data = "switch_owner" if is_owner else "switch_user"
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data=back_data))
        bot.edit_message_text(pesan_kocak, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        return

    if saldo < BIAYA_DAFTAR_RESELLER:
        kurang = BIAYA_DAFTAR_RESELLER - saldo
        msg = (
            f"⚠️ <b>SALDO TIDAK CUKUP</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"💸 Biaya Daftar: Rp {BIAYA_DAFTAR_RESELLER:,}\n"
            f"💰 Saldo Anda : Rp {saldo:,}\n"
            f"❌ Kekurangan : <b>Rp {kurang:,}</b>\n\n"
            f"<i>Silakan isi saldo dulu minimal Rp {BIAYA_DAFTAR_RESELLER:,} biar bisa gabung jadi Reseller.</i>"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("➕ ISI SALDO SEKARANG", callback_data="topup"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        return

    msg = (
        f"⚡ <b>KONFIRMASI UPGRADE RESELLER</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"Saldo kamu cukup nih! Yakin mau upgrade jadi RESELLER?\n\n"
        f"💸 Biaya: <b>Rp {BIAYA_DAFTAR_RESELLER:,}</b>\n"
        f"✅ <i>Saldo otomatis terpotong.</i>"
    )
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("✅ GAS BAYAR!", callback_data="fix_reg_reseller"),
        InlineKeyboardButton("❌ GAK JADI", callback_data="switch_user")
    )
    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "fix_reg_reseller")
def register_reseller_execute(call):
    uid = call.from_user.id
    user = get_user_data(uid)
    saldo = int(user.get('balance', 0))

    if saldo < BIAYA_DAFTAR_RESELLER:
        return bot.answer_callback_query(call.id, "❌ Saldo tidak cukup.", show_alert=True)

    try:
        add_balance(uid, -BIAYA_DAFTAR_RESELLER, "Daftar Reseller Mandiri")
        set_role(uid, 'reseller')
        set_reseller_start(uid)

        pesan_sukses = (
            "🎉 <b>SELAMAT! UPGRADE BERHASIL</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            "✅ Status: ⚡ <b>RESELLER</b>\n\n"
            "<i>Kamu sudah menjadi reseller ...ayo transaksi sebanyak banyak nya!</i>"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🚀 MENU RESELLER", callback_data="switch_reseller"))
        bot.edit_message_text(pesan_sukses, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}")

# --- 2. LAPORAN RESELLER ---
# ==========================================
#  MENU LAPORAN RESELLER (FIXED)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "reseller_report")
def reseller_report_menu(call):
    markup = InlineKeyboardMarkup()
    markup.row(InlineKeyboardButton("📊 Laporan Transaksi", callback_data="reseller_trx_report"))
    markup.row(InlineKeyboardButton("👥 List Downline", callback_data="reseller_downline_list"))
    markup.row(InlineKeyboardButton("🔙 Kembali", callback_data="reseller_menu"))
    
    msg_text = "📊 <b>MENU LAPORAN RESELLER</b>\nSilakan pilih jenis laporan:"
    
    try:
        bot.edit_message_text(msg_text, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        # Abaikan error jika pesan tidak berubah
        if "message is not modified" in str(e):
            pass 
        else:
            # Jika error lain, kirim pesan baru sebagai fallback
            bot.send_message(call.message.chat.id, msg_text, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "report_my_trx")
def reseller_my_report(call):
    uid = call.from_user.id
    history = get_user_transaction_history(uid)
    msg = "<b>📜 RIWAYAT TRANSAKSI SAYA</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not history: msg += "<i>Belum ada transaksi.</i>"
    else:
        for trx in history[:10]:
            msg += f"✅ {trx[0]} | {trx[1]} | <b>Rp {trx[2]:,}</b>\n────────────────\n"
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="report"))
    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "report_downline_trx")
def reseller_downline_report(call):
    uid = call.from_user.id
    try: downline_trx = get_reseller_downline_transactions(uid)
    except: downline_trx = []

    msg = "<b>👥 LAPORAN TRANSAKSI DOWNLINE</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not downline_trx: msg += "<i>Belum ada aktivitas transaksi dari user Anda.</i>"
    else:
        total_omset = 0
        for trx in downline_trx[:15]:
            tgl, user_name, produk, harga = trx
            msg += f"👤 <b>{user_name}</b> beli {produk}\n🕒 {tgl} | 💰 Rp {harga:,}\n────────────────\n"
            total_omset += harga
        msg += f"\n💰 <b>Total Omset (Halaman ini): Rp {total_omset:,}</b>"
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="report"))
    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

# --- 3. BUAT USER (DOWNLINE) ---
@bot.callback_query_handler(func=lambda call: call.data == "create_user")
def create_user_start(call):
    uid = call.from_user.id
    user = get_user_data(uid)
    role = str(user.get('role', 'user')).lower()
    if 'reseller' not in role and str(uid) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "⛔ Akses Ditolak!", show_alert=True)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_reseller"))
    msg = bot.send_message(call.message.chat.id, "<b>➕ TAMBAH DOWNLINE BARU</b>\nSilakan kirim <b>ID Telegram</b> calon user:", parse_mode='HTML', reply_markup=markup)
    bot.register_next_step_handler(msg, process_input_new_user_id)

def process_input_new_user_id(message):
    try:
        target_id = message.text.strip()
        if not target_id.isdigit() or len(target_id) < 5:
            msg = bot.reply_to(message, "❌ <b>ID Tidak Valid!</b> Silakan kirim ID angka yang benar:", parse_mode='HTML')
            bot.register_next_step_handler(msg, process_input_new_user_id)
            return
        msg = bot.reply_to(message, f"✅ ID Diterima: <code>{target_id}</code>\nSekarang kirim <b>NAMA PANGGILAN</b> user:", parse_mode='HTML')
        bot.register_next_step_handler(msg, process_input_new_user_name, target_id)
    except: bot.reply_to(message, "❌ Terjadi kesalahan.")

def process_input_new_user_name(message, target_id):
    name = message.text.strip()
    reseller_id = message.from_user.id
    success, info = add_downline_user(target_id, name, reseller_id)
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_reseller"))

    if success:
        pesan_sukses = (
            "✅ <b>USER BARU BERHASIL DIBUAT!</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👤 Nama: <b>{name}</b>\n🆔 ID: <code>{target_id}</code>\n"
            "<i>⚠️ Pastikan user klik /start di bot ini.</i>"
        )
        bot.reply_to(message, pesan_sukses, parse_mode='HTML', reply_markup=markup)
        try: bot.send_message(target_id, f"🎉 <b>SELAMAT DATANG!</b>\nAkun didaftarkan oleh {message.from_user.first_name}.\nKetik /start untuk mulai.")
        except: pass
    else:
        bot.reply_to(message, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML', reply_markup=markup)
        
@bot.callback_query_handler(func=lambda call: call.data == "reseller_my_list")
def menu_folder_reseller(call):
    user_id = call.from_user.id
    
    # 1. Tampilkan Loading
    try:
        bot.edit_message_text("⏳ <b>Sedang Mengambil Data Server...</b>\n<i>Mohon tunggu...</i>", 
                              call.message.chat.id, call.message.message_id, parse_mode="HTML")
    except: pass

    # 2. Ambil Data Counter User (Pastikan fungsi DB Anda mendukung ini)
    stats = get_reseller_vpn_counts_split(user_id)
    
    # --- BAGIAN YG DIUBAH: HANYA AMBIL INDO ---
    # Hapus baris 'sg = stats["sg"]'
    indo = stats["indo"] 

    # 3. Ambil Data Dashboard Lengkap (HANYA INDO)
    # Hapus baris 'text_sg = ...'
    text_indo = get_vps_dashboard_text("indo")

    # 4. Gabungkan Pesan (Hapus text_sg)
    msg = f"{text_indo}\n"
    msg += "<b>📂 PILIH FOLDER UNTUK MELIHAT ASET:</b>"

    # 5. Tombol Folder (HANYA INDO)
    markup = InlineKeyboardMarkup(row_width=2)

    # --- HAPUS BAGIAN TOMBOL SG ---
    
    # Header INDO (Bisa diubah jadi 'LIST ASET' saja karena cuma 1 server)
    markup.add(InlineKeyboardButton("--- 🇮🇩 ASET SERVER 🇮🇩 ---", callback_data="ignore"))
    markup.add(
        InlineKeyboardButton(f"📂 SSH ({indo['SSH']})", callback_data="my_list_view|SSH|indo"),
        InlineKeyboardButton(f"📂 VMESS ({indo['VMESS']})", callback_data="my_list_view|VMESS|indo")
    )
    markup.add(
        InlineKeyboardButton(f"📂 VLESS ({indo['VLESS']})", callback_data="my_list_view|VLESS|indo"),
        InlineKeyboardButton(f"📂 TROJAN ({indo['TROJAN']})", callback_data="my_list_view|TROJAN|indo")
    )

    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_reseller"))
    
    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)

# ==========================================
# MENAMPILKAN LIST DENGAN TOMBOL DETAIL
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("my_list_view"))
def show_reseller_list_by_proto(call):
    user_id = call.from_user.id
    try:
        protocol_pilih = call.data.split("|")[1] # SSH / VMESS / TROJAN
    except:
        return

    # Ambil data: id, username, protocol, exp_date, password, domain
    all_data = get_vpn_list_by_reseller(user_id)
    
    # Filter sesuai protocol
    filtered_data = []
    if all_data:
        for row in all_data:
            if str(row[2]).upper() == protocol_pilih.upper(): # row[2] = protocol
                filtered_data.append(row)

    if not filtered_data:
        bot.answer_callback_query(call.id, f"❌ Belum ada user {protocol_pilih}", show_alert=True)
        return

    # Hapus pesan sebelumnya biar bersih (Opsional)
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass

    # KIRIM LIST SATU PER SATU (Maksimal 10 biar tidak spam flood)
    bot.send_message(call.message.chat.id, f"📂 <b>LIST {protocol_pilih} BUATAN ANDA</b>", parse_mode="HTML")
    
    for row in filtered_data[:10]: 
        db_id = row[0]
        username = row[1]
        exp_date = row[3]
        # Password dan Domain ada di row[4] dan row[5] tapi kita sembunyikan dulu

        # Tampilan mirip Admin VPS
        text_display = f"━━━━━━━━━━━━━━━━━━\n"
        text_display += f"👤 <b>{username}</b>\n"
        text_display += f"⏳ Exp: {exp_date}\n"
        text_display += f"🏳️ Active\n"
        text_display += f"━━━━━━━━━━━━━━━━━━"

        markup = InlineKeyboardMarkup()
        # Tombol callback membawa ID unik dari database
        markup.add(InlineKeyboardButton(f"👁️ LIHAT DETAIL {username}", callback_data=f"detail_vpn|{db_id}"))

        bot.send_message(call.message.chat.id, text_display, parse_mode="HTML", reply_markup=markup)

    # Tombol Kembali Global di Bawah
    markup_back = InlineKeyboardMarkup()
    markup_back.add(InlineKeyboardButton("🔙 KEMBALI KE FOLDER", callback_data="reseller_my_list"))
    bot.send_message(call.message.chat.id, "⬇️ <i>Tekan tombol di atas untuk melihat detail akun.</i>", parse_mode="HTML", reply_markup=markup_back)


@bot.callback_query_handler(func=lambda call: call.data.startswith("detail_vpn"))
def show_vpn_detail_complete(call):
    try:
        db_id = call.data.split("|")[1]
    except: return

    # 1. AMBIL DATA DARI DATABASE BOT
    data = get_vpn_detail(db_id)
    if not data:
        return bot.answer_callback_query(call.id, "❌ Data tidak ditemukan di database.", show_alert=True)

    username, protocol, exp_date, password, domain, created_at_str, reseller_id = data

    # 2. CARI CREDENTIAL SERVER BERDASARKAN DOMAIN
    target_server = None
    lokasi_server = "indo" # Default
    
    for key, val in SERVER_DATA.items():
        if val['domain'] == domain:
            target_server = val
            lokasi_server = key
            break
            
    # Jika server tidak ketemu (domain beda), pakai default indo (fallback)
    if not target_server: 
        target_server = SERVER_DATA["indo"]

    # 3. CEK STATUS USER DI VPS (REAL-TIME)
    bot.answer_callback_query(call.id, "⏳ Sync status server...")
    
    is_deleted_on_vps = False
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target_server['ip'], username=target_server['user'], password=target_server['pass'], timeout=5)
        
        # Cek apakah user ada di /etc/passwd
        stdin, stdout, stderr = client.exec_command(f"id {username} >/dev/null 2>&1 && echo 'ADA' || echo 'HILANG'")
        status_check = stdout.read().decode().strip()
        client.close()
        
        if status_check == "HILANG":
            is_deleted_on_vps = True
    except Exception as e:
        print(f"Gagal cek VPS: {e}") 
        # Jika gagal connect, kita anggap ada dulu biar user bisa lihat detail

    # 4. JIKA USER SUDAH DIHAPUS DI VPS
    if is_deleted_on_vps:
        markup = InlineKeyboardMarkup()
        # Tombol Hapus dari Database agar sinkron
        markup.add(InlineKeyboardButton(f"🗑️ HAPUS DARI DATABASE", callback_data=f"db_del_vpn|{db_id}|{lokasi_server}"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="reseller_my_list"))
        
        msg_warning = (
            f"❌ <b>STATUS: USER SUDAH DIHAPUS (VPS)</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👤 Username: <code>{username}</code>\n"
            f"⚠️ <b>Peringatan:</b>\n"
            f"Akun ini sudah <b>TIDAK ADA</b> di server VPS, tapi masih tersimpan di history Database Bot.\n\n"
            f"<i>Silakan hapus data ini agar database bersih.</i>"
        )
        try:
            bot.edit_message_text(msg_warning, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(call.message.chat.id, msg_warning, parse_mode="HTML", reply_markup=markup)
        return

    # 5. JIKA USER MASIH ADA, TAMPILKAN DETAIL (FIX VARIABEL)
    # Perbaikan: Mengganti 'res_user' -> 'username', 'DOMAIN' -> 'domain', dll
    
    user_data = get_user_data(call.from_user.id)
    harga_display = 10000 if "id.hokagelegend" in domain else 7000
    
    # Format Tanggal
    try:
        tgl_obj = datetime.strptime(created_at_str.split(" ")[0], "%Y-%m-%d")
        created_date_fmt = tgl_obj.strftime("%d/%m/%Y")
    except: created_date_fmt = created_at_str

    msg = ""

    if protocol == "SSH":
        msg = f"""
========================================
🌟 <b>AKUN SSH PREMIUM</b>
========================================
🔹 <b>INFORMASI AKUN</b>
Username: <code>{username}</code>
Password: <code>{password}</code>
Domain: <code>{domain}</code>
ZIVPN TOKEN: <code>{username}</code>

🔗 <b>CONNECTION</b>
SSH WS: <code>{domain}:80@{username}:{password}</code>
SSH SSL: <code>{domain}:443@{username}:{password}</code>
UDP: <code>{domain}:1-65535@{username}:{password}</code>

📋 <b>INFO LAIN</b>
Expired: <code>{exp_date}</code>
Limit IP: 2 Device
========================================
Generated: {created_date_fmt}
========================================
"""
    elif protocol == "VMESS":
        uuid = password
        # Generate link manual karena fungsi generate ada di luar
        msg = f"""
========================================
⚡ <b>AKUN VMESS PREMIUM</b>
========================================
Remarks: <code>{username}</code>
Domain: <code>{domain}</code>
UUID: <code>{uuid}</code>
Expired: <code>{exp_date}</code>

<i>(Link config silakan copy UUID di atas)</i>

Generated: {created_date_fmt}
========================================
"""
    elif protocol == "VLESS":
        uuid = password
        msg = f"""
========================================
🔮 <b>AKUN VLESS PREMIUM</b>
========================================
Remarks: <code>{username}</code>
Domain: <code>{domain}</code>
UUID: <code>{uuid}</code>
Expired: <code>{exp_date}</code>

Generated: {created_date_fmt}
========================================
"""
    elif protocol == "TROJAN":
        msg = f"""
========================================
🐎 <b>AKUN TROJAN PREMIUM</b>
========================================
Remarks: <code>{username}</code>
Domain: <code>{domain}</code>
Password: <code>{password}</code>
Expired: <code>{exp_date}</code>

Generated: {created_date_fmt}
========================================
"""
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ TUTUP", callback_data="delete_msg"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode="HTML", reply_markup=markup)

# ==========================================
# HANDLER HAPUS DARI DATABASE (DB ONLY)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("db_del_vpn"))
def delete_vpn_from_db_handler(call):
    try:
        _, db_id, lokasi = call.data.split("|")
        
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("DELETE FROM vpn_history WHERE id=?", (db_id,))
        conn.commit()
        conn.close()
        
        bot.answer_callback_query(call.id, "✅ Data berhasil dihapus dari database!", show_alert=True)
        
        # Kembali ke list
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except: pass
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}")
    
# ==========================================
# HELPER GENERATE VMESS LINK (AUTO)
# ==========================================
def gen_vmess_link_detail(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    net = "grpc" if type == "grpc" else "ws"
    path = "vmess-grpc" if type == "grpc" else "/vmess"
    tls = "tls" if type != "none" else "none"
    type_net = "gun" if type == "grpc" else "none"

    config = {
        "v": "2", "ps": name, "add": domain, "port": port, "id": uuid, "aid": "0",
        "net": net, "type": type_net, "host": domain, "path": path, "tls": tls
    }
    return f"vmess://{base64.b64encode(json.dumps(config).encode()).decode()}"
    
def gen_vless_link_detail(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    net = "grpc" if type == "grpc" else "ws"
    path = "vless-grpc" if type == "grpc" else "/vless"
    security = "tls" if type != "none" else "none"
    
    if type == "grpc":
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=grpc&serviceName={path}#{name}"
    else:
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=ws&path={path}#{name}"
        
import urllib.parse # Pastikan ini diimport di paling atas file users.py

def gen_trojan_link_detail(user, domain, password, type="ws"):
    safe_name = urllib.parse.quote(user)
    if type == "grpc":
        return f"trojan://{password}@{domain}:443?security=tls&type=grpc&serviceName=trojan-grpc#{safe_name}"
    else:
        return f"trojan://{password}@{domain}:443?security=tls&type=ws&path=%2Ftrojan#{safe_name}"
        
def get_vps_dashboard_text(lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return f"❌ Config Error: {lokasi}"

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # Timeout diset 4 detik per server
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=4)

        # Command Linux: Ambil OS, Uptime, RAM, ISP (Cek cache dulu biar cepat)
        cmd = """
        os=$(grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')
        upt=$(uptime -p | sed 's/up //')
        ram_u=$(free -m | awk 'NR==2{print $3}')
        ram_t=$(free -m | awk 'NR==2{print $2}')
        # Coba ambil ISP dari cache file .isp jika ada, kalau tidak curl (timeout 1s)
        isp=$(cat /root/.info/.isp 2>/dev/null || curl -s --max-time 1 ipinfo.io/org || echo "Unknown")
        city=$(cat /root/.info/.city 2>/dev/null || curl -s --max-time 1 ipinfo.io/city || echo "Unknown")
        
        echo "$os|$upt|$ram_u|$ram_t|$isp|$city"
        """

        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8").strip()
        client.close()

        if "|" in output:
            parts = output.split("|")
            os_name = parts[0]
            uptime = parts[1]
            ram_u = parts[2]
            ram_t = parts[3]
            isp = parts[4]
            city = parts[5]

            # === FORMAT TAMPILAN DASHBOARD ===
            return f"""
<b>💻 VPS DASHBOARD ({lokasi.upper()})</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» SYSTEM INFORMATION</b>
<code>Domain   :</code> {target['domain']}
<code>IP VPS   :</code> {target['ip']}
<code>ISP      :</code> {isp}
<code>Location :</code> {city}
<code>RAM      :</code> {ram_u}MB / {ram_t}MB
<code>OS       :</code> {os_name}
<code>Uptime   :</code> {uptime}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"""
        else:
             return f"⚠️ <b>{lokasi.upper()}:</b> Gagal parsing data."
    except Exception as e:
        return f"❌ <b>{lokasi.upper()} OFFLINE / ERROR</b>\n<code>{str(e)[:50]}</code>"
        
# ==========================================
#  HANDLER TOMBOL TUTUP / DELETE MESSAGE
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "delete_msg")
def handler_delete_msg(call):
    try:
        # Hapus pesan tempat tombol ini berada
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except Exception:
        # Jika gagal (misal pesan sudah terhapus), biarkan saja
        pass