import telebot
import time
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot_init import bot
from config import ADMIN_ID, MIN_TOPUP_AUTO_RESELLER
from database import (
    get_user_data_complete, update_saldo, update_user_role, 
    get_suspicious_users_list, get_user_data, find_user,
    get_users_with_balance
)

# ==========================================
#  MENU UTAMA MANAJEMEN SALDO
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "manage_saldo")
def saldo_menu_handler(call):
    # Validasi Admin
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")
    
    # 1. Buat Tombol
    m = InlineKeyboardMarkup()
    m.row(InlineKeyboardButton("🔎 CEK DOMPET (BY ID)", callback_data="saldo_check"))
    m.row(InlineKeyboardButton("📜 LIST USER BERSALDO", callback_data="list_active_balance"))
    m.row(InlineKeyboardButton("➕ INJECT SALDO", callback_data="saldo_add"), 
          InlineKeyboardButton("➖ POTONG SALDO", callback_data="saldo_deduct"))
    m.row(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))
    
    # 2. Buat Pesan
    pesan = (
        "<b>💸 PUSAT KONTROL KEUANGAN (VAULT)</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Halo Admin! Panel ini untuk mengelola saldo member secara manual.\n\n"
        "<b>🔰 FITUR:</b>\n"
        "├ 🔎 <b>Cek Dompet:</b> Intip sisa saldo member.\n"
        "├ 📜 <b>List Bersaldo:</b> Lihat siapa yang punya uang.\n"
        "├ ➕ <b>Inject:</b> Topup manual / Bonus.\n"
        "└ ➖ <b>Potong:</b> Denda / Koreksi.\n"
    )

    # 3. Eksekusi Pesan (Dengan Anti-Error)
    try:
        # Coba edit pesan lama agar rapi
        bot.edit_message_text(pesan, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except Exception:
        # Jika pesan lama hilang/error, hapus dulu (opsional) lalu kirim pesan baru
        try: bot.delete_message(call.message.chat.id, call.message.message_id)
        except: pass
        
        bot.send_message(call.message.chat.id, pesan, parse_mode='HTML', reply_markup=m)


# ==========================================
#  1. LIST USER BERSALDO
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "list_active_balance")
def list_active_balance_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    # Ambil data (sekarang sudah ada tanggalnya)
    users = get_users_with_balance() # limit default di db func
    
    if not users:
        return bot.answer_callback_query(call.id, "❌ Belum ada user bersaldo.", show_alert=True)
    
    msg = "<b>📜 LIST USER BERSALDO (TOP 20)</b>\n"
    msg += "<i>(Urut dari saldo terbesar + Waktu Aktif Terakhir)</i>\n"
    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    # Slice manual limit 20
    for i, u in enumerate(users[:20], 1):
        # Data dari database: uid, first_name, balance, username
        uid = u[0]
        # u[1] adalah first_name
        saldo = u[2]
        raw_username = u[3]
        
        # 1. Format Username
        try: username = f"@{raw_username}" if raw_username else "No Username"
        except: username = "Unknown"
        
        msg += f"<b>{i}. {username}</b>\n"
        msg += f"   🆔 <code>{uid}</code>\n"
        msg += f"   💰 Rp {saldo:,}\n"
        msg += "   ────────────────\n"
        
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="manage_saldo"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except Exception:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)


# ==========================================
#  2. CEK SALDO USER
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "saldo_check")
def saldo_check_start(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="cancel_action_saldo"))
    msg = bot.send_message(
        call.message.chat.id, 
        "🔍 <b>CEK DOMPET USER</b>\n\nKirim <b>ID</b> atau <b>Username</b> user:", 
        parse_mode='HTML',
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_check)

def process_saldo_check(message):
    try:
        user = find_user(message.text.strip())
        if not user: 
            return bot.reply_to(message, "❌ User tidak ditemukan.")
        
        uid, nama, saldo, role, username = user
        
        # Tambahkan tombol lihat history
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("📜 LIHAT RIWAYAT", callback_data=f"hist_{uid}_1"))
        
        bot.reply_to(message, f"👤 <b>{nama}</b>\n🆔 <code>{uid}</code>\n💰 Saldo: <b>Rp {saldo:,}</b>", parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {e}")


# ==========================================
#  3. INJECT SALDO (TAMBAH) - FIXED PROVIDER REMOVED
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "saldo_add")
def saldo_add_start(call):
    if str(call.from_user.id) != str(ADMIN_ID): return

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="cancel_action_saldo"))
    msg = bot.send_message(
        call.message.chat.id, 
        "➕ <b>INJECT SALDO MANUAL</b>\n\nKirim <b>ID Telegram</b> atau <b>Username</b> target:", 
        parse_mode='HTML',
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_add_step1)

def process_saldo_add_step1(message):
    target_input = message.text.strip()
    user = find_user(target_input)
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="cancel_action_saldo"))

    if not user:
        msg = bot.reply_to(message, "❌ <b>User tidak ditemukan!</b> Coba lagi:", parse_mode='HTML', reply_markup=markup)
        bot.register_next_step_handler(msg, process_saldo_add_step1)
        return

    uid = user[0]
    nama = user[1] if user[1] else "Tanpa Nama"
    saldo = user[2]
    
    pesan = (
        f"🎯 <b>TARGET: {nama}</b>\n"
        f"🆔 ID: <code>{uid}</code>\n"
        f"💰 Saldo Awal: Rp {saldo:,}\n\n"
        f"💸 <b>Masukkan Nominal Tambahan:</b>\n"
        f"(Angka saja, contoh: 50000)"
    )
    msg = bot.reply_to(message, pesan, parse_mode='HTML', reply_markup=markup)
    # Lanjut ke Step 2
    bot.register_next_step_handler(msg, process_saldo_add_step2, uid)

def process_saldo_add_step2(message, target_id):
    try:
        text_input = message.text.replace(".", "").replace(",", "").strip()
        if not text_input.isdigit():
            bot.reply_to(message, "❌ Nominal harus angka.")
            return

        amount = int(text_input)
        
        # --- EKSEKUSI ADD BALANCE (FIXED) ---
        ref_id_admin = f"ADM-INJ-{int(time.time())}"
        
        # [FIX] HAPUS parameter provider="ADMIN"
        success = update_saldo(
            target_id, 
            amount, 
            description="DEPOSIT VIA ADMIN", 
            ref_id=ref_id_admin
            # provider="ADMIN" <-- SUDAH DIHAPUS
        )

        if success:
            # Auto Upgrade Reseller Logic
            if amount >= MIN_TOPUP_AUTO_RESELLER:
                # (Logika upgrade reseller bisa ditambahkan disini jika perlu)
                pass

            # Notifikasi Sukses dengan Tombol Kembali
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE PROFILE", callback_data=f"hist_{target_id}_1"))

            bot.reply_to(
                message, 
                f"✅ <b>BERHASIL!</b>\n"
                f"Target: <code>{target_id}</code>\n"
                f"Masuk: Rp {amount:,}\n"
                f"Ref: <code>{ref_id_admin}</code>", 
                parse_mode='HTML', 
                reply_markup=markup
            )
            
            # Notif ke User
            try: bot.send_message(target_id, f"💰 Saldo Anda ditambah Admin: <b>Rp {amount:,}</b>", parse_mode='HTML')
            except: pass
        else:
            bot.reply_to(message, "❌ Gagal Inject (Database Error).")

    except Exception as e:
        bot.reply_to(message, f"❌ Error: {e}")


# ==========================================
#  4. POTONG SALDO (DEDUCT) - FIXED PROVIDER REMOVED
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "saldo_deduct")
def saldo_deduct_start(call):
    if str(call.from_user.id) != str(ADMIN_ID): return

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="cancel_action_saldo"))
    msg = bot.send_message(
        call.message.chat.id, 
        "➖ <b>POTONG SALDO MANUAL</b>\n\nKirim <b>ID Telegram</b> atau <b>Username</b> target:", 
        parse_mode='HTML', 
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_deduct_step1)

def process_saldo_deduct_step1(message):
    target_input = message.text.strip()
    user = find_user(target_input)
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="cancel_action_saldo"))

    if not user:
        msg = bot.reply_to(message, "❌ <b>User tidak ditemukan!</b> Coba lagi:", parse_mode='HTML', reply_markup=markup)
        bot.register_next_step_handler(msg, process_saldo_deduct_step1)
        return

    uid = user[0]
    nama = user[1]
    saldo = user[2]

    pesan = (
        f"🎯 <b>TARGET POTONG: {nama}</b>\n"
        f"🆔 ID: <code>{uid}</code>\n"
        f"💰 Saldo Saat Ini: Rp {saldo:,}\n\n"
        f"⚠️ <b>Masukkan Nominal Potongan:</b>"
    )
    msg = bot.reply_to(message, pesan, parse_mode='HTML', reply_markup=markup)
    # Lanjut ke Step 2
    bot.register_next_step_handler(msg, process_saldo_deduct_step2, uid)

def process_saldo_deduct_step2(message, target_id):
    try:
        text_input = message.text.replace(".", "").replace(",", "").strip()
        if not text_input.isdigit():
            bot.reply_to(message, "❌ Nominal harus angka.")
            return
            
        amount = int(text_input)
        
        # --- EKSEKUSI POTONG BALANCE (FIXED) ---
        ref_id_admin = f"ADM-CUT-{int(time.time())}"
        
        success = update_saldo(
            target_id, 
            -amount, 
            description="KOREKSI SALDO (POTONG)", 
            ref_id=ref_id_admin
        )
        
        # [PERBAIKAN UTAMA DISINI]
        # Menggunakan "is not False" agar saldo 0 tetap dianggap sukses
        if success is not False:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE PROFILE", callback_data=f"hist_{target_id}_1"))
            
            bot.reply_to(
                message, 
                f"✅ <b>BERHASIL DIPOTONG!</b>\n"
                f"Target: <code>{target_id}</code>\n"
                f"Potong: Rp {amount:,}\n"
                f"Sisa Saldo: <b>Rp {success:,}</b>", # Menampilkan sisa saldo
                parse_mode='HTML',
                reply_markup=markup
            )
            
            try: bot.send_message(target_id, f"⚠️ Saldo Anda dikoreksi Admin: <b>-Rp {amount:,}</b>", parse_mode='HTML')
            except: pass
        else:
            bot.reply_to(message, "❌ Gagal memotong (Mungkin saldo tidak cukup atau Error DB).")
        
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {e}")


# ==========================================
#  CANCEL HANDLER (UMUM)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "cancel_action_saldo")
def cancel_action_handler(call):
    bot.clear_step_handler_by_chat_id(call.message.chat.id)
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    bot.answer_callback_query(call.id, "❌ Dibatalkan")
    
    # Kembali ke menu saldo
    saldo_menu_handler(call)