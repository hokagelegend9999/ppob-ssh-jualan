# /root/bot_store/handlers/users/user_handlers.py
# [FIXED FINAL] Logic Hot2 dipindah ke sini agar bisa diakses User

import datetime
import logging
import json
import asyncio
import functools
import re
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from app.service.profile_service import ProfileServiceInstance

# --- IMPORTS ---
from app.service.auth import AuthInstance
from app.service.balance_service import BalanceServiceInstance
from app.client.engsel import get_balance, get_otp, submit_otp, get_family, get_package_details
from app.client.engsel2 import get_transaction_history
from app.client.purchase.balance import settlement_balance
from app.type_dict import PaymentItem
from app.config import ADMIN_IDS, user_states, State

# Handler Lain
from .akrab_handler import handle_akrab_callbacks
from app.menus.hot import kirim_menu_hot3, handle_pembelian_hot3
from app.client.atlantic import request_instant_deposit, check_deposit_status
from app.client.registration import dukcapil
from .creation_handler import start_account_creation
from app.utils import run_script 

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# =================================================================================
# == HANDLER MENU HOT 2 (DOR PAKET) - ASYNC
# =================================================================================

async def show_hot2_menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan Menu Dor Paket (Masa Aktif/Akrab)"""
    query = update.callback_query
    try: await query.answer()
    except: pass
    
    text = (
        "✅ <b>MASA AKTIF 30 HARI XL (DOR PAKET CLI)</b>\n\n"
        "Fitur ini memungkinkan inject paket tanpa login aplikasi.\n"
        "Silakan pilih menu di bawah:"
    )
    
    keyboard = [
        [InlineKeyboardButton("⚡ XL Masa Aktif / Akrab", callback_data='hot2_direct_family')],
        [InlineKeyboardButton("👉 Input Family Code Lain", callback_data='hot2_input_family')],
        [InlineKeyboardButton("🔙 Kembali", callback_data='menu_back_main')]
    ]
    
    try:
        await query.message.edit_text(text=text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
    except:
        await context.bot.send_message(update.effective_chat.id, text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_hot2_actions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    chat_id = update.effective_chat.id
    
    if data == 'hot2_direct_family':
        HARDCODED_CODE = "f4fd69c7-12a4-4047-a1f2-f4072a7c543e"
        await execute_family_search_async(update, context, HARDCODED_CODE)
        
    elif data == 'hot2_input_family':
        await query.message.edit_text(
            "📩 <b>Silakan kirimkan Family Code:</b>",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Batal", callback_data='menu_hot2')]])
        )
        user_states[chat_id] = State.AWAIT_FAMILY_CODE

async def execute_family_search_async(update: Update, context: ContextTypes.DEFAULT_TYPE, family_code: str):
    query = update.callback_query
    msg = query.message if query else update.message
    status_msg = await msg.edit_text("🔄 <b>Sedang mencari paket...</b>", parse_mode='HTML')
    
    try:
        api_key = AuthInstance.api_key
        tokens = AuthInstance.get_active_tokens()
        loop = asyncio.get_running_loop()

        # Jalankan fungsi sync get_family di thread terpisah
        fam_data = await loop.run_in_executor(None, get_family, api_key, tokens, family_code)
        
        if not fam_data:
            await loop.run_in_executor(None, AuthInstance.renew_active_user_token)
            tokens = AuthInstance.get_active_tokens()
            fam_data = await loop.run_in_executor(None, get_family, api_key, tokens, family_code)
        
        markup_back = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')]])

        if not fam_data or "package_variants" not in fam_data:
            await status_msg.edit_text("❌ <b>Paket tidak ditemukan!</b>", parse_mode='HTML', reply_markup=markup_back)
            return

        context.user_data['hot2_search_cache'] = {"family_code": family_code, "data": fam_data}

        variants = fam_data.get("package_variants", [])
        keyboard = []
        target_code = "f4fd69c7-12a4-4047-a1f2-f4072a7c543e"
        count = 1
        found_target = False

        for v_idx, variant in enumerate(variants):
            options = variant.get("package_options", [])
            for o_idx, option in enumerate(options):
                name = option.get("name", "Paket")
                price = option.get("price", 0)
                
                if family_code == target_code:
                    if count == 19:
                        keyboard.append([InlineKeyboardButton("🚀 BELI SEKARANG (Rp 5.000)", callback_data=f"fam_sel|{v_idx}|{o_idx}")])
                        found_target = True
                else:
                    keyboard.append([InlineKeyboardButton(f"{count}. {name} - Rp {price}", callback_data=f"fam_sel|{v_idx}|{o_idx}")])
                count += 1
        
        keyboard.append([InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')])
        await status_msg.edit_text("✅ <b>Paket Siap Dibeli.</b>", parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    except Exception as e:
        await status_msg.edit_text(f"❌ Error: {e}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')]]))

async def handle_family_selection_async(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer("🔄 Mengambil detail...")
    
    try:
        data_parts = query.data.split("|")
        v_idx, o_idx = int(data_parts[1]), int(data_parts[2])
        cached = context.user_data.get('hot2_search_cache')
        
        if not cached:
            await query.message.edit_text("❌ Sesi expired.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')]]))
            return

        fam_data = cached["data"]
        target_variant = fam_data["package_variants"][v_idx]
        target_option = target_variant["package_options"][o_idx]

        loop = asyncio.get_running_loop()
        full_detail = await loop.run_in_executor(None, get_package_details, AuthInstance.api_key, AuthInstance.get_active_tokens(), cached["family_code"], target_variant["package_variant_code"], target_option["order"], None, None)

        if not full_detail:
             await query.message.edit_text("❌ Gagal detail.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')]]))
             return

        context.user_data['hot2_selected_item'] = {"name": target_option["name"], "price": target_option["price"], "detail": full_detail}
        
        opt = full_detail.get("package_option") or {}
        msg = (f"📦 <b>KONFIRMASI PEMBELIAN</b>\n🏷️ <b>Nama:</b> {target_option['name']}\n"
               f"💰 <b>Biaya:</b> Rp 5.000 (Saldo Bot)\n⏳ <b>Masa Aktif:</b> 30 Hari\n"
               "⚠️ <i>Lanjutkan pembelian?</i>")

        keyboard = [[InlineKeyboardButton("✅ BELI SEKARANG", callback_data="pay_fam_confirm")], [InlineKeyboardButton("🔙 Batal", callback_data="menu_hot2")]]
        await query.message.edit_text(msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    except Exception as e:
        await query.message.edit_text(f"Error: {e}")

async def handle_family_payment_async(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    
    if BalanceServiceInstance.get_balance(chat_id) < 5000:
        await query.answer("❌ Saldo Bot Kurang! Min Rp 5.000", show_alert=True)
        return

    status_msg = await query.message.edit_text("⏳ <b>Memproses ke XL...</b>", parse_mode='HTML')

    try:
        selected = context.user_data.get('hot2_selected_item')
        if not selected: return

        detail = selected['detail']
        opt = detail.get("package_option") or {}
        payment_items = [PaymentItem(item_code=str(opt.get("package_option_code", "")), product_type="", item_price=selected["price"], item_name=str(selected["name"]), tax=0, token_confirmation=str(detail.get("token_confirmation") or ""))]

        loop = asyncio.get_running_loop()
        res = await loop.run_in_executor(None, settlement_balance, AuthInstance.api_key, AuthInstance.get_active_tokens(), payment_items, "BUY_PACKAGE", False, selected["price"], 0, -1)

        if isinstance(res, dict) and (res.get("status") == "SUCCESS" or res.get("code") == "00"):
            BalanceServiceInstance.reduce_balance(chat_id, 5000, f"Beli Paket: {selected['name']}")
            await status_msg.edit_text("✅ <b>SUKSES!</b> Paket Aktif.", parse_mode='HTML', reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')]]))
        else:
            await status_msg.edit_text(f"❌ Gagal: {res.get('message')}", parse_mode='HTML', reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data='menu_hot2')]]))

    except Exception as e:
        await status_msg.edit_text(f"❌ Error: {e}")

# =================================================================================
# == ROUTER CALLBACK (PENTING: HOT2 DI ATAS)
# =================================================================================

async def main_menu_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    command = query.data
    chat_id = update.effective_chat.id
    
    # [PRIORITAS 1] Menu HOT2 (Bypass Login/Admin)
    if command == 'menu_hot2':
        await show_hot2_menu_handler(update, context)
        return
    if command in ['hot2_direct_family', 'hot2_input_family']:
        await handle_hot2_actions(update, context)
        return
    if command.startswith('fam_sel|'):
        await handle_family_selection_async(update, context)
        return
    if command == 'pay_fam_confirm':
        await handle_family_payment_async(update, context)
        return
    if command == 'menu_back_main':
        await start(update, context)
        return

    # [PRIORITAS 2] Record & Login Check
    ProfileServiceInstance.record_user(query.from_user)
    active_user = AuthInstance.get_active_user(chat_id)
    SENSITIVE = ['hot3_', 'akrab_', 'menu_ssh', 'create_', 'menu_topup', 'admin_panel', 'menu_history', 'menu_logout']
    
    if any(command.startswith(x) for x in SENSITIVE) and not active_user:
        await query.answer("⚠️ Wajib Login OTP dulu.", show_alert=True)
        return

    # [PRIORITAS 3] Routing Lainnya
    if command == 'menu_login':
        await query.message.edit_text("Masukkan No XL:")
        user_states[chat_id] = State.ENTER_PHONE
    elif command == 'menu_hot3': await kirim_menu_hot3(update, context)
    elif command.startswith('hot3_buy'): await handle_pembelian_hot3(update, context)
    elif command.startswith('menu_akrab') or command.startswith('akrab_'): await handle_akrab_callbacks(update, context)
    elif command == 'menu_ssh': 
        # Tampilkan menu SSH sederhana (inline) karena fungsi import mungkin hilang
        await query.message.edit_text("Menu SSH", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Create SSH", callback_data='create_sshws_sg'), InlineKeyboardButton("Kembali", callback_data='menu_back_main')]]))
    elif command.startswith('create_'): await start_account_creation(update, context, service_type="SSH WS") # Simplified
    elif command == 'menu_topup': 
        from .topup_handlers import topup_menu_handler
        await topup_menu_handler(update, context)
    elif command == 'admin_panel': 
        from .admin_handlers import admin_panel_handler
        await admin_panel_handler(update, context)
    elif command == 'menu_history': 
        # Simplified history
        await query.message.edit_text("Menu Riwayat", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Kembali", callback_data='menu_back_main')]]))
    elif command == 'menu_logout':
        AuthInstance.logout(chat_id)
        await query.message.edit_text("Logout Sukses.")
        await start(update, context)
    elif command == 'menu_close': await query.message.delete()

# =================================================================================
# == HANDLER TEXT (START & INPUT)
# =================================================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user or (update.callback_query and update.callback_query.from_user)
    if update.message: user_states.pop(chat_id, None)
    
    text = f"Halo {user.mention_html()}! Selamat datang."
    
    # Menu Utama
    kb = [
        [InlineKeyboardButton("🚀 DOR PAKET NON LEGAL (CLI)", callback_data='menu_hot2')],
        [InlineKeyboardButton("📱 HOT-3", callback_data='menu_hot3'), InlineKeyboardButton("👨‍👩‍👧‍👦 Akrab", callback_data='menu_akrab')],
        [InlineKeyboardButton("👤 Login", callback_data='menu_login'), InlineKeyboardButton("⚙️ Admin", callback_data='admin_panel')],
        [InlineKeyboardButton("Tutup", callback_data='menu_close')]
    ]
    
    if update.callback_query:
        await update.callback_query.message.edit_text(text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(kb))
    else:
        await context.bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(kb))

async def login_flow_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = user_states.get(chat_id)

    if state == State.AWAIT_FAMILY_CODE:
        code = update.message.text.strip()
        user_states.pop(chat_id, None)
        await execute_family_search_async(update, context, code)
        return True

    if state == State.ENTER_PHONE:
        phone = "".join(filter(str.isdigit, update.message.text))
        if phone.startswith('08'): phone = '62' + phone[1:]
        loop = asyncio.get_running_loop()
        res = await loop.run_in_executor(None, get_otp, phone)
        if res:
            context.user_data['phone_number'] = phone
            await update.message.reply_text("✅ Masukkan OTP:")
            user_states[chat_id] = State.ENTER_OTP
        else:
            await update.message.reply_text("❌ Gagal OTP.")
        return True

    if state == State.ENTER_OTP:
        otp = update.message.text.strip()
        phone = context.user_data.get('phone_number')
        loop = asyncio.get_running_loop()
        res = await loop.run_in_executor(None, submit_otp, AuthInstance.api_key, phone, otp)
        if res and "refresh_token" in res:
            AuthInstance.set_active_user(chat_id, int(phone))
            await update.message.reply_text("✅ Login Sukses!")
            await start(update, context)
        else:
            await update.message.reply_text("❌ OTP Salah.")
        return True
    
    return False
