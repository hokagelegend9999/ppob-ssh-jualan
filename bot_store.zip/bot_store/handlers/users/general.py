import telebot
import math
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ForceReply
from telebot.apihelper import ApiTelegramException

# --- IMPORT UTAMA (JANGAN DIHAPUS) ---
from bot_init import bot
from config import ADMIN_ID, ATLANTIC_API_KEY, ATLANTIC_DEPOSIT_STATUS_URL
from menus import menu_admin
from activity_tracker import get_online_icon

# --- IMPORT DATABASE LENGKAP ---
from database import (
    get_all_users_list, 
    find_user, 
    get_user_transaction_history, 
    set_role, 
    set_reseller_start, 
    get_user_data, 
    get_user_data_complete, 
    update_saldo, 
    update_user_role
)

# Helper Rupiah
def format_rupiah(value):
    return f"Rp {value:,}"

# ==========================================
# 1. LIST MEMBER & RESELLER
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "list_member" or call.data.startswith("list_member|"))
def list_member_pagination(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "Akses Ditolak")
    
    if "|" in call.data: page = int(call.data.split("|")[1])
    else: page = 1 

    all_users = get_all_users_list()
    LIMIT = 10
    total_items = len(all_users)
    total_pages = math.ceil(total_items / LIMIT)
    if page > total_pages: page = total_pages
    if page < 1: page = 1

    offset = (page - 1) * LIMIT
    current_users = all_users[offset : offset + LIMIT]

    msg = f"👥 <b>DAFTAR SEMUA MEMBER ({total_items})</b>\n📄 Halaman {page}/{total_pages}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    for i, user in enumerate(current_users, 1):
        uid = user[0]
        try: saldo = int(user[1])
        except: saldo = 0
        try: role = str(user[2]).upper()
        except: role = "USER"
        try: nama = user[3] if user[3] else "Unknown"
        except: nama = "Unknown"
        try: username = user[4]
        except: username = None

        saldo_fmt = f"Rp {saldo:,}".replace(",", ".")
        
        online_stat = get_online_icon(uid)
        role_icon = "⚡" if "RESELLER" in role else "👤"
        warning_sign = "⚠️" if nama == "Unknown" or not username else ""
        nama_display = "Unknown (No Username)" if warning_sign else nama

        msg += f"<b>{offset + i}. {online_stat} {nama_display} {role_icon} {warning_sign}</b>\n"
        msg += f"   🆔 <code>{uid}</code> | 💰 {saldo_fmt}\n   ────────────────\n"

    markup = InlineKeyboardMarkup()
    nav_btns = []
    if page > 1: nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"list_member|{page-1}"))
    nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    if page < total_pages: nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"list_member|{page+1}"))
    markup.row(*nav_btns)
    markup.add(InlineKeyboardButton("🔙 KEMBALI MENU", callback_data="switch_owner"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except ApiTelegramException as e:
        if "message is not modified" in str(e):
            # Jika errornya karena pesan tidak berubah, abaikan saja (Pass)
            pass 
        else:
            # Jika error lain (misal pesan terhapus), kirim pesan baru
            bot.send_message(call.message.chat.id, msg, parse_mode="HTML", reply_markup=markup)
    except Exception as e:
        # Error python lainnya
        print(f"Error UI: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "list_reseller" or call.data.startswith("list_reseller|"))
def list_reseller_pagination(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    if "|" in call.data: page = int(call.data.split("|")[1])
    else: page = 1 

    all_users = get_all_users_list()
    resellers = [u for u in all_users if 'reseller' in str(u[2]).lower()]
    LIMIT = 10
    total_items = len(resellers)
    total_pages = math.ceil(total_items / LIMIT)
    if page > total_pages: page = total_pages
    if page < 1: page = 1
    offset = (page - 1) * LIMIT
    current_users = resellers[offset : offset + LIMIT]

    msg = f"⚡ <b>DAFTAR RESELLER ({total_items})</b>\n📄 Halaman {page}/{total_pages}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not resellers: msg += "\n<i>Belum ada Reseller terdaftar.</i>"
    for i, user in enumerate(current_users, 1):
        uid = user[0]
        try: saldo = int(user[1])
        except: saldo = 0
        try: nama = user[3]
        except: nama = "Unknown"
        saldo_fmt = f"Rp {saldo:,}".replace(",", ".")
        msg += f"<b>{offset + i}. ⚡ {nama}</b>\n   🆔 <code>{uid}</code> | 💰 {saldo_fmt}\n   ────────────────\n"

    markup = InlineKeyboardMarkup()
    nav_btns = []
    if page > 1: nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"list_reseller|{page-1}"))
    nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    if page < total_pages: nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"list_reseller|{page+1}"))
    markup.row(*nav_btns)
    markup.add(InlineKeyboardButton("🔙 KEMBALI MENU", callback_data="switch_owner"))
    try: bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except ApiTelegramException: pass

# ==========================================
# 2. MENU CARI USER & RIWAYAT (PERBAIKAN TOMBOL)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "check_user_history" or call.data.startswith("hist_page|"))
def check_user_history_pagination(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    if "hist_page|" in call.data: 
        page = int(call.data.split("|")[1])
    else: 
        page = 1 

    all_users = get_all_users_list()
    LIMIT = 10
    total_items = len(all_users)
    total_pages = math.ceil(total_items / LIMIT)
    
    if page > total_pages: page = total_pages
    if page < 1: page = 1
    
    offset = (page - 1) * LIMIT
    current_users = all_users[offset : offset + LIMIT]

    msg = f"🔍 <b>DATABASE MEMBER & RESELLER</b>\n"
    msg += f"📊 Total terdaftar: <code>{total_items}</code> User\n"
    msg += f"📑 Halaman: <code>{page}/{total_pages}</code>\n"
    msg += "━━━━━━━━━━━━━━━━━━━━━\n\n"

    markup = InlineKeyboardMarkup(row_width=5) 
    btn_numbers = []

    for i, user in enumerate(current_users, 1):
        uid = user[0]
        try: saldo = int(user[1])
        except: saldo = 0
        role = str(user[2]).upper()
        nama = user[3] if user[3] else "Unknown"
        
        role_icon = "⚡" if "RESELLER" in role else "👤"
        status_icon = get_online_icon(uid)
        
        # Nomor urut yang benar (Global)
        nomor_urut = offset + i
        
        msg += f"<b>[{nomor_urut}]</b> {status_icon} <b>{nama}</b> {role_icon}\n"
        msg += f"╰ ID: <code>{uid}</code> | 💰 Rp {saldo:,}\n"
        msg += "─────────────────────\n"
        
        # --- PERBAIKAN DI SINI ---
        # Label tombol sekarang menggunakan nomor_urut (17, 18...) bukan i (1, 2...)
        btn_numbers.append(InlineKeyboardButton(str(nomor_urut), callback_data=f"hist_{uid}_1"))

    msg += "\n👇 <b>Pilih nomor untuk Detail & Riwayat:</b>"
    
    markup.add(*btn_numbers)
    
    nav_btns = []
    if page > 1: 
        nav_btns.append(InlineKeyboardButton("⏪ Prev", callback_data=f"hist_page|{page-1}"))
    
    nav_btns.append(InlineKeyboardButton(f"💎 {page}/{total_pages}", callback_data="ignore"))
    
    if page < total_pages: 
        nav_btns.append(InlineKeyboardButton("Next ⏩", callback_data=f"hist_page|{page+1}"))
    
    markup.row(*nav_btns)
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))

    try: 
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except ApiTelegramException: 
        pass
        
# ==========================================
# HANDLER AKSI: CEK STATUS PROVIDER
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("cek_provider|") or call.data.startswith("cp|"))
def handler_cek_provider_realtime(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        data = call.data.split("|")
        
        if len(data) < 4:
            return bot.answer_callback_query(call.id, "❌ Data transaksi rusak/tidak lengkap.")
            
        ref_id = data[1]
        tujuan = data[2]
        kode_produk = data[3]
        target_user_id = data[4] if len(data) > 4 else None
        
        bot.answer_callback_query(call.id, "⏳ Menghubungi Server Pusat...")

        try:
            from orderkuota_service import check_orderkuota_status
            hasil_cek = check_orderkuota_status(ref_id, tujuan, kode_produk)
        except ImportError:
            hasil_cek = "Module orderkuota_service belum diimport."

        msg_text = (
            f"📡 <b>HASIL CEK STATUS PROVIDER</b>\n"
            f"➖➖➖➖➖➖➖➖➖➖\n"
            f"🆔 RefID : <code>{ref_id}</code>\n"
            f"📱 Tujuan : <code>{tujuan}</code>\n"
            f"📦 Produk : {kode_produk}\n\n"
            f"📝 <b>Respon Server Pusat:</b>\n"
            f"<code>{hasil_cek}</code>"
        )

        markup = InlineKeyboardMarkup()
        if target_user_id:
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data=f"hist_{target_user_id}_1"))
        else:
            markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="list_member|1"))

        bot.send_message(
            call.message.chat.id, 
            msg_text, 
            parse_mode="HTML", 
            reply_markup=markup
        )

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error System: {str(e)}")

## ==========================================
#  HANDLER DETAIL RIWAYAT USER (FIXED UI & REFRESH BUTTON)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("hist_") and "page" not in call.data)
def detail_user_history(call):
    try:
        parts = call.data.split("_")
        target_id = parts[1]
        page = int(parts[2]) if len(parts) > 2 else 1
    except:
        return bot.answer_callback_query(call.id, "❌ Format Data Error")

    user = get_user_data_complete(target_id)
    if not user:
        return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")
    
    # Helper aman untuk ambil data list
    def safe_get(data, index, default="-"):
        try: 
            val = data[index] if len(data) > index else default
            return val if val is not None else default 
        except: return default

    u_name = safe_get(user, 1, "User")
    u_saldo = safe_get(user, 2, 0)
    u_role = str(safe_get(user, 3, "USER")).upper()
    
    history = get_user_transaction_history(target_id)
    
    LIMIT = 5 
    if not history or not isinstance(history, list): history = []
        
    total_items = len(history)
    total_pages = (total_items + LIMIT - 1) // LIMIT
    if page > total_pages: page = total_pages if total_pages > 0 else 1
    if page < 1: page = 1

    offset = (page - 1) * LIMIT
    current_history = history[offset : offset + LIMIT]

    msg =  f"👑 <b>DASHBOARD MANAGEMENT</b>\n"
    msg += f"<code>──────────────────────────────</code>\n"
    msg += f"👤 <b>NAME        :</b> <code>{u_name}</code>\n"
    msg += f"🆔 <b>USER ID     :</b> <code>{target_id}</code>\n"
    msg += f"💎 <b>RANK        :</b> <code>{u_role}</code>\n"
    msg += f"💰 <b>SALDO SKRG:</b> <b>Rp {u_saldo:,}</b>\n".replace(",", ".")
    msg += f"<code>──────────────────────────────</code>\n\n"
    msg += f"📊 <b>DETIL RIWAYAT ({page}/{total_pages}):</b>\n\n"

    markup = InlineKeyboardMarkup()
    row_btns = []

    if not current_history:
        msg += "<i>📭 Belum ada riwayat transaksi.</i>"
    else:
        import re 
        import sqlite3

        for i, item in enumerate(current_history, start=offset + 1): 
            t_date    = safe_get(item, 0, "-")
            raw_amount = safe_get(item, 2, 0)
            try: t_amount = int(raw_amount)
            except: t_amount = 0
            
            t_status  = safe_get(item, 3, "pending")
            t_dest    = safe_get(item, 4, "-")
            t_sn      = safe_get(item, 5, "-") 
            
            raw_saldo_awal = safe_get(item, 6, 0)
            try: t_saldo_awal = int(raw_saldo_awal)
            except: t_saldo_awal = 0
            
            raw_saldo_akhir = safe_get(item, 7, 0)
            try: t_saldo_akhir = int(raw_saldo_akhir)
            except: t_saldo_akhir = 0
            
            t_ref_id = str(safe_get(item, 8, "-"))

            # --- DB LOOKUP ---
            real_desc_db = "-"
            try:
                conn_fix = sqlite3.connect("store_data.db", timeout=5)
                c_fix = conn_fix.cursor()
                c_fix.execute("SELECT description FROM transactions WHERE ref_id = ?", (t_ref_id,))
                row_fix = c_fix.fetchone()
                if row_fix and row_fix[0]: real_desc_db = row_fix[0]
                conn_fix.close()
            except:
                real_desc_db = str(safe_get(item, 1, "-"))

            # --- LOGIKA NOMINAL & SALDO ---
            real_amount = t_amount
            if real_amount == 0 and t_saldo_akhir != t_saldo_awal:
                real_amount = t_saldo_akhir - t_saldo_awal

            if t_saldo_awal == 0 and t_saldo_akhir != 0:
                t_saldo_awal = t_saldo_akhir - real_amount

            # --- LOGIKA TIPE ---
            clean_desc = real_desc_db
            username_ssh = None
            is_vpn = False
            is_deposit_user = False 
            is_admin_inject = False 
            is_ppob = False

            if t_ref_id.startswith("SYS-"):
                is_vpn = True
                match = re.search(r'\((.*?)\)', real_desc_db)
                if match:
                    username_ssh = match.group(1)
                    clean_desc = real_desc_db.replace(f"({username_ssh})", "")
                clean_desc = clean_desc.replace("Manual", "").strip()
                if not clean_desc or clean_desc == "-": clean_desc = "SSH/VPN SERVER"

            elif "ADM" in t_ref_id:
                is_admin_inject = True
                clean_desc = "KOREKSI ADMIN"

            elif real_amount > 0 and not is_admin_inject:
                is_deposit_user = True
                clean_desc = "DEPOSIT SALDO"
                
            elif t_ref_id.startswith("TRX") or t_ref_id.startswith("ATL"):
                is_ppob = True
                clean_desc = real_desc_db.replace("pembelian", "").replace("Pembelian", "").strip()

            # --- FORMAT TEXT ---
            val_awal = f"Rp {t_saldo_awal:,}".replace(",", ".")
            val_akhir = f"Rp {t_saldo_akhir:,}".replace(",", ".")
            
            if real_amount > 0: val_trx = f"+Rp {real_amount:,}".replace(",", ".")
            else: val_trx = f"-Rp {abs(real_amount):,}".replace(",", ".")

            str_date = str(t_date)
            try:
                jam = str_date[11:16]
                tanggal = str_date[8:10] + "-" + str_date[5:7] + "-" + str_date[:4]
            except: jam, tanggal = "-", "-"

            status_lower = str(t_status).lower()
            if "sukses" in status_lower: stat_icon = "🟢"
            elif "gagal" in status_lower: stat_icon = "🔴"
            else: stat_icon = "🟡"

            # RENDER PESAN
            msg += f"<b>{i}. {stat_icon} {clean_desc}</b>\n"
            msg += f"   Ref Id: <code>{t_ref_id}</code>\n"
            msg += f"   {jam} | {tanggal}\n"
            
            if val_awal != "Rp 0" and val_awal != "-":
                 msg += f"   Saldo Sebelum : {val_awal}\n"
                 msg += f"   Saldo Sesudah : {val_akhir}\n"
            
            msg += f"   Nominal : <b>{val_trx}</b>\n"

            final_dest = "-"
            if is_vpn and username_ssh: final_dest = username_ssh
            elif t_dest and str(t_dest) not in ["-", "0", "None", ""]: final_dest = t_dest
            
            if final_dest != "-": msg += f"   Tujuan : <code>{final_dest}</code>\n"
            
            raw_sn = str(t_sn).strip()
            if raw_sn and raw_sn not in ["-", "", "None"] and is_ppob:
                 if "gagal" in status_lower: msg += f"   Info : <code>{raw_sn[:30]}...</code>\n"
                 else: msg += f"   SN : <code>{raw_sn}</code>\n"
            msg += "\n"

            # === [PERBAIKAN TOMBOL: GANTI COPY JADI REFRESH] ===
            # Ini yang mengatasi error "Data rusak/tidak lengkap"
            if is_ppob:
                cb_data = f"chk|{t_ref_id}|{target_id}"
                row_btns.append(InlineKeyboardButton(f"{i} 🔄", callback_data=cb_data))
            elif is_vpn:
                row_btns.append(InlineKeyboardButton(f"{i} ☁️", callback_data="ignore"))
            elif is_deposit_user:
                 cb_data = f"chk_depo|{t_ref_id}|{target_id}"
                 row_btns.append(InlineKeyboardButton(f"{i} 👁️", callback_data=cb_data))
            else:
                row_btns.append(InlineKeyboardButton("🔒", callback_data="ignore"))

            if len(row_btns) == 5:
                markup.row(*row_btns)
                row_btns = []

    if row_btns: markup.row(*row_btns)

    nav_btns = []
    if page > 1: nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"hist_{target_id}_{page-1}"))
    if total_pages > 1: nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    if page < total_pages: nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"hist_{target_id}_{page+1}"))
    markup.row(*nav_btns)

    msg += f"<code>──────────────────────────────</code>\n"
    msg += f"✨ <i>Klik nomor 👁️ untuk Cek Status Deposit</i>\n"
    msg += f"✨ <i>Klik nomor 🔄 untuk Cek/Refund PPOB</i>"

    markup.add(
        InlineKeyboardButton("➕ ISI SALDO", callback_data=f"saldo_add_shortcut|{target_id}"),
        InlineKeyboardButton("➖ POTONG", callback_data=f"saldo_min_shortcut|{target_id}")
    )
    markup.add(InlineKeyboardButton("🔄 REFRESH LIST", callback_data=f"hist_{target_id}_{page}"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE LIST USER", callback_data="check_user_history"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except Exception:
        bot.send_message(call.message.chat.id, msg, parse_mode="HTML", reply_markup=markup)

# ==========================================
#  HANDLER TOMBOL IGNORE (AGAR TIDAK ERROR)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "ignore")
def handler_ignore_button(call):
    # Cukup hilangkan loading jam pasir, tanpa pesan error
    bot.answer_callback_query(call.id)
# ==========================================
#  HANDLER CEK PROVIDER (WAJIB ADA DI ADMIN.PY)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("cek_provider|"))
def handler_cek_provider_realtime_admin(call):
    # 1. Cek Admin
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        # 2. Parsing Data (Memecah data dari tombol)
        data = call.data.split("|")
        # Format tombol: cek_provider | ref_id | tujuan | kode | user_id
        
        if len(data) < 4:
            return bot.answer_callback_query(call.id, "❌ Data transaksi rusak.")
            
        ref_id = data[1]
        tujuan = data[2]
        kode_produk = data[3]
        target_user_id = data[4] if len(data) > 4 else None
        
        # 3. Beri feedback visual "Loading..."
        bot.answer_callback_query(call.id, "⏳ Menghubungi Server Pusat...")

        # 4. Panggil Service OrderKuota
        try:
            # Import manual di dalam fungsi agar tidak error circular import
            from orderkuota_service import check_orderkuota_status
            
            # Eksekusi Cek Status
            hasil_cek = check_orderkuota_status(
                ref_id=ref_id, 
                nomor_tujuan=tujuan, 
                kode_produk=kode_produk
            )
        except ImportError:
            hasil_cek = "❌ Error: File orderkuota_service.py tidak ditemukan/gagal import."
        except Exception as e:
            hasil_cek = f"❌ Error System: {str(e)}"

        # 5. Auto Update Database jika Sukses
        # Jika respon mengandung kata "SN" dan bukan "Sedang Proses", anggap sukses
        if "SN" in str(hasil_cek) and "Sedang Proses" not in str(hasil_cek):
            try:
                # Ambil SN menggunakan Regex
                import re
                match = re.search(r"SN:?\s*([A-Za-z0-9\/]+)", str(hasil_cek))
                if match:
                    real_sn = match.group(1)
                    # Update status transaksi di database jadi SUKSES
                    update_transaction_status(ref_id, "sukses", real_sn)
            except: pass

        # 6. Tampilkan Hasil
        msg_text = (
            f"📡 <b>HASIL CEK STATUS PROVIDER</b>\n"
            f"➖➖➖➖➖➖➖➖➖➖\n"
            f"🆔 RefID : <code>{ref_id}</code>\n"
            f"📱 Tujuan : <code>{tujuan}</code>\n"
            f"📦 Kode  : {kode_produk}\n\n"
            f"📝 <b>Respon Server Pusat:</b>\n"
            f"<code>{hasil_cek}</code>"
        )

        markup = InlineKeyboardMarkup()
        if target_user_id:
            # Tombol kembali ke riwayat user tersebut
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data=f"hist_{target_user_id}_1"))
        else:
            markup.add(InlineKeyboardButton("🔙 TUTUP", callback_data="admin_panel"))

        # Kirim pesan hasil
        bot.send_message(call.message.chat.id, msg_text, parse_mode="HTML", reply_markup=markup)

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error Handler: {str(e)}")

# Handler Copy untuk Admin (jika belum ada)
@bot.callback_query_handler(func=lambda call: call.data.startswith("cp|"))
def handler_copy_sn_admin(call):
    try:
        parts = call.data.split("|")
        sn_text = "|".join(parts[2:])
        bot.answer_callback_query(call.id, f"🔑 SN: {sn_text}", show_alert=True)
    except: pass


# ==========================================
# HANDLER BARU: COPY SN (POP-UP)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("cp|"))
def handler_copy_sn(call):
    try:
        # Format Data: cp | target_id | sn_text
        parts = call.data.split("|")
        
        # Ambil SN (gabungkan kembali jika ada spasi/pemisah yg ikut ter-split)
        sn_text = "|".join(parts[2:]) if len(parts) > 2 else "Tidak ada SN"
        
        # Tampilkan Alert (Pop-up) berisi SN
        bot.answer_callback_query(call.id, f"🔑 SN: {sn_text}", show_alert=True)
        
    except Exception as e:
        print(f"Error Copy SN: {e}")
        bot.answer_callback_query(call.id, "Gagal copy SN.")




# --- 3. SHORTCUT SALDO ---
@bot.callback_query_handler(func=lambda call: "saldo_add_shortcut" in call.data)
def shortcut_add_saldo(call):
    # Import manual karena circular import
    from handlers.users.admin_saldo import process_saldo_add_step2
    target_id = call.data.split("|")[1]
    msg = bot.send_message(call.message.chat.id, f"➕ <b>ISI SALDO MANUAL</b>\nTarget ID: <code>{target_id}</code>\n\nMasukkan Nominal (Tanpa Titik):", parse_mode='HTML')
    bot.register_next_step_handler(msg, process_saldo_add_step2, target_id)

@bot.callback_query_handler(func=lambda call: "saldo_min_shortcut" in call.data)
def shortcut_deduct_saldo(call):
    from handlers.users.admin_saldo import process_saldo_deduct_step2
    target_id = call.data.split("|")[1]
    msg = bot.send_message(call.message.chat.id, f"➖ <b>POTONG SALDO MANUAL</b>\nTarget ID: <code>{target_id}</code>\n\nMasukkan Nominal Potongan:", parse_mode='HTML')
    bot.register_next_step_handler(msg, process_saldo_deduct_step2, target_id)

# ==========================================
# 4. MANUAL MANAGEMENT RESELLER
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "manual_add_reseller")
def manual_add_reseller_start(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    render_manual_role_page(call.message.chat.id, 1, mode='send', action_type='up')

@bot.callback_query_handler(func=lambda call: call.data.startswith("man_role_nav|"))
def manual_role_navigation(call):
    try:
        _, page_str, action_type = call.data.split("|")
        page = int(page_str)
        render_manual_role_page(call.message.chat.id, page, message_id=call.message.message_id, mode='edit', action_type=action_type)
    except Exception as e:
        print(f"Error Nav: {e}")

def render_manual_role_page(chat_id, page, message_id=None, mode='edit', action_type='up'):
    all_users = get_all_users_list()
    
    if action_type == 'up':
        target_list = [u for u in all_users if 'reseller' not in str(u[2]).lower()]
        title = "⚡ ANGKAT RESELLER MANUAL"
        prompt_text = "balas pesan ini dengan ID User untuk dijadikan RESELLER"
        btn_switch_text = "🔄 Switch ke Mode: HAPUS RESELLER"
        next_action_type = 'down' 
    else:
        target_list = [u for u in all_users if 'reseller' in str(u[2]).lower()]
        title = "🗑️ HAPUS RESELLER (DOWNGRADE)"
        prompt_text = "balas pesan ini dengan ID Reseller untuk dikembalikan jadi USER"
        btn_switch_text = "🔄 Switch ke Mode: ANGKAT RESELLER"
        next_action_type = 'up'

    LIMIT = 10
    total_items = len(target_list)
    total_pages = math.ceil(total_items / LIMIT)
    
    if page > total_pages: page = total_pages
    if page < 1: page = 1
    
    offset = (page - 1) * LIMIT
    current_list = target_list[offset : offset + LIMIT]
    
    msg_text = f"<b>{title}</b>\n"
    msg_text += f"📊 Total: {total_items} Akun\n"
    msg_text += f"📄 Halaman {page}/{total_pages}\n"
    msg_text += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    if not current_list:
        msg_text += "<i>Tidak ada data tersedia.</i>\n"
    else:
        for u in current_list:
            uid = u[0]
            role = str(u[2]).upper()
            nama = u[3] if u[3] else "Unknown"
            uname = f"@{u[4]}" if u[4] else "-"
            
            icon = "👤" if action_type == 'up' else "⚡"
            
            msg_text += f"{icon} <b>{nama}</b> ({uname})\n"
            msg_text += f"└ 🆔 <code>{uid}</code> | {role}\n"
    
    msg_text += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg_text += f"👉 <b>Silakan {prompt_text}:</b>\n"
    msg_text += "<i>Contoh: 1234567890</i>"

    markup = InlineKeyboardMarkup()
    nav_btns = []
    
    if page > 1:
        nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"man_role_nav|{page-1}|{action_type}"))
    
    nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    
    if page < total_pages:
        nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"man_role_nav|{page+1}|{action_type}"))
        
    markup.row(*nav_btns)
    markup.add(InlineKeyboardButton(btn_switch_text, callback_data=f"man_role_nav|1|{next_action_type}"))
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="switch_owner"))

    if mode == 'send':
        sent_msg = bot.send_message(chat_id, msg_text, parse_mode='HTML', reply_markup=markup)
        bot.register_next_step_handler(sent_msg, process_manual_role_input)
    else:
        try:
            bot.edit_message_text(msg_text, chat_id, message_id, parse_mode='HTML', reply_markup=markup)
        except ApiTelegramException: pass

def process_manual_role_input(message):
    try:
        target_id = message.text.strip()
        
        if not target_id.isdigit(): 
            msg = bot.reply_to(message, "❌ <b>ID harus angka!</b> Input ulang:", parse_mode='HTML')
            return bot.register_next_step_handler(msg, process_manual_role_input)
            
        user = find_user(target_id)
        if not user: 
            msg = bot.reply_to(message, f"❌ ID <code>{target_id}</code> tidak ditemukan.", parse_mode='HTML')
            return bot.register_next_step_handler(msg, process_manual_role_input)
        
        u_complete = get_user_data_complete(target_id)
        current_role = str(u_complete[3]).lower() if u_complete else "user"
        u_nama = u_complete[1] if u_complete and u_complete[1] else "Unknown"

        markup = InlineKeyboardMarkup()
        
        if "reseller" in current_role:
            action_code = "down"
            text_confirm = (f"⚠️ <b>KONFIRMASI HAPUS RESELLER</b>\n"
                            f"User: <b>{u_nama}</b>\n"
                            f"Status Saat Ini: ⚡ RESELLER\n\n"
                            f"Yakin ingin kembalikan jadi <b>USER BIASA</b>?")
            btn_text = "✅ YA, JADIKAN USER"
        else:
            action_code = "up"
            text_confirm = (f"⚠️ <b>KONFIRMASI ANGKAT RESELLER</b>\n"
                            f"User: <b>{u_nama}</b>\n"
                            f"Status Saat Ini: 👤 USER\n\n"
                            f"Yakin ingin angkat jadi <b>RESELLER</b>?")
            btn_text = "✅ YA, JADIKAN RESELLER"

        markup.row(
            InlineKeyboardButton(btn_text, callback_data=f"exec_role|{action_code}|{target_id}"),
            InlineKeyboardButton("❌ BATAL", callback_data="switch_owner")
        )
        
        bot.send_message(message.chat.id, text_confirm, parse_mode='HTML', reply_markup=markup)

    except Exception as e:
        bot.reply_to(message, f"❌ Error: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith("exec_role|"))
def execute_role_change(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    _, action, target_id = call.data.split("|")
    
    if action == "up":
        new_role = "reseller"
        msg_success = f"✅ User <code>{target_id}</code> resmi jadi <b>RESELLER</b>."
        msg_user = "🎉 Selamat! Akun Anda telah diupgrade menjadi <b>RESELLER</b>."
        try: set_reseller_start(target_id) 
        except: pass
    else:
        new_role = "user"
        msg_success = f"✅ Reseller <code>{target_id}</code> telah didowngrade jadi <b>USER</b>."
        msg_user = "⚠️ Akun Anda telah dikembalikan menjadi status <b>USER</b>."

    if update_user_role(target_id, new_role):
        bot.answer_callback_query(call.id, "✅ Sukses!", show_alert=True)
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))
        
        bot.edit_message_text(msg_success, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        
        try: bot.send_message(target_id, msg_user, parse_mode='HTML')
        except: pass
    else:
        bot.answer_callback_query(call.id, "❌ Gagal update DB.", show_alert=True)
    
@bot.callback_query_handler(func=lambda call: call.data == "check_user_by_id_menu")
def ask_user_id_detail(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    try:
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except:
        pass

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 BATAL / KEMBALI", callback_data="switch_owner"))

    msg = bot.send_message(
        call.message.chat.id,
        "🔎 **MODE CEK USER DETAIL**\n\n"
        "Silakan balas pesan ini dengan:\n"
        "1. **ID Telegram** (Contoh: `123456789`)\n"
        "2. **Username** (Contoh: `@username`)\n\n"
        "👇 _Ketik input di bawah:_ ",
        parse_mode="Markdown",
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, process_find_user_detail)
    
@bot.callback_query_handler(func=lambda call: call.data == "cancel_check_user")
def cancel_check_user_process(call):
    try:
        bot.clear_step_handler_by_chat_id(call.message.chat.id)

        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except:
            pass

        try:
            from menus import menu_admin
            reply_markup = menu_admin(call.from_user.id)
        except ImportError:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL UTAMA", callback_data="switch_owner"))
            reply_markup = markup

        bot.send_message(
            call.message.chat.id, 
            "⚡ <b>PANEL ADMIN UTAMA</b>\nSilakan pilih menu management:", 
            parse_mode='HTML',
            reply_markup=reply_markup
        )

    except Exception as e:
        print(f"Error Cancel: {e}")
        bot.send_message(call.message.chat.id, "✅ Mode Cek User Dibatalkan.")

def process_find_user_detail(message):
    try:
        query = message.text.strip()
        
        if query.startswith("/"):
            return 

        user_data = find_user(query) 

        if not user_data:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 Coba Cari Lagi", callback_data="check_user_by_id_menu"))
            markup.add(InlineKeyboardButton("🔙 Kembali Menu Utama", callback_data="switch_owner"))
            
            return bot.reply_to(
                message, 
                f"❌ <b>Data tidak ditemukan!</b>\n\n"
                f"Input: <code>{query}</code>\n"
                f"Pastikan ID atau Username benar dan user sudah terdaftar di bot.", 
                parse_mode="HTML", 
                reply_markup=markup
            )

        u_id = user_data[0]
        u_name = user_data[1] if user_data[1] else "Tanpa Nama"
        u_balance = user_data[2] if user_data[2] else 0
        u_role = user_data[3] if user_data[3] else "user"
        u_username = f"@{user_data[4]}" if user_data[4] else "-"

        saldo_fmt = "{:,}".format(u_balance).replace(",", ".")

        text_detail = (
            f"👤 <b>DETAIL USER DITEMUKAN</b>\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 ID: <code>{u_id}</code>\n"
            f"👤 Nama: {u_name}\n"
            f"🏷 Username: {u_username}\n"
            f"💰 Saldo: <b>Rp {saldo_fmt}</b>\n"
            f"🔰 Role: <b>{u_role.upper()}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"👇 <i>Pilih aksi untuk user ini:</i>"
        )

        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("➕ Tambah Saldo", callback_data=f"add_saldo|{u_id}"),
            InlineKeyboardButton("➖ Potong Saldo", callback_data=f"min_saldo|{u_id}")
        )
        markup.add(
            InlineKeyboardButton("📜 Cek Riwayat", callback_data=f"hist_{u_id}_1"),
            InlineKeyboardButton("🔄 Reset Sesi", callback_data=f"reset_session|{u_id}")
        )
        
        if "user" in str(u_role).lower():
            markup.add(InlineKeyboardButton("⬆️ Up ke Reseller", callback_data=f"up_reseller|{u_id}"))
        elif "reseller" in str(u_role).lower():
            markup.add(InlineKeyboardButton("⬇️ Down ke User", callback_data=f"down_user|{u_id}"))

        markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL ADMIN", callback_data="switch_owner"))

        bot.send_message(message.chat.id, text_detail, parse_mode="HTML", reply_markup=markup)

    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Terjadi kesalahan system: {e}")

# ==========================================
# HANDLER AKSI: CEK RIWAYAT BY ID
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("history_by_id|"))
def action_history_by_id(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    _, target_id = call.data.split("|")
    
    # Panggil fungsi detail history
    # Karena kita ada di file yang sama, kita bisa panggil langsung (dengan trick manipulasi call.data)
    call.data = f"hist_{target_id}_1"
    detail_user_history(call)

# ==========================================
# HANDLER AKSI: RESET SESI LOGIN (CLI)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("reset_session|"))
def action_reset_session(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    _, target_id = call.data.split("|")
    
    bot.answer_callback_query(call.id, "⚠️ Fitur Reset Sesi butuh integrasi Nomor HP.", show_alert=True)

# ==========================================
# HANDLER AKSI: UPGRADE / DOWNGRADE ROLE
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("up_reseller|") or call.data.startswith("down_user|"))
def action_change_role_status(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    action, target_id = call.data.split("|")
    new_role = "reseller" if action == "up_reseller" else "user"
    
    if update_user_role(target_id, new_role):
        bot.answer_callback_query(call.id, f"✅ Sukses ubah ke {new_role.upper()}")
        
        # Update tampilan pesan agar status berubah real-time
        from telebot.types import Message
        dummy_msg = Message(call.message.message_id, call.from_user, call.message.date, call.message.chat, "text", {}, "")
        dummy_msg.text = target_id 
        
        bot.send_message(call.message.chat.id, f"✅ Role User `{target_id}` berhasil diubah menjadi **{new_role.upper()}**.", parse_mode="Markdown")
        
        # Notif ke User
        try:
            bot.send_message(target_id, f"🎉 Status akun Anda telah diubah menjadi **{new_role.upper()}** oleh Admin.", parse_mode="Markdown")
        except: pass
    else:
        bot.send_message(call.message.chat.id, "❌ Gagal update database.")
        
