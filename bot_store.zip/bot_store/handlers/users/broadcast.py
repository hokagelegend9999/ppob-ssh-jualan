import telebot
import time
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot_init import bot
from config import ADMIN_ID
from database import get_all_ids

@bot.callback_query_handler(func=lambda call: call.data == "broadcast_menu")
def broadcast_ask(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    msg_text = (
        "<b>📢 BROADCAST MESSAGE</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Silakan kirim pesan yang ingin disebarkan ke seluruh member.\n\n"
        "<b>Support Format:</b>\n📝 Teks, 📸 Gambar, 📂 File, 🤡 Sticker, 🎙 Audio\n\n"
        "<i>👇 Kirim pesan Anda sekarang atau tekan Batal.</i>"
    )
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("❌ BATAL KEMBALI", callback_data="broadcast_cancel"))
    
    try: sent_msg = bot.edit_message_text(msg_text, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except: sent_msg = bot.send_message(call.message.chat.id, msg_text, parse_mode='HTML', reply_markup=m)
        
    bot.register_next_step_handler(sent_msg, broadcast_process)

@bot.callback_query_handler(func=lambda call: call.data == "broadcast_cancel")
def broadcast_cancel_handler(call):
    bot.clear_step_handler_by_chat_id(call.message.chat.id)
    bot.answer_callback_query(call.id, "Broadcast dibatalkan")
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="setting_menu"))
    bot.edit_message_text("❌ <b>Broadcast Dibatalkan.</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)

def broadcast_process(message):
    if message.content_type == 'text' and message.text.startswith('/'):
        bot.reply_to(message, "❌ Broadcast dibatalkan karena Anda mengirim command.")
        return
        
    all_users = get_all_ids() 
    total_users = len(all_users)
    status_msg = bot.reply_to(message, f"⏳ <b>Memulai Broadcast...</b>\nTarget: {total_users} User\n<i>Mohon tunggu...</i>", parse_mode='HTML')
    
    success = 0
    failed = 0
    start_time = time.time()
    
    for i, uid in enumerate(all_users, 1):
        try:
            bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
            success += 1
        except Exception:
            failed += 1
            
        if i % 20 == 0 or i == total_users:
            try:
                bot.edit_message_text(
                    f"🚀 <b>Sedang Mengirim...</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n✅ Sukses : {success}\n❌ Gagal  : {failed}\n📊 Progress: {i}/{total_users}",
                    chat_id=message.chat.id, 
                    message_id=status_msg.message_id,
                    parse_mode='HTML'
                )
            except: pass
        time.sleep(0.05) 
        
    duration = round(time.time() - start_time, 2)
    report_text = (
        f"✅ <b>BROADCAST SELESAI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"👥 Total Target : {total_users}\n✅ Terkirim      : <b>{success}</b>\n❌ Gagal          : <b>{failed}</b>\n"
        f"⏱ Durasi         : {duration} detik\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    )
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="setting_menu"))
    try: bot.delete_message(message.chat.id, status_msg.message_id)
    except: pass
    bot.reply_to(message, report_text, parse_mode='HTML', reply_markup=m)