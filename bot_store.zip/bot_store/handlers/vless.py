import telebot
import paramiko
import re
from datetime import datetime, timedelta
import time

from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID
from database import add_balance, get_user_data, increment_reseller_trx, save_vpn_created
from utils_helper import get_back_markup

# ======================================================
# 1. KONFIGURASI HARGA (VLESS)
# ======================================================
HARGA_VLESS = {
    "sg":   {"user": 15000, "reseller": 12000},
    "indo": {"user": 13000, "reseller": 10000}
}

# ======================================================
# 2. KONFIGURASI SERVER
# ======================================================
SERVER_DATA = {
    "sg": { 
        "name": "Singapore Premium", 
        "domain": "batiaja.hokage.web.id", 
        "ip": "146.190.105.29", 
        "user": "root", 
        "pass": "hendra2026" 
    },
    "sg2": { 
        "name": "Singapore2 Premium", 
        "domain": "sg2.hokage.web.id", 
        "ip": "157.245.204.74", 
        "user": "root", 
        "pass": "azzam2016" 
    },
    "indo": { 
        "name": "Indonesia Private", 
        "domain": "id.hokagelegend.web.id", 
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016" 
    }
}

# ======================================================
# HELPER: GENERATE LINK VLESS
# ======================================================
def gen_vless_link(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    path = "vless-grpc" if type == "grpc" else "/vless"
    security = "tls" if type != "none" else "none"
    
    if type == "grpc":
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=grpc&serviceName={path}#{name}"
    else:
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=ws&path={path}#{name}"

# ======================================================
# HELPER: CALL SCRIPT ADDVLESS DI VPS
# ======================================================
def create_vless_remote(username, quota, masa_aktif, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=15)
        
        # PANGGIL SCRIPT ADDVLESS (BRIDGE)
        cmd = f"/usr/bin/addvless {username} {masa_aktif} {quota} 2"
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode().strip()
        client.close()

        if "SUCCESS" in output:
            parts = output.split("|") # SUCCESS|UUID|EXP
            u_uuid = parts[1]
            return True, "Sukses", {'uuid': u_uuid}
        elif "ERROR" in output:
            return False, "Username sudah digunakan", {}
        else:
            return False, f"Gagal Script: {output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HELPER: EKSEKUSI REMOTE GENERAL
# ======================================================
def eksekusi_remote(lokasi, command):
    target = SERVER_DATA.get(lokasi)
    if not target: return []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=20,            
            banner_timeout=200,    
            allow_agent=False, 
            look_for_keys=False
        )
        
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors='ignore').strip()
        client.close()
        
        if output:
            return output.split("\n")
        else:
            return []
            
    except Exception as e:
        print(f"❌ Error Remote {lokasi}: {e}")
        return []

# ======================================================
# HANDLER UTAMA: BELI VLESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_vless_"))
def buy_vless(call):
    try:
        uid = call.from_user.id
        try: lokasi = call.data.split("_")[2]
        except: return bot.answer_callback_query(call.id, "❌ Error Data")

        if lokasi not in HARGA_VLESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

        user_data = get_user_data(uid)
        if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

        role = str(user_data.get('role', 'user')).lower()
        saldo = int(user_data.get('balance', 0))

        if 'reseller' in role or 'owner' in role or str(uid) == str(ADMIN_ID):
            price = HARGA_VLESS[lokasi]["reseller"]
        else:
            price = HARGA_VLESS[lokasi]["user"]

        is_owner = str(uid) == str(ADMIN_ID) or 'owner' in role

        if not is_owner and saldo < price:
            kurang = price - saldo
            msg_error = f"⚠️ <b>SALDO TIDAK CUKUP</b>\nKurang: Rp {kurang:,}"
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
            return bot.send_message(call.message.chat.id, msg_error, parse_mode='HTML', reply_markup=markup)
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_user"))
        
        msg = bot.send_message(call.message.chat.id, 
            f"<b>🔮 BELI VLESS {lokasi.upper()}</b>\nMasukkan <b>Username</b>:", 
            parse_mode='HTML', reply_markup=m)
        
        bot.register_next_step_handler(msg, lambda m: vless_process(m, lokasi, price, is_owner))
    except Exception as e: bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def vless_process(m, lokasi, price, is_owner):
    if m.content_type != 'text': return
    u = m.text.strip()
    
    if not re.match("^[a-zA-Z0-9]+$", u):
        return bot.reply_to(m, "❌ <b>Username Invalid!</b>\nHanya boleh huruf dan angka.", parse_mode='HTML')
        
    if len(u) < 3: 
        return bot.reply_to(m, "❌ Username terlalu pendek (Min 3 karakter).")
    
    uid = m.from_user.id
    status = bot.reply_to(m, f"⏳ <b>Memproses Vless...</b>", parse_mode='HTML')
    vless_execution(m, u, uid, price, status, lokasi, is_owner)

def vless_execution(m, u, uid, price, status_msg, lokasi, is_owner):
    try:
        quota_gb = "100"
        masa_aktif = "30"
        
        succ, info, res = create_vless_remote(u, quota_gb, masa_aktif, lokasi)
        
        if succ:
            if not is_owner:
                add_balance(uid, -price, f"Beli Vless {lokasi.upper()} ({u})")
                if get_user_data(uid).get('role') == 'reseller': increment_reseller_trx(uid)
                sisa_saldo = f"{int(get_user_data(uid).get('balance', 0)):,}"
            else:
                sisa_saldo = "Unlimited"

            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            
            res_uuid = res.get('uuid')
            domain = SERVER_DATA.get(lokasi)['domain']
            now = datetime.now()
            exp_date = now + timedelta(days=int(masa_aktif)) 
            tgl_exp = exp_date.strftime("%d %b, %Y")
            
            try: save_vpn_created(uid, u, "VLESS", tgl_exp, res_uuid, domain)
            except: pass
            
            link_tls = gen_vless_link(f"{u}-TLS", domain, res_uuid, "tls")
            link_ntls = gen_vless_link(f"{u}-NTLS", domain, res_uuid, "none")
            link_grpc = gen_vless_link(f"{u}-GRPC", domain, res_uuid, "grpc")

            txt = f"""
========================================
🔮 <b>AKUN VLESS PREMIUM</b>
========================================
🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{u}</code>
Domain    : <code>{domain}</code>
UUID      : <code>{res_uuid}</code>
Expired   : <code>{tgl_exp}</code>
Limit IP  : 2 Device

🔗 <b>LINK VLESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VLESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VLESS GRPC</b>
<code>{link_grpc}</code>
========================================
💰 Harga: Rp {price:,} | Sisa Saldo: {sisa_saldo}
"""
            bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup())
        else:
            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            bot.reply_to(m, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML')
            
    except Exception as e:
        bot.reply_to(m, f"❌ Error System: {e}")

# ==========================================
#  LIST & DELETE VLESS REMOTE
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vless_vps"))
def check_vless_vps(call):
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        
        # Deteksi sumber panggilan
        if "del_vless" in parts[0]: 
            page = int(parts[3]) if len(parts) > 3 else 0
        else:
            page = int(parts[2]) if len(parts) > 2 else 0
    except: 
        lokasi = "sg"
        page = 0

    cmd = "grep '#& ' /etc/xray/config.json" 
    raw_lines = eksekusi_remote(lokasi, cmd)

    users = []
    seen = set()
    now_ts = time.time() 

    if raw_lines:
        for line in raw_lines:
            try:
                line = line.strip()
                parts = line.split()
                if len(parts) >= 3 and parts[0] == "#&":
                    u_name = parts[1]
                    u_exp_str = parts[2]

                    if u_name in seen: continue
                    seen.add(u_name)

                    try:
                        exp_struct = time.strptime(u_exp_str, "%Y-%m-%d")
                        exp_ts = time.mktime(exp_struct)
                        sisa_hari = int((exp_ts - now_ts) / 86400)
                        tgl_display = time.strftime("%d %b %Y", exp_struct)
                    except:
                        sisa_hari = -999 
                        tgl_display = u_exp_str 

                    if sisa_hari >= 0:
                        status_icon = "✅ Active"
                        ket_hari = f"{sisa_hari} Hari"
                    else:
                        status_icon = "❌ Expired"
                        ket_hari = "DEAD ☠️"

                    users.append({
                        "name": u_name,
                        "exp_date": tgl_display,
                        "status": status_icon,
                        "ket": ket_hari,
                        "sort_val": sisa_hari
                    })
            except: continue

    users.sort(key=lambda x: x['sort_val'], reverse=True)

    per_page = 5
    total_items = len(users)
    total_pages = (total_items + per_page - 1) // per_page

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    sliced_data = users[start:end]

    msg = f"<b>🔮 LIST VLESS ({lokasi.upper()})</b>\n"
    msg += f"Total: {total_items} User | Page: {page+1}/{total_pages}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    markup = InlineKeyboardMarkup()

    if not users:
        msg += "<i>Belum ada user Vless.</i>"
    else:
        for u in sliced_data:
            msg += f"👤 <b>{u['name']}</b>\n"
            msg += f"📅 <b>Exp: {u['exp_date']}</b>\n"
            msg += f"🏳️ {u['status']} ({u['ket']})\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            markup.add(InlineKeyboardButton(f"🗑️ Hapus {u['name']}", callback_data=f"del_vless|{lokasi}|{u['name']}|{page}"))

    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️", callback_data=f"check_vless_vps|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vless_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("➡️", callback_data=f"check_vless_vps|{lokasi}|{page+1}"))

    if nav: markup.row(*nav)
    markup.add(InlineKeyboardButton(f"🔙 KEMBALI", callback_data=f"monitor_{lokasi}"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("del_vless"))
def del_vless_remote(call):
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except: return
    
    cmd = f"""
    sed -i "\|#& {user} |,\|}}|d" /etc/xray/config.json
    sed -i "\|### {user} |d" /etc/vless/.vless.db
    rm -f "/etc/kyt/limit/vless/ip/{user}"
    systemctl restart xray
    """
    
    eksekusi_remote(lokasi, cmd)
    bot.answer_callback_query(call.id, f"✅ User {user} berhasil dihapus!", show_alert=True)
    check_vless_vps(call)