import telebot
import paramiko
import math
import time
import os
import zipfile
import json
import smtplib
import sqlite3
import requests
import socket
from datetime import date as DateClass, datetime as DateTimeClass
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import datetime
from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import (
    ADMIN_ID, DOMAIN_HOST_SG, ATLANTIC_API_KEY, DOMAIN_HOST_ID,
    SMTP_SERVER, SMTP_PORT, SMTP_EMAIL, SMTP_PASSWORD, RECIPIENT_EMAIL
)
from database import get_all_transactions, update_transaction_status, DB_NAME, add_balance, get_user_data, increment_reseller_trx
today = DateClass.today()
# Coba import OkeConnect (Safe Import)
try:
    from orderkuota_service import get_okeconnect_profile, check_orderkuota_status, buy_okeconnect_product
except ImportError:
    get_okeconnect_profile = None
    check_orderkuota_status = None
    buy_okeconnect_product = None

# DATA SERVER
SERVER_DATA = {
    "sg": { "name": "Singapore Premium", "domain": "batiaja.hokage.web.id", "ip": "146.190.105.29", "user": "root", "pass": "hendra2026" },
    "sg2": { "name": "Singapore2 Premium", "domain": "hendra.hokagelegend.web.id", "ip": "103.127.135.191", "user": "root", "pass": "hendra2026" },
    "indo": { "name": "Indonesia Private", "domain": "id.hokagelegend.web.id", "ip": "103.150.226.10", "user": "root", "pass": "azzam2016" }
}

PATH_BRIDGE = "/root/bot_store/kyt/modules/bridge.py"
# Helper untuk mengambil data VPS lengkap (System + User Count)
# Helper Ambil System Info Saja (Tanpa Hitung User)
# --- FUNGSI HELPER REMOTE (BRIDGE) ---
# ==========================================
#  HELPER ATLANTIC (SESUAI DOKUMENTASI)
# ==========================================
def check_atlantic_trx_api(trx_id):
    """
    Mengambil status transaksi dari Atlantic API
    Endpoint: /transaksi/status
    Method: POST (x-www-form-urlencoded)
    """
    url = "https://atlantich2h.com/transaksi/status"
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    
    # Parameter wajib sesuai dokumentasi: api_key, id, type
    # Kita default type ke 'prabayar' karena bot store umumnya prabayar
    payload = {
        'api_key': ATLANTIC_API_KEY,
        'id': trx_id,
        'type': 'prabayar' 
    }
    
    try:
        # Requests data=payload otomatis format ke x-www-form-urlencoded
        resp = requests.post(url, data=payload, headers=headers, timeout=10)
        return resp.json()
    except Exception as e:
        return {"status": False, "message": f"Koneksi Error: {str(e)}"}
        
def eksekusi_remote(lokasi, command):
    target = SERVER_DATA.get(lokasi)
    if not target: return []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        # PERBAIKAN DISINI:
        # 1. timeout dinaikkan jadi 20
        # 2. banner_timeout ditambah jadi 200 (PENTING untuk error banner)
        # 3. allow_agent & look_for_keys False (supaya fokus ke password saja, lebih cepat)
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=20,           
            banner_timeout=200,   
            allow_agent=False, 
            look_for_keys=False
        )
        
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors='ignore').strip() # Tambah errors='ignore'
        client.close()
        
        if output:
            return output.split("\n")
        else:
            return []
            
    except Exception as e:
        print(f"❌ Error Remote {lokasi}: {e}")
        return []
def get_vps_system_only(lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return f"❌ Config {lokasi} Error"

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # Timeout 4 detik cukup
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=20,           
            banner_timeout=200,
            allow_agent=False, 
            look_for_keys=False
        )

        # Command: Ambil OS, Uptime, RAM, ISP (Tanpa hitung user)
        cmd = """
        os=$(grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')
        upt=$(uptime -p | sed 's/up //')
        ram_u=$(free -m | awk 'NR==2{print $3}')
        ram_t=$(free -m | awk 'NR==2{print $2}')
        # Cek cache ISP/City biar cepat, fallback ke curl
        isp=$(cat /root/.info/.isp 2>/dev/null || curl -s --max-time 1 ipinfo.io/org || echo "-")
        city=$(cat /root/.info/.city 2>/dev/null || curl -s --max-time 1 ipinfo.io/city || echo "-")
        
        echo "$os|$upt|$ram_u|$ram_t|$isp|$city"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8").strip()
        client.close()
        
        if "|" in output:
            d = output.split("|")
            # d[0]=OS, d[1]=Uptime, d[2]=RAM_U, d[3]=RAM_T, d[4]=ISP, d[5]=City
            
            return f"""
<b>💻 VPS {lokasi.upper()} ({d[0]})</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» SYSTEM INFORMATION</b>
🌐 IP: <code>{target['ip']}</code>
🎯 Domain: <code>{target['domain']}</code>
🏢 ISP: {d[4]}
📍 Loc: {d[5]}
💾 RAM: {d[2]}MB / {d[3]}MB
⏰ Uptime: {d[1]}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"""
        else:
            return f"⚠️ <b>{lokasi.upper()}:</b> Gagal parsing data."
            
    except Exception as e:
        return f"❌ <b>{lokasi.upper()} OFFLINE / ERROR</b>\n<code>{str(e)[:50]}</code>"
        
@bot.callback_query_handler(func=lambda call: call.data == "check_vps_menu")
def check_vps_menu(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Fitur khusus Owner!")

    # 1. Loading Message (Update teks loading)
    bot.edit_message_text(
        "🚀 <b>CONNECTING TO SERVERS...</b>\n"
        "<i>Sedang cek status kesehatan server SG, SG2 & INDO...</i>",
        call.message.chat.id, call.message.message_id, parse_mode='HTML'
    )

    # 2. Ambil Data (System Only) - TAMBAHKAN SG2 DISINI
    info_sg = get_vps_system_only("sg")
    info_sg2 = get_vps_system_only("sg2") # <--- Baru
    info_indo = get_vps_system_only("indo")

    # 3. Gabungkan Pesan
    full_msg = f"{info_sg}\n\n{info_sg2}\n\n{info_indo}"
    
    # 4. Buat Tombol Manage
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("🇸🇬 MANAGE SG", callback_data="monitor_sg"),
        InlineKeyboardButton("🇸🇬2 MANAGE SG2", callback_data="monitor_sg2"), # <--- Tombol SG2
        InlineKeyboardButton("🇮🇩 MANAGE INDO", callback_data="monitor_indo")
    )
    markup.add(InlineKeyboardButton("🔄 REFRESH SEMUA", callback_data="check_vps_menu"))
    markup.add(InlineKeyboardButton("⚙️ SYSTEM BOT & BACKUP", callback_data="setting_menu"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))
    
    # 5. Tampilkan
    bot.edit_message_text(full_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

# ==========================================
#  HANDLER DASHBOARD (FIXED: REGEX INDENTASI JSON)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data in ["monitor_sg", "monitor_sg2", "monitor_indo"])
def show_dashboard(call):
    if str(call.from_user.id) != str(ADMIN_ID): return

    lokasi = call.data.replace("monitor_", "")
    target = SERVER_DATA.get(lokasi)
    
    if not target:
        return bot.answer_callback_query(call.id, f"❌ Data {lokasi} tidak ditemukan!", show_alert=True)
    
    bot.answer_callback_query(call.id, f"⏳ Mengambil Data {lokasi.upper()}...", show_alert=False)

    stats = {"ssh": "0", "vmess": "0", "vless": "0", "trojan": "0"}
    
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=8)
        
        # === COMMAND SINKRONISASI ===
        cmd = """
        c_ssh=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)
        c_vmess=$(grep -c "^### " "/etc/vmess/.vmess.db" 2>/dev/null || echo 0)
        c_vless=$(grep -c "#& " "/etc/xray/config.json" 2>/dev/null || echo 0)
        c_trojan=$(grep -c "^### " "/etc/trojan/.trojan.db" 2>/dev/null || echo 0)
        echo "$c_ssh|$c_vmess|$c_vless|$c_trojan"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8").strip()
        client.close()
        
        if "|" in output:
            data = output.split("|")
            stats = {
                "ssh": data[0].strip(), 
                "vmess": data[1].strip(), 
                "vless": data[2].strip(), 
                "trojan": data[3].strip()
            }
            
    except Exception as e:
        print(f"Error Stats {lokasi}: {e}")

    # Tampilan Dashboard
    msg = f"""
<b>⚙️ MANAGE VPS ({lokasi.upper()})</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» USER STATISTICS</b>
👤 <b>SSH User    :</b> <code>{stats['ssh']}</code> Akun
⚡ <b>VMess User  :</b> <code>{stats['vmess']}</code> Akun
🔮 <b>VLess User  :</b> <code>{stats['vless']}</code> Akun
🐎 <b>Trojan User :</b> <code>{stats['trojan']}</code> Akun
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Silakan pilih menu di bawah untuk mengelola user server <b>{lokasi.upper()}</b>.</i>
"""

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(InlineKeyboardButton("⚡ CEK STATUS SERVICE", callback_data=f"srv_check_status|{lokasi}"))
    markup.add(
        InlineKeyboardButton(f"📂 SSH ({stats['ssh']})", callback_data=f"menu_ssh_vps|{lokasi}"), 
        InlineKeyboardButton(f"📂 VMESS ({stats['vmess']})", callback_data=f"check_vmess_vps|{lokasi}")
    )
    markup.add(
        InlineKeyboardButton(f"📂 VLESS ({stats['vless']})", callback_data=f"check_vless_vps|{lokasi}"),
        InlineKeyboardButton(f"📂 TROJAN ({stats['trojan']})", callback_data=f"check_trojan_vps|{lokasi}")
    )
    markup.add(InlineKeyboardButton("🔙 KEMBALI DASHBOARD", callback_data="check_vps_menu"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

# ==========================================
# 2. HANDLER CEK SERVICE (BRIDGE) - FIXED VERSION
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("srv_check_status"))
def check_service_status(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try: lokasi = call.data.split("|")[1]
    except: lokasi = "sg"
    
    bot.answer_callback_query(call.id, f"⏳ Checking {lokasi.upper()}...", show_alert=False)
    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    raw_out = ""
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        cmd = f"python3 {PATH_BRIDGE} system check_service"
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_out = stdout.read().decode("utf-8", errors="ignore").strip()
        client.close()

        if raw_out and "|" in raw_out and not raw_out.startswith("ERROR"):
            d = raw_out.split("|")
            
            def icon(stat):
                return "<code>ON</code> ✅" if stat == "ON" else "<code>OFF</code> ❌"

            msg = (
                f"<b>🖥 SYSTEM INFORMATION</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"💻 <b>OS     :</b> <code>{d[0]}</code>\n"
                f"🌐 <b>IP     :</b> <code>{d[1]}</code>\n"
                f"🎯 <b>Domain :</b> <code>{d[2]}</code>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
                f"<b>⚙️ SERVICE STATUS ({lokasi.upper()})</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"🟢 <b>SSH / OVPN</b>\n"
                f"├ SSH Service    : {icon(d[3])}\n"
                f"├ Dropbear       : {icon(d[4])}\n"
                f"├ OpenVPN        : {icon(d[5])}\n"
                f"└ Haproxy        : {icon(d[6])}\n\n"
                
                f"🔵 <b>XRAY / ZiVPN</b>\n"
                f"├ Xray Core      : {icon(d[7])}\n"
                f"└ Websocket      : {icon(d[8])}\n\n"
                
                f"🟠 <b>UDP & LAINNYA</b>\n"
                f"├ Nginx Web      : {icon(d[8])}\n"
                f"├ ZiVPN Tunnel   : {icon(d[9])}\n" # Menggunakan d[9]
                f"├ UDP Custom     : {icon(d[10])}\n" # Menggunakan d[10]
                f"└ Crontab        : {icon(d[11])}\n" # Menggunakan d[11]
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            )

            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 REFRESH STATUS", callback_data=f"srv_check_status|{lokasi}"))
            markup.add(InlineKeyboardButton("🔙 DASHBOARD", callback_data=f"monitor_{lokasi}"))
            
            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        else:
            raise Exception(f"Format respon salah. Respon: {raw_out[:100]}")

    except Exception as e:
        error_display = str(raw_out)[:500] if raw_out else str(e)[:500]
        m_err = InlineKeyboardMarkup()
        m_err.add(InlineKeyboardButton("🔄 COBA LAGI", callback_data=call.data))
        m_err.add(InlineKeyboardButton("🔙 DASHBOARD", callback_data=f"monitor_{lokasi}"))
        bot.edit_message_text(f"❌ <b>GAGAL MENGAMBIL DATA</b>\n\n<code>{error_display}</code>", 
                              call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m_err)

# ==========================================
#  3. MENU SSH ADMIN (DENGAN NOMOR DETAIL & NATIVE OS)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("menu_ssh_vps"))
def menu_ssh_vps(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try: lokasi = call.data.split("|")[1]
    except: lokasi = "sg"
    render_ssh_page(call.message.chat.id, call.message.message_id, lokasi, 0)

def render_ssh_page(chat_id, message_id, lokasi, page=0):
    target = SERVER_DATA.get(lokasi)
    if not target: return
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # SCRIPT BASH: Membaca Expired LANGSUNG dari sistem Linux (chage) agar tidak UNKNOWN
        cmd = """
        for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
            # Ambil Tanggal Expired asli dari Linux
            exp_raw=$(chage -l "$u" 2>/dev/null | grep 'Account expires' | cut -d: -f2 | sed 's/^ *//')
            if [ "$exp_raw" = "never" ] || [ -z "$exp_raw" ]; then
                exp_date="UNKNOWN"
            else
                exp_date=$(date -d "$exp_raw" +"%Y-%m-%d" 2>/dev/null || echo "UNKNOWN")
            fi
            
            # Coba ambil password dari .ssh.db jika ada
            pass=$(grep "### $u " /etc/ssh/.ssh.db 2>/dev/null | awk '{print $4}')
            [ -z "$pass" ] && pass="UNKNOWN"
            
            echo "$u|$exp_date|$pass"
        done
        """
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_output = stdout.read().decode("utf-8").strip()
        client.close()
        
        users = []
        today = datetime.date.today()
        # Harga tidak perlu diambil dari config global karena ini panel admin, kita beri teks default saja
        harga_str = "Premium" 
        
        for line in raw_output.split("\n"):
            if not line or "|" not in line: continue
            parts = line.split("|")
            u_name = parts[0]
            u_exp_str = parts[1]
            u_pass = parts[2]
            
            sisa_hari = -999
            tgl_buat = "UNKNOWN"
            status_icon = "⚠️"
            
            if u_exp_str != "UNKNOWN":
                try:
                    exp_obj = datetime.datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                    sisa_hari = (exp_obj - today).days
                    
                    # Estimasi Tanggal Pembuatan (Mundur 30 Hari dari Expired)
                    buat_obj = exp_obj - datetime.timedelta(days=30)
                    tgl_buat = buat_obj.strftime("%d %b %Y")
                    u_exp_str = exp_obj.strftime("%d %b %Y")
                    
                    if sisa_hari >= 0:
                        status_icon = "✅ Aktif"
                    else:
                        status_icon = "❌ Expired"
                except: pass
            
            users.append({
                "u": u_name,
                "exp": u_exp_str,
                "pass": u_pass,
                "sisa": sisa_hari,
                "buat": tgl_buat,
                "status": status_icon,
                "harga": harga_str
            })
            
        # Urutkan: User yang masih aktif berada di paling atas
        users.sort(key=lambda x: x['sisa'], reverse=True)
                
    except Exception as e:
        users = []
        print(f"Error SSH List: {e}")

    # LOGIKA PAGINATION
    per_page = 5 
    total_items = len(users)
    total_pages = (total_items + per_page - 1) // per_page
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    
    start = page * per_page
    end = start + per_page
    sliced_data = users[start:end]
    
    # TAMPILAN HEADER LIST
    msg = f"🌟 <b>LIST SSH PREMIUM ({lokasi.upper()})</b>\n"
    msg += f"📊 Total: {total_items} Akun | Hal: {page+1}/{total_pages}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    m = InlineKeyboardMarkup(row_width=5)
    
    if not users:
        msg += "<i>Belum ada akun SSH yang terdaftar.</i>\n"
    else:
        btn_row = []
        # TAMPILAN BODY LIST (DENGAN TEMA PREMIUM)
        for index, u in enumerate(sliced_data, start=1):
            sisa_txt = f"{u['sisa']} Hari" if u['sisa'] != -999 else "Unknown"
            if u['sisa'] < 0 and u['sisa'] != -999: sisa_txt = "DEAD ☠️"
            
            msg += f"<b>{index}. {u['u']}</b> {u['status']}\n"
            msg += f"   📝 Dibuat : <code>{u['buat']}</code>\n"
            msg += f"   ⏳ Expired: <code>{u['exp']}</code> ({sisa_txt})\n"
            msg += f"   💎 Harga  : {u['harga']}\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            
            # Tombol detail dengan angka berderet ke samping
            btn_row.append(InlineKeyboardButton(f"👁️ {index}", callback_data=f"ssh_det|{lokasi}|{u['u']}|{page}"))
        
        if btn_row:
            m.row(*btn_row)

    # TOMBOL NAVIGASI
    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"ssh_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"ssh_nav_rem|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"ssh_nav_rem|{lokasi}|{page+1}"))
    
    if nav: m.row(*nav)
    m.add(InlineKeyboardButton(f"🔙 KEMBALI KE DASHBOARD", callback_data=f"monitor_{lokasi}"))

    try:
        bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=m)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("ssh_nav_rem"))
def nav_ssh(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, page = call.data.split("|")
        render_ssh_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    except: pass

# ==========================================
#  HANDLER DETAIL POP-UP (SESUAI FORMAT CREATE)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("ssh_det"))
def detail_ssh(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, user, page = call.data.split("|")
    except: return

    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # Ambil detail khusus user tersebut untuk pop-up
        cmd = f"""
        pass=$(grep "### {user} " /etc/ssh/.ssh.db 2>/dev/null | awk '{{print $4}}')
        [ -z "$pass" ] && pass="UNKNOWN"
        
        exp_raw=$(chage -l "{user}" 2>/dev/null | grep 'Account expires' | cut -d: -f2 | sed 's/^ *//')
        if [ "$exp_raw" = "never" ] || [ -z "$exp_raw" ]; then
            exp_date="UNKNOWN"
        else
            exp_date=$(date -d "$exp_raw" +"%d %b %Y" 2>/dev/null || echo "$exp_raw")
        fi
        
        echo "$pass|$exp_date"
        """
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_output = stdout.read().decode("utf-8").strip()
        client.close()
        
        password = "UNKNOWN"
        exp_date_str = "UNKNOWN"
        
        if "|" in raw_output:
            parts = raw_output.split("|")
            password = parts[0]
            exp_date_str = parts[1]

        domain_server = target.get('domain', target['ip'])
        limit = 3 # Hardcoded based on your create_ssh logic

        reply_msg = f"""
========================================
🌟 <b>DETAIL AKUN SSH PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Username: <code>{user}</code>
Domain  : <code>{domain_server}</code>
Password: <code>{password}</code>
Expired : <code>{exp_date_str}</code>
IP Limit: <code>{limit} Device</code>

🔹 <b>PORT INFO</b>
SSH WS       : 80, 2082
SSH SSL      : 443
UDP GW       : 7100-7300
ZiVPN        : <code>{user}</code>

🔹UDP Costum   : 
<code>{domain_server}</code>:1-65535@<code>{user}</code>:<code>{password}</code>

🔹ZIVPN FORMAT :
UDP SERVER   : <code>{domain_server}</code>
UDP PASSWORD : <code>{user}</code>


========================================

🔗 <b>PAYLOAD CONTOH</b>
<code>GET / HTTP/1.1[crlf]Host: {domain_server}[crlf]Upgrade: websocket[crlf][crlf]</code>

========================================
<i>Silakan pilih tindakan di bawah ini:</i>
"""
        
        m = InlineKeyboardMarkup()
        # Tombol Hapus diletakkan dengan aman di dalam pop-up detail ini
        m.add(InlineKeyboardButton(f"🗑️ HAPUS AKUN INI", callback_data=f"ssh_del_rem|{lokasi}|{user}|{page}"))
        m.add(InlineKeyboardButton("🔙 KEMBALI KE LIST SSH", callback_data=f"ssh_nav_rem|{lokasi}|{page}"))
        
        bot.edit_message_text(reply_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)

# ==========================================
#  HANDLER HAPUS SSH
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("ssh_del_rem"))
def del_ssh(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, user, page = call.data.split("|")
        target = SERVER_DATA.get(lokasi)
        
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # Hapus user OS, hapus log db, dan hapus dari zivpn
        cmd = f"""
        userdel -f {user}
        sed -i '/### {user} /d' /etc/ssh/.ssh.db
        if [ -f /etc/zivpn/config.json ]; then
            jq 'del(.auth.config[] | select(. == "{user}"))' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
        fi
        systemctl restart zivpn
        """
        client.exec_command(cmd)
        client.close()
        
        bot.answer_callback_query(call.id, f"✅ User {user} berhasil dihapus permanen!", show_alert=True)
        # Kembali ke halaman list
        render_ssh_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)

# Helper Redirect
@bot.callback_query_handler(func=lambda call: call.data.startswith("list_ssh_vps"))
def list_ssh_redirect_handler(call):
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        page = 0
        render_ssh_page(call.message.chat.id, call.message.message_id, lokasi, page)
    except: pass

# Helper cepat untuk cek status VPS (Hanya cek Port 22 SSH)
def quick_check_online(ip):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1.5) # Timeout cepat 1.5 detik agar bot tidak lemot
        result = sock.connect_ex((ip, 22))
        sock.close()
        return "🟢" if result == 0 else "🔴"
    except:
        return "🔴"

@bot.callback_query_handler(func=lambda call: call.data == "setting_menu")
def setting_menu(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    # 1. Pesan Loading (Opsional, agar user tau bot sedang bekerja)
    try:
        bot.edit_message_text("⏳ <b>Checking Server Status...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    except: pass

    # 2. Cek Status VPS (Realtime)
    # Mengambil IP dari variable SERVER_DATA yang ada di atas script Anda
    stat_sg   = quick_check_online(SERVER_DATA['sg']['ip'])
    stat_sg2  = quick_check_online(SERVER_DATA['sg2']['ip'])
    stat_indo = quick_check_online(SERVER_DATA['indo']['ip'])

    # 3. Cek Saldo OkeConnect
    saldo_oke = "Rp 0"
    if get_okeconnect_profile:
        try: saldo_oke = get_okeconnect_profile()
        except: pass

    # 4. Cek Saldo Atlantic
    atl_name, atl_bal, atl_email = "-", "Rp 0", "-"
    try:
        url = "https://atlantich2h.com/get_profile"
        payload = {'api_key': ATLANTIC_API_KEY}
        raw = requests.post(url, data=payload, timeout=3).json() # Timeout dipercepat
        if str(raw.get('status')).lower() == 'true':
            data_user = raw.get('data', {})
            atl_name = data_user.get('name', 'Admin') 
            atl_bal = f"Rp {int(data_user.get('balance', 0)):,}"
            atl_email = data_user.get('email', '-')
    except: pass

    # 5. Susun Pesan dengan Indikator Warna
    msg = (f"🎛 <b>CONTROL PANEL ADMIN</b>\n"
           f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
           f"🇸🇬 <b>SG1 HENDRA :</b> {stat_sg} <code>{SERVER_DATA['sg']['domain']}</code>\n"
           f"🇸🇬 <b>SG2 PREMIUM :</b> {stat_sg2} <code>{SERVER_DATA['sg2']['domain']}</code>\n"
           f"🇮🇩 <b>INDO PRIVATE:</b> {stat_indo} <code>{SERVER_DATA['indo']['domain']}</code>\n"
           f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
           f"<b>💰 INFO SALDO SERVER</b>\n"
           f"🏦 <b>OkeConnect:</b> {saldo_oke}\n\n"
           f"🌊 <b>Atlantic Pedia</b>\n"
           f"├ Nama  : {atl_name}\n"
           f"├ Saldo : <b>{atl_bal}</b>\n"
           f"└ Email : {atl_email}\n\n"
           f"🕒 <i>Updated: {datetime.now().strftime('%H:%M:%S')}</i>")
    
    # 6. Susun Tombol
    m = InlineKeyboardMarkup(row_width=2)
    m.add(InlineKeyboardButton("🔄 REFRESH DATA", callback_data="setting_menu"))
    m.add(
        InlineKeyboardButton("📜 Riwayat OkeConnect", callback_data="oke_admin_history"),
        InlineKeyboardButton("🕵️ Cek Status Oke", callback_data="oke_admin_check_status")
    )
    m.add(InlineKeyboardButton("🌊 Cek Status Atlantic", callback_data="atlantic_check_status"))
    m.row(InlineKeyboardButton("💾 BACKUP DATABASE", callback_data="srv_backup"), 
          InlineKeyboardButton("🔁 RESTART BOT", callback_data="srv_restart"))
    
    m.add(InlineKeyboardButton("🔙 KEMBALI KE OWNER", callback_data="switch_owner"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=m)

# ==========================================
# 7. FITUR PPOB
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "oke_admin_history")
def admin_oke_history(call):
    try:
        bot.answer_callback_query(call.id, "🔄 Mengambil Data...")
        all_trx = get_all_transactions(limit=50) 
        data = []
        if all_trx:
            for row in all_trx:
                tgl, desc, amt, stt, ref, dest, sn, src = "-", "-", 0, "-", "-", "-", "-", "-"
                if len(row) == 8: tgl, ref, desc, sn, dest, amt, src, stt = row
                elif len(row) == 7: tgl, desc, amt, stt, ref, dest, sn = row
                elif len(row) == 5: tgl, desc, amt, stt, ref = row
                else: continue

                is_oke = "OKE" in str(desc).upper() or "OKE" in str(ref).upper()
                if len(row) == 8 and str(src).upper() == "OKE": is_oke = True

                if is_oke:
                    if str(stt).lower() in ["pending", "proses"] and check_orderkuota_status:
                        try:
                            latest_status = check_orderkuota_status(ref)
                            status_str = str(latest_status).lower()
                            new_stt = None
                            if "sukses" in status_str: new_stt = "sukses"
                            elif "gagal" in status_str: new_stt = "gagal"
                            if new_stt:
                                stt = new_stt
                                update_transaction_status(ref, new_stt, sn)
                        except: pass
                    
                    clean_prov = str(desc).replace("Beli ", "").replace(" (OKE)", "")
                    data.append({'tgl': tgl, 'prov': clean_prov, 'amt': amt, 'stt': stt, 'ref': ref, 'dest': dest, 'sn': sn})
        
        data = data[:10]
    except Exception as e:
        data = []
        print(f"❌ Error History: {e}")

    msg = "<b>📜 RIWAYAT TRANSAKSI OKECONNECT</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not data: msg += "<i>Belum ada data transaksi.</i>"
    else:
        for i, item in enumerate(data, 1):
            s = str(item['stt']).lower()
            icon = "✅" if "sukses" in s else "❌" if "gagal" in s else "⏳"
            msg += f"<b>{i}. {item['tgl']}</b>\n🆔 {item['ref']}\n📦 {item['prov']}\n📱 {item['dest']}\n🎟 {item['sn']}\n📊 {icon} {item['stt']}\n────────────────\n"

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔄 REFRESH", callback_data="oke_admin_history"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="setting_menu"))
    try: bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "oke_admin_check_status")
def admin_oke_check_ask(call):
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="setting_menu"))
    msg = bot.send_message(call.message.chat.id, "🕵️ <b>CEK STATUS TRANSAKSI</b>\nMasukkan RefID/SN/Tujuan:", parse_mode='HTML', reply_markup=markup)
    bot.register_next_step_handler(msg, admin_oke_check_process)

def admin_oke_check_process(message):
    try:
        input_data = message.text.strip()
        
        # Kirim pesan loading
        status_msg = bot.send_message(message.chat.id, f"⏳ Cek: {input_data}...", parse_mode='HTML')
        
        respon_server = "Gagal"
        if check_orderkuota_status:
            try: 
                respon_server = str(check_orderkuota_status(input_data))
            except Exception as e: 
                respon_server = f"Error: {e}"
        
        # ==========================================
        # [MODIFIKASI] TAMBAHAN TOMBOL KEMBALI
        # ==========================================
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔄 Cek Lagi", callback_data="oke_admin_check_status"))
        markup.add(InlineKeyboardButton("🔙 Kembali ke Menu", callback_data="setting_menu"))
        
        # Edit pesan loading menjadi hasil + tombol
        bot.edit_message_text(
            f"📊 <b>HASIL CEK</b>\n"
            f"Input: {input_data}\n"
            f"Respon: <code>{respon_server}</code>", 
            message.chat.id, 
            status_msg.message_id, 
            parse_mode='HTML',
            reply_markup=markup  # <--- Tombol dimasukkan di sini
        )
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error System: {e}")

# ==========================================
#  HANDLER CEK STATUS ATLANTIC
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "atlantic_check_status")
def admin_atlantic_check_ask(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="setting_menu"))
    
    msg = bot.send_message(
        call.message.chat.id, 
        "🌊 <b>CEK STATUS ATLANTIC</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Silakan masukkan <b>ID Transaksi</b> (Trx ID) dari Atlantic yang ingin dicek.\n\n"
        "<i>Contoh: 12345678</i>", 
        parse_mode='HTML', 
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, admin_atlantic_check_process)

def admin_atlantic_check_process(message):
    try:
        trx_id = message.text.strip()
        
        # 1. Kirim Pesan Loading
        load_msg = bot.send_message(message.chat.id, f"⏳ <b>Menghubungi Server Atlantic...</b>\n<i>Checking ID: {trx_id}</i>", parse_mode='HTML')
        
        # 2. Panggil API
        result = check_atlantic_trx_api(trx_id)
        
        # 3. Parsing Hasil
        status_bool = result.get('status', False)
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔄 Cek ID Lain", callback_data="atlantic_check_status"))
        markup.add(InlineKeyboardButton("🔙 Kembali Menu", callback_data="setting_menu"))

        if status_bool:
            # Data ditemukan
            d = result.get('data', {})
            
            # Tentukan Icon Status
            stt_txt = str(d.get('status')).lower()
            if "success" in stt_txt: icon_stt = "✅ SUKSES"
            elif "pending" in stt_txt: icon_stt = "⏳ PENDING"
            elif "failed" in stt_txt: icon_stt = "❌ GAGAL"
            else: icon_stt = f"⚠️ {stt_txt.upper()}"
            
            # Format Pesan Mewah
            final_msg = (
                f"🌊 <b>DETAIL TRANSAKSI ATLANTIC</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"🆔 <b>Trx ID :</b> <code>{d.get('id')}</code>\n"
                f"🏷 <b>Reff ID:</b> <code>{d.get('reff_id')}</code>\n"
                f"📦 <b>Produk :</b> {d.get('layanan')}\n"
                f"🎯 <b>Target :</b> <code>{d.get('target')}</code>\n"
                f"🎟 <b>SN/Ket :</b> <code>{d.get('sn')}</code>\n"
                f"💰 <b>Harga  :</b> Rp {int(d.get('price', 0)):,}\n"
                f"📅 <b>Waktu  :</b> {d.get('created_at')}\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"📊 <b>STATUS : {icon_stt}</b>"
            )
        else:
            # Gagal / Data tidak ditemukan
            msg_err = result.get('message', 'Data tidak ditemukan.')
            final_msg = (
                f"❌ <b>TRANSAKSI TIDAK DITEMUKAN</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"Input ID: <code>{trx_id}</code>\n"
                f"Respon  : {msg_err}\n\n"
                f"<i>Pastikan ID Transaksi benar dan jenis transaksi adalah Prabayar.</i>"
            )
            
        # 4. Tampilkan Hasil
        bot.edit_message_text(final_msg, message.chat.id, load_msg.message_id, parse_mode='HTML', reply_markup=markup)
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ <b>System Error:</b> {e}", parse_mode='HTML')

def send_email_backup(zip_filename):
    try:
        msg = MIMEMultipart()
        msg['From'] = SMTP_EMAIL
        msg['To'] = RECIPIENT_EMAIL
        msg['Subject'] = f"Backup Bot {datetime.now()}"
        
        with open(zip_filename, "rb") as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f"attachment; filename= {zip_filename}")
            msg.attach(part)
        
        # --- PERBAIKAN LOGIKA KONEKSI ---
        # Coba paksa koneksi (Gunakan timeout agar tidak hang)
        if SMTP_PORT == 465:
            server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, timeout=10)
        else:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10)
            server.starttls() # Penting untuk port 587
            
        server.login(SMTP_EMAIL, SMTP_PASSWORD)
        server.sendmail(SMTP_EMAIL, RECIPIENT_EMAIL, msg.as_string())
        server.quit()
        return True, "Terkirim"
    except Exception as e:
        return False, str(e)

# ==========================================
# 8. UPDATE FUNGSI BACKUP (DENGAN TOMBOL KEMBALI)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "srv_backup")
def backup_handler(call):
    chat_id = call.message.chat.id
    
    # Pesan tunggu
    wait = bot.send_message(chat_id, "⏳ <b>Memproses Backup...</b>", parse_mode='HTML')
    
    zname = ""
    try:
        # 1. Membuat file ZIP
        zname = f"Backup_Bot_{datetime.now().strftime('%Y%m%d_%H%M')}.zip"
        with zipfile.ZipFile(zname, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk('.'):
                for file in files:
                    # Filter file yang mau di backup
                    if file.endswith(('.py', '.db', '.json', '.txt')) and not file.startswith('Backup_'):
                        zipf.write(os.path.join(root, file))
        
        # 2. Mengirim Email
        is_sent, status_msg = send_email_backup(zname)
        status_icon = "✅" if is_sent else "⚠️"
        
        # 3. MEMBUAT TOMBOL KEMBALI (Updated)
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="setting_menu"))

        # 4. Mengirim File ke Telegram dengan Tombol
        with open(zname, 'rb') as f:
            caption_text = (
                f"📦 <b>BACKUP SYSTEM SELESAI</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"{status_icon} <b>Status Email:</b> {status_msg}\n"
                f"📅 <b>Waktu:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            bot.send_document(
                chat_id, 
                f, 
                caption=caption_text, 
                parse_mode='HTML', 
                reply_markup=markup  # <--- Tombol dimasukkan di sini
            )
        
        # Hapus pesan tunggu
        bot.delete_message(chat_id, wait.message_id)

    except Exception as e:
        # Jika error coding/permissions
        markup_err = InlineKeyboardMarkup()
        markup_err.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="setting_menu"))
        bot.edit_message_text(f"❌ <b>Error Backup:</b> {e}", chat_id, wait.message_id, parse_mode='HTML', reply_markup=markup_err)
    
    finally:
        # Bersihkan file zip lokal
        if zname and os.path.exists(zname): os.remove(zname)

@bot.callback_query_handler(func=lambda call: call.data == "srv_restart")
def restart_bot(call):
    bot.answer_callback_query(call.id, "♻️ Restarting Bot...")
    with open("restart_state.json", "w") as f:
        json.dump({"chat_id": call.message.chat.id, "message_id": call.message.message_id}, f)
    import subprocess
    subprocess.Popen(["systemctl", "restart", "bot-store"])

@bot.callback_query_handler(func=lambda call: call.data.startswith("oke_confirm"))
def oke_confirm(call):
    try:
        parts = call.data.split("|")
        if len(parts) < 4: return bot.answer_callback_query(call.id, "❌ Data tidak valid.", show_alert=True)
        code = parts[1]
        dest = parts[2]
        price = int(parts[3])
        ref_id = parts[4] if len(parts) > 4 else f"TRX-{int(time.time())}"
        
        uid = call.from_user.id
        user_data = get_user_data(uid)
        
        if user_data['balance'] < price:
            return bot.answer_callback_query(call.id, "⚠️ Saldo tidak cukup!", show_alert=True)
            
        bot.answer_callback_query(call.id, "⏳ Memproses transaksi...")
        bot.edit_message_text(f"🔄 <b>Mengirim Order...</b>\n📦 {code} -> {dest}", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        
        try:
            if buy_okeconnect_product:
                status, sn, info_res = buy_okeconnect_product(code, dest, ref_id)
            else:
                status, sn, info_res = False, "", "Service PPOB Off."
        except Exception as e:
            status, sn, info_res = False, "", f"Error API: {str(e)}"

        if status:
            add_balance(uid, -price, f"Beli {code} {dest}")
            increment_reseller_trx(uid)
            msg = f"✅ <b>SUKSES!</b>\n📦 {code}\n📱 {dest}\n🎟 SN: <code>{sn}</code>"
        else:
            msg = f"❌ <b>GAGAL</b>\n📦 {code}\n⚠️ {info_res}"
                    
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML')
        try: bot.delete_message(call.message.chat.id, call.message.message_id)
        except: pass

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error: {e}")
        
# ==========================================
#  HANDLER VMESS REMOTE
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vmess_vps"))
def check_vmess_vps(call):
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        page = int(parts[2]) if len(parts) > 2 else 0
    except: lokasi = "sg"; page = 0

    cmd = "grep '^###' /etc/vmess/.vmess.db | awk '{print $2}'"
    users = eksekusi_remote(lokasi, cmd)

    per_page = 5
    total_items = len(users)

    # --- [BAGIAN INI DIGANTI] ---
    # Hapus/Ganti baris math.ceil dengan rumus ini:
    total_pages = (total_items + per_page - 1) // per_page
    # ----------------------------

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    sliced_data = users[start:end]

    msg = f"<b>⚡ LIST VMESS ({lokasi.upper()})</b>\nTotal: {total_items} User | Page: {page+1}/{total_pages}\n━━━━━━━━━━━━━━━━━━\n"
    markup = InlineKeyboardMarkup()
    
    if not users:
        msg += "<i>Belum ada user VMess.</i>"
    else:
        for u in sliced_data:
            msg += f"👤 <b>{u}</b>\n"
            markup.add(InlineKeyboardButton(f"🗑️ Hapus {u}", callback_data=f"del_vmess|{lokasi}|{u}|{page}"))
    
    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️", callback_data=f"check_vmess_vps|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vmess_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("➡️", callback_data=f"check_vmess_vps|{lokasi}|{page+1}"))

    markup.row(*nav)
    markup.add(InlineKeyboardButton(f"🔙 KEMBALI", callback_data=f"monitor_{lokasi}"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vless_vps"))
def check_vless_vps(call):
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        
        # --- LOGIC BARU: DETEKSI SUMBER PANGGILAN ---
        # Jika dipanggil dari tombol 'del_vless' (setelah hapus), posisi page ada di index 3
        if "del_vless" in parts[0]: 
            page = int(parts[3]) if len(parts) > 3 else 0
        else:
            # Jika dari menu biasa, page ada di index 2
            page = int(parts[2]) if len(parts) > 2 else 0
    except: 
        lokasi = "sg"
        page = 0

    # Ambil data dari config (Grep tanpa tanda ^ agar lebih kuat membaca spasi)
    cmd = "grep '#& ' /etc/xray/config.json" 
    raw_lines = eksekusi_remote(lokasi, cmd)

    users = []
    seen = set()
    
    import time
    now_ts = time.time() 

    if raw_lines:
        for line in raw_lines:
            try:
                line = line.strip()
                parts = line.split()
                if len(parts) >= 3 and parts[0] == "#&":
                    u_name = parts[1]
                    u_exp_str = parts[2]

                    # Filter duplikat (Username /start TETAP DIMUNCULKAN agar bisa dihapus)
                    if u_name in seen: continue
                    seen.add(u_name)

                    try:
                        exp_struct = time.strptime(u_exp_str, "%Y-%m-%d")
                        exp_ts = time.mktime(exp_struct)
                        sisa_hari = int((exp_ts - now_ts) / 86400)
                        tgl_display = time.strftime("%d %b %Y", exp_struct)
                    except:
                        sisa_hari = -999 
                        tgl_display = u_exp_str 

                    if sisa_hari >= 0:
                        status_icon = "✅ Active"
                        ket_hari = f"{sisa_hari} Hari"
                    else:
                        status_icon = "❌ Expired"
                        ket_hari = "DEAD ☠️"

                    users.append({
                        "name": u_name,
                        "exp_date": tgl_display,
                        "status": status_icon,
                        "ket": ket_hari,
                        "sort_val": sisa_hari
                    })
            except: continue

    users.sort(key=lambda x: x['sort_val'], reverse=True)

    per_page = 5
    total_items = len(users)
    total_pages = (total_items + per_page - 1) // per_page

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    sliced_data = users[start:end]

    msg = f"<b>🔮 LIST VLESS ({lokasi.upper()})</b>\n"
    msg += f"Total: {total_items} User | Page: {page+1}/{total_pages}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    markup = InlineKeyboardMarkup()

    if not users:
        msg += "<i>Belum ada user Vless.</i>"
    else:
        for u in sliced_data:
            msg += f"👤 <b>{u['name']}</b>\n"
            msg += f"📅 <b>Exp: {u['exp_date']}</b>\n"
            msg += f"🏳️ {u['status']} ({u['ket']})\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            # Tombol Hapus (Callback data disiapkan untuk handler delete)
            markup.add(InlineKeyboardButton(f"🗑️ Hapus {u['name']}", callback_data=f"del_vless|{lokasi}|{u['name']}|{page}"))

    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️", callback_data=f"check_vless_vps|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vless_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("➡️", callback_data=f"check_vless_vps|{lokasi}|{page+1}"))

    if nav: markup.row(*nav)
    markup.add(InlineKeyboardButton(f"🔙 KEMBALI", callback_data=f"monitor_{lokasi}"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

    
# ==========================================
#  HANDLER DELETE REMOTE (VMESS/VLESS/TROJAN)
# ==========================================

@bot.callback_query_handler(func=lambda call: call.data.startswith("vms_del_rem"))
def del_vmess(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except:
        return bot.answer_callback_query(call.id, "Data Error", show_alert=True)
        
    try:
        client = get_ssh_connection_monitor(lokasi)
        if client:
            # PERBAIKAN COMMAND HAPUS (Lebih Agresif & Aman)
            # Menghapus blok konfigurasi dari baris ### username hingga kurung tutup },
            cmd = f"""
            sed -i "/^### {user} /d" /etc/vmess/.vmess.db
            sed -i "\|### {user} |,\|}}|d" /etc/xray/config.json
            rm -f /etc/vmess/{user}*
            rm -f /etc/kyt/limit/vmess/ip/{user}
            systemctl restart xray
            """
            
            client.exec_command(cmd)
            client.close()
            
            bot.answer_callback_query(call.id, f"✅ {user} Dihapus dari sistem!", show_alert=True)
            render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
        else:
            bot.answer_callback_query(call.id, f"❌ Gagal koneksi SSH", show_alert=True)
    except Exception as e: 
        bot.answer_callback_query(call.id, f"Error: {str(e)[:50]}", show_alert=True)

@bot.callback_query_handler(func=lambda call: call.data.startswith("del_vless"))
def del_vless_remote(call):
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except: return

    # --- PERBAIKAN COMMAND SED ---
    # Menggunakan delimiter '|' agar tanda '/' pada username '/start' tidak bikin error
    # Syntax: sed -i "\|pola_awal|,\|pola_akhir|d" file
    
    cmd = f"""
    sed -i "\|#& {user} |,\|}}|d" /etc/xray/config.json
    sed -i "\|### {user} |d" /etc/vless/.vless.db
    rm -f "/etc/kyt/limit/vless/ip/{user}"
    systemctl restart xray
    """
    
    eksekusi_remote(lokasi, cmd)
    bot.answer_callback_query(call.id, f"✅ User {user} berhasil dihapus!", show_alert=True)
    
    # Refresh list (Fungsi check_vless_vps di atas sudah siap menerima data ini)
    check_vless_vps(call)

# 3. HAPUS TROJAN
@bot.callback_query_handler(func=lambda call: call.data.startswith("del_trojan"))
def del_trojan_remote(call):
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except: return

    cmd = f"sed -i '/^### {user} /d' /etc/trojan/.trojan.db"
    eksekusi_remote(lokasi, cmd)
    
    bot.answer_callback_query(call.id, f"✅ User {user} dihapus dari {lokasi.upper()}", show_alert=True)
    check_trojan_vps(call)

