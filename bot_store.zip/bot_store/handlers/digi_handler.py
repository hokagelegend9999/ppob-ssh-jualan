import time
from bot_init import bot 
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from menus import menu_digi_categories, menu_digi_brands, menu_digi_products
# Import Logic
from digi.digiflazz_logic import transaksi_prabayar

# Dictionary sementara untuk menyimpan status user saat input nomor
user_trans_state = {}

# ==========================================
# 1. HANDLER NAVIGASI MENU (KATEGORI/BRAND)
# ==========================================

@bot.callback_query_handler(func=lambda call: call.data.startswith('digi_'))
def digi_navigation_handler(call):
    cmd = call.data.split("|")
    
    # MENU UTAMA KATEGORI
    if cmd[0] == "digi_menu":
        text_msg = (
            "🛍️ <b>DIGITAL STORE MENU</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "Silakan pilih kategori produk digital\n"
            "yang Anda butuhkan di bawah ini:"
        )
        bot.edit_message_text(
            text_msg, 
            call.message.chat.id, 
            call.message.message_id, 
            parse_mode='HTML', 
            reply_markup=menu_digi_categories()
        )
    
    # MENU PILIH BRAND/PROVIDER
    elif cmd[0] == "digi_cat":
        category = cmd[1]
        text_msg = (
            f"📂 <b>KATEGORI: {category.upper()}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "Pilih Provider / Operator tujuan:"
        )
        bot.edit_message_text(
            text_msg, 
            call.message.chat.id, 
            call.message.message_id, 
            parse_mode='HTML', 
            reply_markup=menu_digi_brands(category)
        )
    
    # MENU PILIH PRODUK
    elif cmd[0] == "digi_brand":
        category, brand = cmd[1], cmd[2]
        text_msg = (
            f"📦 <b>{brand} - {category.upper()}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "🟢 = Stok Tersedia\n"
            "🔴 = Gangguan / Kosong\n\n"
            "<i>Silakan klik paket untuk membeli:</i>"
        )
        bot.edit_message_text(
            text_msg, 
            call.message.chat.id, 
            call.message.message_id, 
            parse_mode='HTML', 
            reply_markup=menu_digi_products(category, brand)
        )

# ==========================================
# 2. HANDLER TRANSAKSI PRABAYAR
# ==========================================

# --- FITUR BARU: TOMBOL BATAL ---
@bot.callback_query_handler(func=lambda call: call.data == 'cancel_digi_trx')
def cancel_transaction(call):
    chat_id = call.message.chat.id
    
    # 1. Hentikan Bot Menunggu Input (Clear Step Handler)
    bot.clear_step_handler_by_chat_id(chat_id)
    
    # 2. Hapus Data Sementara
    if chat_id in user_trans_state:
        del user_trans_state[chat_id]
        
    # 3. Hapus Pesan "Masukkan Nomor"
    try:
        bot.delete_message(chat_id, call.message.message_id)
    except:
        pass

    # 4. Kirim Notifikasi Batal
    bot.send_message(chat_id, "❌ <b>Transaksi Dibatalkan.</b>", parse_mode='HTML')
    # Opsional: Bisa langsung tampilkan menu kategori lagi
    # bot.send_message(chat_id, "Mau beli yang lain?", reply_markup=menu_digi_categories())


# Step 1: Saat tombol produk diklik
@bot.callback_query_handler(func=lambda call: call.data.startswith('buy_digi|'))
def ask_phone_number(call):
    # Data dari tombol: buy_digi|KODE_SKU
    sku_code = call.data.split('|')[1]
    
    # Simpan SKU yang dipilih user ke memori sementara
    user_trans_state[call.message.chat.id] = {'sku': sku_code}
    
    # --- TAMBAHAN TOMBOL BATAL ---
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="cancel_digi_trx"))
    
    # Minta user input nomor
    msg = bot.send_message(
        call.message.chat.id, 
        "📞 <b>MASUKKAN NOMOR TUJUAN:</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        "Silakan ketik nomor HP / ID Pelanggan / Nomor Meter\n"
        "<i>Contoh: 081234567890</i>",
        parse_mode='HTML',
        reply_markup=markup  # <--- Tempel tombol batal disini
    )
    
    # Register langkah selanjutnya ke fungsi 'process_transaction_prabayar'
    bot.register_next_step_handler(msg, process_transaction_prabayar)

# Step 2: Proses Transaksi setelah kirim nomor
def process_transaction_prabayar(message):
    chat_id = message.chat.id
    nomor_tujuan = message.text
    
    # Validasi input (harus angka)
    if not nomor_tujuan.isdigit():
        bot.send_message(chat_id, "❌ <b>Nomor tidak valid!</b> Harap ulangi pembelian dan masukkan hanya angka.", parse_mode='HTML')
        return

    # Ambil data SKU yang tadi disimpan
    state = user_trans_state.get(chat_id)
    if not state:
        bot.send_message(chat_id, "⚠️ Sesi habis / Dibatalkan. Silakan pilih produk ulang.")
        return
    
    sku_code = state['sku']
    
    # Buat Ref ID Unik (Contoh: TRX-WaktuSekarang)
    ref_id = f"TRX-{int(time.time())}"
    
    # Beri notifikasi loading
    loading_msg = bot.send_message(chat_id, "⏳ <b>Sedang memproses transaksi...</b>", parse_mode='HTML')
    
    # --- TEMBAK API DIGIFLAZZ ---
    result = transaksi_prabayar(sku_code, nomor_tujuan, ref_id)
    
    # Hapus pesan loading
    try:
        bot.delete_message(chat_id, loading_msg.message_id)
    except:
        pass
    
    # Proses Hasil
    if result and isinstance(result, dict):
        status = result.get('status')      # Sukses / Pending / Gagal
        sn = result.get('sn', '')          # Serial Number
        rc = result.get('rc')              # Response Code
        pesan = result.get('message')      # Pesan Server
        
        if status == "Sukses" or status == "Pending":
            reply = (
                "✅ <b>TRANSAKSI BERHASIL / DIPROSES!</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"📦 <b>Produk:</b> {sku_code}\n"
                f"📱 <b>Tujuan:</b> {nomor_tujuan}\n"
                f"🧾 <b>SN:</b> <code>{sn}</code>\n"
                f"📝 <b>Status:</b> {status}\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                "<i>Terima kasih sudah order!</i>"
            )
        else:
            # Transaksi Gagal
            reply = (
                "❌ <b>TRANSAKSI GAGAL!</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"Alasan: {pesan}\n"
                f"RC: {rc}\n"
                "<i>Silakan hubungi Admin jika saldo terpotong.</i>"
            )
    else:
        reply = "❌ <b>Gagal menghubungi server.</b> Silakan coba lagi nanti."
        
    bot.send_message(chat_id, reply, parse_mode='HTML')
    
    # Bersihkan state memori
    if chat_id in user_trans_state:
        del user_trans_state[chat_id]