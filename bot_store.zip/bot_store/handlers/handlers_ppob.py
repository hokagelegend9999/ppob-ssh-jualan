# handlers/handlers_ppob.py
import telebot
import requests
import json
import time
import logging
import re
from datetime import datetime
from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot.apihelper import ApiTelegramException
from database import get_user_data, add_balance, update_saldo, increment_reseller_trx, save_ppob_transaction, update_transaction_status, check_transaction_exists
from config import ADMIN_ID, ATLANTIC_API_KEY, ATLANTIC_TRX_URL
import sqlite3
# Import Service Atlantic & OkeConnect
from atlantic_service import get_atlantic_price_list
try:
    from orderkuota_service import get_okeconnect_price, request_orderkuota_trx, check_orderkuota_status
except ImportError:
    # Dummy handler jika file tidak ada
    def get_okeconnect_price(): return []
    def request_orderkuota_trx(a,b,c): return {'success': False, 'msg': 'Module Missing'}
    def check_orderkuota_status(a,b,c=None,d=None): return "Error Module"

# Konfigurasi Logger
logger = logging.getLogger(__name__)
MARKUP_MEMBER = 3000
MARKUP_RESELLER = 2000

# ==========================================
#  HELPER UTILS
# ==========================================
def sensor_pesan_error(pesan_asli):
    """Mengubah pesan error sensitif menjadi pesan umum."""
    pesan_lower = str(pesan_asli).lower()
    kata_terlarang = ["saldo", "balance", "not enough", "insufficient", "kurang", "limit", "deposit", "cutoff"]
    if any(word in pesan_lower for word in kata_terlarang):
        return "⚠️ Sedang Gangguan Pusat (Maintenance)"
    return pesan_asli

def parse_respon_server(raw_text):
    """Memecah respon server jadi SN, Harga, dan Info Sisa"""
    data = {'sn': '-', 'harga': '0', 'info_sisa': '-'}
    try:
        pattern = r"SN:\s*(.*?)\.\s*Hrg\s*([\d\.]+)\s*(.*)"
        match = re.search(pattern, raw_text, re.IGNORECASE | re.DOTALL)
        if match:
            data['sn'] = match.group(1).strip()
            data['harga'] = match.group(2).strip()
            data['info_sisa'] = match.group(3).strip()
        else:
            simple_sn = re.search(r"SN:\s*(.*?)(?:\.|$)", raw_text, re.IGNORECASE)
            if simple_sn: data['sn'] = simple_sn.group(1).strip()
    except Exception as e:
        print(f"Regex Error: {e}")
    return data

def log_act(user, action, detail=""):
    try:
        username = user.username if user.username else "NoUsername"
        print(f"📝 [AKTIVITAS] ID:{user.id} | @{username} | {action} | {detail}")
    except:
        print(f"📝 [AKTIVITAS] ID:{user.id} | {action}")

# ==========================================
#  1. MENU UTAMA: OKECONNECT (FIXED INDENTATION)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "ppob_menu" or call.data == "ppob_orderkuota")
def ppob_okeconnect_main(call):
    try:
        log_act(call.from_user, "MEMBUKA MENU OKECONNECT")
        bot.answer_callback_query(call.id)
        
        uid = call.from_user.id
        user = get_user_data(uid)
        if user:
            raw_balance = user.get('balance', 0)
            balance = int(raw_balance if raw_balance is not None else 0)
        else:
            balance = 0
        balance = user['balance'] if user else 0
        
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("🔴 TELKOMSEL", callback_data="oke_op|TELKOMSEL|1"),
            InlineKeyboardButton("🟡 INDOSAT", callback_data="oke_op|INDOSAT|1"),
            InlineKeyboardButton("🔵 XL", callback_data="oke_op|XL|1"),
            InlineKeyboardButton("👻 BY.U", callback_data="oke_op|BYU|1")
        )
        markup.row(
            InlineKeyboardButton("🟣 AXIS", callback_data="oke_op|AXIS|1"),
            InlineKeyboardButton("3️⃣ TRI", callback_data="oke_op|THREE|1"),
            InlineKeyboardButton("📶 SMARTFREN", callback_data="oke_op|SMARTFREN|1")
        )
        markup.row(
            InlineKeyboardButton("💡 PLN TOKEN", callback_data="oke_op|PLN|1"),
            InlineKeyboardButton("💎 GAMES", callback_data="oke_op|GAME|1"),
            InlineKeyboardButton("💳 E-MONEY", callback_data="oke_op|DANA|1")
        )
        markup.row(InlineKeyboardButton("🔍 CEK VALIDASI AKUN", callback_data="oke_op|DIGITAL_CHECK|1"))
        markup.row(InlineKeyboardButton("📱 PULSA (ALL OPR)", callback_data="oke_op|PULSA|1"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU UTAMA", callback_data="switch_owner"))
        
        msg = (f"🏪 <b>PPOB OKECONNECT (MURAH)</b>\n"
               f"━━━━━━━━━━━━━━━━━━━━━\n"
               f"💰 <b>Saldo:</b> <code>Rp {balance:,}</code>\n"
               f"👇 <i>Pilih operator layanan:</i>")
    
        # --- PERBAIKAN: TRY-EXCEPT UNTUK EDIT MESSAGE ---
        try:
            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except ApiTelegramException as e:
            # Jika error karena pesan sama persis (User klik 2x), abaikan saja
            if "message is not modified" in str(e):
                pass 
            else:
                logger.error(f"Error Oke Main (API): {e}")
        # ------------------------------------------------

    except Exception as e: 
        logger.error(f"Error Oke Main: {e}")

# ==========================================
#  2. LIST PRODUK OKECONNECT
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("oke_op|"))
def ppob_oke_list_product(call):
    try:
        parts = call.data.split("|")
        operator, page = parts[1].upper(), int(parts[2])
        
        if page == 1: log_act(call.from_user, "MELIHAT HARGA OKE", operator)
        
        all_data = get_okeconnect_price()
        if not all_data:
            return bot.edit_message_text("❌ Gagal mengambil data harga.", call.message.chat.id, call.message.message_id, reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_menu")))

        # --- LOGIKA FILTERING ---
        filtered = []
        for p in all_data:
            raw_kode = str(p.get('kode', '')).upper()
            raw_ket = str(p.get('keterangan', '')).upper()
            raw_kat = str(p.get('kategori', '')).upper()
            
            if operator == "DIGITAL_CHECK":
                if raw_kode.startswith("CEK"): filtered.append(p)
            elif operator == "PULSA":
                if "PULSA" in raw_kat or "PULSA" in raw_ket: filtered.append(p)
            elif operator == "PLN":
                if "PLN" in raw_kode: filtered.append(p)
            elif operator == "BYU":
                if "BYU" in raw_kat or "BY.U" in raw_kat or "BYU" in raw_ket: filtered.append(p)
            elif operator == "DANA":
                if any(x in raw_kat or x in raw_ket for x in ["DANA", "OVO", "GOPAY", "SHOPEE", "LINKAJA", "EMONEY", "BRIZZI", "TAPCASH", "FLAZZ"]):
                    filtered.append(p)
            else:
                if operator in (raw_kat + raw_ket): filtered.append(p)

        filtered.sort(key=lambda x: x['keterangan'])

        # Pagination
        LIMIT = 10
        total_items = len(filtered)
        total_pages = (total_items + LIMIT - 1) // LIMIT if total_items > 0 else 1
        page = max(1, min(page, total_pages))
        current_items = filtered[(page-1)*LIMIT : page*LIMIT]
        
        udata = get_user_data(call.from_user.id)
        markup_val = MARKUP_RESELLER if udata and str(udata.get('role')).lower() == 'reseller' else MARKUP_MEMBER
        display_op = "CEK VALIDASI AKUN" if operator == "DIGITAL_CHECK" else operator
        
        msg = f"✨ <b>DAFTAR PRODUK: {display_op}</b>\n📄 Halaman: {page} / {total_pages}\n━━━━━━━━━━━━━━━━━━━━━\n\n"
        markup = InlineKeyboardMarkup(row_width=5)
        btns = []
        
        if not current_items:
            msg += "❌ <b>Produk tidak ditemukan / Kosong.</b>"
        else:
            for i, item in enumerate(current_items, 1):
                price = int(item['harga']) + markup_val
                raw_status = str(item.get('status', '1')) 
                
                if raw_status == '1':
                    status_icon, status_text = "🟢", "Tersedia"
                    btn_label = str(i)
                    cb_data = f"okebuy|{item['kode']}|{price}|{operator}"
                else:
                    status_icon, status_text = "🔴", "Gangguan"
                    btn_label, cb_data = "❌", "ignore"

                msg += f"<b>[{i}] {item['keterangan']}</b>\n🆔 <b>CODE:</b> <code>{item['kode']}</code>\n💰 <b>HARGA:</b> <b>Rp {price:,}</b>\n📊 <b>STATUS:</b> {status_icon} <i>{status_text}</i>\n─────────────────────\n"
                btns.append(InlineKeyboardButton(btn_label, callback_data=cb_data))
        
        markup.add(*btns)
        nav = []
        if page > 1: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"oke_op|{operator}|{page-1}"))
        nav.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
        if page < total_pages: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"oke_op|{operator}|{page+1}"))
        
        markup.row(*nav)
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_menu"))
        
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    
    except Exception as e:
        if "message is not modified" not in str(e):
            print(f"Error Edit Message: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "ppob_atlantic")
def ppob_atlantic_main(call):
    log_act(call.from_user, "MEMBUKA MENU UTAMA PPOB (ATL)")
    bot.answer_callback_query(call.id, "🔄 Memuat Atlantic...")
    
    # Ambil data
    res = get_atlantic_price_list("prabayar")
    
    # [FIX] Tambahkan "res and" untuk mencegah crash jika None
    if res and res.get('status') is True:
        markup = InlineKeyboardMarkup()
        markup.row(InlineKeyboardButton("🔴 TELKOMSEL", callback_data="atl_prov|TELKOMSEL"), InlineKeyboardButton("🟡 INDOSAT", callback_data="atl_prov|INDOSAT"))
        markup.row(InlineKeyboardButton("🔵 XL AXIATA", callback_data="atl_prov|XL"), InlineKeyboardButton("🟣 AXIS", callback_data="atl_prov|AXIS"))
        markup.row(InlineKeyboardButton("3️⃣ THREE", callback_data="atl_prov|TRI"), InlineKeyboardButton("📶 SMARTFREN", callback_data="atl_prov|SMARTFREN"))
        markup.row(InlineKeyboardButton("💎 MLBB", callback_data="atl_cat|MOBILE LEGENDS|Games|1"), InlineKeyboardButton("🔫 PUBG", callback_data="atl_cat|PUBG MOBILE|Games|1"), InlineKeyboardButton("⚔️ GENSHIN", callback_data="atl_cat|Genshin Impact|Games|1"))
        markup.row(InlineKeyboardButton("🏗️ ROBLOX", callback_data="atl_cat|ROBLOX|Games|1"), InlineKeyboardButton("🪄 CANVA", callback_data="atl_cat|CANVA|Akun Premium|1"))
        markup.row(InlineKeyboardButton("💡 PLN", callback_data="atl_prov|PLN"), InlineKeyboardButton("🎮 LAYANAN LAINNYA", callback_data="atl_more_menu"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU UTAMA", callback_data="switch_owner"))
        
        msg = ("🏛 <b>PUSAT LAYANAN DIGITAL TERLENGKAP</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n💎 <b>Solusi Transaksi Cepat & Terpercaya</b>\n\n👇 <b>Pilih Kategori Layanan Anda:</b>")
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    else: 
        # Pesan jika server down/None
        bot.send_message(call.message.chat.id, "❌ Gagal koneksi ke server Atlantic (Server Down).")

@bot.callback_query_handler(func=lambda call: call.data.startswith("atl_prov|"))
def ppob_atl_category(call):
    try:
        provider = call.data.split("|")[1]
        log_act(call.from_user, "MEMBUKA PROVIDER", provider)
        bot.answer_callback_query(call.id, f"🔄 Memuat kategori {provider}...")
        
        res = get_atlantic_price_list("prabayar")
        
        # [FIX] Tambahkan "res and" agar aman
        if res and res.get('status') is True:
            all_data = res.get('data', [])
            cats = set()
            search_prov = provider.lower().replace(" ", "")
            
            for p in all_data:
                data_prov = str(p.get('provider', '')).lower().replace(" ", "")
                match_prov = (data_prov == search_prov) or (search_prov == 'tri' and 'three' in data_prov) or (search_prov == 'three' and 'tri' in data_prov)
                if match_prov: cats.add(p.get('category'))
            
            sorted_cats = sorted(list(cats))
            markup = InlineKeyboardMarkup(row_width=2)
            for c in sorted_cats: 
                markup.add(InlineKeyboardButton(f"📂 {c}", callback_data=f"atl_cat|{provider}|{c}|1"))
            
            markup.row(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_atlantic"))
            msg = f"🔵 <b>LAYANAN: {provider}</b>\n👇 Silakan pilih kategori produk:" if sorted_cats else f"❌ Kategori untuk <b>{provider}</b> tidak ditemukan."
            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        else:
            bot.answer_callback_query(call.id, "❌ Gagal mengambil data (Server Gangguan).", show_alert=True)
    except Exception as e:
        print(f"❌ [ERROR] category: {e}")

# ==========================================
#  HANDLER PRODUK ATLANTIC (FIXED & SAFE)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("atl_cat|"))
def ppob_atl_products(call):
    try:
        # 1. Parsing Data dari Tombol
        parts = call.data.split("|")
        prov, cat, page = parts[1], parts[2], int(parts[3])
        
        # Log aktivitas hanya di halaman 1 agar tidak spam log
        if page == 1: 
            log_act(call.from_user, "MELIHAT PRODUK", f"{prov} - {cat}")
        
        bot.answer_callback_query(call.id, f"🔄 Memuat {prov}...")
        
        # 2. Ambil Data dari API Atlantic
        res = get_atlantic_price_list("prabayar")
        
        # [FIX PENTING] Cek apakah 'res' ada isinya dan statusnya True
        # Ini mencegah error 'NoneType object has no attribute get'
        if res and res.get('status') is True:
            all_products = res.get('data', [])
            
            # Helper untuk membersihkan teks (huruf kecil & tanpa spasi)
            def clean(text): return str(text).lower().replace(" ", "")
            search_prov, search_cat = clean(prov), clean(cat)

            filtered_products = []
            
            # 3. Filtering Produk
            for p in all_products:
                item_prov = clean(p.get('provider', ''))
                item_cat = clean(p.get('category', ''))
                
                # Daftar kata kunci layanan khusus (bukan provider seluler biasa)
                special_keywords = ["mobilelegends", "roblox", "pubg", "hbo", "dana", "ovo", "gopay", "shopee", "linkaja", "maxim", "grab", "gojek", "wifi", "spotify", "capcut", "bstation", "vidio", "viu", "netflix", "disney", "youtube", "genshin", "freefire","chatgpt", "callofduty"]
                
                # Logika Filter
                if any(x in search_prov for x in special_keywords):
                    # Jika layanan khusus, cocokkan providernya saja
                    if search_prov in item_prov: 
                        filtered_products.append(p)
                else:
                    # Jika pulsa/data reguler, cocokkan Provider DAN Kategori
                    # Handle kasus "Tri" vs "Three"
                    match_prov = (item_prov == search_prov) or \
                                 (search_prov == 'tri' and 'three' in item_prov) or \
                                 (search_prov == 'three' and 'tri' in item_prov)
                    
                    if match_prov and search_cat in item_cat: 
                        filtered_products.append(p)
            
            # Sortir berdasarkan Harga Termurah
            filtered_products.sort(key=lambda x: int(x.get('price', 0)))
            
            # 4. Pagination (Membagi Halaman)
            LIMIT = 10
            total_items = len(filtered_products)
            total_pages = (total_items + LIMIT - 1) // LIMIT if total_items > 0 else 1
            page = max(1, min(page, total_pages))
            current_items = filtered_products[(page-1)*LIMIT : page*LIMIT]
            
            # Cek User Role (Reseller/Member) untuk Markup Harga
            udata = get_user_data(call.from_user.id)
            markup_val = MARKUP_RESELLER if udata and str(udata.get('role')).lower() == 'reseller' else MARKUP_MEMBER
            
            # Header Pesan
            msg = f"✨ <b>DETAIL LAYANAN: {prov.upper()}</b>\n📄 Halaman: {page} / {total_pages}\n━━━━━━━━━━━━━━━━━━━━━\n\n"
            markup = InlineKeyboardMarkup(row_width=5)
            nums_btns = []
            
            if not current_items:
                msg += "❌ <b>Produk tidak ditemukan atau Kosong.</b>"
            else:
                for i, p in enumerate(current_items, 1):
                    # Hitung Harga Jual
                    price = int(p.get('price', 0)) + markup_val
                    
                    # Cek Status Stok
                    raw_status = str(p.get('status', 'empty')).lower()
                    status_icon = "🟢" if raw_status == 'available' else "🔴"
                    catatan = p.get('note', '-') or '-'
                    
                    # Tampilan List Produk
                    msg += (f"<b>[{i}] {p.get('name')}</b>\n"
                            f"🆔 <code>{p.get('code')}</code>\n"
                            f"💰 <b>Rp {price:,}</b>\n"
                            f"📊 {status_icon} <i>{raw_status.capitalize()}</i>\n"
                            f"📝 {catatan}\n"
                            f"─────────────────────\n")
                    
                    # Buat Tombol Angka
                    btn_label = str(i) if raw_status == 'available' else "❌"
                    # Callback Data: atlbeli | Kode | Harga | Provider
                    cb = f"atlbeli|{p['code']}|{price}|{prov}" if raw_status == 'available' else "ignore"
                    nums_btns.append(InlineKeyboardButton(btn_label, callback_data=cb))
            
            # Pasang Tombol Angka
            markup.add(*nums_btns)
            
            # 5. Tombol Navigasi (Prev/Next)
            nav = []
            if page > 1: 
                nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"atl_cat|{prov}|{cat}|{page-1}"))
            
            nav.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
            
            if page < total_pages: 
                nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"atl_cat|{prov}|{cat}|{page+1}"))
            
            markup.row(*nav)
            
            # 6. Tombol Kembali (Context Aware)
            premium_provs = ["NETFLIX", "PICSART", "VIDIO", "WIFI", "PERPLEXITY", "HBO", 
                "SPOTIFY", "CAPCUT", "BSTATION", "VIU", "YOUTUBE", "GENSHIN", 
                "DISNEY", "CHATGPT"]
            emoney_provs = ["DANA", "OVO", "GOPAY", "SHOPEE", "LINKAJA", "MAXIM", "GRAB", "GOJEK"]
            
            if any(x in prov.upper() for x in premium_provs):
                markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU PREMIUM", callback_data="atl_more_menu"))
            elif any(x in prov.upper() for x in emoney_provs):
                markup.add(InlineKeyboardButton("🔙 KEMBALI KE E-MONEY", callback_data="atl_special_cat|EMONEY"))
            else:
                markup.add(InlineKeyboardButton("🔙 KEMBALI KE KATEGORI", callback_data=f"atl_prov|{prov}"))
            
            # Kirim/Edit Pesan
            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
            
        else:
            # HANDLER JIKA SERVER DOWN / RESPONSE NONE
            bot.answer_callback_query(call.id, "❌ Gagal sinkronisasi data (Server Gangguan).", show_alert=True)
            
    except Exception as e:
        print(f"Error atl_products: {e}")
        # Jangan kirim pesan error ke user agar bot tidak terlihat crash, cukup print di console

# ==========================================
#  5. HANDLER INPUT DESTINASI
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("okebuy|") or call.data.startswith("atlbeli|"))
def ppob_input_dest(call):
    parts = call.data.split("|")
    prefix, kode, harga, op = ("OKE" if parts[0] == "okebuy" else "ATL"), parts[1], parts[2], parts[3]
    log_act(call.from_user, "KLIK BELI", f"{op} - {kode}")
    
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    premium_keywords = ["CANVA", "NETFLIX", "SPOTIFY", "YOUTUBE", "GENSHIN", "PERPLEXITY"]
    if any(x in op.upper() for x in premium_keywords): prompt_text = "📧 <b>Kirim Email / ID Akun Tujuan:</b>"
    elif op.upper() == "PLN": prompt_text = "💡 <b>Kirim ID Pelanggan / Nomor Meter:</b>"
    else: prompt_text = "📱 <b>Kirim Nomor HP Tujuan:</b>"

    markup = InlineKeyboardMarkup()
    back_data = f"oke_op|{op}|1" if prefix == "OKE" else f"atl_prov|{op}"
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=back_data))

    msg = bot.send_message(call.message.chat.id, f"🛒 <b>BELI {op} ({prefix})</b>\n📦 Kode: <code>{kode}</code>\n💰 Harga: Rp {int(harga):,}\n\n👇 {prompt_text}", parse_mode='HTML', reply_markup=markup)
    
    if prefix == "OKE": bot.register_next_step_handler(msg, oke_confirm, kode, harga, op)
    else: bot.register_next_step_handler(msg, atl_confirm, kode, harga, op)

def oke_confirm(message, kode, harga, op):
    try:
        dest = message.text.strip()
        if op != "DIGITAL_CHECK" and not dest.isdigit() and not dest.isalnum():
            msg = bot.reply_to(message, "❌ <b>Format Salah!</b>\nHanya boleh angka/huruf tanpa spasi.")
            return bot.register_next_step_handler(msg, oke_confirm, kode, harga, op)

        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("✅ BELI SEKARANG", callback_data=f"okefix|{kode}|{harga}|{dest}"))
        markup.add(InlineKeyboardButton("❌ BATAL", callback_data="ppob_menu"))

        bot.reply_to(message, f"⚠️ <b>KONFIRMASI PEMBELIAN (OKE)</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📦 Kode: {kode}\n🎯 Tujuan: <code>{dest}</code>\n💸 Harga: <b>Rp {int(harga):,}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nPastikan data benar!", parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        logger.error(f"Error oke_confirm: {e}")
        bot.reply_to(message, "❌ Terjadi kesalahan sistem. Ulangi dari awal.")

def atl_confirm(message, kode, harga, prov):
    dest = message.text.strip()
    allow_text_provs = ["CANVA", "NETFLIX", "SPOTIFY", "YOUTUBE", "BSTATION", "VIDIO", "VIU", "PICSART", "CAPCUT", "MOBILE LEGENDS", "PUBG", "ROBLOX", "FREE FIRE", "GAMES", "PREMIUM", "HBO", "DISNEY", "GENSHIN", "PERPLEXITY"]
    
    is_numeric_only = not any(p in prov.upper() for p in allow_text_provs)
    
    if is_numeric_only and not dest.isdigit():
        sent = bot.reply_to(message, "❌ <b>Format Salah!</b>\nUntuk layanan ini, harap kirim <b>NOMOR HP</b> (Angka saja).", parse_mode='HTML')
        return bot.register_next_step_handler(sent, atl_confirm, kode, harga, prov)
        
    if len(dest) < 4:
        sent = bot.reply_to(message, "❌ <b>Terlalu Pendek!</b>\nMasukkan Nomor HP / Email yang valid.", parse_mode='HTML')
        return bot.register_next_step_handler(sent, atl_confirm, kode, harga, prov)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("✅ BELI SEKARANG", callback_data=f"atlfix|{kode}|{harga}|{dest}"))
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"atl_prov|{prov}"))
    
    bot.reply_to(message, f"⚠️ <b>KONFIRMASI PEMBELIAN (ATL)</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📦 Produk: {kode}\n🎯 Tujuan: <code>{dest}</code>\n💸 Harga: <b>Rp {int(harga):,}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nPastikan data sudah benar?", parse_mode='HTML', reply_markup=markup)

# ==========================================
#  6. EKSEKUSI TRANSAKSI (FIXED & ATOMIC)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("atlfix|"))
def ppob_execute_atl(call):
    # 1. Parsing Data
    _, kode, harga, dest = call.data.split("|")
    harga, uid = int(harga), call.from_user.id
    
    # [FIX] Anti-Error Edit Message (Jika pesan lama hilang, kirim baru)
    try:
        bot.edit_message_text("⏳ <b>Sedang Memproses Atlantic...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    except Exception:
        bot.send_message(call.message.chat.id, "⏳ <b>Sedang Memproses Atlantic...</b>", parse_mode='HTML')

    # 2. Generate Ref ID & Deskripsi
    ref_id_local = f"ATL{int(time.time())}{uid}"
    deskripsi_trx = f"BELI {kode} (ATL)"

    # 3. Potong Saldo (Pakai Logic Baru agar History Lengkap)
    # HAPUS baris 'save_ppob_transaction' karena update_saldo sudah otomatis simpan
    if str(uid) == str(ADMIN_ID): 
        berhasil_potong = True
    else: 
        berhasil_potong = update_saldo(
            uid, 
            -harga, 
            description=deskripsi_trx, 
            ref_id=ref_id_local, 
            dest=dest
            
        )

    if not berhasil_potong:
        # Gunakan Try-Except di sini juga jaga-jaga
        try:
            return bot.edit_message_text("❌ <b>TRANSAKSI GAGAL</b>\nSaldo tidak mencukupi.", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        except:
            return bot.send_message(call.message.chat.id, "❌ <b>TRANSAKSI GAGAL</b>\nSaldo tidak mencukupi.", parse_mode='HTML')

    # 4. Request ke API Atlantic
    print(f"🚀 [TRANSAKSI ATL] START | Ref:{ref_id_local} | Kode:{kode}")
    
    payload = {'api_key': ATLANTIC_API_KEY, 'code': kode, 'target': dest, 'reff_id': ref_id_local}
    atlantic_trx_id = None
    msg_srv = "No Message"
    is_success = False

    try:
        # Timeout 30 detik agar bot tidak hang
        raw_response = requests.post(ATLANTIC_TRX_URL, data=payload, timeout=30)
        try:
            res = raw_response.json()
            is_success = res.get('status') is True
            msg_srv = res.get('message', 'No Message')
            if is_success and 'data' in res: 
                atlantic_trx_id = res['data'].get('id')
        except:
            res = {}
            msg_srv = f"Server Error: {raw_response.status_code}"
    except Exception as e: 
        res = {}
        msg_srv = f"Koneksi Gagal: {str(e)}"
    
    markup = InlineKeyboardMarkup()
    
    # 5. Cek Hasil & Update Database
    if is_success:
        status_h = "✅ <b>DIPROSES</b>"
        
        if atlantic_trx_id: 
            # --- PERBAIKAN FATAL: GANTI REF_ID LOKAL DENGAN ID ATLANTIC! ---
            # Kita update database yang lama (ATL177...) agar diganti menjadi ID Atlantic (xTsT...)
            try:
                conn = sqlite3.connect("store_data.db")
                c = conn.cursor()
                c.execute("UPDATE transactions SET ref_id = ? WHERE ref_id = ?", (atlantic_trx_id, ref_id_local))
                conn.commit()
                conn.close()
                
                # Setelah database diubah, kita gunakan ID Atlantic untuk tombol Refresh
                markup.add(InlineKeyboardButton("🔄 CEK STATUS", callback_data=f"atl_chk|{atlantic_trx_id}|{atlantic_trx_id}"))
                ref_id_tampil = atlantic_trx_id # Agar di struk munculnya ID Atlantic
            except Exception as e:
                print(f"Gagal Replace ID: {e}")
                markup.add(InlineKeyboardButton("🔄 CEK STATUS", callback_data=f"atl_chk|{atlantic_trx_id}|{ref_id_local}"))
                ref_id_tampil = ref_id_local
            # -----------------------------------------------------------------
        else:
             ref_id_tampil = ref_id_local
        
        print(f"✅ [TRANSAKSI ATL] SUKSES API | Ref:{ref_id_tampil}")
    else:
        status_h = "❌ <b>GAGAL</b>"
        ref_id_tampil = ref_id_local
        
        # [FIX] Refund dengan Logic Baru (Tercatat di History)
        if str(uid) != str(ADMIN_ID):
            update_saldo(
                uid, 
                harga, 
                description=f"REFUND {kode}", 
                ref_id=f"REF-{ref_id_local}",
                dest=dest
            )
        
        # Update Status Transaksi jadi Gagal
        msg_srv = sensor_pesan_error(msg_srv)
        try: update_transaction_status(ref_id_local, "gagal", msg_srv)
        except: pass
        
        print(f"❌ [ATL GAGAL] Ref:{ref_id_local} | Refunded")
    
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_atlantic"))
    
    msg = (f"{status_h}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📦 Produk: {kode}\n📱 Tujuan: {dest}\n💰 Harga: Rp {harga:,}\n🧾 RefID: {ref_id_tampil}\n📝 Ket: {msg_srv}")
    
    # [FIX] Final Edit Message dengan Safety
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)

def check_status_atlantic_api(atlantic_id):
    try:
        url = "https://atlantich2h.com/transaksi/status"
        payload = {'api_key': ATLANTIC_API_KEY, 'id': atlantic_id, 'type': 'prabayar'}
        response = requests.post(url, data=payload, timeout=10)
        return response.json()
    except Exception as e: return {'status': False, 'message': str(e)}

# FILE: handlers/handlers_ppob.py

@bot.callback_query_handler(func=lambda call: call.data.startswith("okefix|"))
def ppob_execute_oke(call):
    try:
        # 1. Parsing Data
        _, kode, harga, dest = call.data.split("|")
        harga, uid = int(harga), call.from_user.id
        
        # Anti-Error Edit Message
        try:
            bot.edit_message_text("⏳ <b>Sedang Memproses OkeConnect...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        except:
            bot.send_message(call.message.chat.id, "⏳ <b>Sedang Memproses OkeConnect...</b>", parse_mode='HTML')

        # 2. Generate Ref ID
        ref_id = f"TRX{int(time.time())}{uid}"
        deskripsi_trx = f"BELI {kode} (OKE)"

        # 3. Potong Saldo User
        if str(uid) == str(ADMIN_ID): 
            berhasil_potong = True
        else: 
            berhasil_potong = update_saldo(
                uid, 
                -harga, 
                description=deskripsi_trx, 
                ref_id=ref_id, 
                dest=dest
            )

        if not berhasil_potong:
            # Fallback jika edit gagal
            try:
                return bot.edit_message_text("❌ <b>TRANSAKSI GAGAL</b>\nSaldo tidak mencukupi.", call.message.chat.id, call.message.message_id, parse_mode='HTML')
            except:
                return bot.send_message(call.message.chat.id, "❌ <b>TRANSAKSI GAGAL</b>\nSaldo tidak mencukupi.", parse_mode='HTML')
        
        # 4. Request ke API
        try:
            res = request_orderkuota_trx(kode, dest, ref_id)
        except Exception as e:
            res = {'success': False, 'msg': f"Error System: {str(e)}"}

        markup = InlineKeyboardMarkup()
        
        # 5. Cek Hasil
        if res['success']:
            server_id = res.get('server_id', '')
            parsed = parse_respon_server(res['msg'])
            sn_info = parsed['sn'] if parsed['sn'] != '-' else "Sedang Proses"
            
            # Update Status Database
            update_transaction_status(ref_id, "sukses", sn_info)
            
            status_header = "✅ <b>TRANSAKSI SUKSES</b>" if "sukses" in res['msg'].lower() else "✅ <b>TRANSAKSI DIPROSES</b>"
            display_harga = f"Rp {harga:,}".replace(",", ".")
            
            # === [BAGIAN PENTING: SENSOR SALDO & HARGA ADMIN] ===
            raw_msg = res['msg']
            clean_msg = re.sub(r"Saldo\s+[\d\.,\s\-=\+]+(@\d{2}:\d{2})?", "", raw_msg, flags=re.IGNORECASE)
            
            # TAMBAHAN: Sensor Harga Asli Provider (Hrg 10.460 -> Hrg ***)
            clean_msg = re.sub(r"(?i)(hrg|harga)\s*[:=]?\s*[\d\.,]+", r"\1 ***", clean_msg).strip()
            # ============================================
            
            msg_body = (
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📦 Produk : {kode}\n"
                f"📱 Tujuan : {dest}\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"🎟 SN: <code>{parsed['sn']}</code>\n"
                f"💸 <b>Hrg : {display_harga}</b>\n\n" 
                f"📝 <b>Info Lengkap:</b>\n{clean_msg}"
            )
            
            markup.add(InlineKeyboardButton("🔄 Refresh Status", callback_data=f"cs|{server_id}|{ref_id}|{kode}|{dest}"))
            print(f"✅ [TRANSAKSI OKE] SUKSES API | Ref:{ref_id}")

        else:
            # GAGAL -> REFUND
            status_header = "❌ <b>TRANSAKSI GAGAL</b>"
            
            if str(uid) != str(ADMIN_ID):
                update_saldo(
                    uid, 
                    harga, 
                    description=f"REFUND {kode}", 
                    ref_id=f"REF-{ref_id}",
                    dest=dest
                )
            
            update_transaction_status(ref_id, "gagal", res['msg'])
            
            # Sensor pesan error juga jaga-jaga
            pesan_aman = sensor_pesan_error(res['msg'])
            msg_body = f"━━━━━━━━━━━━━━━━━━━━━\n Produk : {kode}\n Tujuan : {dest}\n━━━━━━━━━━━━━━━━━━━━━\n📝 <b>Keterangan:</b>\n{pesan_aman}\n\n💰 <i>Saldo telah dikembalikan otomatis.</i>"

        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU PPOB", callback_data="ppob_menu"))
        
        try:
            bot.edit_message_text(f"{status_header}\n{msg_body}", call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except:
             bot.send_message(call.message.chat.id, f"{status_header}\n{msg_body}", parse_mode='HTML', reply_markup=markup)

    except Exception as e:
        print(f"CRITICAL ERROR PPOB: {e}")
        bot.send_message(call.message.chat.id, "❌ Terjadi kesalahan sistem fatal. Hubungi Admin.")

@bot.callback_query_handler(func=lambda call: call.data == "atl_more_menu")
def ppob_atl_more_menu(call):
    bot.answer_callback_query(call.id)
    log_act(call.from_user, "MEMBUKA MENU PREMIUM")
    
    markup = InlineKeyboardMarkup(row_width=2)
    markup.row(InlineKeyboardButton("🎬 NETFLIX", callback_data="atl_cat|NETFLIX|Akun Premium|1"), InlineKeyboardButton("▶️ YOUTUBE", callback_data="atl_cat|YOUTUBE|Akun Premium|1"))
    
    # --- UPDATE DI SINI (Menambahkan Disney+) ---
    # Saya pasangkan Disney dengan HBO GO
    markup.row(InlineKeyboardButton("🏰 DISNEY+", callback_data="atl_cat|Disney|Akun Premium|1"), InlineKeyboardButton("📺 HBO GO", callback_data="atl_cat|HBO|Akun Premium|1"))
    
    markup.row(InlineKeyboardButton("📽️ VIDIO", callback_data="atl_cat|VIDIO|Akun Premium|1"), InlineKeyboardButton("🟡 VIU", callback_data="atl_cat|VIU|Akun Premium|1"))
    markup.row(InlineKeyboardButton("🎵 SPOTIFY", callback_data="atl_cat|SPOTIFY|Akun Premium|1"), InlineKeyboardButton("📺 BSTATION", callback_data="atl_cat|BSTATION|Akun Premium|1"))
    markup.row(InlineKeyboardButton("✂️ CAPCUT", callback_data="atl_cat|CAPCUT|Akun Premium|1"), InlineKeyboardButton("🎨 PICSART", callback_data="atl_cat|PICSART|Akun Premium|1"))
    
    markup.row(
        InlineKeyboardButton("🤖 PERPLEXITY", callback_data="atl_cat|AI PERPLEXITY|Akun Premium|1"), 
        InlineKeyboardButton("🧠 CHATGPT", callback_data="atl_cat|CHATGPT|Akun Premium|1")
    )
    markup.row(InlineKeyboardButton("📶 WIFI.ID", callback_data="atl_cat|WIFI ID|Voucher|1"), InlineKeyboardButton("🏦 E-MONEY", callback_data="atl_special_cat|EMONEY"))
    
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_atlantic"))
    
    bot.edit_message_text("🎮 <b>MENU LAYANAN PREMIUM</b>\n👇 <b>Silakan pilih kategori:</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("atl_special_cat|"))
def ppob_atl_special_cat(call):
    if call.data.split("|")[1] == "EMONEY":
        log_act(call.from_user, "MEMBUKA MENU E-MONEY")
        bot.answer_callback_query(call.id, "🔄 Memuat E-Money...")
        emoney_providers = ["DANA", "OVO", "GOPAY", "SHOPEEPAY", "LINKAJA", "MAXIM", "GRAB", "GOJEK", "ISR"]
        markup = InlineKeyboardMarkup(row_width=2)
        for prov in emoney_providers: markup.add(InlineKeyboardButton(f"💰 {prov}", callback_data=f"atl_cat|{prov}|E-Money|1"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="atl_more_menu"))
        bot.edit_message_text("🏦 <b>DOMPET DIGITAL & OJEK ONLINE</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👇 <i>Silakan pilih jenis E-Money:</i>", call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("cs|"))
def ppob_refresh_status_v2(call):
    try:
        parts = call.data.split("|")
        server_id = parts[1] if len(parts) > 1 else ""
        ref_id = parts[2] if len(parts) > 2 else ""
        kode_produk_val = parts[3] if len(parts) > 3 else None
        nomor_tujuan_val = parts[4] if len(parts) > 4 else None
        
        # 1. Cek Status ke Provider
        raw_response = check_orderkuota_status(
            ref_id, 
            nomor_tujuan=nomor_tujuan_val,
            kode_produk=kode_produk_val,
            server_id=server_id
        )
        
        # 2. Analisa Hasil
        status_lower = raw_response.lower()
        header = "⏳ SEDANG DIPROSES"
        is_failed = False
        
        if "sukses" in status_lower: 
            header = "✅ TRANSAKSI SUKSES"
        elif any(x in status_lower for x in ["gagal", "salah", "stok habis", "tidak ditemukan"]): 
            header = "❌ TRANSAKSI GAGAL"
            is_failed = True
        
        # 3. Parsing SN
        parsed = parse_respon_server(raw_response)
        if parsed['sn'] == '-' and "SN" in raw_response:
             try:
                 match_pln = re.search(r"SN\s*/?\s*Ref\s*[:\s]*([^\s]+)", raw_response, re.IGNORECASE)
                 if match_pln: parsed['sn'] = match_pln.group(1)
             except: pass

        # 4. UPDATE DATABASE & AUTO REFUND
        from database import get_transaction_status, get_trx_amount_by_ref_id
        
        current_status = get_transaction_status(ref_id) # Cek status skrg
        
        # JIKA SUKSES
        if parsed['sn'] not in ['-', '', None] and "sukses" in status_lower:
             if current_status != 'sukses':
                 update_transaction_status(ref_id, "sukses", parsed['sn'])
        
        # JIKA GAGAL (DAN BELUM DI-REFUND)
        elif is_failed and current_status != 'gagal':
             # Update ke Gagal
             update_transaction_status(ref_id, "gagal", raw_response[:50])
             
             # Ambil Nominal & Refund
             amount = get_trx_amount_by_ref_id(ref_id)
             if amount > 0:
                 # Eksekusi Refund
                 add_balance(
                     call.from_user.id, 
                     amount, 
                     f"REFUND {ref_id}", 
                     ref_id=f"REF-{ref_id}"
                 )
                 header += "\n💰 <b>SALDO SUDAH DIKEMBALIKAN</b>"
        # === SENSOR INFO SERVER ===
        safe_response = re.sub(r"Saldo\s+[\d\.,\s\-=\+]+(@\d{2}:\d{2})?", "", raw_response, flags=re.IGNORECASE)
        safe_response = re.sub(r"(?i)(hrg|harga)\s*[:=]?\s*[\d\.,]+", "ok ☑️", safe_response).strip()
        # 5. Tampilkan Pesan
        msg = (f"<b>{header}</b>\n"
               f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
               f"🆔 RefID : {ref_id}\n"
               f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
               f"🎟 SN: <code>{parsed['sn']}</code>\n"
               f"📦 Produk: {kode_produk_val if kode_produk_val else '-'}\n"
               f"📝 Info Server:\n{safe_response}\n\n"
               f"🕒 Last Check: {datetime.now().strftime('%H:%M:%S')}")
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔄 Refresh Status", callback_data=f"cs|{server_id}|{ref_id}|{kode_produk_val}|{nomor_tujuan_val}"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="ppob_menu"))
        
        try: bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except ApiTelegramException as e: 
            if "message is not modified" in str(e): bot.answer_callback_query(call.id, "✅ Data belum berubah.")
            else: bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)
            
    except Exception as e:
        print(f"❌ Error CS V2: {e}")
        bot.answer_callback_query(call.id, "Gagal update status.")

@bot.callback_query_handler(func=lambda call: call.data == "search_product_menu")
def search_product_start(call):
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="menu_user")) 
    msg = bot.send_message(call.message.chat.id, "🔍 <b>PENCARIAN PRODUK</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nSilakan ketik <b>Nama Produk</b>, <b>Provider</b>, atau <b>Kode</b> yang dicari.\n\n<i>Contoh: 'Telkomsel 10', 'Dana 20', 'PLN', 'Pubg'</i>", parse_mode='HTML', reply_markup=markup)
    bot.register_next_step_handler(msg, process_search_product)

def get_search_results_data(keyword):
    results = []
    keyword = keyword.lower()
    try:
        oke_data = get_okeconnect_price() 
        if oke_data: # Cek jika ada datanya
            for p in oke_data:
                if keyword in f"{p['kode']} {p['keterangan']} {p['kategori']}".lower():
                    results.append({'source': 'OKE', 'code': p['kode'], 'name': p['keterangan'], 'price': int(p['harga']), 'status': str(p['status']), 'callback': f"okebuy|{p['kode']}|{int(p['harga'])}|OKE"})
    except: pass
    
    try:
        res_atl = get_atlantic_price_list("prabayar")
        # [FIX] Cek res_atl sebelum .get
        if res_atl and res_atl.get('status') is True:
            for p in res_atl.get('data', []):
                if keyword in f"{p['code']} {p['name']} {p['category']} {p['provider']}".lower():
                    results.append({'source': 'ATL', 'code': p['code'], 'name': p['name'], 'price': int(p['price']), 'status': '1' if p['status'] == 'available' else '0', 'callback': f"atlbeli|{p['code']}|{p['price']}|ATL"})
    except: pass
    
    results.sort(key=lambda x: x['price'])
    return results

def process_search_product(message):
    keyword = message.text.strip()
    if len(keyword) < 2: return bot.reply_to(message, "❌ Kata kunci terlalu pendek. Minimal 2 karakter.")
    loading = bot.reply_to(message, "⏳ <b>Sedang mencari di semua server...</b>", parse_mode='HTML')
    results = get_search_results_data(keyword)
    try: bot.delete_message(message.chat.id, loading.message_id)
    except: pass
    show_search_results(message.chat.id, keyword, results, 1, message_id=None)

@bot.callback_query_handler(func=lambda call: call.data.startswith("srcnav|"))
def search_pagination_handler(call):
    _, keyword, page_str = call.data.split("|")
    results = get_search_results_data(keyword)
    show_search_results(call.message.chat.id, keyword, results, int(page_str), message_id=call.message.message_id)

def show_search_results(chat_id, keyword, results, page, message_id=None):
    LIMIT = 10
    total_items = len(results)
    total_pages = (total_items + LIMIT - 1) // LIMIT if total_items > 0 else 1
    page = max(1, min(page, total_pages))
    current_items = results[(page-1)*LIMIT : page*LIMIT]
    
    user = get_user_data(chat_id)
    markup_price = MARKUP_RESELLER if user and str(user.get('role')).lower() == 'reseller' else MARKUP_MEMBER

    msg = f"🔍 <b>HASIL PENCARIAN: '{keyword}'</b>\n📄 Halaman {page} dari {total_pages}\n📊 Ditemukan: {total_items} produk\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    markup = InlineKeyboardMarkup(row_width=5)
    nums_btns = []

    if not current_items: msg += "❌ <i>Produk tidak ditemukan di server manapun.</i>"
    else:
        for i, item in enumerate(current_items, 1):
            final_price = item['price'] + markup_price
            src_text = "🔵 ATL" if item['source'] == "ATL" else "🟠 OKE"
            is_available = item['status'] in ['1', 'available', 'active']
            stat_text = "✅ Ready" if is_available else "❌ Gangguan"

            msg += f"<b>{i}. {item['name']}</b>\n   🏷 <code>{item['code']}</code> | {src_text}\n   💰 <b>Rp {final_price:,}</b> | {stat_text}\n   ────────────────\n"
            btn_cb = item['callback'].replace(f"|{item['price']}|", f"|{final_price}|") if is_available else "ignore"
            nums_btns.append(InlineKeyboardButton(str(i) if is_available else "❌", callback_data=btn_cb))
    
    markup.add(*nums_btns)
    nav_btns = []
    if page > 1: nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"srcnav|{keyword}|{page-1}"))
    nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    if page < total_pages: nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"srcnav|{keyword}|{page+1}"))
    markup.row(*nav_btns)
    markup.add(InlineKeyboardButton("🔍 CARI KATA KUNCI LAIN", callback_data="search_product_menu"))
    markup.add(InlineKeyboardButton("🔙 TUTUP", callback_data="menu_user"))

    if message_id:
        try: bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=markup)
        except: bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=markup)
    else: bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("atl_chk|"))
def ppob_atlantic_refresh_status(call):
    try:
        _, atlantic_id, ref_id_local = call.data.split("|")
        res = check_status_atlantic_api(atlantic_id)
        
        status_text, sn_text, msg_detail = "⚠️ Gagal Cek", "-", "Tidak ada data."
        
        if res.get('status') is True:
            data = res.get('data', {})
            raw_status = data.get('status', 'pending').lower()
            sn_text = data.get('sn') if data.get('sn') else "Sedang diproses..."
            
            if raw_status == 'success':
                status_text = "✅ <b>SUKSES</b>"
                try: update_transaction_status(ref_id_local, "sukses", sn_text)
                except: pass
            elif raw_status == 'failed':
                status_text = "❌ <b>GAGAL</b>"
                # --- AUTO REFUND LOGIC ---
                # Import di sini untuk menghindari circular import
                from database import get_transaction_status, get_trx_amount_by_ref_id
                current_db_status = get_transaction_status(ref_id_local)
                
                if current_db_status in ['pending', 'process']:
                    amount = get_trx_amount_by_ref_id(ref_id_local)
                    if amount > 0:
                        update_transaction_status(ref_id_local, "gagal", sn_text or "Gagal dari Pusat")
                        add_balance(call.from_user.id, amount, f"REFUND {ref_id_local}", ref_id=f"REF-{ref_id_local}")
                        status_text += "\n💰 <b>SALDO TELAH DIKEMBALIKAN OTOMATIS</b>"
                # -------------------------
            else:
                status_text = "⏳ <b>PENDING / DIPROSES</b>"
            
            msg_detail = f"{status_text}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📦 Layanan: {data.get('layanan')}\n📱 Target: {data.get('target')}\n🧾 RefID: {ref_id_local}\n🎟 <b>SN:</b> <code>{sn_text}</code>\n🕒 Update: {datetime.now().strftime('%H:%M:%S')}"
        else:
            msg_detail = f"❌ <b>Gagal Cek Status</b>\nMsg: {res.get('message')}"
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔄 REFRESH LAGI", callback_data=call.data))
        markup.add(InlineKeyboardButton("🔙 MENU", callback_data="ppob_atlantic"))
        
        try: bot.edit_message_text(msg_detail, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except ApiTelegramException as e:
            if "message is not modified" in str(e): bot.answer_callback_query(call.id, "Status belum berubah.", show_alert=False)
            else: raise e
    except Exception as e:
        print(f"Error Refresh Atl: {e}")
        bot.answer_callback_query(call.id, "Error saat refresh status.")
        
# ==========================================
# TAMBAHAN: HANDLER CEK STATUS VIA CHAT (MANUAL)
# Tempel ini di paling bawah file handlers_ppob.py
# ==========================================
@bot.message_handler(func=lambda message: message.text.upper().startswith("TRX") or message.text.upper().startswith("R#") or message.text.upper().startswith("ATL"))
def handle_cek_transaksi_manual_ppob(message):
    input_text = message.text.strip()
    
    # 1. Kirim Pesan Loading
    loading = bot.reply_to(message, "⏳ <b>Sedang Melacak Transaksi...</b>", parse_mode='HTML')

    try:
        # 2. Tentukan Provider Berdasarkan Kode Depan
        if input_text.upper().startswith("ATL"):
            # Logika Cek Atlantic
            # (Pastikan fungsi check_status_atlantic_api ada atau import)
            from handlers.handlers_ppob import check_status_atlantic_api # Import diri sendiri jika perlu
            trx_id = input_text.replace("ATL", "").strip()
            # Bersihkan jika ada suffix user id (misal ATL1234567890) -> ambil ID aslinya saja jika perlu logika khusus
            # Disini kita asumsi input murni ID Atlantic
            
            res = check_status_atlantic_api(input_text) # Cek ke API
            if res.get('status'):
                d = res['data']
                hasil_teks = f"Status: {d.get('status')}\nSN: {d.get('sn')}"
            else:
                hasil_teks = f"Gagal: {res.get('message')}"
                
        else:
            # Logika Cek OkeConnect (OrderKuota)
            # Input text langsung dikirim sebagai RefID/SN
            if check_orderkuota_status:
                hasil_teks = check_orderkuota_status(input_text)
                # SENSOR SALDO & HARGA
                hasil_teks = re.sub(r"Saldo\s+[\d\.,\s\-=\+]+(@\d{2}:\d{2})?", "", hasil_teks, flags=re.IGNORECASE)
                hasil_teks = re.sub(r"(?i)(hrg|harga)\s*[:=]?\s*[\d\.,]+", r"\1 ***", hasil_teks).strip()
            else:
                hasil_teks = "❌ Modul Cek Status tidak aktif."

        # 3. Buat Tombol Kembali / Tutup
        markup = InlineKeyboardMarkup()
        # Tombol Refresh (Opsional, arahkan ke callback refresh yang sudah ada)
        # markup.add(InlineKeyboardButton("🔄 Refresh", callback_data=f"cs|SERVER|{input_text}|-|-" )) 
        markup.add(InlineKeyboardButton("❌ TUTUP / KEMBALI", callback_data="ppob_menu"))

        # 4. Tampilkan Hasil
        bot.delete_message(message.chat.id, loading.message_id) # Hapus loading
        
        bot.reply_to(
            message, 
            f"📊 <b>HASIL CEK TRANSAKSI</b>\n"
            f"Input: <code>{input_text}</code>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"📝 <b>Respon Server:</b>\n"
            f"{hasil_teks}", 
            parse_mode='HTML', 
            reply_markup=markup
        )

    except Exception as e:
        try: bot.delete_message(message.chat.id, loading.message_id)
        except: pass
        bot.reply_to(message, f"❌ Error: {str(e)}")