import telebot
import paramiko
import time
import datetime
from datetime import timedelta
from bot_init import bot
from config import ADMIN_ID
from database import get_user_data, add_balance, save_vpn_created
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# ======================================================
# 1. KONFIGURASI HARGA (Sesuai Config Anda)
# ======================================================
HARGA_SSH = {
    "sg":   {"user": 15000, "reseller": 12000},
    "indo": {"user": 13000, "reseller": 10000}
}

# ======================================================
# 2. KONFIGURASI SERVER (DATA BARU)
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "165.22.48.206",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "sg.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.web.id"
    }
}

# ======================================================
# HELPER: EKSEKUSI BASH (UPDATED FOR ZIVPN SYNC)
# ======================================================
def create_ssh_native(lokasi, username, password, days):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan di database bot."

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        # Hitung Tanggal Expired
        date_obj = datetime.date.today() + timedelta(days=days)
        exp_date = date_obj.strftime("%Y-%m-%d")
        
        # Koneksi SSH
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=8)
        
        # === PERINTAH LINUX UPDATE (SSH + ZIVPN) ===
        # Penjelasan logika:
        # 1. Cek apakah user ada.
        # 2. Buat user system (useradd).
        # 3. Set password (chpasswd).
        # 4. Cek file config zivpn, lalu gunakan jq untuk memasukkan username ke .auth.config
        # 5. Restart service zivpn agar efeknya langsung terasa.
        
        cmd = f"""
        if id "{username}" &>/dev/null; then
            echo "ERROR: User {username} sudah ada!"
        else
            # 1. Buat User System
            useradd -e "{exp_date}" -s /bin/false -M "{username}" && \\
            echo "{username}:{password}" | chpasswd && \\
            
            # 2. Inject ke ZIVPN Config (Hanya jika file ada)
            if [ -f /etc/zivpn/config.json ]; then
                # Cek dulu biar gak duplikat (opsional tapi aman), lalu tambahkan
                if ! jq -e ".auth.config | index(\\"{username}\\")" /etc/zivpn/config.json > /dev/null; then
                    jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && \\
                    mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                fi
            fi && \\

            # 3. Restart Service ZiVPN (Wajib agar user terbaca)
            systemctl restart zivpn && \\
            
            # 4. Indikator Sukses
            echo "SUCCESS"
            
            # 5. Log Database (Opsional - Sesuai script lama Anda)
            echo "### {username} {exp_date} {password}" >> /etc/ssh/.ssh.db 2>/dev/null
        fi
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode().strip()
        client.close()

        if "SUCCESS" in output: 
            return True, f"Berhasil dibuat sampai {exp_date}"
        elif "ERROR" in output:
            return False, "Username sudah terpakai di server."
        else:
            # Tampilkan error jika ada (misal jq tidak terinstall)
            return False, f"Gagal execute: {output}"
            
    except Exception as e:
        return False, f"Connection Error: {str(e)}"

# ======================================================
# HANDLER UTAMA: INPUT MANUAL SSH
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_ssh_"))
def start_create_ssh_manual(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    # Format data: buy_ssh_sg atau buy_ssh_indo
    try: lokasi = call.data.split("_")[2] 
    except: return bot.answer_callback_query(call.id, "❌ Error Data")

    if lokasi not in HARGA_SSH: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

    user_data = get_user_data(user_id)
    if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

    saldo = int(user_data.get('balance', 0))
    role = str(user_data.get('role', 'user')).lower()

    # Cek Role & Harga
    if 'reseller' in role or 'owner' in role or str(user_id) == str(ADMIN_ID):
        harga = HARGA_SSH[lokasi]["reseller"]
        tipe_user = "RESELLER ⚡"
    else:
        harga = HARGA_SSH[lokasi]["user"]
        tipe_user = "MEMBER 👤"
    
    is_owner = str(user_id) == str(ADMIN_ID) or 'owner' in role

    # Cek Saldo
    if not is_owner and saldo < harga:
        kurang = harga - saldo
        msg_error = (
            f"⚠️ <b>SALDO TIDAK CUKUP</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"💸 <b>Harga Produk:</b> Rp {harga:,}\n"
            f"💰 <b>Saldo Anda:</b> Rp {saldo:,}\n"
            f"❌ <b>Kekurangan:</b> Rp {kurang:,}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"<i>Silakan lakukan pengisian saldo terlebih dahulu.</i>"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        return bot.send_message(chat_id, msg_error, parse_mode='HTML', reply_markup=markup)

    # Form Input Username
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="cancel_input_ssh"))

    msg = bot.send_message(chat_id, 
        f"💎 <b>ORDER SSH {lokasi.upper()}</b>\n"
        f"👤 <b>Status:</b> {tipe_user}\n"
        f"💸 <b>Harga:</b> Rp {harga:,}\n"
        f"💰 <b>Saldo:</b> Rp {saldo:,}\n\n"
        f"👇 <b>Masukkan Username Baru:</b>\n"
        f"<i>(Ketik username, misal: user01)</i>", 
        parse_mode='HTML',
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, step_get_password, lokasi, harga, is_owner)

# ======================================================
# HANDLER: BATAL INPUT
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data == "cancel_input_ssh")
def cancel_ssh_input(call):
    # Hapus pesan input & stop step handler
    bot.clear_step_handler_by_chat_id(chat_id=call.message.chat.id)
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_user"))
    bot.send_message(call.message.chat.id, "❌ Transaksi dibatalkan.", reply_markup=markup)

# ======================================================
# STEP 2: MINTA PASSWORD
# ======================================================
def step_get_password(message, lokasi, harga, is_owner):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    
    # Validasi Username (Hanya Huruf Angka)
    if not username.isalnum():
        msg = bot.reply_to(message, "❌ Username harus huruf/angka (tanpa spasi). Masukkan lagi:")
        return bot.register_next_step_handler(msg, step_get_password, lokasi, harga, is_owner)

    msg = bot.reply_to(message, "🔑 <b>Masukkan Password:</b>", parse_mode='HTML')
    bot.register_next_step_handler(msg, execute_create_ssh, lokasi, harga, is_owner, username)

# ======================================================
# STEP 3: EKSEKUSI PEMBUATAN AKUN
# ======================================================
def execute_create_ssh(message, lokasi, harga, is_owner, username):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    password = message.text.strip()
    user_id = message.from_user.id
    days = 30        
    limit = 3       

    # Double Check Saldo
    if not is_owner:
        user_data = get_user_data(user_id)
        current_saldo = int(user_data.get('balance', 0))
        if current_saldo < harga:
            return bot.reply_to(message, "❌ Transaksi Gagal: Saldo tidak cukup saat memproses.")

    loading = bot.reply_to(message, "⏳ <b>Memproses di Server...</b>", parse_mode='HTML')

    # --- PANGGIL FUNGSI NATIVE BASH ---
    sukses, response = create_ssh_native(lokasi, username, password, days)

    if sukses:
        server_info = SERVER_DATA[lokasi]
        domain_server = server_info.get('domain', server_info['ip'])
        exp_date_str = (datetime.date.today() + timedelta(days=days)).strftime("%d %b %Y")

        # 1. Simpan ke Database Bot (Agar muncul di menu 'List Akun Saya')
        try:
            save_vpn_created(user_id, username, "SSH", exp_date_str, password, domain_server)
        except Exception as e:
            print(f"⚠️ Gagal simpan riwayat VPN: {e}")
        
        # 2. Potong Saldo & Catat Transaksi
        sisa_saldo = "Unlimited"
        if not is_owner:
            import time
            ref_id = f"SSH-{int(time.time())}"
            add_balance(
                user_id, 
                -harga, 
                f"Beli SSH {lokasi.upper()}", 
                ref_id=ref_id, 
                destination=username
            )
            sisa_saldo = f"Rp {int(get_user_data(user_id).get('balance', 0)):,}"

        # Hapus loading message
        try: bot.delete_message(message.chat.id, loading.message_id)
        except: pass
        
        created_date = datetime.date.today().strftime("%d/%m/%Y")

        reply_msg = f"""
========================================
🌟 <b>AKUN SSH PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Username: <code>{username}</code>
Domain  : <code>{domain_server}</code>
Password: <code>{password}</code>
Expired : <code>{exp_date_str}</code>
IP Limit: <code>{limit} Device</code>

🔹 <b>PORT INFO</b>
SSH WS       : 80, 2082
SSH SSL      : 443
UDP GW       : 7100-7300
ZiVPN        : <code>{username}</code>

🔹UDP Costum   : 
<code>{domain_server}</code>:1-65535@<code>{username}</code>:<code>{password}</code>

🔹ZIVPN FORMAT :
UDP SERVER   : <code>{domain_server}</code>
UDP PASSWORD : <code>{username}</code>


========================================

🔗 <b>PAYLOAD CONTOH</b>
<code>GET / HTTP/1.1[crlf]Host: {domain_server}[crlf]Upgrade: websocket[crlf][crlf]</code>

========================================
💰 Harga: Rp {harga:,}
💰 Sisa Saldo: {sisa_saldo}
========================================
"""
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="switch_user"))
        bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
    else:
        # Gagal
        bot.delete_message(message.chat.id, loading.message_id)
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        
        bot.reply_to(message, f"❌ <b>GAGAL MEMBUAT AKUN:</b>\n\n{response}\n\n<i>Silakan coba lagi atau hubungi Admin.</i>", parse_mode='HTML', reply_markup=markup)