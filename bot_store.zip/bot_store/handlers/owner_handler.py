import telebot
import subprocess
import time
import requests
from bot_instance import bot
from config import ADMIN_ID, DOMAIN_HOST, ATLANTIC_API_KEY
from database import find_user, add_balance, get_user_data, set_role, set_reseller_start, get_all_ids, get_all_users_list, get_resellers_list, get_user_transaction_history, get_reseller_history
from utils_view import get_back_markup, HARGA_DAFTAR_RESELLER, TARGET_RESELLER

PATH_KYT = "/root/bot_store/kyt/shell/bot"

# --- MANAJEMEN SALDO ---
@bot.callback_query_handler(func=lambda call: call.data == "manage_saldo")
def saldo_menu_handler(call):
    # ... (Code Anda)
    pass

# --- SETTING SERVER (REBOOT/BACKUP) ---
@bot.callback_query_handler(func=lambda call: call.data == "setting_menu")
def setting_menu(call):
    # ... (Code Anda)
    pass

# --- BROADCAST ---
@bot.callback_query_handler(func=lambda call: call.data == "broadcast_menu")
def broadcast_ask(call):
    # ... (Code Anda)
    pass
    
def broadcast_process(message):
    # ... (Code Anda)
    pass

# --- WITHDRAW OWNER ---
# ... (Paste code WD Owner disini)
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ForceReply
from bot_init import bot, ADMIN_ID
# Sesuaikan import database ini dengan file database.py Anda
from database import get_user_data # Asumsi fungsi untuk ambil data user

# ==========================================
# HANDLER: TRIGGER INPUT ID
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "check_user_by_id_menu")
def ask_user_id_detail(call):
    # Validasi Owner
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    try:
        # Hapus pesan menu sebelumnya agar bersih
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except:
        pass

    # Kirim pesan dengan ForceReply agar input owner langsung terdeteksi
    msg = bot.send_message(
        call.message.chat.id,
        "🔎 **MODE CEK USER DETAIL**\n\n"
        "Silakan balas pesan ini dengan **ID Telegram** user yang ingin dicek.\n"
        "Contoh: `1234567890`",
        parse_mode="Markdown",
        reply_markup=ForceReply(selective=True)
    )
    # Lanjut ke fungsi proses pencarian
    bot.register_next_step_handler(msg, process_find_user_detail)

# ==========================================
# HANDLER: PROSES PENCARIAN & TAMPILKAN DATA
# ==========================================
def process_find_user_detail(message):
    try:
        target_id = message.text.strip()

        # Validasi input harus angka
        if not target_id.isdigit():
            msg = bot.send_message(message.chat.id, "❌ **ID harus berupa angka!**\nSilakan input ulang:", reply_markup=ForceReply())
            return bot.register_next_step_handler(msg, process_find_user_detail)

        # Cari data di database (Sesuaikan fungsi ini dengan database.py Anda)
        # Asumsi return: (id, username, saldo, role, tanggal_daftar)
        user = get_user_data(target_id) 

        if not user:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 Cari Lagi", callback_data="check_user_by_id_menu"))
            markup.add(InlineKeyboardButton("🔙 Menu Owner", callback_data="admin_panel")) # Sesuaikan callback menu utama
            
            return bot.send_message(
                message.chat.id, 
                f"❌ User dengan ID `{target_id}` tidak ditemukan di database.", 
                parse_mode="Markdown", 
                reply_markup=markup
            )

        # Parsing Data (Sesuaikan index dengan struktur DB Anda)
        u_id = user[0]
        u_username = f"@{user[1]}" if user[1] else "Tanpa Username"
        u_saldo = user[2]
        u_role = user[3]
        
        # Format Rupiah
        saldo_fmt = "{:,}".format(u_saldo).replace(",", ".")

        # Tampilkan Detail
        text_detail = (
            f"👤 **DETAIL USER DITEMUKAN**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 ID: `{u_id}`\n"
            f"👤 Username: {u_username}\n"
            f"💰 Saldo: **Rp {saldo_fmt}**\n"
            f"🔰 Role: **{u_role.upper()}**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"👇 _Pilih aksi untuk user ini:_"
        )

        # Tombol Aksi Cepat
        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("➕ Tambah Saldo", callback_data=f"add_saldo|{u_id}"),
            InlineKeyboardButton("➖ Potong Saldo", callback_data=f"min_saldo|{u_id}")
        )
        markup.add(
            InlineKeyboardButton("📜 Cek Riwayat", callback_data=f"history_by_id|{u_id}"),
            InlineKeyboardButton("🔄 Reset Sesi", callback_data=f"reset_session|{u_id}")
        )
        
        # Tombol Upgrade/Downgrade Role
        if u_role.lower() == "user":
            markup.add(InlineKeyboardButton("⬆️ Up ke Reseller", callback_data=f"up_reseller|{u_id}"))
        elif u_role.lower() == "reseller":
            markup.add(InlineKeyboardButton("⬇️ Down ke User", callback_data=f"down_user|{u_id}"))

        markup.add(InlineKeyboardButton("🔙 Kembali ke Menu Owner", callback_data="admin_panel"))

        bot.send_message(message.chat.id, text_detail, parse_mode="Markdown", reply_markup=markup)

    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Terjadi kesalahan: {e}")