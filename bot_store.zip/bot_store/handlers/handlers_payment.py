# handlers_payment.py
import telebot
import requests
import time
from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID, ATLANTIC_API_KEY, ATLANTIC_PROFILE_URL, ATLANTIC_TRANSFER_URL
from utils_helper import get_back_markup

# --- KONFIGURASI TAMPILAN ---
LINE_SEP = "━━━━━━━━━━━━━━━━━━━━━━━━━━"

# --- KONFIGURASI AKUN TETAP (WD OWNER) ---
FIXED_DESTINATION = {
    "name": "DEDEN IRWANSYAH",
    "bank": "MANDIRI",
    "rek": "1640002915488"
}

# --- API HELPERS (DIPERBAIKI) ---
def request_atlantic_profile_data():
    try:
        response = requests.post(
            ATLANTIC_PROFILE_URL, 
            data={'api_key': ATLANTIC_API_KEY}, 
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=10
        )
        return response.json()
    except Exception as e: 
        print(f"API Error: {e}")
        return None

def request_atlantic_transfer(bank, akun, nominal, nama):
    try:
        payload = {
            'api_key': ATLANTIC_API_KEY, 
            'ref_id': f"TRF-{int(time.time())}", 
            'kode_bank': bank, 
            'nomor_akun': akun, 
            'nama_pemilik': nama, 
            'nominal': nominal
        }
        response = requests.post(
            ATLANTIC_TRANSFER_URL, 
            data=payload, 
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=30 # Timeout lebih lama untuk transaksi
        )
        return response.json()
    except Exception as e:
        return {"status": False, "message": f"Koneksi Error: {str(e)}"}
        
def request_atlantic_transfer_status(transfer_id):
    """Mengecek status transfer berdasarkan ID dari Atlantic"""
    try:
        url = "https://atlantich2h.com/transfer/status"
        payload = {
            'api_key': ATLANTIC_API_KEY, 
            'id': transfer_id
        }
        response = requests.post(
            url, 
            data=payload, 
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=15
        )
        return response.json()
    except Exception as e:
        return {"status": False, "message": f"Koneksi Error: {str(e)}"}

# --- TOMBOL BATAL UNIVERSAL ---
def get_cancel_markup():
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="cancel_wd_process"))
    return m

# --- HANDLER: BATAL PROSES ---
@bot.callback_query_handler(func=lambda call: call.data == "cancel_wd_process")
def cancel_wd_process(call):
    # Hapus step handler agar bot tidak menunggu input lagi
    bot.clear_step_handler_by_chat_id(call.message.chat.id)
    
    msg = (
        "<b>🚫 TRANSAKSI DIBATALKAN</b>\n"
        f"{LINE_SEP}\n"
        "Proses input telah dibatalkan oleh pengguna.\n"
        "Silakan pilih menu kembali."
    )
    # Kembali ke menu WD
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("🔙 Menu Transfer", callback_data="owner_wd_menu"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=m)

# --- WITHDRAW / TRANSFER MENU UTAMA ---
@bot.callback_query_handler(func=lambda call: call.data == "owner_wd_menu")
def wd_menu_start(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    # [UPDATE: SKIP IF OLD QUERY]
    try:
        bot.answer_callback_query(call.id, "🔄 Mengambil data saldo...")
    except: pass # Abaikan jika query too old

    res = request_atlantic_profile_data()
    saldo_display = "Gagal Load"
    
    if res and (res.get('status') is True or str(res.get('status')).lower() == 'true'):
         bal = res.get('data', {}).get('balance', 0)
         saldo_display = f"Rp {bal:,}".replace(",", ".")

    # Desain Menu Utama
    text = (
        "<b>💸 TRANSFER DANA & WITHDRAW</b>\n"
        f"{LINE_SEP}\n"
        f"💰 <b>Sisa Saldo Server:</b> <code>{saldo_display}</code>\n"
        f"{LINE_SEP}\n"
        "Silakan pilih metode transfer yang diinginkan:\n\n"
        "🚀 <b>Transfer Kilat:</b> Ke rekening utama owner.\n"
        "✍️ <b>Input Manual:</b> Input Bank/E-Wallet lain.\n"
        f"{LINE_SEP}"
    )

    m = InlineKeyboardMarkup()
    # Tombol 1: Ke Akun Tetap
    btn_text = f"🚀 KE {FIXED_DESTINATION['name'][:10]}.." 
    m.add(InlineKeyboardButton(btn_text, callback_data="wd_fixed_start"))
    # Tombol 2: Manual
    m.add(InlineKeyboardButton("✍️ INPUT MANUAL", callback_data="wd_input_bank"))
    # Tombol Kembali
    m.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_owner"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)

# ==========================================
# FLOW 1: TRANSFER KILAT (AKUN TETAP)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "wd_fixed_start")
def wd_fixed_step1(call):
    # Desain Info Rekening Tujuan
    info = (
        f"<b>🏦 Bank Tujuan :</b> <code>{FIXED_DESTINATION['bank']}</code>\n"
        f"<b>💳 No. Rek      :</b> <code>{FIXED_DESTINATION['rek']}</code>\n"
        f"<b>👤 Atas Nama    :</b> <code>{FIXED_DESTINATION['name']}</code>"
    )
    
    text = (
        "<b>⚡ TRANSFER KILAT</b>\n"
        f"{LINE_SEP}\n"
        f"{info}\n"
        f"{LINE_SEP}\n\n"
        "💰 <b>Silakan Masukkan NOMINAL Transfer:</b>\n"
        "<i>(Contoh: 50000 atau 100000)</i>"
    )
    
    # Kirim pesan baru agar step handler bersih
    msg = bot.send_message(call.message.chat.id, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_fixed_step2_confirm)

def wd_fixed_step2_confirm(message):
    try:
        # Cek apakah user mengetik command cancel manual
        if message.text.lower() == 'batal':
            bot.reply_to(message, "🚫 Proses dibatalkan.")
            return

        nom = int(message.text.replace(".", "").replace(",", ""))
        
        # [SECURITY UPDATE] Validasi Minus
        if nom <= 0:
            msg = bot.reply_to(message, "❌ <b>Error:</b> Nominal harus lebih dari 0!", parse_mode='HTML', reply_markup=get_cancel_markup())
            return bot.register_next_step_handler(msg, wd_fixed_step2_confirm)
            
    except ValueError:
        msg = bot.reply_to(message, "⚠️ <b>Error:</b> Harap masukkan hanya angka.\nSilakan input ulang nominal:", parse_mode='HTML', reply_markup=get_cancel_markup())
        return bot.register_next_step_handler(msg, wd_fixed_step2_confirm)

    kode = FIXED_DESTINATION['bank']
    akun = FIXED_DESTINATION['rek']
    nama = FIXED_DESTINATION['name']

    show_confirmation(message.chat.id, kode, akun, nom, nama)

# ==========================================
# FLOW 2: TRANSFER MANUAL (STEP BY STEP)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "wd_input_bank")
def wd_step1_bank(call):
    text = (
        "<b>🏦 INPUT DATA MANUAL - STEP 1/4</b>\n"
        f"{LINE_SEP}\n"
        "Masukkan <b>KODE BANK</b> tujuan.\n"
        "<i>(Contoh: DANA, OVO, 014, 002)</i>"
    )
    msg = bot.send_message(call.message.chat.id, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step2_number)

def wd_step2_number(message):
    kode = message.text.strip().upper()
    text = (
        "<b>💳 INPUT DATA MANUAL - STEP 2/4</b>\n"
        f"{LINE_SEP}\n"
        f"Bank Selected: <b>{kode}</b>\n\n"
        "Masukkan <b>NOMOR REKENING / E-WALLET</b> tujuan:"
    )
    msg = bot.reply_to(message, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step3_nominal, kode)

def wd_step3_nominal(message, kode):
    akun = message.text.strip()
    text = (
        "<b>💰 INPUT DATA MANUAL - STEP 3/4</b>\n"
        f"{LINE_SEP}\n"
        f"Bank: {kode}\nRek : {akun}\n\n"
        "Masukkan <b>NOMINAL</b> transfer:"
    )
    msg = bot.reply_to(message, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step4_name, kode, akun)

def wd_step4_name(message, kode, akun):
    try: 
        nom = int(message.text.replace(".","").replace(",",""))
        # [SECURITY UPDATE] Validasi Minus
        if nom <= 0:
            msg = bot.reply_to(message, "❌ Nominal harus lebih dari 0. Input ulang:", reply_markup=get_cancel_markup())
            return bot.register_next_step_handler(msg, wd_step4_name, kode, akun)
    except: 
        msg = bot.reply_to(message, "⚠️ Angka tidak valid. Input nominal ulang:", reply_markup=get_cancel_markup())
        return bot.register_next_step_handler(msg, wd_step4_name, kode, akun)
        
    text = (
        "<b>👤 INPUT DATA MANUAL - STEP 4/4</b>\n"
        f"{LINE_SEP}\n"
        f"Nominal: Rp {nom:,}\n\n"
        "Masukkan <b>NAMA PEMILIK REKENING</b> (untuk validasi):"
    )
    msg = bot.reply_to(message, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step5_exec, kode, akun, nom)

def wd_step5_exec(message, kode, akun, nom):
    nama = message.text.strip()
    show_confirmation(message.chat.id, kode, akun, nom, nama)

# ==========================================
# FUNGSI KONFIRMASI & EKSEKUSI
# ==========================================
def show_confirmation(chat_id, kode, akun, nom, nama):
    # Tampilan Konfirmasi Mewah
    text = (
        "<b>⚠️ KONFIRMASI TRANSAKSI</b>\n"
        f"{LINE_SEP}\n"
        "Mohon cek kembali data berikut:\n\n"
        f"<b>🏦 Bank Tujuan :</b> <code>{kode}</code>\n"
        f"<b>💳 No. Rek      :</b> <code>{akun}</code>\n"
        f"<b>👤 Atas Nama    :</b> <code>{nama}</code>\n"
        f"<b>💰 Nominal      :</b> <code>Rp {nom:,}</code>\n"
        f"{LINE_SEP}\n"
        "<i>Pastikan data sudah benar sebelum mengirim.</i>"
    )
    
    m = InlineKeyboardMarkup()
    # Data callback dipisah pipeline |
    callback_data = f"wd_fix|{kode}|{akun}|{nom}|{nama}"
    
    m.add(InlineKeyboardButton("✅ KIRIM SEKARANG", callback_data=callback_data))
    m.add(InlineKeyboardButton("❌ BATALKAN", callback_data="cancel_wd_process")) # Redirect ke handler cancel
    
    bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=m)

@bot.callback_query_handler(func=lambda call: call.data.startswith("wd_fix|"))
def wd_process_api(call):
    if str(call.from_user.id) != str(ADMIN_ID): return

    try:
        _, kode, akun, nom, nama = call.data.split("|")
        
        # Edit pesan jadi Loading
        bot.edit_message_text("⏳ <b>Sedang Memproses Transaksi...</b>\nMohon tunggu sebentar.", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        
        res = request_atlantic_transfer(kode, akun, int(nom), nama)
        
        # Hapus pesan loading, kirim pesan baru (Struk)
        bot.delete_message(call.message.chat.id, call.message.message_id)
        
        if res and (res.get('status') is True or str(res.get('status')).lower() == 'true'):
            data_api = res.get('data', {})
            
            # TANGKAP ID DARI ATLANTIC UNTUK CEK STATUS
            atlantic_id = data_api.get('id', '') 
            msg_server = res.get('message', 'Sedang Diproses')
            
            # Tampilan Awal: PENDING / DIPROSES
            receipt = (
                "<b>⏳ TRANSAKSI DIPROSES PROVIDER</b>\n"
                f"{LINE_SEP}\n"
                "<b>📦 Detail Transaksi:</b>\n\n"
                f"<b>🏦 Bank      :</b> <code>{kode}</code>\n"
                f"<b>💳 Akun      :</b> <code>{akun}</code>\n"
                f"<b>👤 Nama      :</b> <code>{nama}</code>\n"
                f"<b>💰 Nominal :</b> <code>Rp {int(nom):,}</code>\n\n"
                f"<b>📝 Status    :</b> <b>PENDING</b>\n"
                f"<b>🔑 Trx ID    :</b> <code>{atlantic_id}</code>\n"
                f"{LINE_SEP}\n"
                f"<i>Pesan: {msg_server}</i>\n\n"
                "⚠️ <i>Klik tombol Refresh di bawah untuk melihat update status terbaru dari server pusat.</i>"
            )
            
            m = InlineKeyboardMarkup()
            # TOMBOL REFRESH BARU
            if atlantic_id:
                m.add(InlineKeyboardButton("🔄 Refresh Status", callback_data=f"wd_cek|{atlantic_id}"))
                
            m.row(
                InlineKeyboardButton("🔙 Menu Utama", callback_data="owner_wd_menu"),
                InlineKeyboardButton("🗑 Hapus", callback_data="close_message")
            )
            
            bot.send_message(call.message.chat.id, receipt, parse_mode='HTML', reply_markup=m)
            
        else:
            reason = res.get('message') if res else "No Response from Server"
            
            fail_text = (
                "<b>❌ TRANSAKSI GAGAL</b>\n"
                f"{LINE_SEP}\n"
                f"<b>Penyebab:</b> {reason}\n\n"
                "<i>Saldo Anda tidak terpotong. Silakan coba lagi.</i>"
            )
            
            m = InlineKeyboardMarkup()
            m.add(InlineKeyboardButton("🔄 Coba Lagi", callback_data="owner_wd_menu"))
            
            bot.send_message(call.message.chat.id, fail_text, parse_mode='HTML', reply_markup=m)
            
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ <b>Error System:</b>\n{str(e)}", parse_mode='HTML')

# --- HANDLER PROFIL (ATLANTIC) ---
@bot.callback_query_handler(func=lambda call: call.data == "check_atlantic_profile")
def atlantic_profile_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    # [UPDATE: SKIP ERROR OLD QUERY]
    try:
        bot.answer_callback_query(call.id, "Mengambil data...")
    except: pass

    res = request_atlantic_profile_data()
    
    if res and (res.get('status') is True or str(res.get('status')).lower() == 'true'):
        d = res.get('data', {})
        bal = d.get('balance', 0)
        
        msg = (
            "<b>🌊 ATLANTIC PROFILE</b>\n"
            f"{LINE_SEP}\n"
            f"<b>👤 Name      :</b> {d.get('name')}\n"
            f"<b>💰 Saldo    :</b> <code>Rp {bal:,}</code>\n"
            f"<b>📊 Status :</b> {d.get('status')}\n"
            f"{LINE_SEP}"
        )
    else:
        msg = "❌ <b>Gagal</b> mengambil data profil Atlantic."
    
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("🔄 Refresh", callback_data="check_atlantic_profile"))
    m.add(InlineKeyboardButton("🔙 Kembali", callback_data="switch_owner"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=m)

# --- HANDLER CEK STATUS WITHDRAW/TRANSFER ---
@bot.callback_query_handler(func=lambda call: call.data.startswith("wd_cek|"))
def check_wd_status_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try:
        _, atlantic_id = call.data.split("|")
        bot.answer_callback_query(call.id, "🔄 Mengecek status terbaru ke pusat...")
        
        if not atlantic_id or atlantic_id == '-':
            bot.answer_callback_query(call.id, "❌ ID Transfer tidak valid!", show_alert=True)
            return
        
        # Panggil API Status Transfer
        res = request_atlantic_transfer_status(atlantic_id)
        
        if res and str(res.get('status')).lower() == 'true':
            data = res.get('data', {})
            api_status = str(data.get('status', 'pending')).lower()
            
            # Desain Status Berdasarkan Respon API
            if api_status == 'success':
                status_display = "✅ <b>TRANSAKSI SUKSES</b>"
            elif api_status == 'failed':
                status_display = "❌ <b>TRANSAKSI GAGAL</b>"
            else:
                status_display = "⏳ <b>MASIH DIPROSES (PENDING)</b>"
                
            nama = data.get('nama', '-')
            rekening = data.get('nomor_tujuan', '-')
            bank = str(data.get('bank_code', '-')).upper()
            nominal = data.get('nominal', 0)
            fee = data.get('fee', 0)
            total = data.get('total', 0)
            created_at = data.get('created_at', '-')
            msg_server = res.get('message', 'Sukses mengecek status.')
            
            receipt = (
                f"{status_display}\n"
                f"{LINE_SEP}\n"
                "<b>📦 Detail Transaksi Terbaru:</b>\n\n"
                f"<b>🏦 Bank      :</b> <code>{bank}</code>\n"
                f"<b>💳 Akun      :</b> <code>{rekening}</code>\n"
                f"<b>👤 Nama      :</b> <code>{nama}</code>\n"
                f"<b>💰 Nominal :</b> <code>Rp {int(nominal):,}</code>\n"
                f"<b>💸 Fee Admin :</b> <code>Rp {int(fee):,}</code>\n"
                f"<b>💵 Total Potong:</b> <code>Rp {int(total):,}</code>\n\n"
                f"<b>🔑 Trx ID    :</b> <code>{atlantic_id}</code>\n"
                f"<b>🕒 Tanggal   :</b> <code>{created_at}</code>\n"
                f"{LINE_SEP}\n"
                f"<i>Pesan: {msg_server}</i>\n"
                f"<i>🕒 Last Update: {time.strftime('%H:%M:%S')}</i>"
            )
            
            m = InlineKeyboardMarkup()
            m.add(InlineKeyboardButton("🔄 Refresh Status", callback_data=call.data))
            m.row(
                InlineKeyboardButton("🔙 Menu Utama", callback_data="owner_wd_menu"),
                InlineKeyboardButton("🗑 Hapus", callback_data="close_message")
            )
            
            # Edit pesan struk dengan data terbaru
            try:
                bot.edit_message_text(receipt, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
            except telebot.apihelper.ApiTelegramException as e:
                if "message is not modified" in str(e):
                    pass # Abaikan jika status belum berubah
                else:
                    bot.send_message(call.message.chat.id, receipt, parse_mode='HTML', reply_markup=m)
        else:
            reason = res.get('message', 'Unknown Error') if res else "Server Tidak Merespon"
            bot.answer_callback_query(call.id, f"❌ Gagal Cek: {reason}", show_alert=True)
            
    except Exception as e:
        bot.answer_callback_query(call.id, "❌ Terjadi Kesalahan Sistem.", show_alert=True)
        print(f"Error Cek WD: {e}")