import telebot
import paramiko
from bot_init import bot
from database import get_user_data, add_balance
from menus import PRICES # Import harga dari menus.py
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import random, string, datetime

# --- SETTING SERVER VPS ---
SERVER_DATA = {
    "sg":   {"ip": "159.65.15.214", "user": "root", "pass": "azzam2016"},
    "indo": {"ip": "103.150.226.10", "user": "root", "pass": "azzam2016"}
}

# --- FUNGSI KONEKSI KE BRIDGE ---
def remote_create_account(lokasi, protocol, username, password, days=30, limit=2):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan"

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=5)

        # Panggil bridge.py yang sudah kita buat di TAHAP 1
        script = "/root/bot_store/kyt/modules/bridge.py"
        cmd = f"python3 {script} {protocol} create {username} {password} {days} {limit}"
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode().strip()
        client.close()

        if "SUCCESS" in output:
            data = output.split("|")
            return True, {"user": data[2], "pass": data[3], "exp": data[4]}
        else:
            return False, output
    except Exception as e:
        return False, f"SSH Error: {e}"

# --- HANDLER PEMBELIAN (CALLBACK) ---
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_ssh_"))
def process_buy_ssh(call):
    # Data: buy_ssh_sg
    lokasi = call.data.split("_")[2]
    user_id = call.from_user.id
    
    # 1. CEK HARGA SESUAI ROLE
    user_data = get_user_data(user_id)
    role = str(user_data.get('role', 'user')).lower()
    
    # Tentukan kategori harga (user/reseller)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"
    
    try:
        harga = PRICES[lokasi]["ssh"][kategori]
    except:
        return bot.answer_callback_query(call.id, "❌ Harga Error")

    # 2. CEK SALDO
    saldo = int(user_data.get('balance', 0))
    if saldo < harga:
        return bot.answer_callback_query(call.id, f"❌ Saldo Kurang! Butuh {harga:,}", show_alert=True)

    # 3. PROSES PEMBUATAN
    bot.answer_callback_query(call.id, "⏳ Memproses...", show_alert=False)
    msg = bot.send_message(call.message.chat.id, "⏳ <b>Menghubungkan ke Server...</b>", parse_mode='HTML')

    # Generate User/Pass Random
    username = "u" + ''.join(random.choices(string.ascii_lowercase + string.digits, k=5))
    password = ''.join(random.choices(string.digits, k=4))

    # Panggil fungsi remote di atas
    sukses, info = remote_create_account(lokasi, "ssh", username, password)

    if sukses:
        # Potong Saldo
        add_balance(user_id, -harga, f"Beli SSH {lokasi}")
        
        # Kirim Hasil
        txt = (f"✅ <b>AKUN SSH SUKSES</b>\n"
               f"👤 User: <code>{info['user']}</code>\n"
               f"🔑 Pass: <code>{info['pass']}</code>\n"
               f"📅 Exp : {info['exp']}\n"
               f"💸 Harga: Rp {harga:,} ({kategori.upper()})")
        bot.edit_message_text(txt, call.message.chat.id, msg.message_id, parse_mode='HTML')
    else:
        bot.edit_message_text(f"❌ Gagal: {info}", call.message.chat.id, msg.message_id)