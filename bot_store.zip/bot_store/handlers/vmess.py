import threading
import datetime
import telebot
import paramiko
import json
import base64
import re
from bot_init import bot
from config import ADMIN_ID
from database import get_user_data, add_balance, increment_reseller_trx, save_vpn_created
from utils_helper import get_back_markup
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# ======================================================
# 1. KONFIGURASI HARGA
# ======================================================
HARGA_VMESS = {
    "sg":   {"user": 15000, "reseller": 12000},
    "indo": {"user": 13000, "reseller": 10000}
}

# ======================================================
# 2. KONFIGURASI SERVER
# ======================================================
SERVER_DATA = {
    "sg": { 
        "name": "Singapore VIP", 
        "domain": "sg.hokage.web.id", 
        "ip": "165.22.48.206", 
        "user": "root", 
        "pass": "azzam2016" 
    },
    "indo": { 
        "name": "Indonesia Private", 
        "domain": "id.hokagelegend.web.id", 
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016" 
    }
}

# ======================================================
# HELPER: GENERATE LINK (TETAP DI PYTHON)
# ======================================================
def gen_vmess_link(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    net = "grpc" if type == "grpc" else "ws"
    path = "vmess-grpc" if type == "grpc" else "/vmess"
    tls = "tls" if type != "none" else "none"
    type_net = "gun" if type == "grpc" else "none"

    config = {
        "v": "2", "ps": name, "add": domain, "port": port, "id": uuid, "aid": "0",
        "net": net, "type": type_net, "host": domain, "path": path, "tls": tls
    }
    return f"vmess://{base64.b64encode(json.dumps(config).encode()).decode()}"

# ======================================================
# HELPER: EKSEKUSI SCRIPT "BRIDGE" DI VPS
# ======================================================
def create_vmess_remote(username, quota, masa_aktif, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    # Sanitasi username (hanya huruf dan angka) untuk keamanan
    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=15)
        
        # ==================================================================
        # PENTING: MENGGUNAKAN SCRIPT API YANG KITA BUAT SEBELUMNYA
        # Pastikan file /usr/bin/addvmess_api sudah dibuat di VPS
        # ==================================================================
        cmd = f"/usr/bin/addvmess_api {safe_username} {masa_aktif} {quota} 2"
        
        stdin, stdout, stderr = client.exec_command(cmd)
        
        # Tunggu command selesai
        exit_status = stdout.channel.recv_exit_status()
        
        output = stdout.read().decode().strip()
        error_msg = stderr.read().decode().strip() # Baca error dari sistem
        client.close()

        # Debugging Print (Cek log bot jika error)
        print(f"--- DEBUG VMESS ---")
        print(f"CMD: {cmd}")
        print(f"STDOUT: {output}")
        print(f"STDERR: {error_msg}")
        print(f"-------------------")

        # Parse Output
        if "SUCCESS" in output:
            try:
                parts = output.split("|") 
                u_uuid = parts[1]
                return True, "Sukses", {'uuid': u_uuid}
            except IndexError:
                return False, "Gagal parsing output VPS", {}
        elif "ERROR" in output:
            # Mengambil pesan error dari script bash (setelah kata ERROR|)
            reason = output.split("|")[1] if "|" in output else "Error Unknown"
            return False, f"VPS: {reason}", {}
        else:
            # Tampilkan pesan error jika output kosong tapi ada error sistem
            if "command not found" in error_msg:
                return False, "Script 'addvmess_api' belum dibuat di VPS", {}
            
            pesan_gagal = error_msg if error_msg else output[:100]
            return False, f"Gagal Script: {pesan_gagal}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HANDLER UTAMA (TRANSAKSI)
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_vmess_"))
def buy_vmess(call):
    try:
        uid = call.from_user.id
        try: lokasi = call.data.split("_")[2]
        except: return bot.answer_callback_query(call.id, "❌ Error Data")

        if lokasi not in HARGA_VMESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

        user_data = get_user_data(uid)
        if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

        role = str(user_data.get('role', 'user')).lower()
        saldo = int(user_data.get('balance', 0))

        if 'reseller' in role or 'owner' in role or str(uid) == str(ADMIN_ID):
            price = HARGA_VMESS[lokasi]["reseller"]
            tipe_user = "RESELLER ⚡"
        else:
            price = HARGA_VMESS[lokasi]["user"]
            tipe_user = "MEMBER 👤"

        is_owner = str(uid) == str(ADMIN_ID) or 'owner' in role

        if not is_owner and saldo < price:
            kurang = price - saldo
            msg_error = f"⚠️ <b>SALDO TIDAK CUKUP</b>\nKurang: Rp {kurang:,}"
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
            return bot.send_message(call.message.chat.id, msg_error, parse_mode='HTML', reply_markup=markup)
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_user"))
        
        msg = bot.send_message(call.message.chat.id, 
            f"<b>⚡ BELI VMESS {lokasi.upper()}</b>\nMasukkan <b>Username</b>:", 
            parse_mode='HTML', reply_markup=m)
        
        bot.register_next_step_handler(msg, lambda m: vmess_process(m, lokasi, price, is_owner))
    except Exception as e: bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def vmess_process(m, lokasi, price, is_owner):
    if m.content_type != 'text': return
    u = m.text.strip()
    if not u.isalnum() or len(u) < 3: return bot.reply_to(m, "❌ Username Invalid (Min 3 huruf/angka)")
    
    uid = m.from_user.id
    status = bot.reply_to(m, f"⏳ <b>Memproses...</b>", parse_mode='HTML')
    # Jalankan eksekusi
    vmess_execution(m, u, uid, price, status, lokasi, is_owner)

def vmess_execution(m, u, uid, price, status_msg, lokasi, is_owner):
    try:
        # ==========================================
        # SETTING KUOTA DISINI
        # 0 = Unlimited
        # ==========================================
        quota_gb = "0" 
        masa_aktif = "30"
        
        # PANGGIL FUNGSI YANG MENJALANKAN SCRIPT VPS
        succ, info, res = create_vmess_remote(u, quota_gb, masa_aktif, lokasi)
        
        if succ:
            if not is_owner:
                add_balance(uid, -price, f"Beli Vmess {lokasi.upper()} ({u})")
                if get_user_data(uid).get('role') == 'reseller': increment_reseller_trx(uid)
                sisa_saldo = f"{int(get_user_data(uid).get('balance', 0)):,}"
            else:
                sisa_saldo = "Unlimited"

            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            
            # Generate Info
            res_uuid = res.get('uuid')
            domain = SERVER_DATA.get(lokasi)['domain']
            now = datetime.datetime.now()
            exp_date = now + datetime.timedelta(days=int(masa_aktif))
            tgl_exp = exp_date.strftime("%d %b, %Y")
            
            # Simpan DB
            try: save_vpn_created(uid, u, "VMESS", tgl_exp, res_uuid, domain)
            except: pass
            
            # Generate Link
            link_tls = gen_vmess_link(f"{u}-TLS", domain, res_uuid, "tls")
            link_ntls = gen_vmess_link(f"{u}-NTLS", domain, res_uuid, "none")
            link_grpc = gen_vmess_link(f"{u}-GRPC", domain, res_uuid, "grpc")

            # LOGIC TAMPILAN TEXT KUOTA
            tampilan_kuota = "Unlimited" if quota_gb == "0" else f"{quota_gb} GB"

            txt = f"""
========================================
⚡ <b>AKUN VMESS PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{u}</code>
Domain    : <code>{domain}</code>
Port TLS  : 443
Port NTLS : 80
Port GRPC : 443
UUID      : <code>{res_uuid}</code>
AlterId   : 0
Network   : WS / gRPC
Path      : /vmess
ServiceName: vmess-grpc

🔗 <b>LINK VMESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VMESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VMESS GRPC</b>
<code>{link_grpc}</code>

📋 <b>INFORMASI TAMBAHAN</b>
Expired: <code>{tgl_exp}</code>
Quota: {tampilan_kuota}
Limit IP: 2 Device

========================================
💰 Harga: Rp {price:,} | Sisa Saldo: {sisa_saldo}
"""
            bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup())
        else:
            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            bot.reply_to(m, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML')
            
    except Exception as e:
        bot.reply_to(m, f"❌ Error System: {e}")

# ======================================================
# MONITORING & DELETE (TETAP MENGGUNAKAN SSH DIRECT KARENA HANYA BACA/HAPUS)
# ======================================================
def get_ssh_connection_monitor(lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return None
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        return client
    except Exception: return None

def render_vmess_page(chat_id, message_id, lokasi, page=0):
    target = SERVER_DATA.get(lokasi)
    if not target: return
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    users = []
    today = datetime.datetime.now().date()

    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # SINKRONISASI TOTAL: Ambil data langsung dari config.json seperti Dashboard
        stdin, stdout, stderr = client.exec_command("grep '### ' /etc/xray/config.json")
        raw_data = stdout.read().decode("utf-8").strip()
        client.close()
        
        seen = set()
        if raw_data:
            for line in raw_data.split("\n"):
                line = line.strip()
                parts = line.split()
                
                # Format tag di config.json: ### username exp_date
                if len(parts) >= 2 and parts[0] == "###":
                    u_name = parts[1]
                    
                    # Hindari duplikat jika Xray menulis 2 tag untuk 1 user
                    if u_name in seen: continue
                    seen.add(u_name)
                    
                    u_exp_str = "ERROR"
                    sisa_hari = -999
                    status_text = "UNKNOWN"
                    status_icon = "⚠️"
                    
                    # Jika ada keterangan tanggal di sebelahnya
                    if len(parts) >= 3:
                        u_exp_str = parts[2]
                        try:
                            u_exp_date = datetime.datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                            sisa_hari = (u_exp_date - today).days
                            status_icon = "✅" if sisa_hari >= 0 else "❌"
                            status_text = "Active" if sisa_hari >= 0 else "Expired"
                        except: pass

                    users.append({
                        "u": u_name, 
                        "ex": u_exp_str, 
                        "sisa": sisa_hari, 
                        "stat": status_text, 
                        "icon": status_icon, 
                        "quota": "0.0", # Config JSON tidak menyimpan kuota
                        "lim": "2"
                    })
                    
    except Exception as e: 
        bot.send_message(chat_id, f"❌ Error Reading Config: {e}")
        return

    # Sortir: User yang masih aktif di atas, yang error/expired di bawah
    users.sort(key=lambda x: x['sisa'], reverse=True)
    
    per_page = 5
    total = (len(users) + per_page - 1) // per_page
    if page < 0: page = 0
    if total > 0 and page >= total: page = total - 1
    
    start = page * per_page
    end = start + per_page
    cur = users[start:end]
    
    msg = f"<b>⚡ LIST VMESS ({lokasi.upper()})</b>\nTotal: {len(users)} | Page: {page+1}/{total}\n━━━━━━━━━━━━━━━━━━\n"
    m = InlineKeyboardMarkup()
    
    if not users:
        msg += "<i>Belum ada user VMess.</i>\n"
    else:
        for u in cur:
            day_txt = f"{u['sisa']} Hari" if u['sisa'] >= 0 else "DEAD ☠️" if u['sisa'] != -999 else "FORMAT ERROR"
            msg += f"👤 <b>{u['u']}</b>\n🏳️ {u['icon']} {u['stat']} ({day_txt})\n🎯 {u['quota']}GB | {u['lim']} IP\n━━━━━━━━━━━━━━━━━━\n"
            # Tombol hapus mengarah ke vms_del_rem
            m.add(InlineKeyboardButton(f"🗑️ Hapus {u['u']}", callback_data=f"vms_del_rem|{lokasi}|{u['u']}|{page}"))
    
    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️", callback_data=f"vms_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vmess_vps|{lokasi}|0"))
    if page < total - 1: nav.append(InlineKeyboardButton("➡️", callback_data=f"vms_nav_rem|{lokasi}|{page+1}"))
    if nav: m.row(*nav)
    m.add(InlineKeyboardButton(f"🔙 DASHBOARD {lokasi.upper()}", callback_data=f"monitor_{lokasi}"))
    
    try: bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=m)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vmess_vps"))
def start_cek_vmess(call): 
    if str(call.from_user.id) != str(ADMIN_ID): return
    try: lokasi = call.data.split("|")[1]
    except: lokasi = "sg"
    bot.answer_callback_query(call.id, f"Memuat data {lokasi.upper()}...")
    render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, 0)

@bot.callback_query_handler(func=lambda call: call.data.startswith("vms_nav_rem"))
def nav_vmess(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    _, lokasi, page = call.data.split("|")
    render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, int(page))

@bot.callback_query_handler(func=lambda call: call.data.startswith("vms_del_rem"))
def del_vmess(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    _, lokasi, user, page = call.data.split("|")
    try:
        client = get_ssh_connection_monitor(lokasi)
        if client:
            # Command delete disesuaikan dengan format addvmess_api
            cmd = f"""
            sed -i "/^### {user} /,+1d" /etc/xray/config.json
            sed -i "/^### {user} /d" /etc/vmess/.vmess.db
            rm -f /etc/vmess/{user}
            rm -f /etc/kyt/limit/vmess/ip/{user}
            systemctl restart xray
            """
            
            client.exec_command(cmd)
            client.close()
            bot.answer_callback_query(call.id, f"✅ {user} Dihapus!", show_alert=True)
            render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    except Exception as e: bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)