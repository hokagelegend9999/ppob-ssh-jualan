import sys
import os
import sqlite3
import pandas as pd
from dotenv import load_dotenv
from datetime import datetime
import telebot
# ==========================================
# 1. SETUP ENV & PATH (WAJIB DITARUH PALING ATAS!)
# ==========================================
# Tentukan path folder me-cli
cli_path = '/root/bot_store/me-cli'
sys.path.append(cli_path)

# Load .env SEBELUM import module lain berjalan
env_file = os.path.join(cli_path, '.env')
if os.path.exists(env_file):
    load_dotenv(env_file)
    print(f"✅ Loaded .env from: {env_file}")
else:
    print(f"❌ Warning: File .env tidak ditemukan di {cli_path}")

# ==========================================
# 2. BARU IMPORT MODULE LAIN DI SINI
# ==========================================

from bot_init import bot
# Import fungsi dari file baru (PASTIKAN BARIS INI ADA)
from app.menus.dor_family import (
    handle_input_family_code, 
    show_family_package_detail, 
    execute_family_purchase
)

# Import menu login (Sekarang aman karena .env sudah diload di atas)
from app.menus.bot_login import start_login_process, logout_process, handle_login_callbacks
from menus import menu_admin, menu_user
from app.menus.dor_paket import menu_dor_non_legal
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ForceReply, Message
from database import (
    get_user_data_complete, 
    update_saldo, 
    update_user_role, 
    get_suspicious_users_list, 
    get_user_data, 
    add_balance, 
    find_user,
    get_user_transaction_history,
    update_transaction_status    
)
from handlers import handlers_vps
import handlers.users
from handlers import handlers_ppob
from handlers import handlers_payment
from config import ADMIN_ID, ATLANTIC_API_KEY, ATLANTIC_DEPOSIT_STATUS_URL
from datetime import datetime
from app.menus.bot_hot_menu import (
    menu_hot1_bot, 
    handle_hot1_selection,
    menu_hot2_bot, 
    handle_hot2_selection,
    handle_hot_payment,
    prompt_family_code_input, handle_family_list_selection, handle_family_payment,
    handle_direct_family_search
)
import subprocess
import html
import json


DB_NAME = "store_data.db"
broadcast_msg_id = None
try:
    from orderkuota_service import check_orderkuota_status
except ImportError:
    check_orderkuota_status = None
    
# --- HANDLER MENU HOT 1 ---
@bot.callback_query_handler(func=lambda call: call.data == "menu_hot1")
def route_hot1(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    menu_hot1_bot(call.message.chat.id, call.message.message_id, bot)

@bot.callback_query_handler(func=lambda call: call.data.startswith("hot1_sel|"))
def route_hot1_sel(call):
    handle_hot1_selection(call, bot)

# --- HANDLER MENU HOT 2 ---
#@bot.callback_query_handler(func=lambda call: call.data == "menu_hot2")
#def route_hot2(call):
#    if str(call.from_user.id) != str(ADMIN_ID): return
#    menu_hot2_bot(call.message.chat.id, call.message.message_id, bot)

@bot.callback_query_handler(func=lambda call: call.data.startswith("hot2_sel|"))
def route_hot2_sel(call):
    handle_hot2_selection(call, bot)
@bot.callback_query_handler(func=lambda call: call.data == "hot2_direct_family")
def on_direct_family_search(call):
    # --- TAMBAHKAN PENGECEKAN LOGIN DISINI ---
    from app.service.auth import AuthInstance
    tokens = AuthInstance.get_active_tokens()
    
    if not tokens or not tokens.get("access_token"):
        # Jika belum login, tampilkan peringatan dan arahkan ke login
        markup_login = InlineKeyboardMarkup()
        markup_login.add(InlineKeyboardButton("🔐 Login OTP Sekarang", callback_data="auth_login_menu"))
        markup_login.add(InlineKeyboardButton("🔙 Batal", callback_data="run_me_cli"))
        
        return bot.edit_message_text(
            "⚠️ <b>AKSES DITOLAK</b>\n\n"
            "Pembelian <b>MASA AKTIF XL 30 HARI</b> memerlukan akses login OTP.\n"
            "Silakan login akun XL Anda terlebih dahulu.",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup_login
        )
    # --- AKHIR PENGECEKAN ---
    
    # Jika sudah login, lanjut ke fungsi pencarian paket
    handle_direct_family_search(call, bot)
def route_hot_pay(call):
    handle_hot_payment(call, bot)   
# --- Helper Cek Deposit ---
def cek_status_deposit_atlantic(deposit_id):
    from config import ATLANTIC_API_KEY, ATLANTIC_DEPOSIT_STATUS_URL
    import requests
    
    url = ATLANTIC_DEPOSIT_STATUS_URL
    payload = {'api_key': ATLANTIC_API_KEY, 'id': deposit_id}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    
    try:
        response = requests.post(url, data=payload, headers=headers, timeout=10)
        return response.json()
    except Exception as e:
        return {'status': False, 'message': str(e)}
# ==========================================
# 1. HANDLER: KEMBALI KE MENU OWNER
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "admin_panel")
def back_to_owner_menu(call):
    # [PERBAIKAN] Jika User Biasa, kembalikan ke MENU UTAMA BOT (awal)
    if str(call.from_user.id) != str(ADMIN_ID):
        try:
            # Panggil menu utama user (layout PPOB/VPN awal)
            markup = menu_user(role="user") 
            
            bot.edit_message_text(
                "🏠 <b>MENU UTAMA</b>\nSilakan pilih layanan:",
                call.message.chat.id,
                call.message.message_id,
                reply_markup=markup,
                parse_mode="HTML"
            )
        except Exception as e:
            # Fallback jika gagal edit (misal pesan terlalu lama)
            bot.send_message(call.message.chat.id, "Ketik /start untuk ke menu utama.")
        return

    first_name = call.from_user.first_name
    username = call.from_user.username
    uid = call.from_user.id

    text = (
        f"👑 <b>PANEL OWNER (GOD MODE)</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"👋 Halo, Bos <b>{first_name}</b>!\n"
        f"🆔 ID Akun: <code>{uid}</code>\n"
        f"👤 Username: @{username}\n"
        f"💰 <b>Saldo: ♾️ UNLIMITED (Owner)</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"🛡️ <i>Sebagai Owner, Anda memiliki akses penuh dan saldo tak terbatas.\n"
        f"Gunakan panel di bawah untuk mengelola bot.</i>"
    )

    markup = menu_admin(uid)
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    except Exception as e:
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

# Tambahkan ini di main.py jika belum ada
@bot.callback_query_handler(func=lambda call: call.data == "back_to_main_menu")
def handler_back_main_menu_global(call):
    try:
        markup = menu_user(role="user")
        bot.edit_message_text(
            "🏠 <b>MENU UTAMA</b>\nSilakan pilih layanan:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode="HTML"
        )
    except Exception as e:
        print(f"Error back main: {e}")

# ==========================================
# 2. HANDLER MANAJEMEN SALDO (TAMBAH/KURANG)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("add_saldo|") or call.data.startswith("min_saldo|"))
def action_manage_saldo(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")
    
    action, target_id = call.data.split("|")
    mode = "TAMBAH" if action == "add_saldo" else "POTONG"
    
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 BATAL / KEMBALI", callback_data=f"back_to_detail|{target_id}"))

    msg = bot.send_message(
        call.message.chat.id,
        f"💰 **{mode} SALDO USER**\n"
        f"Target ID: `{target_id}`\n\n"
        f"Masukkan nominal (Angka saja):\n"
        f"Contoh: `50000`",
        parse_mode="Markdown",
        reply_markup=markup 
    )
    
    bot.register_next_step_handler(msg, process_update_saldo, target_id, mode)

def process_update_saldo(message, target_id, mode):
    try:
        text_input = message.text.strip().replace(".", "").replace(",", "")
        
        if not text_input.isdigit():
            return bot.send_message(message.chat.id, "❌ Nominal harus berupa angka! Ulangi dari awal.")
            
        nominal = int(text_input)
        amount = nominal if mode == "TAMBAH" else -nominal
        
        success_balance = update_saldo(target_id, amount)
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Kembali ke Panel", callback_data="admin_panel"))

        if success_balance is not False:
            bot.send_message(
                message.chat.id,
                f"✅ **BERHASIL DIUPDATE!**\n\n"
                f"👤 Target: `{target_id}`\n"
                f"💵 Nominal: {'+' if amount > 0 else ''}Rp {nominal:,}\n"
                f"💰 Sisa Saldo: **Rp {success_balance:,}**\n"
                f"🔒 Status: **VALID & AMAN**",
                parse_mode="Markdown",
                reply_markup=markup
            )
            try:
                pesan = f"💰 Saldo Anda telah {'ditambahkan' if amount > 0 else 'dipotong'} oleh Admin sebesar **Rp {nominal:,}**"
                bot.send_message(target_id, pesan, parse_mode="Markdown")
            except: pass
        else:
            bot.send_message(message.chat.id, "❌ **GAGAL UPDATE!**\nDatabase menolak transaksi (Security Alert) atau saldo user tidak cukup.", reply_markup=markup)
            
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error: {e}")    

@bot.callback_query_handler(func=lambda call: call.data.startswith("back_to_detail|"))
def back_to_user_detail_handler(call):
    try:
        bot.clear_step_handler_by_chat_id(call.message.chat.id)
        
        _, target_id = call.data.split("|")
        
        try: bot.delete_message(call.message.chat.id, call.message.message_id)
        except: pass
        
        # Simulasi pesan dummy agar bisa memanggil fungsi detail user
        dummy_msg = Message(
            message_id=call.message.message_id, 
            from_user=call.from_user, 
            date=call.message.date, 
            chat=call.message.chat, 
            content_type="text", 
            options={}, 
            json_string=""
        )
        dummy_msg.text = target_id
        
        process_find_user_detail(dummy_msg)
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error Back: {e}")
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Panel Owner", callback_data="admin_panel"))
        bot.send_message(call.message.chat.id, "Kembali ke menu utama.", reply_markup=markup)

# ==========================================
# 3. HANDLER CEK USER DETAIL
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "check_user_by_id_menu")
def ask_user_id_detail(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    try:
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except:
        pass

    msg = bot.send_message(
        call.message.chat.id,
        "🔎 **MODE CEK USER DETAIL**\n\n"
        "Silakan balas pesan ini dengan **ID Telegram** user yang ingin dicek.\n"
        "Contoh: `1234567890`",
        parse_mode="Markdown",
        reply_markup=ForceReply(selective=True)
    )
    bot.register_next_step_handler(msg, process_find_user_detail)

def process_find_user_detail(message):
    try:
        target_id = message.text.strip()

        if not target_id.isdigit():
            msg = bot.send_message(message.chat.id, "❌ **ID harus berupa angka!**\nSilakan input ulang:", reply_markup=ForceReply())
            return bot.register_next_step_handler(msg, process_find_user_detail)

        user = get_user_data_complete(target_id)

        if not user:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 Cari Lagi", callback_data="check_user_by_id_menu"))
            markup.add(InlineKeyboardButton("🔙 Menu Owner", callback_data="admin_panel"))
            
            return bot.send_message(
                message.chat.id, 
                f"❌ User dengan ID `{target_id}` tidak ditemukan di database.", 
                parse_mode="Markdown", 
                reply_markup=markup
            )

        u_id = user[0]
        u_username = f"@{user[1]}" if user[1] else "Tanpa Username"
        u_saldo = user[2]
        u_role = user[3]
        
        saldo_fmt = "{:,}".format(u_saldo).replace(",", ".")

        text_detail = (
            f"👤 **DETAIL USER DITEMUKAN**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 ID: `{u_id}`\n"
            f"👤 Username: {u_username}\n"
            f"💰 Saldo: **Rp {saldo_fmt}**\n"
            f"🔰 Role: **{u_role.upper()}**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"👇 _Pilih aksi untuk user ini:_"
        )

        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("➕ Tambah Saldo", callback_data=f"add_saldo|{u_id}"),
            InlineKeyboardButton("➖ Potong Saldo", callback_data=f"min_saldo|{u_id}")
        )
        markup.add(
            InlineKeyboardButton("📜 Cek Riwayat", callback_data=f"history_by_id|{u_id}"),
            InlineKeyboardButton("🔄 Reset Sesi", callback_data=f"reset_session|{u_id}")
        )
        
        if u_role.lower() == "user":
            markup.add(InlineKeyboardButton("⬆️ Up ke Reseller", callback_data=f"up_reseller|{u_id}"))
        elif u_role.lower() == "reseller":
            markup.add(InlineKeyboardButton("⬇️ Down ke User", callback_data=f"down_user|{u_id}"))

        markup.add(InlineKeyboardButton("🔙 Kembali ke Menu Owner", callback_data="admin_panel"))

        bot.send_message(message.chat.id, text_detail, parse_mode="Markdown", reply_markup=markup)

    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Terjadi kesalahan: {e}")
        
        
# ==========================================
#  HANDLER DETAIL RIWAYAT USER (FIXED UI & REFRESH BUTTON)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("hist_") and "page" not in call.data)
def detail_user_history(call):
    try:
        parts = call.data.split("_")
        target_id = parts[1]
        page = int(parts[2]) if len(parts) > 2 else 1
    except:
        return bot.answer_callback_query(call.id, "❌ Format Data Error")

    user = get_user_data_complete(target_id)
    if not user:
        return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")
    
    # Helper aman untuk ambil data list
    def safe_get(data, index, default="-"):
        try: 
            val = data[index] if len(data) > index else default
            return val if val is not None else default 
        except: return default

    u_name = safe_get(user, 1, "User")
    u_saldo = safe_get(user, 2, 0)
    u_role = str(safe_get(user, 3, "USER")).upper()
    
    history = get_user_transaction_history(target_id)
    
    LIMIT = 5 
    if not history or not isinstance(history, list): history = []
        
    total_items = len(history)
    total_pages = (total_items + LIMIT - 1) // LIMIT
    if page > total_pages: page = total_pages if total_pages > 0 else 1
    if page < 1: page = 1

    offset = (page - 1) * LIMIT
    current_history = history[offset : offset + LIMIT]

    msg =  f"👑 <b>DASHBOARD MANAGEMENT</b>\n"
    msg += f"<code>──────────────────────────────</code>\n"
    msg += f"👤 <b>NAME        :</b> <code>{u_name}</code>\n"
    msg += f"🆔 <b>USER ID     :</b> <code>{target_id}</code>\n"
    msg += f"💎 <b>RANK        :</b> <code>{u_role}</code>\n"
    msg += f"💰 <b>SALDO SKRG:</b> <b>Rp {u_saldo:,}</b>\n".replace(",", ".")
    msg += f"<code>──────────────────────────────</code>\n\n"
    msg += f"📊 <b>DETIL RIWAYAT ({page}/{total_pages}):</b>\n\n"

    markup = InlineKeyboardMarkup()
    row_btns = []

    if not current_history:
        msg += "<i>📭 Belum ada riwayat transaksi.</i>"
    else:
        import re 
        import sqlite3

        for i, item in enumerate(current_history, start=offset + 1): 
            t_date    = safe_get(item, 0, "-")
            raw_amount = safe_get(item, 2, 0)
            try: t_amount = int(raw_amount)
            except: t_amount = 0
            
            t_status  = safe_get(item, 3, "pending")
            t_dest    = safe_get(item, 4, "-")
            t_sn      = safe_get(item, 5, "-") 
            
            raw_saldo_awal = safe_get(item, 6, 0)
            try: t_saldo_awal = int(raw_saldo_awal)
            except: t_saldo_awal = 0
            
            raw_saldo_akhir = safe_get(item, 7, 0)
            try: t_saldo_akhir = int(raw_saldo_akhir)
            except: t_saldo_akhir = 0
            
            t_ref_id = str(safe_get(item, 8, "-"))

            # --- DB LOOKUP ---
            real_desc_db = "-"
            try:
                conn_fix = sqlite3.connect("store_data.db", timeout=5)
                c_fix = conn_fix.cursor()
                c_fix.execute("SELECT description FROM transactions WHERE ref_id = ?", (t_ref_id,))
                row_fix = c_fix.fetchone()
                if row_fix and row_fix[0]: real_desc_db = row_fix[0]
                conn_fix.close()
            except:
                real_desc_db = str(safe_get(item, 1, "-"))

            # --- LOGIKA NOMINAL & SALDO ---
            real_amount = t_amount
            if real_amount == 0 and t_saldo_akhir != t_saldo_awal:
                real_amount = t_saldo_akhir - t_saldo_awal

            if t_saldo_awal == 0 and t_saldo_akhir != 0:
                t_saldo_awal = t_saldo_akhir - real_amount

            # --- LOGIKA TIPE ---
            clean_desc = real_desc_db
            username_ssh = None
            is_vpn = False
            is_deposit_user = False 
            is_admin_inject = False 
            is_ppob = False

            if t_ref_id.startswith("SYS-"):
                is_vpn = True
                match = re.search(r'\((.*?)\)', real_desc_db)
                if match:
                    username_ssh = match.group(1)
                    clean_desc = real_desc_db.replace(f"({username_ssh})", "")
                clean_desc = clean_desc.replace("Manual", "").strip()
                if not clean_desc or clean_desc == "-": clean_desc = "SSH/VPN SERVER"

            elif "ADM" in t_ref_id:
                is_admin_inject = True
                clean_desc = "KOREKSI ADMIN"

            elif real_amount > 0 and not is_admin_inject:
                is_deposit_user = True
                clean_desc = "DEPOSIT SALDO"
                
            elif t_ref_id.startswith("TRX") or t_ref_id.startswith("ATL"):
                is_ppob = True
                clean_desc = real_desc_db.replace("pembelian", "").replace("Pembelian", "").strip()

            # --- FORMAT TEXT ---
            val_awal = f"Rp {t_saldo_awal:,}".replace(",", ".")
            val_akhir = f"Rp {t_saldo_akhir:,}".replace(",", ".")
            
            if real_amount > 0: val_trx = f"+Rp {real_amount:,}".replace(",", ".")
            else: val_trx = f"-Rp {abs(real_amount):,}".replace(",", ".")

            str_date = str(t_date)
            try:
                jam = str_date[11:16]
                tanggal = str_date[8:10] + "-" + str_date[5:7] + "-" + str_date[:4]
            except: jam, tanggal = "-", "-"

            status_lower = str(t_status).lower()
            if "sukses" in status_lower: stat_icon = "🟢"
            elif "gagal" in status_lower: stat_icon = "🔴"
            else: stat_icon = "🟡"

            # RENDER PESAN
            msg += f"<b>{i}. {stat_icon} {clean_desc}</b>\n"
            msg += f"   Ref Id: <code>{t_ref_id}</code>\n"
            msg += f"   {jam} | {tanggal}\n"
            
            if val_awal != "Rp 0" and val_awal != "-":
                 msg += f"   Saldo Sebelum : {val_awal}\n"
                 msg += f"   Saldo Sesudah : {val_akhir}\n"
            
            msg += f"   Nominal : <b>{val_trx}</b>\n"

            final_dest = "-"
            if is_vpn and username_ssh: final_dest = username_ssh
            elif t_dest and str(t_dest) not in ["-", "0", "None", ""]: final_dest = t_dest
            
            if final_dest != "-": msg += f"   Tujuan : <code>{final_dest}</code>\n"
            
            raw_sn = str(t_sn).strip()
            if raw_sn and raw_sn not in ["-", "", "None"] and is_ppob:
                 if "gagal" in status_lower: msg += f"   Info : <code>{raw_sn[:30]}...</code>\n"
                 else: msg += f"   SN : <code>{raw_sn}</code>\n"
            msg += "\n"

            # === [PERBAIKAN TOMBOL: GANTI COPY JADI REFRESH] ===
            # Ini yang mengatasi error "Data rusak/tidak lengkap"
            if is_ppob:
                cb_data = f"chk|{t_ref_id}|{target_id}"
                row_btns.append(InlineKeyboardButton(f"{i} 🔄", callback_data=cb_data))
            elif is_vpn:
                row_btns.append(InlineKeyboardButton(f"{i} ☁️", callback_data="ignore"))
            elif is_deposit_user:
                 cb_data = f"chk_depo|{t_ref_id}|{target_id}"
                 row_btns.append(InlineKeyboardButton(f"{i} 👁️", callback_data=cb_data))
            else:
                row_btns.append(InlineKeyboardButton("🔒", callback_data="ignore"))

            if len(row_btns) == 5:
                markup.row(*row_btns)
                row_btns = []

    if row_btns: markup.row(*row_btns)

    nav_btns = []
    if page > 1: nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"hist_{target_id}_{page-1}"))
    if total_pages > 1: nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    if page < total_pages: nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"hist_{target_id}_{page+1}"))
    markup.row(*nav_btns)

    msg += f"<code>──────────────────────────────</code>\n"
    msg += f"✨ <i>Klik nomor 👁️ untuk Cek Status Deposit</i>\n"
    msg += f"✨ <i>Klik nomor 🔄 untuk Cek/Refund PPOB</i>"

    markup.add(
        InlineKeyboardButton("➕ ISI SALDO", callback_data=f"saldo_add_shortcut|{target_id}"),
        InlineKeyboardButton("➖ POTONG", callback_data=f"saldo_min_shortcut|{target_id}")
    )
    markup.add(InlineKeyboardButton("🔄 REFRESH LIST", callback_data=f"hist_{target_id}_{page}"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE LIST USER", callback_data="check_user_history"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except Exception:
        bot.send_message(call.message.chat.id, msg, parse_mode="HTML", reply_markup=markup)
# ==========================================
#  HANDLER TOMBOL IGNORE (AGAR TIDAK ERROR)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "ignore")
def handler_ignore_button(call):
    # Cukup hilangkan loading jam pasir, tanpa pesan error
    bot.answer_callback_query(call.id)
# Handler Copy untuk Admin (jika belum ada)
@bot.callback_query_handler(func=lambda call: call.data.startswith("cp|"))
def handler_copy_sn_admin(call):
    try:
        parts = call.data.split("|")
        sn_text = "|".join(parts[2:])
        bot.answer_callback_query(call.id, f"🔑 SN: {sn_text}", show_alert=True)
    except: pass

# --- HANDLER SHORTCUT SALDO (DARI DASHBOARD) ---
@bot.callback_query_handler(func=lambda call: "saldo_add_shortcut" in call.data)
def shortcut_add_saldo(call):
    # Import di sini untuk menghindari circular import jika ada
    from handlers.users.admin_saldo import process_saldo_add_step2
    target_id = call.data.split("|")[1]
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"hist_{target_id}_1"))
    
    msg = bot.send_message(
        call.message.chat.id, 
        f"➕ <b>ISI SALDO MANUAL (SHORTCUT)</b>\nTarget ID: <code>{target_id}</code>\n\nMasukkan Nominal (Angka saja):", 
        parse_mode='HTML',
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_add_step2, target_id)

@bot.callback_query_handler(func=lambda call: "saldo_min_shortcut" in call.data)
def shortcut_deduct_saldo(call):
    from handlers.users.admin_saldo import process_saldo_deduct_step2
    target_id = call.data.split("|")[1]
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"hist_{target_id}_1"))
    
    msg = bot.send_message(
        call.message.chat.id, 
        f"➖ <b>POTONG SALDO MANUAL (SHORTCUT)</b>\nTarget ID: <code>{target_id}</code>\n\nMasukkan Nominal Potongan:", 
        parse_mode='HTML',
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_deduct_step2, target_id)
# ==========================================
# 4. HANDLER BACKUP DATABASE & SOURCE CODE (UPDATED)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "backup_db")
def export_database_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    markup_back = InlineKeyboardMarkup()
    markup_back.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))

    msg = None 

    try:
        msg = bot.send_message(call.message.chat.id, "⏳ <b>Sedang memproses FULL BACKUP...</b>\nMohon tunggu...", parse_mode='HTML')
        
        today = datetime.now().strftime("%Y-%m-%d_%H-%M")
        excel_filename = f"Backup_Store_{today}.xlsx"
        zip_filename = f"FULL_BACKUP_BOT_{today}.zip"

        # --------------------------------------------------------
        # A. KIRIM FILE DATABASE ASLI (.DB)
        # --------------------------------------------------------
        if os.path.exists(DB_NAME):
            with open(DB_NAME, 'rb') as f:
                bot.send_document(
                    call.message.chat.id, 
                    f, 
                    caption=f"🗄 <b>DATABASE RAW ({today})</b>\nFile ini untuk restore jika bot error.",
                    parse_mode='HTML'
                )
        else:
            bot.send_message(call.message.chat.id, "❌ File database asli tidak ditemukan!")

        # --------------------------------------------------------
        # B. EXPORT KE EXCEL (.XLSX)
        # --------------------------------------------------------
        # (Bagian ini tetap sama seperti sebelumnya, untuk laporan user/transaksi)
        conn = sqlite3.connect(DB_NAME)
        
        with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
            # Sheet Users
            try:
                df_users = pd.read_sql_query("SELECT * FROM users", conn)
                if 'user_id' in df_users.columns:
                    df_users['user_id'] = df_users['user_id'].astype(str)
                df_users.to_excel(writer, sheet_name='Users', index=False)
            except Exception as e:
                print(f"Gagal export sheet Users: {e}")

            # Sheet Transaksi
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='transactions'")
                if cursor.fetchone():
                    df_trx = pd.read_sql_query("SELECT * FROM transactions", conn)
                    # Konversi kolom ID jadi string agar tidak error notasi ilmiah di Excel
                    for col in ['user_id', 'id', 'ref_id', 'sn']:
                        if col in df_trx.columns:
                            df_trx[col] = df_trx[col].astype(str)
                            
                    df_trx.to_excel(writer, sheet_name='Transaksi', index=False)
            except Exception as e:
                print(f"Gagal export sheet Transaksi: {e}")
        
        conn.close()

        # Kirim File Excel
        if os.path.exists(excel_filename):
            with open(excel_filename, 'rb') as f:
                bot.send_document(
                    call.message.chat.id, 
                    f, 
                    caption=f"📊 <b>LAPORAN EXCEL ({today})</b>\nData user dan transaksi agar mudah dibaca.",
                    parse_mode='HTML'
                )
            os.remove(excel_filename)
        
        # --------------------------------------------------------
        # C. ZIP FOLDER BOT + SERVICE SYSTEMD (BAGIAN BARU)
        # --------------------------------------------------------
        
        try: bot.edit_message_text(f"⏳ <b>Mengompres Folder & Service...</b>", call.message.chat.id, msg.message_id, parse_mode='HTML')
        except: pass
        
        # Command Zip: Mengompres folder bot DAN file service systemd
        # Pastikan path folder benar: /root/bot_store
        command = f"zip -r {zip_filename} /root/bot_store /etc/systemd/system/bot-store.service /etc/systemd/system/webhook-store.service"
        
        try:
            # Menjalankan perintah linux via python
            subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
            
            if os.path.exists(zip_filename):
                with open(zip_filename, 'rb') as f:
                    bot.send_document(
                        call.message.chat.id,
                        f,
                        caption=f"📦 <b>FULL SOURCE + SERVICE ({today})</b>\n\n✅ <b>Isi Backup:</b>\n1. Folder /root/bot_store\n2. Service Bot Telegram\n3. Service Webhook\n\n<i>Simpan file ini untuk pindah VPS!</i>",
                        parse_mode='HTML'
                    )
                os.remove(zip_filename) # Hapus file zip di VPS setelah terkirim
            else:
                bot.send_message(call.message.chat.id, "❌ Gagal membuat file ZIP (File output tidak ditemukan).")
                
        except subprocess.CalledProcessError as e:
            err_msg = str(e.output.decode('utf-8')) if e.output else str(e)
            bot.send_message(call.message.chat.id, f"❌ <b>Error ZIP:</b>\nPastikan 'zip' terinstall (apt install zip).\n\nLog: {err_msg}", parse_mode='HTML')

        # Final Message
        try: bot.delete_message(call.message.chat.id, msg.message_id)
        except: pass

        bot.send_message(
            call.message.chat.id, 
            "✅ <b>BACKUP LENGKAP SELESAI!</b>\nSemua data telah diamankan.", 
            parse_mode='HTML', 
            reply_markup=markup_back
        )

    except Exception as e:
        try: 
            if msg: bot.delete_message(call.message.chat.id, msg.message_id)
        except: pass
        
        bot.reply_to(call.message, f"❌ Gagal Backup Total: {e}", reply_markup=markup_back)
        print(f"Error Backup: {e}")

# ==========================================
# 5. SISTEM BROADCAST
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "broadcast_all")
def start_broadcast(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATALKAN", callback_data="admin_panel"))
    
    msg = bot.edit_message_text(
        "📢 <b>MODE BROADCAST AKTIF</b>\n\n"
        "Silakan kirim pesan (Teks, Gambar, Video, atau GIF) yang akan disebar ke semua member.",
        call.message.chat.id, 
        call.message.message_id, 
        parse_mode='HTML', 
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, show_broadcast_preview)

def show_broadcast_preview(message):
    global broadcast_msg_id 
    
    if message.text == "/cancel": 
        bot.send_message(message.chat.id, "✅ Broadcast dibatalkan.")
        return

    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("✅ KIRIM SEKARANG", callback_data="confirm_broadcast"), 
        InlineKeyboardButton("❌ BATAL", callback_data="admin_panel")
    )

    bot.send_message(message.chat.id, "👇 <b>PRATINJAU PESAN ANDA:</b>", parse_mode='HTML')
    
    broadcast_msg_id = message.message_id
    
    bot.copy_message(
        chat_id=message.chat.id, 
        from_chat_id=message.chat.id, 
        message_id=message.message_id, 
        reply_markup=markup
    )
# 1. Handler Tombol Menu "6. Beli ..."
@bot.callback_query_handler(func=lambda call: call.data == "hot2_input_family")
def on_hot2_input_family(call):
    # Memanggil fungsi Step 1 dari dor_family.py
    handle_input_family_code(call, bot)
@bot.callback_query_handler(func=lambda call: call.data.startswith("sel_fam|"))
def on_select_family_package(call):
    # Memanggil fungsi detail dari file dor_family.py
    show_family_package_detail(call, bot)
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_fam_exec|"))
def on_exec_family_buy(call):
    # Memanggil fungsi eksekusi dari file dor_family.py
    execute_family_purchase(call, bot)


# 2. Handler saat tombol "Beli Paket Ini" (hasil pencarian) ditekan
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_fam|"))
def on_buy_family_execute(call):
    # Memanggil fungsi eksekusi dari file dor_family.py
    execute_family_purchase(call, bot)
# 2. Handler Saat Memilih Paket dari List
@bot.callback_query_handler(func=lambda call: call.data.startswith("fam_sel|"))
def on_family_list_selection(call):
    handle_family_list_selection(call, bot)

# 3. Handler Saat Bayar Paket Family
@bot.callback_query_handler(func=lambda call: call.data.startswith("pay_fam|"))
def on_family_payment(call):
    handle_family_payment(call, bot)
@bot.callback_query_handler(func=lambda call: call.data == "confirm_broadcast")
def final_send_broadcast(call):
    global broadcast_msg_id
    
    if not broadcast_msg_id: 
        return bot.answer_callback_query(call.id, "❌ Pesan kadaluarsa, ulangi broadcast.", show_alert=True)
    
    try:
        conn = sqlite3.connect(DB_NAME)
        users = conn.cursor().execute("SELECT user_id FROM users").fetchall()
        conn.close()
    except Exception as e:
        return bot.send_message(call.message.chat.id, f"❌ Error Database: {e}")
    
    total_users = len(users)
    if total_users == 0:
        return bot.send_message(call.message.chat.id, "❌ Tidak ada user di database.")

    status_msg = bot.send_message(call.message.chat.id, f"🚀 <b>Memulai Broadcast ke {total_users} user...</b>", parse_mode='HTML')
    
    success = 0
    failed = 0
    processed = 0
    
    markup_user = InlineKeyboardMarkup()
    markup_user.add(InlineKeyboardButton("🏠 MENU UTAMA", callback_data="back_to_main_menu"))

    for u in users:
        processed += 1
        user_id = u[0]
        
        try:
            bot.copy_message(
                chat_id=user_id, 
                from_chat_id=call.message.chat.id, 
                message_id=broadcast_msg_id, 
                reply_markup=markup_user
            )
            success += 1
        except Exception:
            failed += 1
        
        if processed % 15 == 0 or processed == total_users:
            percent = int((processed / total_users) * 100)
            bar_length = 10
            filled_length = int(bar_length * processed // total_users)
            bar = "█" * filled_length + "░" * (bar_length - filled_length)
            
            text_progress = (
                f"🚀 <b>STATUS BROADCAST</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"📊 Progress: <b>{percent}%</b>\n"
                f"<code>[{bar}]</code>\n\n"
                f"✅ Berhasil : <b>{success}</b>\n"
                f"❌ Gagal    : <b>{failed}</b>\n"
                f"👥 Total    : <b>{processed}/{total_users}</b>"
            )
            
            try:
                bot.edit_message_text(
                    text_progress, 
                    call.message.chat.id, 
                    status_msg.message_id, 
                    parse_mode='HTML'
                )
            except: 
                pass

    try: bot.delete_message(call.message.chat.id, status_msg.message_id)
    except: pass
    
    final_report = (
        f"✅ <b>BROADCAST SELESAI!</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"📨 Terkirim : <b>{success}</b>\n"
        f"🚫 Gagal    : <b>{failed}</b>\n"
        f"👥 Total    : <b>{total_users}</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    )
    
    markup_back = InlineKeyboardMarkup()
    markup_back.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="admin_panel"))
    
    bot.send_message(call.message.chat.id, final_report, parse_mode='HTML', reply_markup=markup_back)
    
    broadcast_msg_id = None

# Pastikan import ini ada di paling atas file
from datetime import datetime
import os
import json

# Ensure these imports are present
import json
import os
from datetime import datetime

@bot.callback_query_handler(func=lambda call: call.data == "run_me_cli")
def handler_run_me_cli(call):
    try:
        # 1. Setup Menu & UI
        markup, _ = menu_dor_non_legal(call.from_user) 
        telegram_id = str(call.from_user.id)
        nomor_hp = None
        
        # Path Folder Sesi
        BASE_DIR = "/root/bot_store"
        SESSION_DIR = os.path.join(BASE_DIR, "sessions")
        
        # 2. Baca Sesi Telegram
        session_file = os.path.join(SESSION_DIR, f"{telegram_id}.txt")
        if os.path.exists(session_file):
            with open(session_file, "r") as f:
                nomor_hp = f.read().strip()
        
        # 3. Import Module
        from app.service.auth import AuthInstance
        from app.client.engsel import get_balance
        from datetime import datetime
        
        tokens = {}
        is_token_found = False
        
        # 4. Deteksi Token (Gunakan logika manual agar sinkron)
        if nomor_hp:
            # Paksa muat ulang database token
            AuthInstance.load_tokens()
            if AuthInstance.set_active_user(nomor_hp):
                tokens = AuthInstance.get_active_tokens() or {}
                if tokens.get("id_token"):
                    is_token_found = True

            # Fallback jika set_active_user gagal (baca JSON langsung)
            if not is_token_found:
                db_path = "/root/bot_store/me-cli/refresh-tokens.json"
                if os.path.exists(db_path):
                    with open(db_path, "r") as f:
                        db_data = json.load(f)
                        for entry in db_data:
                            if str(entry.get("number")) == str(nomor_hp):
                                tokens = entry
                                is_token_found = True
                                break

        # 5. Variabel Tampilan
        display_msisdn = nomor_hp if nomor_hp else "-"
        masa_aktif = "-"
        login_stat = "❌ Belum Login"
        balance_info = ""

        # 6. Eksekusi Ambil Data Saldo
        if is_token_found and tokens.get("id_token"):
            login_stat = "✅ Akun Terhubung"
            api_key = AuthInstance.api_key or "490a6630-1646-4a46-8339-3c723ae73a87"
            
            # Coba ambil saldo
            bal_data = None
            try:
                bal_data = get_balance(api_key, tokens["id_token"])
            except: pass
            
            # Auto-Refresh jika token expired (Missing Bearer)
            if not bal_data:
                try:
                    if AuthInstance.renew_active_user_token():
                        new_tks = AuthInstance.get_active_tokens()
                        bal_data = get_balance(api_key, new_tks.get("id_token"))
                except: pass

            if bal_data:
                exp_ts = bal_data.get("expired_at")
                rem_bal = bal_data.get("remaining", 0)
                if exp_ts:
                    try:
                        dt = datetime.fromtimestamp(int(exp_ts))
                        masa_aktif = dt.strftime("%d-%m-%Y")
                    except: masa_aktif = "Error Tgl"
                balance_info = f" (Rp {rem_bal:,})"
            else:
                masa_aktif = "Gagal Ambil Data"
        
        elif nomor_hp:
            login_stat = "⚠️ Sesi Kadaluarsa / Data Tidak Ditemukan"
            masa_aktif = "Silakan Login Ulang"

        # 7. Tampilkan Menu
        msg_body = (
            f"🚀 <b>MENU DOR PAKET (NON LEGAL)</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👤 <b>User:</b> {call.from_user.first_name}\n"
            f"🆔 <b>ID Telegram:</b> <code>{telegram_id}</code>\n"
            f"📱 <b>Nomor:</b> <code>{display_msisdn}</code>\n"
            f"📅 <b>Masa Aktif:</b> {masa_aktif}{balance_info}\n"
            f"🔑 <b>Status:</b> {login_stat}\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"Silakan pilih operator atau tools yang ingin dijalankan:"
        )

        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=msg_body,
            reply_markup=markup,
            parse_mode="HTML"
        )

    except Exception as e:
        print(f"Error run_me_cli: {e}")
        # HAPUS variabel is_logged_in yang tidak didefinisikan
        markup_err = InlineKeyboardMarkup()
        markup_err.add(InlineKeyboardButton("🔙 Kembali ke Menu Utama", callback_data="run_me_cli"))
        
        bot.send_message(
            call.message.chat.id,
            f"❌ <b>Gagal Memuat Data Token</b>\n\nSistem gagal membaca sesi login. Pastikan login sukses.\n<i>Error: {str(e)}</i>",
            parse_mode="HTML",
            reply_markup=markup_err
        )

@bot.callback_query_handler(func=lambda call: call.data == "menu_hot2")
def show_hot2_menu_handler(call):
    bot.answer_callback_query(call.id, "🔥 Memuat Paket Hot 2...")
    
    json_path = '/root/me-cli/app/pg-hot2-local.json'
    
    try:
        if not os.path.exists(json_path):
            bot.send_message(call.message.chat.id, "❌ Error: File paket (pg-hot2-local.json) tidak ditemukan.")
            return

        with open(json_path, 'r') as f:
            packages = json.load(f)

        if not packages:
            bot.send_message(call.message.chat.id, "⚠️ Daftar paket HOT-2 kosong.")
            return

        markup = InlineKeyboardMarkup(row_width=1)
        
        for i, p in enumerate(packages):
            name = p.get('name', 'N/A')
            price = p.get('price', 'N/A')
            markup.add(InlineKeyboardButton(f"{i+1}. {name} - {price}", callback_data=f"hot2_buy_{i}"))

        markup.add(InlineKeyboardButton("« Kembali ke Menu Utama", callback_data="menu_back_main"))

        bot.edit_message_text(
            "🔥 <b>Available Hot 2 Packages (Lokal):</b>\n\nSilakan pilih paket:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error membaca JSON: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "menu_back_main")
def back_main_handler(call):
    try:
        # [PERBAIKAN] Pastikan ini memanggil handler_run_me_cli yang sudah dibuka aksesnya
        handler_run_me_cli(call) 
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error Back: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith("hot2_buy_"))
def confirm_hot2_purchase(call):
    try:
        pkg_index = int(call.data.split("_")[-1])
    except ValueError:
        return bot.answer_callback_query(call.id, "❌ Data Paket Invalid")

    json_path = '/root/me-cli/app/pg-hot2-local.json'
    try:
        with open(json_path, 'r') as f:
            packages = json.load(f)
        
        selected_pkg = packages[pkg_index]
        pkg_name = selected_pkg.get('name', 'Unknown Package')
        pkg_price = selected_pkg.get('price', 'Rp 0')
        pkg_detail = selected_pkg.get('detail', 'Tidak ada deskripsi.')
        
    except Exception as e:
        return bot.answer_callback_query(call.id, f"❌ Gagal baca file: {e}", show_alert=True)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🚀 GAS TEMBAK PAKET", callback_data=f"exec_hot2|{pkg_index}")) 
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="menu_hot2"))

    safe_detail = html.escape(pkg_detail)

    bot.edit_message_text(
        f"⚙️ <b>KONFIRMASI TEMBAK PAKET (ADMIN)</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"📦 <b>Paket:</b> {pkg_name}\n"
        f"💰 <b>Harga:</b> {pkg_price}\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"📝 <b>Detail Paket:</b>\n"
        f"<code>{safe_detail}</code>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"⚠️ <i>Peringatan: Paket akan dieksekusi menggunakan akun/nomor yang terlogin di CLI server. Pastikan saldo/kuota mencukupi.</i>",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("exec_hot2|"))
def execute_hot2_process(call):
    # Inisialisasi variabel msg agar tidak error di block except
    msg = None 
    try:
        # 1. Parsing Data
        pkg_index = int(call.data.split("|")[1])
        user_id = call.from_user.id
        
        # 2. Cek Harga Paket (Untuk Validasi Saldo)
        json_path = '/root/me-cli/app/pg-hot2-local.json'
        price = 0
        try:
            with open(json_path, 'r') as f:
                packages = json.load(f)
                raw_price = packages[pkg_index].get('price', '0')
                # Bersihkan format harga (Rp 5.000 -> 5000)
                price = int(str(raw_price).replace('Rp', '').replace('.', '').replace(',', '').strip())
        except:
            price = 0 # Fallback jika json error

        # 3. Cek Saldo (Jika BUKAN Admin)
        if str(user_id) != str(ADMIN_ID):
            user_data = get_user_data_complete(str(user_id))
            saldo_user = user_data[2] if user_data else 0
            
            if saldo_user < price:
                return bot.answer_callback_query(
                    call.id, 
                    f"❌ Saldo tidak cukup! Butuh: Rp {price:,}", 
                    show_alert=True
                )

        # 4. Kirim Feedback Awal
        bot.answer_callback_query(call.id, "🚀 Memproses transaksi...")
        msg = bot.send_message(
            call.message.chat.id, 
            "⏳ <b>Sedang menjalankan Auto-Tembak...</b>\nMohon tunggu log keluar...", 
            parse_mode='HTML'
        )

        # 5. Eksekusi Script Jembatan (tembak_otomatis.py)
        script_path = "/root/bot_store/me-cli/tembak_otomatis.py"
        work_dir = "/root/bot_store/me-cli/"
        
        # Command: cd ke folder -> jalankan python script dengan parameter
        command = f"cd {work_dir} && python3 {script_path} {user_id} {pkg_index}"
        
        hasil_byte = subprocess.check_output(
            command, 
            shell=True, 
            stderr=subprocess.STDOUT, 
            executable='/bin/bash'
        )
        
        # 6. Format Output
        output = hasil_byte.decode('utf-8', errors='ignore')
        output = html.escape(output)

        # Potong log jika terlalu panjang (Telegram max 4096 char)
        if len(output) > 3500: 
            output = output[:1000] + "\n... [LOG BAGIAN TENGAH DILEWATI] ...\n" + output[-2000:]

        result_text = (
            f"✅ <b>TRANSAKSI SELESAI</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"<pre>{output}</pre>"
        )
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="menu_hot2"))

        # Edit pesan loading menjadi hasil
        bot.edit_message_text(
            result_text, 
            call.message.chat.id, 
            msg.message_id, 
            parse_mode='HTML', 
            reply_markup=markup
        )

    except subprocess.CalledProcessError as e:
        # Error dari script Python (misal error syntax atau script gagal)
        err_out = e.output.decode('utf-8', errors='ignore') if e.output else str(e)
        if msg:
            bot.edit_message_text(
                f"❌ <b>GAGAL EKSEKUSI</b>\n<pre>{html.escape(err_out)}</pre>", 
                call.message.chat.id, 
                msg.message_id, 
                parse_mode='HTML'
            )
        else:
            bot.send_message(call.message.chat.id, f"❌ Gagal: {html.escape(err_out)}")

    except Exception as e:
        # Error umum (misal codingan bot error)
        if msg:
            bot.edit_message_text(
                f"❌ <b>SYSTEM ERROR:</b> {e}", 
                call.message.chat.id, 
                msg.message_id
            )
        else:
            bot.send_message(call.message.chat.id, f"❌ Error: {e}")


@bot.callback_query_handler(func=lambda call: call.data == "audit_scan_start")
def audit_scan_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")
    
    msg_wait = bot.send_message(call.message.chat.id, "🕵️‍♂️ <b>Sedang Mengaudit Database...</b>\nMohon tunggu...", parse_mode='HTML')
    
    try:
        suspects = get_suspicious_users_list()
        
        bot.delete_message(call.message.chat.id, msg_wait.message_id)
        
        if not suspects:
            return bot.send_message(call.message.chat.id, "✅ <b>DATABASE AMAN!</b>\nTidak ditemukan user dengan saldo mencurigakan.", parse_mode='HTML')
        
        msg = f"🚨 <b>DITEMUKAN {len(suspects)} USER SUSPECT!</b>\n"
        msg += "User ini memiliki Saldo > Total Deposit Valid.\n"
        msg += "─────────────────────────────\n"
        
        markup = InlineKeyboardMarkup()
        for s in suspects:
            info = f"{s['name']} (Hantu: Rp {s['ilegal']:,})"
            markup.add(InlineKeyboardButton(info, callback_data=f"audit_act_{s['id']}"))
            
        markup.add(InlineKeyboardButton("🔙 KEMBALI MENU", callback_data="admin_panel"))
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)

    except Exception as e:
        bot.delete_message(call.message.chat.id, msg_wait.message_id)
        bot.send_message(call.message.chat.id, f"❌ Error System: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith("audit_act_"))
def audit_action_handler(call):
    target_id = call.data.split("_")[2]
    suspects = get_suspicious_users_list()
    target_data = next((item for item in suspects if str(item["id"]) == str(target_id)), None)
    
    if not target_data:
        return bot.answer_callback_query(call.id, "✅ Data bersih / sudah berubah.", show_alert=True)
    
    u = target_data
    msg = f"🕵️ <b>DETAIL AUDIT USER</b>\n"
    msg += f"─────────────────────\n"
    msg += f"👤 Nama: <b>{u['name']}</b>\n"
    msg += f"🆔 ID: <code>{u['id']}</code>\n"
    msg += f"💰 Saldo Skrg: Rp {u['saldo']:,}\n"
    msg += f"✅ Depo Valid: Rp {u['valid']:,}\n"
    msg += f"⚠️ <b>SALDO HANTU: Rp {u['ilegal']:,}</b>\n"
    msg += f"─────────────────────\n"
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton(f"✂️ POTONG Rp {u['ilegal']:,}", callback_data=f"audit_fix_{u['id']}_{u['ilegal']}"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI LIST", callback_data="audit_scan_start"))
    
    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("audit_fix_"))
def audit_fix_execute(call):
    _, _, target_id, amount_str = call.data.split("_")
    amount = int(amount_str)
    
    success = add_balance(target_id, -amount, "KOREKSI AUDIT SYSTEM", ref_id="AUDIT_FIX")
    
    if success:
        bot.answer_callback_query(call.id, "✅ Saldo dipotong!", show_alert=True)
        audit_scan_handler(call) 
    else:
        bot.answer_callback_query(call.id, "❌ Gagal update db.", show_alert=True)

# ==========================================
# 7. VPS SERVICE UTILS
# ==========================================
def get_service_status(service_name):
    try:
        result = subprocess.run(
            ["systemctl", "is-active", service_name], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
        status = result.stdout.strip()
        
        if status == "active" or status == "running":
            return "🟢 Online"
        else:
            return "🔴 Offline"
    except:
        return "🔴 Error"

def get_system_info():
    try:
        os_name = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | tr -d '\"'", shell=True).decode().strip()
    except:
        os_name = "Unknown Linux"

    try:
        ip_vps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        ip_vps = "Unknown IP"

    try:
        if os.path.exists("/etc/xray/domain"):
            with open("/etc/xray/domain", "r") as f:
                domain = f.read().strip()
        else:
            domain = "-"
    except:
        domain = "-"
        
    return os_name, ip_vps, domain

@bot.callback_query_handler(func=lambda call: call.data == "vps_service_detail")
def show_vps_service_detail(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    bot.answer_callback_query(call.id, "🔄 Memeriksa service...")
    bot.send_chat_action(call.message.chat.id, 'typing')

    os_name, ip_vps, domain = get_system_info()

    ssh_stat = get_service_status("ssh")
    dropbear_stat = get_service_status("dropbear")
    haproxy_stat = get_service_status("haproxy")
    xray_stat = get_service_status("xray") 
    nginx_stat = get_service_status("nginx")
    cron_stat = get_service_status("cron")
    fail2ban_stat = get_service_status("fail2ban")
    openvpn_stat = get_service_status("openvpn")
    
    udp1 = get_service_status("udp-mini-1")
    udp2 = get_service_status("udp-mini-2")
    udp3 = get_service_status("udp-mini-3")
    
    ws_stat = get_service_status("ws") 
    udp_custom = get_service_status("udp-custom")

    msg = (
        f"<b>🖥 SYSTEM INFORMATION</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"💻 <b>OS      :</b> <code>{os_name}</code>\n"
        f"🌐 <b>IP      :</b> <code>{ip_vps}</code>\n"
        f"🎯 <b>Domain :</b> <code>{domain}</code>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"<b>⚙️ SERVICE STATUS</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"🟢 <b>SSH / OVPN</b>\n"
        f"├ SSH Service    : {ssh_stat}\n"
        f"├ Dropbear       : {dropbear_stat}\n"
        f"├ OpenVPN        : {openvpn_stat}\n"
        f"└ Haproxy        : {haproxy_stat}\n\n"
        f"🔵 <b>XRAY / TUNNEL</b>\n"
        f"├ Xray Core      : {xray_stat}\n"
        f"├ (Vmess/Vless/Trojan/Shadowsocks)\n"
        f"└ Websocket      : {ws_stat}\n\n"
        f"🟠 <b>UDP & LAINNYA</b>\n"
        f"├ Nginx Web      : {nginx_stat}\n"
        f"├ UDP Custom     : {udp_custom}\n"
        f"├ BadVPN 7100    : {udp1}\n"
        f"├ BadVPN 7200    : {udp2}\n"
        f"├ BadVPN 7300    : {udp3}\n"
        f"├ Crontab        : {cron_stat}\n"
        f"└ Fail2Ban       : {fail2ban_stat}\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    )

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔄 Refresh Status", callback_data="vps_service_detail"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="check_vps_menu"))

    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
# ==========================================
#  HANDLER CEK PROVIDER (WAJIB ADA DI ADMIN.PY)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("cek_provider|"))
def handler_cek_provider_realtime_admin(call):
    # 1. Cek Admin
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        # 2. Parsing Data (Memecah data dari tombol)
        data = call.data.split("|")
        # Format tombol: cek_provider | ref_id | tujuan | kode | user_id
        
        if len(data) < 4:
            return bot.answer_callback_query(call.id, "❌ Data transaksi rusak.")
            
        ref_id = data[1]
        tujuan = data[2]
        kode_produk = data[3]
        target_user_id = data[4] if len(data) > 4 else None
        
        # 3. Beri feedback visual "Loading..."
        bot.answer_callback_query(call.id, "⏳ Menghubungi Server Pusat...")

        # 4. Panggil Service OrderKuota
        try:
            # Import manual di dalam fungsi agar tidak error circular import
            from orderkuota_service import check_orderkuota_status
            
            # Eksekusi Cek Status
            hasil_cek = check_orderkuota_status(
                ref_id=ref_id, 
                nomor_tujuan=tujuan, 
                kode_produk=kode_produk
            )
        except ImportError:
            hasil_cek = "❌ Error: File orderkuota_service.py tidak ditemukan/gagal import."
        except Exception as e:
            hasil_cek = f"❌ Error System: {str(e)}"

        # 5. Auto Update Database jika Sukses
        # Jika respon mengandung kata "SN" dan bukan "Sedang Proses", anggap sukses
        if "SN" in str(hasil_cek) and "Sedang Proses" not in str(hasil_cek):
            try:
                # Ambil SN menggunakan Regex
                import re
                match = re.search(r"SN:?\s*([A-Za-z0-9\/]+)", str(hasil_cek))
                if match:
                    real_sn = match.group(1)
                    # Update status transaksi di database jadi SUKSES
                    update_transaction_status(ref_id, "sukses", real_sn)
            except: pass

        # 6. Tampilkan Hasil
        msg_text = (
            f"📡 <b>HASIL CEK STATUS PROVIDER</b>\n"
            f"➖➖➖➖➖➖➖➖➖➖\n"
            f"🆔 RefID : <code>{ref_id}</code>\n"
            f"📱 Tujuan : <code>{tujuan}</code>\n"
            f"📦 Kode  : {kode_produk}\n\n"
            f"📝 <b>Respon Server Pusat:</b>\n"
            f"<code>{hasil_cek}</code>"
        )

        markup = InlineKeyboardMarkup()
        
        # [MODIFIKASI] Deteksi jika hasil cek "Tidak Ditemukan"
        if "tidak ditemukan" in str(hasil_cek).lower():
             markup.add(InlineKeyboardButton("⚠️ CEK ULANG", callback_data=f"cek_provider|{ref_id}|{tujuan}|{kode_produk}|{target_user_id}"))

        if target_user_id:
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data=f"hist_{target_user_id}_1"))
        else:
            markup.add(InlineKeyboardButton("🔙 TUTUP / KEMBALI", callback_data="admin_panel"))

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error Handler: {str(e)}")
        
# ==========================================
#  HANDLER CEK PROVIDER (SMART CHECK + AUTO REFUND)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("chk|"))
def handler_check_provider_smart(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        parts = call.data.split("|")
        ref_id = parts[1]
        target_id = parts[2]
        
        bot.answer_callback_query(call.id, "⏳ Melacak Transaksi...")
        loading_msg = bot.send_message(call.message.chat.id, "📡 <b>Menghubungi Server Pusat...</b>", parse_mode='HTML')

        # Ambil Data
        history = get_user_transaction_history(target_id)
        trx_found = None
        if history:
            for item in history:
                if str(item[8]) == str(ref_id): 
                    trx_found = item
                    break
        
        if not trx_found:
            try: bot.delete_message(call.message.chat.id, loading_msg.message_id)
            except: pass
            return bot.send_message(call.message.chat.id, "❌ Transaksi tidak ditemukan di database bot.")

        tujuan = trx_found[4] if trx_found[4] not in [None, "None"] else "-"
        deskripsi = trx_found[1]
        status_lama = str(trx_found[3]).lower()
        
        try:
            clean_desc = deskripsi.replace("pembelian", "").replace("Pembelian", "").strip().upper()
            parts_desc = clean_desc.split()
            guess_code = "CEK"
            for p in parts_desc:
                if any(c.isdigit() for c in p) and p.isupper():
                    guess_code = p
                    break
            if guess_code == "CEK" and len(parts_desc) > 1: guess_code = parts_desc[1]
        except: guess_code = "CEK"

        # --- FUNGSI INTERNAL CEK ATLANTIC (SESUAI DOKUMENTASI) ---
        def cek_ke_atlantic(id_transaksi):
            try:
                import requests
                from config import ATLANTIC_API_KEY
                url = "https://atlantich2h.com/transaksi/status"
                
                # SESUAI DOKUMENTASI: Body request menggunakan id dan type prabayar
                payload = {
                    'api_key': ATLANTIC_API_KEY, 
                    'id': id_transaksi, # WAJIB ID dari Atlantic (contoh: xTsTMm...)
                    'type': 'prabayar'
                }
                headers = {'Content-Type': 'application/x-www-form-urlencoded'}
                resp = requests.post(url, data=payload, headers=headers, timeout=10).json()
                
                if str(resp.get('status')).lower() == 'true':
                    data = resp.get('data', {})
                    status_atl = str(data.get('status', '')).lower()
                    sn_atl = data.get('sn', '-')
                    if status_atl in ['success', 'sukses']: return True, f"Sukses SN: {sn_atl}", "sukses"
                    elif status_atl in ['failed', 'gagal']: return True, f"GAGAL: {data.get('message', 'Unknown')}", "gagal"
                    else: return True, f"Status: {status_atl}", "pending"
                
                # JIKA STATUS FALSE
                error_msg = str(resp.get('message', 'Data tidak ditemukan'))
                return False, f"⚠️ API Error: {error_msg}", "error_api"
                
            except Exception as e: return False, f"Error Atl: {str(e)}", "error_api"

        # --- LOGIKA SMART CHECKER ---
        hasil_cek = "Menunggu..."
        provider_used = "UNKNOWN"
        status_asli_provider = "pending"

        if ref_id.startswith("ATL"):
            found, hasil_cek, status_asli_provider = cek_ke_atlantic(ref_id)
            provider_used = "ATLANTIC"
        else:
            try:
                from orderkuota_service import check_orderkuota_status
                hasil_cek = check_orderkuota_status(ref_id, tujuan, guess_code)
                provider_used = "OKECONNECT"
                
                if any(x in str(hasil_cek).lower() for x in ["tidak ada", "tidak ditemukan"]):
                    found_atl, res_atl, status_asli_provider = cek_ke_atlantic(ref_id)
                    if found_atl or status_asli_provider == "error_api": 
                        hasil_cek = f"[ATL] {res_atl}"
                        provider_used = "ATLANTIC (Fallback)"
            except ImportError:
                hasil_cek = "Module OkeConnect Missing"
                status_asli_provider = "error_api"

        try: bot.delete_message(call.message.chat.id, loading_msg.message_id)
        except: pass

        # --- ANALISA HASIL (PENGAMANAN FATAL ERROR) ---
        update_status = None
        update_note = None
        status_icon = "⚠️"

        # 1. JIKA API ERROR / DATA TIDAK DITEMUKAN -> JANGAN SENTUH DATABASE!
        if status_asli_provider == "error_api" or "tidak ditemukan" in str(hasil_cek).lower():
            status_icon = "⚠️"
            update_note = "Cek manual di web Atlantic (ID Bot tidak sama dengan ID Pusat)"
            update_status = None # Mengunci database agar tidak diubah
        
        # 2. JIKA BENAR-BENAR SUKSES
        elif status_asli_provider == "sukses" or ("sukses" in str(hasil_cek).lower() and "gagal" not in str(hasil_cek).lower()):
            update_status = "sukses"
            status_icon = "✅"
            try:
                import re
                match = re.search(r"SN(?:\s*\/|:|=)?\s*([A-Za-z0-9\/\-\.]+)", str(hasil_cek))
                update_note = match.group(1) if match else "Sukses"
            except: update_note = "Sukses Manual"

        # 3. JIKA BENAR-BENAR GAGAL DARI PROVIDER
        elif status_asli_provider == "gagal" or any(x in str(hasil_cek).lower() for x in ["gagal", "stok habis"]):
            update_status = "gagal"
            status_icon = "❌"
            update_note = str(hasil_cek)[:100]

        # --- UPDATE DB & AUTO REFUND ---
        db_report = "⚠️ Database tidak diubah (Aman dari Bug)"
        
        if update_status:
            update_transaction_status(ref_id, update_status, update_note)
            
            if update_status == 'gagal' and status_lama != 'gagal':
                nominal_asli = int(trx_found[2]) 
                refund_amount = abs(nominal_asli) 
                if refund_amount > 0:
                    add_balance(target_id, refund_amount, f"REFUND {ref_id}", ref_id=f"REF-{ref_id}")
                    db_report = f"✅ Status: GAGAL | 💰 <b>REFUND SUKSES: Rp {refund_amount:,}</b>"
            else:
                db_report = f"✅ Database diupdate: <b>{update_status.upper()}</b>"

        msg_text = (
            f"<b>📡 LIVE CHECKER RESULT ({provider_used})</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"<b>📦 INFO TRANSAKSI</b>\n"
            f"├ 🆔 RefID : <code>{ref_id}</code>\n"
            f"├ 🎯 Tujuan: <code>{tujuan}</code>\n"
            f"└ 🏷 Kode  : <code>{guess_code}</code>\n\n"
            f"<b>📝 RESPON SERVER PUSAT</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"{status_icon} <code>{hasil_cek}</code>\n\n"
            f"<b>⚙️ SYSTEM ACTION:</b>\n"
            f"└ {db_report}"
        )

        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data=f"hist_{target_id}_1"))
        bot.send_message(call.message.chat.id, msg_text, parse_mode="HTML", reply_markup=markup)

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error System: {str(e)}")
        

# ==========================================
# 8. SISTEM MENU MULTI-SERVER (INDO & SINGAPORE)
# ==========================================

# 1. Handler Menu Pemilihan Lokasi Server
# Ubah callback menu utama kamu yang mengarah ke VPN agar mengarah ke sini (misal: "menu_vps_select")
@bot.callback_query_handler(func=lambda call: call.data == "menu_vps_select")
def handler_select_server_region(call):
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("🇮🇩 SERVER INDONESIA", callback_data="region_indo"),
        InlineKeyboardButton("🇸🇬 SERVER SINGAPORE", callback_data="region_sg")
    )
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="back_to_main_menu"))
    
    bot.edit_message_text(
        "🌍 <b>PILIH LOKASI SERVER</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Silakan pilih lokasi server yang tersedia untuk performa terbaik Anda:",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

# 2. Handler Jika Memilih INDO (Arahkan ke menu lama kamu)
@bot.callback_query_handler(func=lambda call: call.data == "region_indo")
def handler_region_indo(call):
    # Asumsi: "check_vps_menu" atau "menu_user_vpn" adalah callback menu vps lama kamu
    # Sesuaikan "menu_vpn_default" dengan callback menu SSH/Xray Indo kamu yang sudah ada
    try:
        # Kita panggil fungsi menu user lama atau arahkan callback
        # Jika kamu pakai handler terpisah, trigger callbacknya:
        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("☁️ SSH OVPN", callback_data="buy_ssh"),
            InlineKeyboardButton("🟣 VMess", callback_data="buy_vmess"),
            InlineKeyboardButton("🔵 VLess", callback_data="buy_vless"),
            InlineKeyboardButton("🟠 Trojan", callback_data="buy_trojan")
        )
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="menu_vps_select"))
        
        bot.edit_message_text(
            "🇮🇩 <b>SERVER INDONESIA</b>\nSilakan pilih layanan:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )
    except Exception as e:
        bot.send_message(call.message.chat.id, f"Error Menu Indo: {e}")

# 3. Handler Jika Memilih SINGAPORE (Menu Baru)
@bot.callback_query_handler(func=lambda call: call.data == "region_sg")
def handler_region_sg(call):
    markup = InlineKeyboardMarkup(row_width=2)
    # Perhatikan callback_data saya tambahkan akhiran "_sg"
    markup.add(
        InlineKeyboardButton("☁️ SSH SG", callback_data="buy_ssh_sg"),
        InlineKeyboardButton("🟣 VMess SG", callback_data="buy_vmess_sg"),
        InlineKeyboardButton("🔵 VLess SG", callback_data="buy_vless_sg"),
        InlineKeyboardButton("🟠 Trojan SG", callback_data="buy_trojan_sg")
    )
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="menu_vps_select"))
    
    bot.edit_message_text(
        "🇸🇬 <b>SERVER SINGAPORE</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Koneksi stabil & latency rendah.\n"
        "Silakan pilih layanan:",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

# 4. Handler Transaksi Singapore
# Ini menangkap tombol yang di klik di menu Singapore tadi
@bot.callback_query_handler(func=lambda call: call.data in ["buy_ssh_sg", "buy_vmess_sg", "buy_vless_sg", "buy_trojan_sg"])
def handler_process_buy_sg(call):
    # Ambil jenis layanan dari callback data
    jenis = call.data.replace("buy_", "").replace("_sg", "").upper()
    
    # Disini kamu harus mengintegrasikan dengan script backend kamu
    # Biasanya script backend butuh parameter IP Server Singapore
    
    # CONTOH SEDERHANA (Hanya meneruskan ke logic pembayaran/input)
    # Kamu mungkin perlu mengimport fungsi dari handlers_vps
    # from handlers.handlers_vps import process_vps_purchase
    
    bot.answer_callback_query(call.id, f"🇸🇬 Memilih {jenis} Singapore...")
    
    # Tampilkan menu durasi (Trial/Bulanan) khusus SG
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("⏳ Trial (Gratis)", callback_data=f"deal_sg_trial|{jenis}"),
        InlineKeyboardButton("📅 30 Hari (VIP)", callback_data=f"deal_sg_30|{jenis}")
    )
    markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="region_sg"))
    
    bot.edit_message_text(
        f"🇸🇬 <b>ORDER {jenis} SINGAPORE</b>\n"
        f"Pilih durasi layanan:",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

# 5. Handler Eksekusi Deal Singapore (Trial/Bulanan)
@bot.callback_query_handler(func=lambda call: call.data.startswith("deal_sg_"))
def handler_deal_sg(call):
    try:
        # Format data: deal_sg_trial|SSH atau deal_sg_30|VMESS
        _, mode, jenis = call.data.split("_")[1].split("|")
        jenis = call.data.split("|")[1]
        mode = call.data.split("|")[0].replace("deal_sg_", "") # trial atau 30
        
        user_id = call.from_user.id
        
        # --- DISINI LOGIKA PEMANGGILAN SERVER SINGAPORE ---
        # Karena kamu pakai me-cli, kamu harus punya file .env atau config yang menyimpan IP SG
        # Atau menjalankan script remote SSH ke server SG.
        
        bot.send_message(call.message.chat.id, 
                         f"⚙️ <b>Memproses {jenis} Server Singapore...</b>\n"
                         f"⏳ Durasi: {mode}\n\n"
                         f"<i>(Silakan tambahkan logic koneksi ke IP Server Singapore di bagian ini pada code Python Anda)</i>", 
                         parse_mode='HTML')
        
        # Contoh Logic integrasi (Pseudo-code):
        # if mode == "trial":
        #    subprocess.run(f"ssh root@IP_SG 'menu-trial {jenis} {user_id}'", shell=True)
        # else:
        #    check_saldo_and_process(user_id, price, "SG")
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error SG Handler: {e}")
# Handler untuk tombol "PAKET HOT 1" (Placeholder / Jika mau dibuat juga)
@bot.callback_query_handler(func=lambda call: call.data == "menu_hot1")
def handler_open_hot1(call):
    bot.answer_callback_query(call.id, "⚠️ Fitur Hot 1 sedang dikerjakan...", show_alert=True)
# Pastikan ini ada (biasanya di handler back_to_owner_menu baris 44)
# Jika callback di dor_paket.py adalah "back_to_owner", 
# kita perlu arahkan ke fungsi "admin_panel" atau buat handler khusus:


# ==========================================
# FIX HANDLER LOGIN & LOGOUT (FINAL VERSION)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data in ["auth_login_menu", "auth_req_otp", "auth_logout"])
def handler_auth_combined(call):
    # 1. Cek Admin
    #if str(call.from_user.id) != str(ADMIN_ID): 
    #    return bot.answer_callback_query(call.id, "❌ Akses Ditolak")
    
    try:
        # 2. Handle Login Menu
        if call.data == "auth_login_menu":
            bot.answer_callback_query(call.id, "🔄 Membuka Menu Login...")
            # Kita kirim object message lengkap
            start_login_process(call.message, bot)
            
        # 3. Handle Request OTP (Input Nomor)
        elif call.data == "auth_req_otp":
            handle_login_callbacks(call, bot)

        # 4. Handle Logout (PERBAIKAN DISINI)
        elif call.data == "auth_logout":
            bot.answer_callback_query(call.id, "👋 Logging out...")
            
            # SEBELUMNYA ERROR: logout_process(call.message.chat.id, bot)
            # FIX: Kirim 'call.message' (Object), bukan ID-nya saja
            logout_process(call.message, bot)
            
    except Exception as e:
        print(f"[ERROR AUTH] {e}")
        try:
            # Kirim pesan error ke Telegram biar kita tahu kenapa
            bot.send_message(call.message.chat.id, f"❌ Error Sistem: {e}")
        except: pass

# ==========================================
# HANDLER CEK PAKET SAYA (FIX LOGS & REFRESH)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "check_my_pkg")
def handler_check_my_packages(call):
    # 1. Setup Awal
    from app.service.auth import AuthInstance
    from app.client.engsel import send_api_request
    from datetime import datetime
    
    try:
        telegram_id = str(call.from_user.id)
        BASE_DIR = "/root/bot_store"
        SESSION_DIR = os.path.join(BASE_DIR, "sessions")
        session_file = os.path.join(SESSION_DIR, f"{telegram_id}.txt")
        
        nomor_hp = None
        if os.path.exists(session_file):
            with open(session_file, "r") as f: nomor_hp = f.read().strip()
        
        if not nomor_hp:
            return bot.answer_callback_query(call.id, "⚠️ Silakan Login Terlebih Dahulu!", show_alert=True)

        # [FIX UTAMA] Konversi ke Integer agar terbaca oleh AuthInstance
        try:
            nomor_int = int(nomor_hp)
            if hasattr(AuthInstance, 'set_active_user'):
                AuthInstance.set_active_user(nomor_int)
        except ValueError:
            print(f"[ERROR] Format nomor salah: {nomor_hp}")
            return bot.answer_callback_query(call.id, "❌ Format Nomor Salah", show_alert=True)
            
        # Ambil Token Awal
        tokens = AuthInstance.get_active_tokens() or {}

    except Exception as e:
        print(f"[CheckPkg] Error Auth: {e}")
        return bot.answer_callback_query(call.id, "❌ Error Auth System", show_alert=True)

    # 2. Kirim Loading Message
    loading_msg = bot.send_message(call.message.chat.id, "⏳ <b>Sedang memuat paket...</b>", parse_mode='HTML')

    try:
        # 3. Fungsi Request Internal (Supaya bisa di-retry)
        def fetch_quota_data(api_key, token):
            if not token: return None
            path = "api/v8/packages/quota-details"
            payload = {"is_enterprise": False, "lang": "en", "family_member_id": ""}
            try:
                # Panggil API XL
                res = send_api_request(api_key, path, payload, token, "POST")
                # Cek jika response valid (bukan error bearer)
                if isinstance(res, dict) and "data" in res:
                    return res
                # Cek error spesifik
                if isinstance(res, dict) and res.get("code") == "132":
                    return None
            except: pass
            return None

        api_key = AuthInstance.api_key
        id_token = tokens.get("id_token")

        # Percobaan 1
        res = fetch_quota_data(api_key, id_token)

        # Jika Gagal (Token Expired), Lakukan Refresh & Coba Lagi
        if not res:
            try:
                # Refresh Token
                if AuthInstance.renew_active_user_token():
                    # Ambil token baru dari instance
                    new_tokens = AuthInstance.get_active_tokens()
                    new_id_token = new_tokens.get("id_token")
                    # Percobaan 2
                    res = fetch_quota_data(api_key, new_id_token)
            except Exception as e:
                print(f"[CheckPkg] Refresh Failed: {e}")

        # Hapus loading
        try: bot.delete_message(call.message.chat.id, loading_msg.message_id)
        except: pass

        # Validasi Hasil Akhir
        if not res or res.get("status") != "SUCCESS":
            msg_fail = res.get('message') if res else "Koneksi Gagal / Token Invalid"
            return bot.send_message(call.message.chat.id, f"❌ Gagal mengambil data.\nMsg: {msg_fail}")

        quotas = res["data"].get("quotas", [])
        
        if not quotas:
            return bot.send_message(call.message.chat.id, "📭 <b>Anda tidak memiliki paket aktif.</b>", parse_mode='HTML')

        # 4. Format Hasil (PREMIUM UI)
        msg_result = f"📋 <b>INFO PAKET AKTIF</b>\n"
        msg_result += f"📱 User: <code>{nomor_hp}</code>\n"
        msg_result += f"📦 Total Paket: <b>{len(quotas)}</b>\n"
        msg_result += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"

        for i, quota in enumerate(quotas, 1):
            pkg_name = quota.get("name", "Unknown Package")
            
            # Parsing Masa Aktif
            exp_date_str = "Seumur Hidup"
            raw_exp = quota.get("expired_at")
            if raw_exp:
                try:
                    dt_exp = datetime.fromtimestamp(int(raw_exp))
                    bulan_indo = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
                    exp_date_str = f"{dt_exp.day} {bulan_indo[dt_exp.month - 1]} {dt_exp.year}"
                except: pass
            
            # Parsing Benefits
            benefits = quota.get("benefits", [])
            benefit_text = ""
            
            def fmt_quota(val):
                if val >= 1073741824: return f"{val/1073741824:.2f} GB"
                if val >= 1048576: return f"{val/1048576:.2f} MB"
                return f"{val} B"

            for b in benefits:
                b_name = b.get("name", "Kuota")
                b_type = b.get("data_type", "")
                rem = float(b.get("remaining", 0))
                tot = float(b.get("total", 0))
                
                clean_b_name = b_name.replace(pkg_name, "").strip()
                if not clean_b_name: clean_b_name = "Kuota Utama"

                if b_type == "DATA":
                    benefit_text += f"   ⭐️ <b>{clean_b_name}</b>\n"
                    benefit_text += f"     🔵 Total : {fmt_quota(tot)}\n"
                    benefit_text += f"     ✅ Sisa  : <code>{fmt_quota(rem)}</code>\n"
                elif b_type == "VOICE":
                    benefit_text += f"   📞 <b>{clean_b_name}</b>\n"
                    benefit_text += f"     ✅ Sisa  : {rem/60:.0f} Menit\n"
                elif b_type == "TEXT":
                    benefit_text += f"   📩 <b>{clean_b_name}</b>\n"
                    benefit_text += f"     ✅ Sisa  : {int(rem)} SMS\n"
                
                if len(benefits) > 1 and benefits.index(b) < len(benefits) - 1:
                    benefit_text += "\n"

            msg_result += f"<b>{i}. 🎁 {pkg_name}</b>\n"
            msg_result += f"   📅 Expired: <b>{exp_date_str}</b>\n"
            msg_result += f"   ========================\n"
            
            if benefit_text:
                msg_result += benefit_text
            else:
                msg_result += "   ℹ️ (Hanya Masa Aktif / Unlimited)\n"
            
            msg_result += "─────────────────────\n"

        if len(msg_result) > 4000:
            msg_result = msg_result[:4000] + "\n... (Daftar dipotong)"

        markup_back = InlineKeyboardMarkup()
        markup_back.add(InlineKeyboardButton("🔄 Refresh List", callback_data="check_my_pkg"))
        markup_back.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="run_me_cli"))

        bot.send_message(call.message.chat.id, msg_result, parse_mode='HTML', reply_markup=markup_back)

    except Exception as e:
        try: bot.delete_message(call.message.chat.id, loading_msg.message_id)
        except: pass
        print(f"[CheckPkg] Error: {e}")
        bot.send_message(call.message.chat.id, f"❌ Terjadi kesalahan: {e}")
        
@bot.callback_query_handler(func=lambda call: call.data == "back_to_owner")
def back_owner_bridge(call):
    # Lempar ke fungsi menu admin utama
    back_to_owner_menu(call)
@bot.callback_query_handler(func=lambda call: True)
def default_callback(call):
    handled_prefixes = [
        'ppob_', 'atl_', 'atlbeli', 'atlfix', 'check_atlantic', 'digi_', 'buy_digi',
        'vps_', 'srv_', 'check_vps', 'ssh_', 'vmess_', 'vless_', 'trojan_',
        'folder_indo', 'folder_indo2', 'buy_ssh', 'buy_vmess', 'buy_vless', 'buy_trojan',
        'list_', 'hist_', 'saldo_', 'manual_', 'broadcast', 'deal_',
        'check_user', 'history_by_id', 'reset_session', 
        'add_saldo', 'min_saldo', 'up_reseller', 'down_user', 
        'back_to_detail', 'switch_owner', 'switch_user', 'switch_reseller',
        'admin_panel', 'backup_db', 'audit_', 'manage_saldo', 'owner_wd_menu',
        'wd_', 'cek_profil', 'topup', 'register_reseller', 'history_user',
        'run_me_cli', 'menu_hot2', 'hot2_', 'exec_hot2', 'menu_back_main', 'setting_menu',
        'cek_provider', 'chk' # Added cek_provider and chk here
    ]
    
    if any(call.data.startswith(p) for p in handled_prefixes): 
        return

    bot.answer_callback_query(call.id, "⚠️ Fitur belum tersedia / Maintenance")

if __name__ == "__main__":
    print("Bot Admin Modules Loaded...")
    
# ==========================================
# FITUR DARURAT: SET STATUS MANUAL + AUTO REFUND
# ==========================================
@bot.message_handler(commands=['setstatus'])
def manual_set_status(message):
    # Pastikan hanya Owner/Admin yang bisa pakai
    if str(message.from_user.id) != str(ADMIN_ID): 
        return
        
    parts = message.text.split(" ", 3)
    if len(parts) < 4:
        pesan = (
            "❌ <b>Format Salah!</b>\n\n"
            "Gunakan format:\n<code>/setstatus [RefID] [sukses/gagal] [SN/Keterangan]</code>\n\n"
            "Contoh Gagal:\n<code>/setstatus ATL123 gagal Saldo direfund</code>"
        )
        return bot.reply_to(message, pesan, parse_mode='HTML')
        
    ref_id = parts[1]
    status_baru = parts[2].lower()
    sn_atau_ket = parts[3]
    
    if status_baru not in ['sukses', 'gagal']:
        return bot.reply_to(message, "❌ Status hanya boleh diisi <b>sukses</b> atau <b>gagal</b>.", parse_mode='HTML')
    
    try:
        import sqlite3
        from database import update_transaction_status, get_transaction_status, add_balance
        
        # 1. Cek status saat ini di database
        status_lama = get_transaction_status(ref_id)
        
        # 2. Update status baru ke database
        update_transaction_status(ref_id, status_baru, sn_atau_ket)
        
        refund_msg = ""
        # 3. Lakukan Auto-Refund JIKA diubah ke 'gagal' DAN sebelumnya bukan 'gagal'
        if status_baru == "gagal" and status_lama != "gagal":
            conn = sqlite3.connect("store_data.db")
            c = conn.cursor()
            c.execute("SELECT user_id, amount FROM transactions WHERE ref_id = ?", (ref_id,))
            data_trx = c.fetchone()
            conn.close()
            
            if data_trx:
                uid = data_trx[0]
                amount = abs(int(data_trx[1])) # Pastikan angka positif
                
                if amount > 0:
                    add_balance(uid, amount, f"REFUND MANUAL {ref_id}", ref_id=f"REF-{ref_id}")
                    refund_msg = f"\n\n💰 <b>SALDO Rp {amount:,} TELAH OTOMATIS DI-REFUND KE USER {uid}</b>"
        
        # 4. Tampilkan Pesan Sukses
        icon = "✅" if status_baru == "sukses" else "❌"
        sukses_msg = (
            f"{icon} <b>DATABASE BERHASIL DIUPDATE!</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"🆔 RefID : <code>{ref_id}</code>\n"
            f"📊 Status: <b>{status_baru.upper()}</b>\n"
            f"📝 Ket   : <code>{sn_atau_ket}</code>{refund_msg}"
        )
        
        markup = telebot.types.InlineKeyboardMarkup()
        markup.add(telebot.types.InlineKeyboardButton("🔙 KEMBALI KE PANEL ADMIN", callback_data="admin_panel"))
        
        bot.reply_to(message, sukses_msg, parse_mode='HTML', reply_markup=markup)
        
    except Exception as e:
        bot.reply_to(message, f"❌ Gagal update database: {e}")