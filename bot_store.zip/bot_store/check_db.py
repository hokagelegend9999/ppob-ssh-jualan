import sqlite3

# Lokasi database (sesuaikan jika berbeda)
DB_PATH = "/root/bot_store/store_data.db"

def cek_database():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    print("\n🔍 MENAMPILKAN 15 TRANSAKSI TERAKHIR DARI DATABASE")
    print("="*100)
    # Header Tabel
    print(f"{'TANGGAL':<18} | {'REF ID':<22} | {'HARGA/NOM':<10} | {'SALDO AWAL':<10} | {'SALDO AKHIR':<10} | {'KETERANGAN'}")
    print("-" * 100)
    
    try:
        # Mengambil data penting: Tanggal, Ref ID, Harga, Saldo Awal, Saldo Akhir, Keterangan
        c.execute("""
            SELECT date, ref_id, price, balance_before, balance_after, code 
            FROM transactions 
            ORDER BY date DESC 
            LIMIT 15
        """)
        
        rows = c.fetchall()
        
        if not rows:
            print("⚠️ Belum ada data transaksi sama sekali.")
        
        for row in rows:
            # Ambil data per kolom (gunakan '0' atau '-' jika kosong)
            tgl = str(row[0])[:16] if row[0] else "-"
            ref = str(row[1]) if row[1] else "-"
            price = row[2] if row[2] is not None else 0
            awal = row[3] if row[3] is not None else 0
            akhir = row[4] if row[4] is not None else 0
            desc = str(row[5])[:25] if row[5] else "-" # Potong keterangan biar muat
            
            # Tampilkan baris data
            print(f"{tgl:<18} | {ref:<22} | {price:<10} | {awal:<10} | {akhir:<10} | {desc}")
            
    except Exception as e:
        print(f"❌ Gagal membaca database: {e}")
        print("Kemungkinan kolom 'balance_before' atau 'price' belum ada di transaksi lama.")
        
    print("="*100)
    conn.close()

if __name__ == "__main__":
    cek_database()
