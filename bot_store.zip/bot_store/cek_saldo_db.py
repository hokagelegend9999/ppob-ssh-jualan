import sqlite3

DB_NAME = "/root/bot_store/store_data.db"

def cek_data_mentah():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # ID Transaksi dari screenshot Bapak yang bermasalah (Rp 0)
    target_refs = [
        "ATL17691891666310575986",  # PPOB Atlantic
        "TRX17690638206310575986",  # PPOB OkeConnect
        "ADM-INJ-1769063591",       # Inject Admin
        "SYS-1768910572"            # SSH (Ini pembanding yg datanya ada)
    ]

    print(f"🔍 INSPEKSI DATA SALDO DI DATABASE")
    print("="*100)
    print(f"{'REF ID':<25} | {'DESC':<20} | {'AMOUNT':<10} | {'SALDO AWAL':<12} | {'SALDO AKHIR':<12}")
    print("-" * 100)

    for ref in target_refs:
        try:
            # Kita cek kolom balance_before dan balance_after
            c.execute("""
                SELECT ref_id, description, amount, balance_before, balance_after 
                FROM transactions 
                WHERE ref_id = ?
            """, (ref,))

            row = c.fetchone()

            if row:
                # Tampilkan apa adanya dari database
                b_awal = row['balance_before']
                b_akhir = row['balance_after']
                desc = row['description'][:20]
                amt = row['amount']
                print(f"{ref:<25} | {desc:<20} | {amt:<10} | {b_awal:<12} | {b_akhir:<12}")
            else:
                print(f"{ref:<25} | ❌ TIDAK DITEMUKAN DI DB")
        except Exception as e:
            print(f"Error cek {ref}: {e}")

    conn.close()
    print("="*100)

if __name__ == "__main__":
    cek_data_mentah()
