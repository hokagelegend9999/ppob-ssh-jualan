import sqlite3
import datetime
import time
import re

DB_NAME = "store_data.db"

# ==========================================
#  CORE DATABASE CONNECTION & INIT
# ==========================================
def get_connection():
    return sqlite3.connect(DB_NAME, check_same_thread=False, timeout=10)

def init_db():
    conn = get_connection()
    c = conn.cursor()
    
    # Tables
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (user_id INTEGER PRIMARY KEY, balance INTEGER DEFAULT 0, role TEXT DEFAULT 'user',
                  first_name TEXT, username TEXT, trx_count INTEGER DEFAULT 0, 
                  cycle_date TEXT, uplink INTEGER DEFAULT 0)''') 
    
    c.execute('''CREATE TABLE IF NOT EXISTS transactions 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount INTEGER, 
                  description TEXT, date TEXT, ref_id TEXT DEFAULT '-', destination TEXT DEFAULT '-',
                  status TEXT DEFAULT 'pending', sn TEXT DEFAULT '-', source TEXT DEFAULT 'BOT',
                  saldo_before INTEGER DEFAULT 0, saldo_after INTEGER DEFAULT 0)''') 
    
    c.execute('''CREATE TABLE IF NOT EXISTS vpn_history 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, reseller_id INTEGER, username TEXT, 
                  protocol TEXT, exp_date TEXT, created_at TEXT, 
                  password TEXT DEFAULT '-', domain TEXT DEFAULT '-')''')

    c.execute("PRAGMA journal_mode=WAL;") 
    c.execute("PRAGMA synchronous=NORMAL;")              
    
    # Auto Migration
    cols_users = ["first_name", "username", "trx_count", "cycle_date", "uplink", "last_active"]
    for col in cols_users:
        try: c.execute(f"ALTER TABLE users ADD COLUMN {col} TEXT")
        except: pass
        
    cols_trx = ["ref_id", "destination", "status", "sn", "source", "saldo_before", "saldo_after"]
    for col in cols_trx:
        try: c.execute(f"ALTER TABLE transactions ADD COLUMN {col} TEXT")
        except: pass

    try: c.execute("ALTER TABLE vpn_history ADD COLUMN password TEXT DEFAULT '-'")
    except: pass
    try: c.execute("ALTER TABLE vpn_history ADD COLUMN domain TEXT DEFAULT '-'")
    except: pass

    conn.commit()
    conn.close()

init_db()

# ==========================================
#  CORE: BALANCE MANAGEMENT
# ==========================================
def add_balance(user_id, amount, description="Topup", ref_id=None, destination="-"):
    """
    Fungsi Utama Tambah/Kurang Saldo.
    """
    if amount > 0:
        if not ref_id or ref_id in ["-", "", "None"]:
            print(f"⛔ SECURITY ALERT: Percobaan isi saldo ilegal ke {user_id}. DIBATALKAN.")
            return False 

    conn = get_connection()
    c = conn.cursor()
    
    try:
        # 1. Ambil Saldo Awal
        res = c.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)).fetchone()
        
        if res:
            saldo_before = int(res[0])
            saldo_after = saldo_before + amount
            
            if amount < 0 and saldo_after < 0:
                return False 
            
            c.execute("UPDATE users SET balance=? WHERE user_id=?", (saldo_after, user_id))
        else:
            if amount < 0: return False 
            saldo_before = 0
            saldo_after = amount
            c.execute("INSERT INTO users (user_id, balance, role, trx_count) VALUES (?, ?, 'user', 0)", (user_id, amount))
        
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        final_ref = ref_id if ref_id else f"SYS-{int(time.time())}"
        
        # 2. Simpan Transaksi
        c.execute('''
            INSERT INTO transactions 
            (user_id, amount, description, date, status, source, saldo_before, saldo_after, ref_id, destination) 
            VALUES (?, ?, ?, ?, 'sukses', 'SYSTEM', ?, ?, ?, ?)
        ''', (user_id, amount, description, now, saldo_before, saldo_after, final_ref, destination))
        
        conn.commit()
        return saldo_after 
        
    except Exception as e:
        print(f"❌ Error add_balance: {e}")
        return False
    finally:
        conn.close()

# ==========================================
#  ADMIN & TRANSACTION TOOLS (FIXED)
# ==========================================

# [FIX] Ditambahkan parameter 'dest=None' untuk kompatibilitas dengan handlers_ppob.py
def update_saldo(user_id, amount, description="KOREKSI SALDO", ref_id=None, destination="-", dest=None):
    # Jika handler mengirim pakai 'dest', kita pindahkan ke 'destination'
    if dest is not None:
        destination = dest
        
    if ref_id is None:
        ref_id = f"ADM-{int(time.time())}"
        
    return add_balance(user_id, amount, description, ref_id, destination)

def save_buy_transaction(user_id, amount, description, ref_id, destination, sn='pending', status='sukses'):
    real_amount = -abs(int(amount))
    return add_balance(user_id, real_amount, description, ref_id, destination)

def save_ppob_transaction(user_id, amount, description, ref_id, destination, status='pending'):
    real_amount = -abs(int(amount))
    return add_balance(user_id, real_amount, description, ref_id, destination)

def save_transaction(user_id, ref_id, code, dest, sn, price, status, provider):
    conn = get_connection()
    try:
        c = conn.cursor()
        res = c.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)).fetchone()
        saldo_now = res[0] if res else 0
        saldo_before = saldo_now + int(price)
        
        date_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        c.execute("""
            INSERT INTO transactions (user_id, ref_id, description, destination, sn, amount, status, source, date, saldo_before, saldo_after)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, ref_id, code, dest, sn, -abs(int(price)), status, provider, date_now, saldo_before, saldo_now))
        conn.commit()
    except Exception as e: print(f"Error save_transaction: {e}")
    finally: conn.close()

# ==========================================
#  USER DATA
# ==========================================
def add_user(user_id, first_name, username):
    conn = get_connection()
    c = conn.cursor()
    if c.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,)).fetchone():
        c.execute("UPDATE users SET first_name=?, username=? WHERE user_id=?", (first_name, username, user_id))
    else:
        c.execute("INSERT INTO users (user_id, balance, role, first_name, username) VALUES (?, 0, 'user', ?, ?)", (user_id, first_name, username))
    conn.commit()
    conn.close()

def get_user_data(user_id):
    conn = get_connection()
    res = conn.cursor().execute("SELECT role, balance, trx_count FROM users WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return {"role": res[0], "balance": res[1], "trx": res[2]} if res else None

def get_user_data_complete(user_id):
    conn = get_connection()
    res = conn.cursor().execute("SELECT user_id, username, balance, role, first_name FROM users WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return res

def find_user(query):
    conn = get_connection()
    c = conn.cursor()
    q = str(query).strip().replace("@", "")
    if q.isdigit():
        res = c.execute("SELECT user_id, first_name, balance, role, username FROM users WHERE user_id=?", (q,)).fetchone()
    else:
        res = c.execute("SELECT user_id, first_name, balance, role, username FROM users WHERE username LIKE ?", (f"%{q}%",)).fetchone()
    conn.close()
    return res

def get_all_users_list():
    conn = get_connection()
    data = conn.cursor().execute("SELECT user_id, balance, role, first_name, username, last_active FROM users ORDER BY balance DESC, last_active DESC").fetchall()
    conn.close()
    return data

def get_all_ids():
    conn = get_connection()
    ids = [row[0] for row in conn.cursor().execute("SELECT user_id FROM users").fetchall()]
    conn.close()
    return ids

def set_role(user_id, new_role):
    conn = get_connection()
    conn.cursor().execute("UPDATE users SET role=? WHERE user_id=?", (new_role, user_id))
    conn.commit()
    conn.close()

def update_user_role(user_id, new_role):
    return set_role(user_id, new_role)

def get_users_with_balance():
    conn = get_connection()
    data = conn.cursor().execute("SELECT user_id, first_name, balance, username FROM users WHERE balance > 0 ORDER BY balance DESC").fetchall()
    conn.close()
    return data

# ==========================================
#  TRANSACTION HELPERS
# ==========================================
def update_transaction_status(ref_id, new_status, sn='-'):
    conn = get_connection()
    conn.cursor().execute("UPDATE transactions SET status=?, sn=? WHERE ref_id=?", (new_status, sn, ref_id))
    conn.commit()
    conn.close()

def get_transaction_status(ref_id):
    conn = get_connection()
    res = conn.cursor().execute("SELECT status FROM transactions WHERE ref_id=?", (ref_id,)).fetchone()
    conn.close()
    return res[0] if res else None

def get_trx_amount_by_ref_id(ref_id):
    conn = get_connection()
    res = conn.cursor().execute("SELECT amount FROM transactions WHERE ref_id=?", (ref_id,)).fetchone()
    conn.close()
    return abs(res[0]) if res else 0

def get_all_transactions(limit=10):
    conn = get_connection()
    data = conn.cursor().execute("SELECT date, ref_id, description, sn, destination, amount, source, status FROM transactions ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return data


def get_user_transaction_history(user_id, limit=50):
    """
    Mengambil riwayat transaksi user berdasarkan user_id.
    Urutan SELECT dikunci mati agar 100% sinkron dengan indeks di admin.py
    Telah dilengkapi IFNULL agar data kosong (None) otomatis jadi "-"
    """
    try:
        conn = get_connection()
        c = conn.cursor()
        
        # URUTAN WAJIB UNTUK ADMIN.PY:
        # [0] date
        # [1] description
        # [2] amount
        # [3] status
        # [4] destination (Tujuan PPOB/VPN)
        # [5] sn
        # [6] saldo_before
        # [7] saldo_after
        # [8] ref_id
        
        query = """
            SELECT 
                IFNULL(date, '-'), 
                IFNULL(description, '-'), 
                IFNULL(amount, 0), 
                IFNULL(status, 'pending'), 
                IFNULL(destination, '-'), 
                IFNULL(sn, '-'), 
                IFNULL(saldo_before, 0), 
                IFNULL(saldo_after, 0), 
                IFNULL(ref_id, '-') 
            FROM transactions 
            WHERE user_id = ? 
            ORDER BY id DESC 
            LIMIT ?
        """
        
        c.execute(query, (str(user_id), limit))
        data = c.fetchall()
        conn.close()
        return data
        
    except Exception as e:
        print(f"Error get_user_transaction_history: {e}")
        return []
    


def get_transaction_detail(trx_id):
    conn = get_connection()
    c = conn.cursor()
    
    res = c.execute("""
        SELECT date, description, amount, sn, destination, status 
        FROM transactions 
        WHERE id=?
    """, (trx_id,)).fetchone()
    
    if not res:
        conn.close()
        return None
        
    date_str, desc, amount, sn, dest, status = res
    desc_lower = str(desc).lower()
    
    # --- DETEKSI JENIS TRANSAKSI SECARA KETAT ---
    trx_type = "ppob" 
    if "deposit" in desc_lower or "saldo" in desc_lower:
        trx_type = "deposit"
    elif any(vpn in desc_lower for vpn in ["vless", "vmess", "trojan", "ssh", "udp", "xray"]):
        trx_type = "vpn"

    data = {
        'type': trx_type,
        'product_name': desc,
        'price': abs(int(amount)),
        'date': date_str,
        'status': status.upper(),
        'sn': sn,
        'destination': dest,
        'vpn_username': '-', 'vpn_password': '-', 'vpn_domain': '-', 'vpn_protocol': '-', 'vpn_expired': '-'
    }

    if trx_type == "vpn":
        match = re.search(r'\((.*?)\)', desc)
        if match:
            username_vpn = match.group(1).strip()
            data['vpn_username'] = username_vpn
            
            # FITUR BARU: Hitung otomatis 30 Hari dari tanggal transaksi untuk akun lama
            try:
                # Memotong jam, hanya ambil YYYY-MM-DD
                d_str = date_str.split(" ")[0] 
                created_dt = datetime.datetime.strptime(d_str, "%Y-%m-%d")
                exp_dt = created_dt + datetime.timedelta(days=30)
                data['vpn_expired'] = exp_dt.strftime("%d %b %Y")
            except Exception as e:
                data['vpn_expired'] = "30 Hari (Cek VPS)"

            # Coba cari data asli di vpn_history (Untuk akun yang baru dibuat)
            vpn_res = c.execute("""
                SELECT protocol, exp_date, password, domain, created_at 
                FROM vpn_history WHERE username=? ORDER BY id DESC LIMIT 1
            """, (username_vpn,)).fetchone()
            
            if vpn_res:
                data['vpn_protocol'] = vpn_res[0]
                if vpn_res[1] and vpn_res[1] != '-': data['vpn_expired'] = vpn_res[1]
                data['vpn_password'] = vpn_res[2]
                data['vpn_domain'] = vpn_res[3]
                if vpn_res[4] and vpn_res[4] != '-':
                    data['date'] = vpn_res[4]

    conn.close()
    return data

def check_transaction_exists(ref_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM transactions WHERE ref_id = ?", (ref_id,))
    result = cursor.fetchone()
    conn.close()
    return result is not None

# ==========================================
#  RESELLER SYSTEM
# ==========================================
def add_downline_user(target_id, name, reseller_id):
    conn = get_connection()
    c = conn.cursor()
    try:
        if c.execute("SELECT user_id FROM users WHERE user_id=?", (target_id,)).fetchone():
            return False, "User sudah terdaftar."
        c.execute("INSERT INTO users (user_id, first_name, username, role, balance, uplink) VALUES (?, ?, 'UserBaru', 'user', 0, ?)", 
                  (target_id, name, reseller_id))
        conn.commit()
        return True, "Sukses"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def check_and_downgrade_resellers():
    conn = get_connection()
    c = conn.cursor()
    today = datetime.date.today()
    downgraded = []
    try:
        c.execute("SELECT user_id, trx_count, cycle_date FROM users WHERE role = 'reseller' AND cycle_date IS NOT NULL")
        for r in c.fetchall():
            uid, count, start_date_str = r
            if not start_date_str: continue
            try: start_date = datetime.datetime.strptime(start_date_str, "%Y-%m-%d").date()
            except: continue 
            
            if (today - start_date).days >= 30:
                count = count if count else 0
                if count < 5:
                    c.execute("UPDATE users SET role = 'user', trx_count = 0, cycle_date = NULL WHERE user_id = ?", (uid,))
                    downgraded.append(uid)
                else:
                    new_cycle = today.strftime("%Y-%m-%d")
                    c.execute("UPDATE users SET trx_count = 0, cycle_date = ? WHERE user_id = ?", (new_cycle, uid))
        conn.commit()
    except Exception as e: print(f"Error Check Reseller: {e}")
    finally: conn.close()
    return downgraded

def increment_reseller_trx(user_id):
    conn = get_connection()
    conn.cursor().execute("UPDATE users SET trx_count = trx_count + 1 WHERE user_id = ? AND role = 'reseller'", (user_id,))
    conn.commit()
    conn.close()

def set_reseller_start(user_id):
    conn = get_connection()
    today = datetime.date.today().strftime("%Y-%m-%d")
    conn.cursor().execute("UPDATE users SET cycle_date = ?, trx_count = 0 WHERE user_id = ?", (today, user_id))
    conn.commit()
    conn.close()

def get_resellers_list():
    conn = get_connection()
    data = conn.cursor().execute("SELECT user_id, balance, role, first_name, username, trx_count FROM users WHERE role='reseller' ORDER BY balance DESC").fetchall()
    conn.close()
    return data

def get_reseller_history():
    conn = get_connection()
    query = "SELECT t.date, u.first_name, t.description, t.amount FROM transactions t JOIN users u ON t.user_id = u.user_id WHERE u.role = 'reseller' ORDER BY t.id DESC LIMIT 20"
    data = conn.cursor().execute(query).fetchall()
    conn.close()
    return data

def get_reseller_downline_transactions(reseller_id):
    conn = get_connection()
    query = "SELECT t.date, u.username, t.description, t.amount FROM transactions t JOIN users u ON t.user_id = u.user_id WHERE u.uplink = ? ORDER BY t.date DESC LIMIT 20"
    data = conn.cursor().execute(query, (reseller_id,)).fetchall()
    conn.close()
    return data

# ==========================================
#  AUDIT & ACTIVITY
# ==========================================
def get_suspicious_users_list():
    conn = get_connection()
    c = conn.cursor()
    rich_users = c.execute("SELECT user_id, first_name, balance, username FROM users WHERE balance > 5000").fetchall()
    suspects = []
    for user in rich_users:
        uid, name, cur_bal, uname = user
        res = c.execute("SELECT SUM(amount) FROM transactions WHERE user_id=? AND amount > 0 AND ref_id NOT IN ('-', '', 'None', 'ILLEGAL_NO_ID')", (uid,)).fetchone()
        valid_depo = res[0] if res[0] else 0
        if cur_bal > valid_depo:
            selisih = cur_bal - valid_depo
            if selisih > 2000:
                suspects.append({"id": uid, "name": name, "username": uname, "saldo": cur_bal, "valid": valid_depo, "ilegal": selisih})
    conn.close()
    return suspects

def update_user_activity(user_id):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        if c.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,)).fetchone():
            c.execute("UPDATE users SET last_active = ? WHERE user_id = ?", (now, user_id))
            conn.commit()
    except: pass
    finally: conn.close()

def get_online_icon(user_id):
    conn = get_connection()
    c = conn.cursor()
    try:
        data = c.execute("SELECT last_active FROM users WHERE user_id=?", (user_id,)).fetchone()
        if data and data[0] and data[0] != "None":
            last_time = datetime.datetime.strptime(data[0], "%Y-%m-%d %H:%M:%S")
            diff = (datetime.datetime.now() - last_time).total_seconds()
            if diff < 600: return "🟢" 
        return "🔴" 
    except: return "🔴" 
    finally: conn.close()

# ==========================================
#  VPN HISTORY
# ==========================================
def save_vpn_created(reseller_id, username, protocol, exp_date, password, domain):
    conn = get_connection()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    conn.cursor().execute("INSERT INTO vpn_history (reseller_id, username, protocol, exp_date, password, domain, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)", (reseller_id, username, protocol, exp_date, password, domain, now))
    conn.commit()
    conn.close()

def get_vpn_list_by_reseller(reseller_id):
    conn = get_connection()
    data = conn.cursor().execute("SELECT id, username, protocol, exp_date, password, domain FROM vpn_history WHERE reseller_id=? ORDER BY id DESC LIMIT 20", (reseller_id,)).fetchall()
    conn.close()
    return data

def get_vpn_detail(history_id):
    conn = get_connection()
    data = conn.cursor().execute("SELECT username, protocol, exp_date, password, domain, created_at, reseller_id FROM vpn_history WHERE id=?", (history_id,)).fetchone()
    conn.close()
    return data

def get_reseller_vpn_counts(reseller_id):
    conn = get_connection()
    rows = conn.cursor().execute("SELECT protocol, COUNT(*) FROM vpn_history WHERE reseller_id=? GROUP BY protocol", (reseller_id,)).fetchall()
    conn.close()
    return {row[0].upper(): row[1] for row in rows}

def get_reseller_vpn_counts_split(reseller_id):
    conn = get_connection()
    rows = conn.cursor().execute("SELECT protocol, domain FROM vpn_history WHERE reseller_id=?", (reseller_id,)).fetchall()
    conn.close()
    stats = {"sg": {"SSH":0,"VMESS":0,"VLESS":0,"TROJAN":0}, "indo": {"SSH":0,"VMESS":0,"VLESS":0,"TROJAN":0}}
    for r in rows:
        p, d = r[0].upper(), str(r[1]).lower()
        k = "sg" if "sg." in d or "singapore" in d else "indo"
        if p in stats[k]: stats[k][p] += 1
    return stats

# --- UPDATE DATABASE OTOMATIS ---
def check_and_upgrade_db():
    conn = get_connection()
    c = conn.cursor()
    try:
        c.execute("ALTER TABLE transactions ADD COLUMN saldo_before INTEGER DEFAULT 0")
        c.execute("ALTER TABLE transactions ADD COLUMN saldo_after INTEGER DEFAULT 0")
    except: pass 
    conn.commit()
    conn.close()

check_and_upgrade_db()