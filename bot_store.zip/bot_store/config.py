# config.py

# ==========================================
# 1. KONFIGURASI ADMIN
# ==========================================
# Masukkan semua ID Admin di sini
ADMIN_IDS = [
    1469244768,  # ID Utama Anda
    123456789    # ID Cadangan (Ganti/Hapus jika tidak perlu)
]
ADMIN_ID = 1469244768  # ID Telegram Utama (Digunakan untuk validasi owner)

# ==========================================
# 2. KONFIGURASI BOT TELEGRAM
# ==========================================
BOT_TOKEN = "8220710888:AAEcXqzoJlg4bNSxnXQaI1NjWSCRuiAM9wY"

# ==========================================
# 3. KONFIGURASI SERVER (DOMAIN & IP)
# ==========================================
# Server Indonesia
DOMAIN_HOST_ID = "id.hokagelegend.web.id"

# Server Singapore (Baru)
DOMAIN_HOST_SG = "sg.hokage.web.id" 
# Tips: Jika Anda menggunakan script remote SSH, Anda mungkin perlu menambahkan IP SG disini nanti.

# ==========================================
# 4. KONFIGURASI HARGA (PRICES)
# ==========================================
# Format: "lokasi": {"layanan": {"role": harga}}
# Ini harus cocok dengan yang ada di menus.py
PRICES = {
    # --- HARGA SERVER INDONESIA ---
    "indo": {
        "ssh":  {"user": 13000, "reseller": 10000},
        "xray": {"user": 13000, "reseller": 10000}
    },
    # --- HARGA SERVER SINGAPORE ---
    "sg": {
        "ssh":  {"user": 15000, "reseller": 12000},
        "xray": {"user": 15000, "reseller": 12000}
    }
}

# ==========================================
# 5. KONFIGURASI RESELLER & AUTO UPGRADE
# ==========================================
MIN_TOPUP_AUTO_RESELLER = 50000   # Minimal topup untuk otomatis jadi reseller
BIAYA_DAFTAR_RESELLER = 50000     # Biaya daftar reseller mandiri

# ==========================================
# 6. KONFIGURASI PPOB (ATLANTIC)
# ==========================================
ATLANTIC_API_KEY = "isRvfcVi2uUCGjwpN7OoFUvxDshDroXlrv0gDICCVmzeGimCg6VhUmRFwwaB6cKP6OTdf4z36bbYwGM8LpgtzkJR1LqsK2pzBT30"
# Note: Pastikan IP VPS Anda sudah di-Whitelist di Dashboard Atlantic!
ATLANTIC_TRANSFER_URL = "https://atlantich2h.com/transfer/create"
ATLANTIC_PROFILE_URL = "https://atlantich2h.com/get_profile"
ATLANTIC_PRICE_URL = "https://atlantich2h.com/layanan/price_list"
ATLANTIC_TRX_URL = "https://atlantich2h.com/transaksi/create"
ATLANTIC_DEPOSIT_STATUS_URL = "https://atlantich2h.com/deposit/status"

# ==========================================
# 7. KONFIGURASI PPOB (OKECONNECT)
# ==========================================
OKECONNECT_MEMBER_ID = "OK2528108" 
OKECONNECT_PIN = "2787" 
OKECONNECT_PASSWORD = "Azzam2016!?"
OKECONNECT_TRX_URL = "https://h2h.okeconnect.com/trx"
OKECONNECT_PRICE_URL = "https://okeconnect.com/harga/json?id=905ccd028329b0a"

# ==========================================
# 8. KONFIGURASI PPOB (DIGIFLAZZ)
# ==========================================
DIGI_CONFIG = {
    "username": "nojugeDVJwwD",       
    "api_key": "f3514c00-1de1-5f82-9758-d8c31a0843c4",    
    "webhook_id": "webhook_id_jika_ada",   # Opsional
    "cache_expiry": 3600,                  # Update harga otomatis tiap 1 jam
    "markup": 3000                         # Keuntungan Rp 3.000 per transaksi
}

# ==========================================
# 9. KONFIGURASI EMAIL (SMTP)
# ==========================================
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465  # SSL
SMTP_EMAIL = "hokagelegend9999@gmail.com"
SMTP_PASSWORD = "arvzeijncvzedlgq" # App Password
RECIPIENT_EMAIL = "hokagelegend9999@gmail.com"