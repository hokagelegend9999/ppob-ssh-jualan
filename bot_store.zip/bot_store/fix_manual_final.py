import sqlite3

# Konfigurasi
DB_NAME = "/root/bot_store/store_data.db"
TARGET_REF_ID = "ATL17691891666310575986"
SN_BENAR = "04041700000286869887"

def paksa_update_sn():
    print(f"🔧 Sedang memperbaiki transaksi {TARGET_REF_ID} secara manual...")
    
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    # Update status jadi sukses dan masukkan SN yang benar
    # SAYA SUDAH MENGHAPUS KOLOM 'message' AGAR TIDAK ERROR
    c.execute("""
        UPDATE transactions 
        SET status = 'sukses', 
            sn = ?
        WHERE ref_id = ?
    """, (SN_BENAR, TARGET_REF_ID))
    
    if c.rowcount > 0:
        print(f"✅ BERHASIL! Database telah diupdate.")
        print(f"   • Status: Sukses")
        print(f"   • SN    : {SN_BENAR}")
    else:
        print("❌ Gagal: Ref ID tidak ditemukan di database.")
        
    conn.commit()
    conn.close()

if __name__ == "__main__":
    paksa_update_sn()