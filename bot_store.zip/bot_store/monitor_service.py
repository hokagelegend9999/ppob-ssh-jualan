import paramiko

# ==========================================
# KONFIGURASI SERVER
# ==========================================
SERVER_LIST = {
    "sg": {
        "name": "Singapore Premium",
        "ip": "159.65.15.214",
        "user": "root",
        "pass": "azzam2016", 
        "domain": "sg.hokage.web.id"
    },
    "indo": {
        "name": "Indonesia Private",
        "ip": "103.150.226.10",
        "user": "root",
        "pass": "azzam2016", 
        "domain": "id.hokagelegend.web.id"
    }
}

# Path Database
DB_VMESS = "/etc/vmess/.vmess.db"
DB_VLESS = "/etc/vless/.vless.db"
DB_TROJAN = "/etc/trojan/.trojan.db"

def get_ssh_client(ip, user, password):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(ip, username=user, password=password, timeout=10)
        return client
    except Exception as e:
        print(f"SSH Error {ip}: {e}")
        return None

def get_vps_stats(location):
    client = None
    try:
        target = SERVER_LIST.get(location)
        if not target: return False, "Lokasi tidak valid."

        client = get_ssh_client(target['ip'], target['user'], target['pass'])
        if not client: return False, "Gagal koneksi SSH."

        # === LOGIKA HITUNG DIPERBAIKI ===
        # Kita gunakan 'grep -c ###' untuk SEMUA protokol Xray
        # Karena biasanya file .db menyimpan format: ### user exp ...
        
        cmds = [
            "uptime -p",                                                        # 0. Uptime
            "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l", # 1. SSH (User Asli)
            f"grep -c '###' {DB_VMESS} || echo 0",                              # 2. VMESS
            f"grep -c '###' {DB_VLESS} || echo 0",                              # 3. VLESS (FIXED)
            f"grep -c '###' {DB_TROJAN} || echo 0"                              # 4. TROJAN (FIXED)
        ]
        
        full_cmd = " && ".join(cmds)
        stdin, stdout, stderr = client.exec_command(full_cmd)
        
        output = stdout.read().decode().strip().split("\n")
        client.close()

        if len(output) >= 5:
            stats = {
                "uptime": output[0].replace("up ", ""),
                "ssh": output[1].strip(),
                "vmess": output[2].strip(),
                "vless": output[3].strip(),
                "trojan": output[4].strip(),
                "ip": target['ip'],
                "name": target['name']
            }
            return True, stats
        else:
            return False, "Data tidak lengkap."

    except Exception as e:
        if client: client.close()
        return False, f"Error: {str(e)}"