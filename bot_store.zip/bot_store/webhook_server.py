from flask import Flask, request, jsonify
import logging
from database import add_balance, update_transaction_status, check_transaction_exists
from bot_init import bot # Import bot untuk kirim notifikasi

# Setup Flask
app = Flask(__name__)

# Konfigurasi Logging (Agar kelihatan kalau ada data masuk)
logging.basicConfig(level=logging.INFO)

# ======================================================
#  JALUR PENERIMA WEBHOOK (Sesuai URL di Gambar Anda)
# ======================================================
@app.route('/webhook_server.py', methods=['POST'])
def atlantic_callback():
    try:
        # 1. Terima Data dari Atlantic
        # Atlantic biasanya mengirim data dalam format JSON atau Form Data
        data = request.get_json(silent=True) or request.form
        
        print(f"📩 [WEBHOOK] Data Masuk: {data}")
        
        if not data:
            return jsonify({'status': False, 'msg': 'No Data'}), 400

        # 2. Ambil Variabel Penting (Sesuaikan dengan dokumentasi Atlantic)
        # Biasanya parameter: id/ref_id, status, sn/message
        # Ubah key di bawah ini sesuai format asli Atlantic jika beda
        trx_id = data.get('id') or data.get('ref_id') or data.get('trx_id')
        status = str(data.get('status')).lower()
        sn = data.get('sn') or data.get('message') or "-"
        
        if not trx_id:
             return jsonify({'status': False, 'msg': 'No Trx ID'}), 400

        # 3. Proses Logika
        # Cek status transaksi di database kita dulu
        # (Pastikan Anda punya fungsi get_transaction_data untuk ambil user_id & harga)
        # Sederhananya, kita update status saja.

        if status == 'sukses' or status == 'success':
            # UPDATE DATABASE JADI SUKSES
            print(f"✅ Webhook: Trx {trx_id} SUKSES. SN: {sn}")
            # update_transaction_status(trx_id, 'sukses', sn) 
            # (Pastikan fungsi update_transaction_status Anda mendukung update SN)
            
            # Opsional: Kirim notif ke User
            # bot.send_message(user_id, f"✅ Transaksi {trx_id} Berhasil!\nSN: {sn}")

        elif status == 'gagal' or status == 'failed' or status == 'error':
            print(f"❌ Webhook: Trx {trx_id} GAGAL. Melakukan Refund...")
            
            # CEK DULU: Apakah sudah direfund sebelumnya? (Supaya ga double refund)
            # Anda harus buat fungsi cek status database, misal:
            # current_status = get_trx_status(trx_id)
            # if current_status == 'gagal': return jsonify({'status': True, 'msg': 'Already Refunded'})
            
            # UPDATE DATABASE JADI GAGAL
            # update_transaction_status(trx_id, 'gagal', sn)
            
            # --- AUTO REFUND ---
            # Ambil data transaksi (User ID & Nominal) dari database berdasarkan trx_id
            # user_id, nominal = get_trx_detail(trx_id) 
            
            # Lakukan Refund
            # add_balance(user_id, nominal, f"Refund Otomatis {trx_id}", ref_id=f"REF-{trx_id}")
            
            # Notifikasi User
            # bot.send_message(user_id, f"⚠️ Transaksi {trx_id} GAGAL.\nSaldo telah dikembalikan.")

        return jsonify({'status': True, 'msg': 'Callback Received'})

    except Exception as e:
        print(f"⚠️ Error Webhook: {e}")
        return jsonify({'status': False, 'msg': 'Error System'}), 500

if __name__ == '__main__':
    # Jalankan Server di Port 8070 (Sesuai Gambar)
    print("🚀 Webhook Server Atlantic Berjalan di Port 8070...")
    # host='0.0.0.0' agar bisa diakses dari luar VPS
    app.run(host='0.0.0.0', port=9090)
