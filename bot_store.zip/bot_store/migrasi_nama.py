import sqlite3
import re

DB_NAME = "/root/bot_store/store_data.db"

def migrate_username_to_destination():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    print("🚀 MEMULAI MIGRASI DATABASE...")
    print("="*50)
    
    # 1. Ambil semua transaksi VPN/SSH yang punya tanda kurung di deskripsi
    #    dan kolom destination-nya masih kosong/strip
    query = """
        SELECT id, description, destination 
        FROM transactions 
        WHERE (description LIKE '%(%)%') 
        AND (destination = '-' OR destination = '0' OR destination IS NULL)
    """
    
    c.execute(query)
    rows = c.fetchall()
    
    count = 0
    for row in rows:
        trx_id = row['id']
        old_desc = row['description']
        
        # 2. Ekstrak Username menggunakan Regex
        match = re.search(r'\((.*?)\)', old_desc)
        
        if match:
            username = match.group(1) # Ambil teks dalam kurung (misal: carik)
            
            # 3. Bersihkan Deskripsi
            # Hapus (username) dan kata "Manual"
            new_desc = old_desc.replace(f"({username})", "").replace("Manual", "").strip()
            
            # Jika deskripsi jadi kosong, beri default
            if not new_desc: new_desc = "SSH/VPN SERVER"
            
            # 4. Update Database
            # Pindahkan username ke kolom 'destination'
            try:
                c.execute("""
                    UPDATE transactions 
                    SET description = ?, 
                        destination = ? 
                    WHERE id = ?
                """, (new_desc, username, trx_id))
                
                print(f"✅ ID {trx_id}: '{old_desc}' -> Desc: '{new_desc}' | Dest: '{username}'")
                count += 1
            except Exception as e:
                print(f"❌ Gagal Update ID {trx_id}: {e}")
    
    conn.commit()
    conn.close()
    print("="*50)
    print(f"🎉 SELESAI! {count} transaksi berhasil diperbaiki.")

if __name__ == "__main__":
    migrate_username_to_destination()
