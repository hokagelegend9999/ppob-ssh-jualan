#!/usr/bin/env python3
import sys
import os

# Tambahkan path folder saat ini agar module terbaca
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# --- INISIALISASI VARIABEL DULU (PENTING) ---
# Kita set 'None' dulu supaya tidak kena NameError jika file tidak ada
ssh_lib = None
vmess_lib = None
vless_lib = None
trojan_lib = None
service_lib = None

# --- IMPORT MODULE DENGAN AMAN ---
try:
    import service_lib
except ImportError as e:
    # Print error hanya jika kita sedang debugging manual, tapi jangan stop script
    # sys.stderr.write(f"Warning: service_lib not found: {e}\n")
    pass

try:
    import ssh_lib
except ImportError:
    pass

try:
    import vmess_lib
except ImportError:
    pass

try:
    import vless_lib
except ImportError:
    pass

try:
    import trojan_lib
except ImportError:
    pass

def main():
    if len(sys.argv) < 3:
        print("ERROR|Invalid Arguments")
        return

    protocol = sys.argv[1]
    command = sys.argv[2]

    try:
        # === SYSTEM CHECK ===
        if protocol == "system":
            if command == "check_service":
                if service_lib:
                    print(service_lib.check_service())
                else:
                    print("ERROR|File service_lib.py tidak ditemukan atau error")

        # === SSH ===
        elif protocol == "ssh":
            if command == "create" and ssh_lib:
                print(ssh_lib.create(sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]))
            elif command == "delete" and ssh_lib:
                print(ssh_lib.delete(sys.argv[3]))
            else:
                print("ERROR|Module SSH tidak dimuat")

        # === VMESS ===
        elif protocol == "vmess":
            if command == "create" and vmess_lib:
                print(vmess_lib.create(sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]))
            elif command == "delete" and vmess_lib:
                print(vmess_lib.delete(sys.argv[3]))
            else:
                print("ERROR|Module Vmess tidak dimuat")

        # === VLESS ===
        elif protocol == "vless":
            if command == "create" and vless_lib:
                print(vless_lib.create(sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]))
            elif command == "delete" and vless_lib:
                print(vless_lib.delete(sys.argv[3]))
            else:
                print("ERROR|Module Vless tidak dimuat")

        # === TROJAN ===
        elif protocol == "trojan":
            if command == "create" and trojan_lib:
                print(trojan_lib.create(sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]))
            elif command == "delete" and trojan_lib:
                print(trojan_lib.delete(sys.argv[3]))
            else:
                print("ERROR|Module Trojan tidak dimuat")

    except Exception as e:
        print(f"ERROR|Bridge Error: {str(e)}")

if __name__ == "__main__":
    main()