import subprocess
import os

def is_running(service_name):
    """Cek status service active/inactive mentah"""
    try:
        result = subprocess.run(
            ["systemctl", "is-active", service_name], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE,
            text=True,
            timeout=5
        )
        return "ON" if result.stdout.strip() == "active" else "OFF"
    except Exception:
        return "OFF"

def check_service():
    """Fungsi utama status VPS tanpa BadVPN & Fail2Ban"""
    try:
        # 1. Info System Dasar
        os_name = subprocess.getoutput("grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"'")
        ip_vps = subprocess.getoutput("hostname -I | awk '{print $1}'")
        
        # 2. Ambil Domain
        domain = "-"
        if os.path.exists("/etc/xray/domain"):
            with open("/etc/xray/domain", "r") as f:
                domain = f.read().strip()

        # 3. Kumpulkan Status Service (Urutan Baru)
        services = [
            is_running("ssh"),          # d[3]
            is_running("dropbear"),     # d[4]
            is_running("openvpn"),      # d[5]
            is_running("haproxy"),      # d[6]
            is_running("xray"),         # d[7]
            is_running("nginx"),        # d[8]
            is_running("zivpn"),        # d[9]  <-- GANTI DISINI
            is_running("udp-custom"),   # d[10]
            is_running("cron"),         # d[11]
        ]

        data = [str(os_name), str(ip_vps), str(domain)] + services
        return "|".join(data)

    except Exception as e:
        return f"ERROR|{str(e)}"