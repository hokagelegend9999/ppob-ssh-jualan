import subprocess
import datetime as DT
import os
import json

# ==========================================
# 1. HELPER: SINKRONISASI ZIVPN
# ==========================================
def sync_to_zivpn(username, exp_date, limit):
    """
    Menambahkan user baru ke config.json dan user-db.json milik ZIVPN
    """
    config_path = "/etc/zivpn/config.json"
    db_path = "/etc/zivpn/user-db.json"
    
    try:
        # A. UPDATE CONFIG.JSON (AUTH LIST)
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                try: config_data = json.load(f)
                except: config_data = {"auth": {"config": []}}
            
            if "auth" not in config_data: config_data["auth"] = {}
            if "config" not in config_data["auth"]: config_data["auth"]["config"] = []
            
            # Tambah user jika belum ada
            if username not in config_data["auth"]["config"]:
                config_data["auth"]["config"].append(username)
                with open(config_path, 'w') as f:
                    json.dump(config_data, f, indent=2)

        # B. UPDATE USER-DB.JSON (DETAIL EXP & LIMIT)
        db_data = {}
        if os.path.exists(db_path):
            with open(db_path, 'r') as f:
                try: db_data = json.load(f)
                except: db_data = {} 
        
        # Format data ZIVPN
        db_data[username] = {
            "exp": exp_date,
            "ip": int(limit),
            "quota": 0 
        }
        
        with open(db_path, 'w') as f:
            json.dump(db_data, f, indent=2)
        
        # C. RESTART SERVICE ZIVPN
        subprocess.run("systemctl restart zivpn", shell=True)
        return True
        
    except Exception as e:
        # Kita print error log di VPS tapi jangan stop proses utama
        print(f"ERROR ZIVPN: {e}")
        return False

# ==========================================
# 2. LOGIKA CREATE SSH
# ==========================================
def create(user, pw, exp, limit):
    try:
        # Cek user exist
        try:
            subprocess.check_output(f"id {user}", shell=True, stderr=subprocess.DEVNULL)
            return "ERROR|User already exists"
        except:
            pass 

        # Hitung tanggal expired (YYYY-MM-DD) untuk Linux & ZIVPN
        cmd_date = f'date -d "{exp} days" +"%Y-%m-%d"'
        exp_date = subprocess.check_output(cmd_date, shell=True).decode().strip()

        # Hitung tanggal untuk Database Script Member (Format: 03 Jan, 2026)
        # Ini penting agar menu member terlihat rapi
        expiry_obj = DT.date.today() + DT.timedelta(days=int(exp))
        exp_str_db = expiry_obj.strftime("%d %b, %Y")

        # 1. Buat User Linux
        cmd = f'useradd -e {exp_date} -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd'
        subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)

        # 2. Set Limit SSH (Limits.conf)
        cmd_limit = f'echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
        subprocess.run(cmd_limit, shell=True)

        # 3. SYNC KE ZIVPN (PENTING!)
        sync_to_zivpn(user, exp_date, limit)
        
        # 4. SIMPAN KE DATABASE MEMBER (.ssh.db) [BAGIAN BARU]
        # Format: #ssh# username password quota limit exp
        db_entry = f"#ssh# {user} {pw} 0 {limit} {exp_str_db}"
        
        # Hapus data lama jika ada (untuk menghindari duplikat)
        subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)
        # Masukkan data baru
        subprocess.run(f"echo '{db_entry}' >> /etc/ssh/.ssh.db", shell=True)
        
        return f"SUCCESS|ssh|{user}|{pw}|{exp_date}"
        
    except subprocess.CalledProcessError as e:
        return f"ERROR|Gagal Create: {str(e)}"
    except Exception as e:
        return f"ERROR|System: {str(e)}"

# ==========================================
# 3. LOGIKA DELETE SSH
# ==========================================
def delete(user):
    try:
        # 1. Hapus dari Linux
        subprocess.run(f"pkill -u {user}", shell=True)
        subprocess.run(f"userdel -f -r {user}", shell=True)
        subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
        
        # 2. Hapus dari Database Member [BAGIAN BARU]
        subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)
        
        # 3. Hapus dari ZIVPN Config
        config_path = "/etc/zivpn/config.json"
        db_path = "/etc/zivpn/user-db.json"
        
        # Hapus dari config.json
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                data = json.load(f)
            if user in data.get("auth", {}).get("config", []):
                data["auth"]["config"].remove(user)
                with open(config_path, 'w') as f:
                    json.dump(data, f, indent=2)

        # Hapus dari user-db.json
        if os.path.exists(db_path):
            with open(db_path, 'r') as f:
                db = json.load(f)
            if user in db:
                del db[user]
                with open(db_path, 'w') as f:
                    json.dump(db, f, indent=2)
        
        # Restart ZIVPN
        subprocess.run("systemctl restart zivpn", shell=True)

        return "SUCCESS|Deleted"
    except Exception as e:
        return f"ERROR|{str(e)}"