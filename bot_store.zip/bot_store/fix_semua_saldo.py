import sqlite3

DB_NAME = "/root/bot_store/store_data.db"

def perbaiki_saldo_otomatis():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    print("🚀 MEMULAI PERBAIKAN SALDO OTOMATIS (METODE MUNDUR)...")
    print("="*60)

    # 1. Ambil Semua User
    users = c.execute("SELECT user_id, username, balance FROM users").fetchall()
    
    total_fixed = 0
    
    for u in users:
        uid = u['user_id']
        # Handle jika username None
        uname = u['username'] if u['username'] else f"ID_{uid}"
        
        # Handle jika balance None, set ke 0
        current_balance = u['balance'] if u['balance'] is not None else 0
        
        # 2. Ambil Transaksi User ini (Urut dari TERBARU ke TERLAMA)
        trx_list = c.execute("""
            SELECT id, amount, balance_before, balance_after 
            FROM transactions 
            WHERE user_id = ? 
            ORDER BY id DESC
        """, (uid,)).fetchall()
        
        if not trx_list:
            continue
            
        print(f"👤 Memproses User: {uname} (Saldo Skrg: {current_balance})")
        
        # Pointer saldo berjalan
        running_balance = int(current_balance)
        
        for t in trx_list:
            t_id = t['id']
            
            # [FIX] HANDLE AMOUNT NULL/NONE
            raw_amount = t['amount']
            if raw_amount is None:
                amount = 0
            else:
                amount = int(raw_amount)
            
            # Hitung Mundur
            saldo_sesudah = running_balance
            saldo_sebelum = running_balance - amount 
            
            # Update Database
            try:
                c.execute("""
                    UPDATE transactions 
                    SET balance_after = ?, 
                        balance_before = ? 
                    WHERE id = ?
                """, (saldo_sesudah, saldo_sebelum, t_id))
                
                # Set saldo berjalan untuk transaksi berikutnya (yang lebih lampau)
                running_balance = saldo_sebelum
                total_fixed += 1
            except Exception as e:
                print(f"   ❌ Gagal update ID {t_id}: {e}")
            
    conn.commit()
    conn.close()
    print("="*60)
    print(f"✅ SELESAI! {total_fixed} riwayat transaksi telah diperbaiki.")
    print("Silakan cek bot Anda sekarang.")

if __name__ == "__main__":
    perbaiki_saldo_otomatis()