import sqlite3

DB_NAME = "/root/bot_store/store_data.db"

def clean_stuck_transactions():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    print("🧹 Membersihkan transaksi 'pending' yang nyangkut...")
    
    # Ubah status 'pending'/'proses' menjadi 'gagal' jika ID-nya bukan transaksi hari ini
    # (Asumsi transaksi lama yang bikin error)
    
    # Query: Set Gagal semua transaksi pending yang Ref ID-nya dimulai dengan ATL 
    # Hati-hati: Ini akan membatalkan transaksi Atlantic yang pending saat ini.
    # Gunakan hanya jika yakin transaksi tersebut memang nyangkut.
    
    c.execute("UPDATE transactions SET status='gagal', sn='Expired/Dibatalkan Admin' WHERE status IN ('pending', 'proses') AND ref_id LIKE 'ATL%'")
    
    rows = c.rowcount
    conn.commit()
    conn.close()
    
    print(f"✅ Berhasil membatalkan {rows} transaksi Atlantic yang nyangkut.")
    print("Bot tidak akan mengeceknya lagi, sehingga error log akan hilang.")

if __name__ == "__main__":
    clean_stuck_transactions()
