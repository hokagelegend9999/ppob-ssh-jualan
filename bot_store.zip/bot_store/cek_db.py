import sqlite3
import os

# Nama file database (sesuaikan jika nama file Anda beda, misal: bot_database.db)
DB_NAME = 'database.db' 

def cek_database():
    if not os.path.exists(DB_NAME):
        print(f"❌ File database '{DB_NAME}' tidak ditemukan!")
        return

    print(f"📂 MEMBUKA DATABASE: {DB_NAME}")
    print("="*50)

    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()

        # 1. Cek Daftar Tabel
        c.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = c.fetchall()
        print(f"📋 Tabel yang ditemukan: {[t[0] for t in tables]}")
        
        # 2. Cek Struktur & Isi Tabel 'transactions'
        if ('transactions',) in tables:
            print("\n🔍 MENGECEK TABEL 'transactions' (10 Terakhir):")
            print("-" * 50)
            
            # Ambil info kolom
            c.execute("PRAGMA table_info(transactions)")
            columns = c.fetchall()
            col_names = [col[1] for col in columns]
            print(f"📝 Kolom: {col_names}")
            print("-" * 50)

            # Ambil data
            c.execute("SELECT * FROM transactions ORDER BY date DESC LIMIT 10")
            rows = c.fetchall()

            if not rows:
                print("⚠️  TABEL KOSONG! Belum ada riwayat transaksi.")
            else:
                for i, row in enumerate(rows, 1):
                    print(f"Data #{i}: {row}")
        else:
            print("❌ Tabel 'transactions' tidak ditemukan!")

        conn.close()

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    cek_database()
