import sqlite3

DB_NAME = "/root/bot_store/store_data.db"

def cek_trx_terakhir():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    print("\n🔍 MENGAMBIL 3 TRANSAKSI TERAKHIR...")
    print("="*80)
    
    # Ambil semua kolom untuk melihat mana yang aneh
    c.execute("SELECT * FROM transactions ORDER BY id DESC LIMIT 3")
    rows = c.fetchall()
    
    # Ambil nama kolom
    names = [description[0] for description in c.description]
    
    for row in rows:
        print(f"🆔 ID Database: {row[0]}")
        for i, col_name in enumerate(names):
            val = row[i]
            # Tampilkan kolom dan isinya
            print(f"   • {col_name:<15} : {val}")
        print("-" * 80)

    conn.close()

if __name__ == "__main__":
    cek_trx_terakhir()
