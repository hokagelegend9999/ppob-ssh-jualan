import requests
import hashlib
import json
from digi.digiflazz import get_digi_price_list, get_categories, get_brands_by_category, get_products_by_brand
# KONFIGURASI DIGIFLAZZ
DIGI_USERNAME = "username_kamu"
DIGI_API_KEY = "api_key_produksi_kamu"

def get_digi_price_list(cmd="prepaid"):
    """Mengambil daftar harga dari Digiflazz"""
    # Formula Sign: md5(username + apiKey + "pricelist")
    sign_str = f"{DIGI_USERNAME}{DIGI_API_KEY}pricelist"
    signature = hashlib.md5(sign_str.encode()).hexdigest()

    payload = {
        "cmd": cmd,
        "username": DIGI_USERNAME,
        "sign": signature
    }

    try:
        response = requests.post("https://api.digiflazz.com/v1/price-list", json=payload)
        data = response.json()
        
        if "data" in data:
            return data["data"]
        return []
    except Exception as e:
        print(f"Error Digiflazz: {e}")
        return []

def get_categories(data):
    """Mengambil list kategori unik (Pulsa, Data, dll)"""
    return sorted(list(set(item['category'] for item in data)))

def get_brands_by_category(data, category):
    """Mengambil list brand unik berdasarkan kategori (Telkomsel, XL, dll)"""
    return sorted(list(set(item['brand'] for item in data if item['category'] == category)))

def get_products_by_brand(data, category, brand):
    """Mengambil produk berdasarkan kategori dan brand"""
    products = [item for item in data if item['category'] == category and item['brand'] == brand]
    # Urutkan berdasarkan harga termurah
    return sorted(products, key=lambda x: x['price'])