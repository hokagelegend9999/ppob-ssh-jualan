import requests
import hashlib
import json
import os
import time
from config import DIGI_CONFIG

CACHE_FILE = "digi/price_cache.json"

# ==========================================
# 1. LOGIKA DATA PRODUK (CACHE & API)
# ==========================================

def get_digi_data():
    """Mengambil data harga (Cek Cache dulu, baru API)"""
    username = DIGI_CONFIG["username"]
    api_key = DIGI_CONFIG["api_key"]
    expiry = DIGI_CONFIG["cache_expiry"]

    # 1. Cek Cache Lokal
    if os.path.exists(CACHE_FILE):
        file_age = time.time() - os.path.getmtime(CACHE_FILE)
        if file_age < expiry:
            try:
                with open(CACHE_FILE, "r") as f:
                    cached = json.load(f)
                    if isinstance(cached, list):
                        return cached
                    elif isinstance(cached, dict) and "data" in cached:
                        return cached["data"]
            except:
                pass 

    # 2. Tembak API Digiflazz (Jika cache expired/kosong)
    sign_str = f"{username}{api_key}pricelist"
    signature = hashlib.md5(sign_str.encode()).hexdigest()

    payload = {
        "cmd": "prepaid",
        "username": username,
        "sign": signature
    }

    try:
        response = requests.post("https://api.digiflazz.com/v1/price-list", json=payload, timeout=20)
        result = response.json()

        if "data" in result and isinstance(result["data"], list):
            # Simpan ke Cache
            with open(CACHE_FILE, "w") as f:
                json.dump(result["data"], f)
            return result["data"]
        else:
            return []
            
    except Exception as e:
        print(f"❌ Error Koneksi Digiflazz: {e}")
        return []

# ==========================================
# 2. HELPER FUNCTIONS (FILTER & MARKUP)
# ==========================================

def get_categories():
    data = get_digi_data()
    if not data or not isinstance(data, list): return []
    cats = set()
    for item in data:
        if isinstance(item, dict) and 'category' in item:
            cats.add(item['category'])
    return sorted(list(cats))

def get_brands(category):
    data = get_digi_data()
    if not data or not isinstance(data, list): return []
    brands = set()
    for item in data:
        if isinstance(item, dict) and item.get('category') == category:
            brands.add(item['brand'])
    return sorted(list(brands))

def get_products(category, brand):
    data = get_digi_data()
    if not data or not isinstance(data, list): return []
    
    # Ambil Markup dari Config
    markup = DIGI_CONFIG.get("markup", 0) 
    
    filtered = []
    for item in data:
        if not isinstance(item, dict): continue
        try:
            if (item.get('category') == category and 
                item.get('brand') == brand and 
                item.get('buyer_product_status') and 
                item.get('seller_product_status')):
                
                # Cek stok
                if item.get('unlimited_stock') or item.get('stock', 0) > 0:
                    # LOGIKA MARKUP
                    item_jual = item.copy()
                    item_jual['price'] = item['price'] + markup
                    filtered.append(item_jual)
        except:
            continue

    return sorted(filtered, key=lambda x: x['price'])

# ==========================================
# 3. TRANSAKSI PRABAYAR (PULSA, DATA, DLL)
# ==========================================

def transaksi_prabayar(buyer_sku_code, customer_no, ref_id):
    """Melakukan Transaksi Prabayar"""
    username = DIGI_CONFIG["username"]
    api_key = DIGI_CONFIG["api_key"]
    
    # Sign Transaksi: md5(username + apiKey + ref_id)
    sign_str = f"{username}{api_key}{ref_id}"
    signature = hashlib.md5(sign_str.encode()).hexdigest()
    
    payload = {
        "username": username,
        "buyer_sku_code": buyer_sku_code,
        "customer_no": customer_no,
        "ref_id": ref_id,
        "sign": signature
    }
    
    print(f"🔄 [DEBUG] Request Transaksi: {buyer_sku_code} -> {customer_no}")
    
    try:
        response = requests.post("https://api.digiflazz.com/v1/transaction", json=payload, timeout=60)
        result = response.json()
        
        if "data" in result:
            return result["data"]
        else:
            return result 
    except Exception as e:
        print(f"❌ Error Transaksi: {e}")
        return None