import sqlite3

# PASTIKAN PATH INI BENAR
DB_NAME = "/root/bot_store/store_data.db"

def fix_database():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    print("🔄 Memulai perbaikan struktur database...")

    # Daftar kolom baru yang harus ditambahkan
    new_columns = [
        ("code", "TEXT DEFAULT '-'"),
        ("dest", "TEXT DEFAULT '-'"),
        ("sn", "TEXT DEFAULT '-'"),
        ("provider", "TEXT DEFAULT 'SYSTEM'"),
        ("price", "INTEGER DEFAULT 0")  # <--- INI YANG TADI KURANG
    ]

    for col_name, col_type in new_columns:
        try:
            # Coba tambahkan kolom
            c.execute(f"ALTER TABLE transactions ADD COLUMN {col_name} {col_type}")
            print(f"✅ Berhasil menambahkan kolom: {col_name}")
        except sqlite3.OperationalError as e:
            # Error ini muncul jika kolom sudah ada (abaikan saja)
            if "duplicate column" in str(e).lower():
                print(f"ℹ️ Kolom {col_name} sudah ada.")
            else:
                print(f"❌ Gagal {col_name}: {e}")

    conn.commit()
    conn.close()
    print("🎉 Perbaikan Selesai! Silakan restart bot.")

if __name__ == "__main__":
    fix_database()