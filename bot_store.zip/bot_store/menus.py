import sys
import os
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# ==========================================
# 1. KONFIGURASI PATH (WAJIB DI PALING ATAS)
# ==========================================
# Tambahkan folder me-cli agar module 'app' terbaca
sys.path.append('/root/bot_store/me-cli')
# ==========================================

# --- BARU LAKUKAN IMPORT CUSTOM SETELAH PATH DITAMBAHKAN ---
try:
    from app.menus.dor_paket import menu_dor_non_legal
except ImportError as e:
    print(f"⚠️ Gagal import menu dor_paket: {e}")
    def menu_dor_non_legal(): return InlineKeyboardMarkup()
except Exception as e:
    print(f"⚠️ Error lain import dor_paket: {e}")
    def menu_dor_non_legal(): return InlineKeyboardMarkup()

# --- IMPORT LOGIC DIGIFLAZZ ---
try:
    from digi.digiflazz_logic import get_categories, get_brands, get_products
except ImportError:
    print("⚠️ Warning: Modul digi.digiflazz_logic tidak ditemukan!")

# ==========================================
# 2. KONFIGURASI HARGA
# ==========================================
PRICES = {
    "indo2": {
        "ssh":  {"user": 13000, "reseller": 10000},  
        "xray": {"user": 13000, "reseller": 10000}    
    },
    "indo": {
        "ssh":  {"user": 13000, "reseller": 10000}, 
        "xray": {"user": 13000, "reseller": 10000}  
    },
    # --- [BARU] HARGA SERVER SINGAPORE ---
    "sg": {
        "ssh":  {"user": 15000, "reseller": 12000}, 
        "xray": {"user": 15000, "reseller": 12000}  
    }
}

def fmt_price(price):
    return f"{int(price/1000)}k"

# ==========================================
# 3. MENU OWNER
# ==========================================
def menu_admin(user_id):
    markup = InlineKeyboardMarkup(row_width=2)
    
    # --- SHORTCUT DOR PAKET UNTUK OWNER ---
    markup.add(InlineKeyboardButton("🚀 DOR PAKET NON LEGAL (CLI) 🚀", callback_data="run_me_cli"))
    # ---------------------------------------------

    markup.add(
        InlineKeyboardButton("👑 PANEL UTAMA", callback_data="admin_panel"),
        InlineKeyboardButton("💰 SALDO", callback_data="manage_saldo")
    ) 
    markup.add(
        InlineKeyboardButton("💸 TRANSFER / WD", callback_data="owner_wd_menu"),
        InlineKeyboardButton("📂 BACKUP DATABASE", callback_data="backup_db")
    )
    markup.add(
        InlineKeyboardButton("👥 List Member", callback_data="list_member|1"),
        InlineKeyboardButton("🆔 CEK USER (DETAIL)", callback_data="check_user_by_id_menu")
    )
    markup.add(InlineKeyboardButton("🔎 Cek Riwayat User", callback_data="check_user_history"))
    markup.add(InlineKeyboardButton("🕵️ AUDIT SALDO ILEGAL", callback_data="audit_scan_start"))
    markup.add(InlineKeyboardButton("🔍 CEK USER VPS", callback_data="check_vps_menu"))
    markup.add(InlineKeyboardButton("💼 List Reseller", callback_data="list_reseller|1"))
    markup.add(InlineKeyboardButton("📢 BROADCAST PESAN", callback_data="broadcast_all"))
    markup.add(
        InlineKeyboardButton("➕ Angkat Reseller", callback_data="manual_add_reseller"),
        InlineKeyboardButton("⚙️ SETTING SERVER", callback_data="setting_menu")
    )
    markup.add(
        InlineKeyboardButton("👁️ Lihat sbg RESELLER", callback_data="switch_reseller"),
        InlineKeyboardButton("👁️ Lihat sbg USER", callback_data="switch_user")
    )
    return markup

# ==========================================
# 4. MENU RESELLER
# ==========================================
def menu_reseller(is_owner_preview=False):
    markup = InlineKeyboardMarkup(row_width=2)
    
    # --- [UPDATE] MENU VPN (SSH/XRAY) DENGAN PILIHAN SERVER ---
    markup.row(
        InlineKeyboardButton("🇮🇩 INDO (SSH/XRAY)", callback_data="folder_indo"),
        InlineKeyboardButton("🇸🇬 SG (SSH/XRAY)", callback_data="folder_sg")
    )

    markup.add(InlineKeyboardButton("🏪 BELI GROSIR SSH", callback_data="buy_ssh_bulk"))
    
    markup.add(
        InlineKeyboardButton("👥 Buat User Baru", callback_data="create_user"),
        InlineKeyboardButton("📜 LIST AKUN SSH & XRAY", callback_data="reseller_my_list")
    )

    markup.add(InlineKeyboardButton("📊 Laporan", callback_data="report"))
    
    # --- 3 TOMBOL PPOB ---
    markup.row(
        InlineKeyboardButton("📱 PULSA MURAH (ATL)", callback_data="ppob_menu"),
        InlineKeyboardButton("📱 PULSA LENGKAP (OKE)", callback_data="ppob_atlantic")
    )
    markup.add(InlineKeyboardButton("🛍️ PULSA DIGI (AUTO)", callback_data="digi_menu"))

    markup.add(InlineKeyboardButton("🔍 CARI PRODUK (ALL)", callback_data="search_product_menu"))
    
    markup.add(InlineKeyboardButton("👁️ Lihat sbg USER (Cek Harga Jual)", callback_data="switch_user"))
    
    if is_owner_preview:
        markup.add(InlineKeyboardButton("🔙 KEMBALI OWNER", callback_data="switch_owner"))
        
    return markup

# ==========================================
# 5. MENU USER UTAMA
# ==========================================
def menu_user(role, is_owner_preview=False, is_reseller_preview=False):
    markup = InlineKeyboardMarkup(row_width=2)
    
    # --- [UPDATE] MENU VPN DENGAN PILIHAN SINGAPORE ---
    markup.row(
        InlineKeyboardButton("🇮🇩 INDO (SSH/XRAY)", callback_data="folder_indo"),
    #    InlineKeyboardButton("🇸🇬 SG (SSH/XRAY)", callback_data="folder_sg")
    )
    
    # --- 3 TOMBOL PPOB ---
    markup.row(
        InlineKeyboardButton("📱 PULSA MURAH (OKE)", callback_data="ppob_menu"),
        InlineKeyboardButton("📱 PULSA LENGKAP (ATL)", callback_data="ppob_atlantic")
    )

    # ==================================================================
    # [MODIFIKASI] HANYA TAMPILKAN FITUR CLI JIKA ROLE ADALAH OWNER
    # ==================================================================
    if 'owner' in role: 
        markup.add(InlineKeyboardButton("🚀 DOR PAKET NON LEGAL (CLI) 🚀", callback_data="run_me_cli"))
    # ==================================================================

    markup.add(InlineKeyboardButton("🔍 CARI PRODUK (ALL)", callback_data="search_product_menu"))
    
    if 'reseller' not in role:
        markup.add(InlineKeyboardButton("💼 DAFTAR RESELLER (50k)", callback_data="register_reseller"))
    
    markup.add(
        InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"),
        InlineKeyboardButton("📜 RIWAYAT", callback_data="history_user")
    )
    
    if is_owner_preview:
        markup.add(
            InlineKeyboardButton("👁️ Lihat sbg RESELLER", callback_data="switch_reseller"),
            InlineKeyboardButton("🔙 KEMBALI OWNER", callback_data="switch_owner")
        )
    elif is_reseller_preview:
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE RESELLER", callback_data="switch_reseller_back"))
        
    return markup

# ==========================================
# 6. SUB-MENU SINGAPORE / INDO 2 (LEGACY)
# ==========================================
def menu_user_indo2(role):
    markup = InlineKeyboardMarkup(row_width=2)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"

    h_ssh = PRICES["indo2"]["ssh"][kategori]
    h_xray = PRICES["indo2"]["xray"][kategori]

    txt_ssh = fmt_price(h_ssh)
    txt_xray = fmt_price(h_xray)

    markup.add(InlineKeyboardButton(f"🇮🇩 SSH INDO 2 ({txt_ssh})", callback_data="buy_ssh_indo2"))
    markup.add(
        InlineKeyboardButton(f"⚡ VMESS INDO 2 ({txt_xray})", callback_data="buy_vmess_indo2"),
        InlineKeyboardButton(f"🛡️ VLESS INDO 2 ({txt_xray})", callback_data="buy_vless_indo2")
    )
    markup.add(InlineKeyboardButton(f"🐎 TROJAN INDO 2 ({txt_xray})", callback_data="buy_trojan_indo2"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    return markup

# ==========================================
# 7. SUB-MENU INDONESIA
# ==========================================
def menu_user_indo(role):
    markup = InlineKeyboardMarkup(row_width=2)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"

    h_ssh = PRICES["indo"]["ssh"][kategori]
    h_xray = PRICES["indo"]["xray"][kategori]

    txt_ssh = fmt_price(h_ssh)
    txt_xray = fmt_price(h_xray)

    markup.add(InlineKeyboardButton(f"🇮🇩 SSH INDO ({txt_ssh})", callback_data="buy_ssh_indo"))
    markup.add(
        InlineKeyboardButton(f"⚡ VMESS INDO ({txt_xray})", callback_data="buy_vmess_indo"),
        InlineKeyboardButton(f"🛡️ VLESS INDO ({txt_xray})", callback_data="buy_vless_indo")
    )
    markup.add(InlineKeyboardButton(f"🐎 TROJAN INDO ({txt_xray})", callback_data="buy_trojan_indo"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    return markup

# ==========================================
# 8. [BARU] SUB-MENU SINGAPORE
# ==========================================
def menu_user_sg(role):
    markup = InlineKeyboardMarkup(row_width=2)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"

    # Ambil harga dari key "sg"
    h_ssh = PRICES["sg"]["ssh"][kategori]
    h_xray = PRICES["sg"]["xray"][kategori]

    txt_ssh = fmt_price(h_ssh)
    txt_xray = fmt_price(h_xray)

    markup.add(InlineKeyboardButton(f"🇸🇬 SSH SG ({txt_ssh})", callback_data="buy_ssh_sg"))
    markup.add(
    #    InlineKeyboardButton(f"⚡ VMESS SG ({txt_xray})", callback_data="buy_vmess_sg"),
    #    InlineKeyboardButton(f"🛡️ VLESS SG ({txt_xray})", callback_data="buy_vless_sg")
    )
    #markup.add(InlineKeyboardButton(f"🐎 TROJAN SG ({txt_xray})", callback_data="buy_trojan_sg"))
    #markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    return markup
    
# ==========================================
# 9. MENU DIGIFLAZZ (PREMIUM UI)
# ==========================================

CATEGORY_ICONS = {
    "Pulsa": "📱 PULSA REGULER",
    "Data": "🌐 PAKET DATA",
    "PLN": "💡 TOKEN LISTRIK",
    "Games": "🎮 VOUCHER GAME",
    "E-Money": "💳 E-WALLET / DANA",
    "Voucher": "🎟️ VOUCHER FISIK",
    "Masa Aktif": "⏳ MASA AKTIF",
    "Paket SMS & Telpon": "📞 PAKET NELPON",
    "TV": "📺 TV BERBAYAR",
    "Pertagas": "🔥 GAS PGN",
    "Pascabayar": "📄 TAGIHAN PASCA",
    "Streaming": "🎬 STREAMING"
}

def menu_digi_categories():
    markup = InlineKeyboardMarkup(row_width=2)
    raw_categories = get_categories() 
    
    btns = []
    for cat in raw_categories:
        label = CATEGORY_ICONS.get(cat, f"📦 {cat}")
        btns.append(InlineKeyboardButton(label, callback_data=f"digi_cat|{cat}"))
    
    markup.add(*btns)
    markup.row(InlineKeyboardButton("🔙 KEMBALI MENU UTAMA", callback_data="back_to_main_menu"))
    return markup

def menu_digi_brands(category):
    markup = InlineKeyboardMarkup(row_width=3)
    brands = get_brands(category)
    
    btns = []
    for brd in brands:
        label = f"🏷️ {brd}"
        btns.append(InlineKeyboardButton(label, callback_data=f"digi_brand|{category}|{brd}"))
    
    markup.add(*btns)
    markup.add(InlineKeyboardButton(f"🔙 KEMBALI KE {category.upper()}", callback_data="digi_menu"))
    return markup

def menu_digi_products(category, brand):
    markup = InlineKeyboardMarkup(row_width=1)
    products = get_products(category, brand)

    for prod in products[:20]: 
        status_icon = "🟢" if prod['buyer_product_status'] and prod['seller_product_status'] else "🔴"
        harga_fmt = "{:,}".format(prod['price']).replace(",", ".")
        nama_produk = prod['product_name'].replace(brand, "").strip()
        if not nama_produk: nama_produk = prod['product_name']
        
        btn_text = f"{status_icon} {nama_produk} ➡️ Rp {harga_fmt}"
        markup.add(InlineKeyboardButton(btn_text, callback_data=f"buy_digi|{prod['buyer_sku_code']}"))
    
    markup.add(InlineKeyboardButton(f"🔙 KEMBALI KE {brand}", callback_data=f"digi_cat|{category}"))
    return markup