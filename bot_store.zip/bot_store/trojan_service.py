import paramiko
import uuid
import datetime
import time
import json

# ==========================================
# KONFIGURASI SERVER (IP, USER, PASSWORD)
# ==========================================
SERVER_LIST = {
    "sg": {
        "ip": "159.65.15.214",
        "user": "root",
        "pass": "azzam2016", 
        "domain": "sg.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10",
        "user": "root",
        "pass": "azzam2016", 
        "domain": "id.hokagelegend.web.id"
    }
}

# --- PATH DI VPS TARGET ---
CONFIG_JSON = "/etc/xray/config.json"
DB_TROJAN = "/etc/trojan/.trojan.db"
LIMIT_IP_DIR = "/etc/hokage/limit/trojan/ip"
QUOTA_DIR = "/etc/trojan"

def get_ssh_client(ip, user, password):
    """Membuka koneksi SSH ke VPS Target"""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(ip, username=user, password=password, timeout=10)
    return client

def create_trojan_user(username, quota_gb, masa_aktif_hari, location):
    """
    Membuat user TROJAN via SSH Remote.
    """
    client = None
    try:
        # 1. Ambil Data Server
        target = SERVER_LIST.get(location)
        if not target:
            return False, "Lokasi Server tidak valid.", {}

        domain = target['domain']
        u_uuid = str(uuid.uuid4())
        
        # Hitung Expired Date
        today = datetime.datetime.now()
        exp_date = today + datetime.timedelta(days=int(masa_aktif_hari))
        exp_str = exp_date.strftime("%Y-%m-%d") 
        
        # 2. Koneksi SSH
        client = get_ssh_client(target['ip'], target['user'], target['pass'])

        # --- 3. SUSUN COMMAND LINUX ---
        commands = []
        
        # Manipulasi Config Xray (Inject User)
        entry_content = f'#! {username} {exp_str}\\n}},{{"password": "{u_uuid}","email": "{username}"'
        
        # Inject ke marker #trojanws$ dan #trojangrpc$
        commands.append(f"sed -i '/#trojanws$/a\{entry_content}' {CONFIG_JSON}")
        commands.append(f"sed -i '/#trojangrpc$/a\{entry_content}' {CONFIG_JSON}")

        # Update Database
        commands.append(f"sed -i '/\\b{username}\\b/d' {DB_TROJAN}") # Hapus user lama
        
        if quota_gb == "Unlimited": quota_bytes = 0
        else: quota_bytes = int(quota_gb) * 1024 * 1024 * 1024
        
        # Format DB Trojan: ### user exp uuid quota ip_limit
        limit_ip = 2
        entry_db = f"### {username} {exp_str} {u_uuid} {quota_bytes} {limit_ip}"
        commands.append(f"echo '{entry_db}' >> {DB_TROJAN}")

        # Buat File Limit IP & Quota
        commands.append(f"mkdir -p {LIMIT_IP_DIR}")
        commands.append(f"echo '{limit_ip}' > {LIMIT_IP_DIR}/{username}")
        commands.append(f"mkdir -p {QUOTA_DIR}")
        commands.append(f"echo '{quota_bytes}' > {QUOTA_DIR}/{username}")

        # Restart Service
        commands.append("systemctl restart xray")

        # Eksekusi Command
        full_command = " && ".join(commands)
        stdin, stdout, stderr = client.exec_command(full_command)
        
        # Cek Error
        err = stderr.read().decode()
        if err and "sed" not in err:
             print(f"SSH Warning: {err}")
             
        client.close()

        # --- 4. GENERATE LINK (LOKAL) ---
        link_ws = f"trojan://{u_uuid}@{domain}:443?path=/trojan-ws&security=tls&host={domain}&type=ws&sni={domain}#{username}"
        link_grpc = f"trojan://{u_uuid}@{domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={domain}#{username}"

        result_data = {
            'username': username,
            'uuid': u_uuid,
            'link_ws': link_ws,
            'link_grpc': link_grpc,
            'domain': domain
        }
        
        return True, "Sukses", result_data

    except Exception as e:
        if client: client.close()
        return False, f"SSH Error: {str(e)}", {}