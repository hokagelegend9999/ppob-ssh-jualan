import threading
import telebot
import paramiko
import re
from datetime import datetime, timedelta
import time
import uuid # <-- Wajib ditambahkan untuk generate UUID

from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID
from database import add_balance, get_user_data, increment_reseller_trx, save_vpn_created
from utils_helper import get_back_markup

# ======================================================
# 1. KONFIGURASI HARGA (VLESS)
# ======================================================
HARGA_VLESS = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":   {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}

# ======================================================
# 2. KONFIGURASI SERVER
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "aws": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.net"
    }
}

# ======================================================
# HELPER: GENERATE LINK VLESS
# ======================================================
def gen_vless_link(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    path = "vless-grpc" if type == "grpc" else "/vless"
    security = "tls" if type != "none" else "none"
    
    if type == "grpc":
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=grpc&serviceName={path}#{name}"
    else:
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=ws&path={path}#{name}"

# ======================================================
# HELPER: EKSEKUSI SCRIPT "BRIDGE" DI VPS (VLESS) - DIRECT COMMAND
# ======================================================
def create_vless_remote(username, quota, masa_aktif, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)
    new_uuid = str(uuid.uuid4())

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=10,
            look_for_keys=False,
            allow_agent=False
        )
        
        # COMMAND DIRECT XRAY UNTUK VLESS (Format config: #& )
        cmd = f"""
        # 1. Cek Duplikat (Vless biasanya pakai tanda #& di script installer)
        if grep -qw "{safe_username}" /etc/xray/config.json; then
            echo "ERROR|Username sudah ada"
            exit 0
        fi
        
        # 2. Hitung Tanggal (Format YYYY-MM-DD)
        exp=$(date -d "{masa_aktif} days" +"%Y-%m-%d")
        
        # 3. Inject ke config.json (Menggunakan double quotes)
        # Ingat, VLess WS port 443
        sed -i "/#vless$/a\#& {safe_username} $exp\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        # VLess gRPC port 443
        sed -i "/#vlelessgrpc$/a\#& {safe_username} $exp\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        
        # 4. Limit IP (Folder fvstore atau kyt limit)
        mkdir -p /etc/fvstore/limit/vless/ip
        echo "2" > /etc/fvstore/limit/vless/ip/{safe_username}
        mkdir -p /etc/kyt/limit/vless/ip
        echo "2" > /etc/kyt/limit/vless/ip/{safe_username}
        
        # 5. Limit Quota
        if [ ! -e /etc/vless ]; then mkdir -p /etc/vless; fi
        if [ "{quota}" != "0" ]; then
            limit_bytes=$(({quota} * 1024 * 1024 * 1024))
            echo "$limit_bytes" > /etc/vless/{safe_username}
        fi
        
        # 6. Simpan Database Internal
        sed -i "/\\b{safe_username}\\b/d" /etc/vless/.vless.db 2>/dev/null
        echo "### {safe_username} $exp {new_uuid} {quota} 2" >> /etc/vless/.vless.db
        
        # 7. Restart Xray & Cron
        systemctl restart xray > /dev/null 2>&1
        service cron restart > /dev/null 2>&1
        
        # 8. Output Wajib
        echo "SUCCESS|{new_uuid}"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        
        output = stdout.read().decode("utf-8", errors="ignore").strip()
        error_msg = stderr.read().decode("utf-8", errors="ignore").strip()
        client.close()

        print(f"--- DEBUG DIRECT VLESS {lokasi.upper()} ---")
        print(f"STDOUT: {output}")
        if error_msg: print(f"STDERR: {error_msg}")
        print(f"-------------------")

        if "SUCCESS|" in output:
            parts = output.split("SUCCESS|")[1].split("\n")[0]
            return True, "Sukses", {'uuid': parts}
                    
        elif "ERROR|" in output:
            reason = output.split("ERROR|")[1].split("\n")[0]
            return False, f"VPS: {reason}", {}
        else:
            return False, f"VPS Error: {error_msg if error_msg else output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HELPER: EKSEKUSI REMOTE GENERAL
# ======================================================
def eksekusi_remote(lokasi, command):
    target = SERVER_DATA.get(lokasi)
    if not target: return []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=20,            
            banner_timeout=200,    
            allow_agent=False, 
            look_for_keys=False
        )
        
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors='ignore').strip()
        client.close()
        
        if output:
            return output.split("\n")
        else:
            return []
            
    except Exception as e:
        print(f"❌ Error Remote {lokasi}: {e}")
        return []

# ======================================================
# HANDLER UTAMA: BELI VLESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_vless_"))
def buy_vless(call):
    try:
        uid = call.from_user.id
        try: lokasi = call.data.split("_")[2]
        except: return bot.answer_callback_query(call.id, "❌ Error Data")

        if lokasi not in HARGA_VLESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

        user_data = get_user_data(uid)
        if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

        role = str(user_data.get('role', 'user')).lower()
        saldo = int(user_data.get('balance', 0))

        if 'reseller' in role or 'owner' in role or str(uid) == str(ADMIN_ID):
            price = HARGA_VLESS[lokasi]["reseller"]
        else:
            price = HARGA_VLESS[lokasi]["user"]

        is_owner = str(uid) == str(ADMIN_ID) or 'owner' in role

        if not is_owner and saldo < price:
            kurang = price - saldo
            msg_error = f"⚠️ <b>SALDO TIDAK CUKUP</b>\nKurang: Rp {kurang:,}"
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
            return bot.send_message(call.message.chat.id, msg_error, parse_mode='HTML', reply_markup=markup)
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_user"))
        
        msg = bot.send_message(call.message.chat.id, 
            f"<b>🔮 BELI VLESS {lokasi.upper()}</b>\nMasukkan <b>Username</b>:", 
            parse_mode='HTML', reply_markup=m)
        
        bot.register_next_step_handler(msg, lambda m: vless_process(m, lokasi, price, is_owner))
    except Exception as e: bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def vless_process(m, lokasi, price, is_owner):
    if m.content_type != 'text': return
    u = m.text.strip()
    
    if not re.match("^[a-zA-Z0-9]+$", u):
        return bot.reply_to(m, "❌ <b>Username Invalid!</b>\nHanya boleh huruf dan angka.", parse_mode='HTML')
        
    if len(u) < 3: 
        return bot.reply_to(m, "❌ Username terlalu pendek (Min 3 karakter).")
    
    uid = m.from_user.id
    status = bot.reply_to(m, f"⏳ <b>Memproses Vless...</b>", parse_mode='HTML')
    
    # GUNAKAN THREADING AGAR BOT TIDAK HANG!
    threading.Thread(target=vless_execution, args=(m, u, uid, price, status, lokasi, is_owner)).start()

def vless_execution(m, u, uid, price, status_msg, lokasi, is_owner):
    try:
        quota_gb = "100" # Kalau mau unlimited ganti jadi "0"
        masa_aktif = "30"
        
        succ, info, res = create_vless_remote(u, quota_gb, masa_aktif, lokasi)
        
        if succ:
            if not is_owner:
                try:
                    add_balance(uid, -price, f"Beli Vless {lokasi.upper()} ({u})")
                    if get_user_data(uid).get('role') == 'reseller': increment_reseller_trx(uid)
                    sisa_saldo = f"{int(get_user_data(uid).get('balance', 0)):,}"
                except Exception as e:
                    bot.send_message(m.chat.id, f"❌ Error Update Saldo DB: {e}")
                    return
            else:
                sisa_saldo = "Unlimited"

            # Hapus pesan "Memproses..." dengan timeout agar tidak hang
            try: bot.delete_message(m.chat.id, status_msg.message_id, timeout=5)
            except: pass
            
            res_uuid = res.get('uuid')
            domain = SERVER_DATA.get(lokasi)['domain']
            now = datetime.now()
            exp_date = now + timedelta(days=int(masa_aktif)) 
            tgl_exp = exp_date.strftime("%d %b, %Y")
            
            try: save_vpn_created(uid, u, "VLESS", tgl_exp, res_uuid, domain)
            except: pass
            
            link_tls = gen_vless_link(f"{u}-TLS", domain, res_uuid, "tls")
            link_ntls = gen_vless_link(f"{u}-NTLS", domain, res_uuid, "none")
            link_grpc = gen_vless_link(f"{u}-GRPC", domain, res_uuid, "grpc")

            txt = f"""
========================================
🔮 <b>AKUN VLESS PREMIUM</b>
========================================
🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{u}</code>
Domain    : <code>{domain}</code>
UUID      : <code>{res_uuid}</code>
Expired   : <code>{tgl_exp}</code>
Limit IP  : 2 Device
Quota     : {quota_gb} GB

🔗 <b>LINK VLESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VLESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VLESS GRPC</b>
<code>{link_grpc}</code>
========================================
💰 Harga: Rp {price:,} | Sisa Saldo: {sisa_saldo}
"""
            # ======================================================
            # SISTEM AUTO-RETRY PENGIRIMAN PESAN
            # ======================================================
            try:
                # Coba kirim pesan (maksimal tunggu 15 detik)
                bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup(), timeout=15)
            except Exception:
                # Jika gagal/timeout, istirahat 1 detik lalu paksa kirim ulang!
                time.sleep(1)
                try: bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup(), timeout=15)
                except: pass
                
        else:
            try: bot.delete_message(m.chat.id, status_msg.message_id, timeout=5)
            except: pass
            
            try: bot.send_message(m.chat.id, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML', timeout=15)
            except: pass
            
    except Exception as e:
        try: bot.send_message(m.chat.id, f"❌ Error System: {e}", timeout=15)
        except: pass

# ==========================================
#  LIST & DELETE VLESS REMOTE (TEMA PREMIUM & POP-UP DETAIL)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vless_vps"))
def check_vless_vps(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        
        # Deteksi sumber panggilan
        if "del_vless" in parts[0]: 
            page = int(parts[3]) if len(parts) > 3 else 0
        else:
            page = int(parts[2]) if len(parts) > 2 else 0
    except: 
        lokasi = "sg"
        page = 0

    bot.answer_callback_query(call.id, f"Memuat data {lokasi.upper()}...")
    render_vless_page(call.message.chat.id, call.message.message_id, lokasi, page)

def render_vless_page(chat_id, message_id, lokasi, page=0):
    cmd = "grep '#& ' /etc/xray/config.json" 
    raw_lines = eksekusi_remote(lokasi, cmd)

    users = []
    seen = set()
    
    now_ts = time.time() 
    today = datetime.now().date()

    if raw_lines:
        for line in raw_lines:
            try:
                line = line.strip()
                parts = line.split()
                if len(parts) >= 3 and parts[0] == "#&":
                    u_name = parts[1]
                    u_exp_str = parts[2]

                    if u_name in seen: continue
                    seen.add(u_name)

                    try:
                        u_exp_date = datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                        sisa_hari = (u_exp_date - today).days
                        tgl_display = u_exp_date.strftime("%d %b %Y")
                    except:
                        sisa_hari = -999 
                        tgl_display = u_exp_str 

                    if sisa_hari >= 0:
                        status_icon = "✅ Aktif"
                        ket_hari = f"{sisa_hari} Hari"
                    else:
                        status_icon = "❌ Expired"
                        ket_hari = "DEAD ☠️"

                    users.append({
                        "u": u_name,
                        "exp": tgl_display,
                        "status": status_icon,
                        "sisa": sisa_hari,
                        "quota": "0.0",
                        "lim": "2"
                    })
            except: continue

    users.sort(key=lambda x: x['sisa'], reverse=True)

    per_page = 5
    total = len(users)
    total_pages = (total + per_page - 1) // per_page

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    cur = users[start:end]

    msg = f"🔮 <b>LIST VLESS PREMIUM ({lokasi.upper()})</b>\n"
    msg += f"📊 Total: {total} Akun | Hal: {page+1}/{total_pages if total_pages > 0 else 1}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    m = InlineKeyboardMarkup(row_width=5)

    if not users:
        msg += "<i>Belum ada akun VLess yang terdaftar.</i>\n"
    else:
        btn_row = []
        for index, u in enumerate(cur, start=1):
            day_txt = f"{u['sisa']} Hari" if u['sisa'] >= 0 else "DEAD ☠️" if u['sisa'] != -999 else "FORMAT ERROR"
            
            msg += f"<b>{index}. {u['u']}</b> {u['status']}\n"
            msg += f"   ⏳ Expired: <code>{u['exp']}</code> ({day_txt})\n"
            msg += f"   🎯 Limit  : {u['quota']}GB | {u['lim']} IP\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            
            # Tombol detail dengan angka
            btn_row.append(InlineKeyboardButton(f"👁️ {index}", callback_data=f"vls_det|{lokasi}|{u['u']}|{page}"))

        if btn_row:
            m.row(*btn_row)

    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"vls_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vless_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"vls_nav_rem|{lokasi}|{page+1}"))

    if nav: m.row(*nav)
    m.add(InlineKeyboardButton(f"🔙 KEMBALI KE DASHBOARD", callback_data=f"monitor_{lokasi}"))
    
    try:
        bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=m)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("vls_nav_rem"))
def nav_vless(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, page = call.data.split("|")
        render_vless_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    except: pass


# ==========================================
#  HANDLER DETAIL POP-UP VLESS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("vls_det"))
def detail_vless(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, user, page = call.data.split("|")
    except: return

    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # Ambil Expired dan UUID dari server
        cmd = f"""
        exp_raw=$(grep "#& {user} " /etc/xray/config.json | awk '{{print $3}}')
        [ -z "$exp_raw" ] && exp_raw="UNKNOWN"
        
        uuid=$(cat /etc/vless/{user} 2>/dev/null | grep -oP '(?<="id": ")[^"]*')
        if [ -z "$uuid" ]; then
            uuid=$(grep -A 10 "#& {user} " /etc/xray/config.json | grep -oP '(?<="id": ")[^"]*' | head -1)
        fi
        [ -z "$uuid" ] && uuid="UNKNOWN"
        
        echo "$exp_raw|$uuid"
        """
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_output = stdout.read().decode("utf-8").strip()
        client.close()
        
        exp_date_str = "UNKNOWN"
        uuid_str = "UNKNOWN"
        
        if "|" in raw_output:
            parts = raw_output.split("|")
            exp_date_str = parts[0]
            uuid_str = parts[1]

        if exp_date_str != "UNKNOWN":
            try:
                exp_obj = datetime.strptime(exp_date_str, "%Y-%m-%d")
                exp_date_str = exp_obj.strftime("%d %b %Y")
            except: pass

        domain_server = target.get('domain', target['ip'])
        limit = 2
        
        link_tls = "UUID Tidak Ditemukan"
        link_ntls = "UUID Tidak Ditemukan"
        link_grpc = "UUID Tidak Ditemukan"
        
        if uuid_str != "UNKNOWN":
            link_tls = gen_vless_link(f"{user}-TLS", domain_server, uuid_str, "tls")
            link_ntls = gen_vless_link(f"{user}-NTLS", domain_server, uuid_str, "none")
            link_grpc = gen_vless_link(f"{user}-GRPC", domain_server, uuid_str, "grpc")

        harga = HARGA_VLESS[lokasi]["user"] if lokasi in HARGA_VLESS else 0

        reply_msg = f"""
========================================
🔮 <b>DETAIL AKUN VLESS PREMIUM ({lokasi.upper()})</b>
========================================
🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{user}</code>
Domain    : <code>{domain_server}</code>
UUID      : <code>{uuid_str}</code>
Expired   : <code>{exp_date_str}</code>
Limit IP  : <code>{limit} Device</code>

🔗 <b>LINK VLESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VLESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VLESS GRPC</b>
<code>{link_grpc}</code>
========================================
💰 Harga: Rp {harga:,}
========================================
<i>Silakan pilih tindakan di bawah ini:</i>
"""
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton(f"🗑️ HAPUS AKUN INI", callback_data=f"del_vless|{lokasi}|{user}|{page}"))
        m.add(InlineKeyboardButton("🔙 KEMBALI KE LIST VLESS", callback_data=f"vls_nav_rem|{lokasi}|{page}"))
        
        bot.edit_message_text(reply_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)


# ==========================================
#  HANDLER HAPUS VLESS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("del_vless"))
def del_vless_remote(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except: return

    cmd = f"""
    sed -i "\|#& {user} |,\|}}|d" /etc/xray/config.json
    sed -i "\|### {user} |d" /etc/vless/.vless.db
    rm -f "/etc/kyt/limit/vless/ip/{user}"
    rm -f "/etc/fvstore/limit/vless/ip/{user}"
    rm -f "/etc/vless/{user}*"
    systemctl restart xray
    """
    
    eksekusi_remote(lokasi, cmd)
    bot.answer_callback_query(call.id, f"✅ User {user} berhasil dihapus!", show_alert=True)
    
    render_vless_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    
import threading
import telebot
import paramiko
import re
from datetime import datetime, timedelta
import time
import uuid # <-- Wajib ditambahkan untuk generate UUID

from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID
from database import add_balance, get_user_data, increment_reseller_trx, save_vpn_created
from utils_helper import get_back_markup

# ======================================================
# 1. KONFIGURASI HARGA (VLESS)
# ======================================================
HARGA_VLESS = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":   {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}

# ======================================================
# 2. KONFIGURASI SERVER
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "aws": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.net"
    }
}

# ======================================================
# HELPER: GENERATE LINK VLESS
# ======================================================
def gen_vless_link(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    path = "vless-grpc" if type == "grpc" else "/vless"
    security = "tls" if type != "none" else "none"
    
    if type == "grpc":
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=grpc&serviceName={path}#{name}"
    else:
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=ws&path={path}#{name}"

# ======================================================
# HELPER: EKSEKUSI SCRIPT "BRIDGE" DI VPS (VLESS) - DIRECT COMMAND
# ======================================================
def create_vless_remote(username, quota, masa_aktif, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)
    new_uuid = str(uuid.uuid4())

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=10,
            look_for_keys=False,
            allow_agent=False
        )
        
        # COMMAND DIRECT XRAY UNTUK VLESS (Format config: #& )
        cmd = f"""
        # 1. Cek Duplikat (Vless biasanya pakai tanda #& di script installer)
        if grep -qw "{safe_username}" /etc/xray/config.json; then
            echo "ERROR|Username sudah ada"
            exit 0
        fi
        
        # 2. Hitung Tanggal (Format YYYY-MM-DD)
        exp=$(date -d "{masa_aktif} days" +"%Y-%m-%d")
        
        # 3. Inject ke config.json (Menggunakan double quotes)
        # Ingat, VLess WS port 443
        sed -i "/#vless$/a\#& {safe_username} $exp\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        # VLess gRPC port 443
        sed -i "/#vlelessgrpc$/a\#& {safe_username} $exp\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        
        # 4. Limit IP (Folder fvstore atau kyt limit)
        mkdir -p /etc/fvstore/limit/vless/ip
        echo "2" > /etc/fvstore/limit/vless/ip/{safe_username}
        mkdir -p /etc/kyt/limit/vless/ip
        echo "2" > /etc/kyt/limit/vless/ip/{safe_username}
        
        # 5. Limit Quota
        if [ ! -e /etc/vless ]; then mkdir -p /etc/vless; fi
        if [ "{quota}" != "0" ]; then
            limit_bytes=$(({quota} * 1024 * 1024 * 1024))
            echo "$limit_bytes" > /etc/vless/{safe_username}
        fi
        
        # 6. Simpan Database Internal
        sed -i "/\\b{safe_username}\\b/d" /etc/vless/.vless.db 2>/dev/null
        echo "### {safe_username} $exp {new_uuid} {quota} 2" >> /etc/vless/.vless.db
        
        # 7. Restart Xray & Cron
        systemctl restart xray > /dev/null 2>&1
        service cron restart > /dev/null 2>&1
        
        # 8. Output Wajib
        echo "SUCCESS|{new_uuid}"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        
        output = stdout.read().decode("utf-8", errors="ignore").strip()
        error_msg = stderr.read().decode("utf-8", errors="ignore").strip()
        client.close()

        print(f"--- DEBUG DIRECT VLESS {lokasi.upper()} ---")
        print(f"STDOUT: {output}")
        if error_msg: print(f"STDERR: {error_msg}")
        print(f"-------------------")

        if "SUCCESS|" in output:
            parts = output.split("SUCCESS|")[1].split("\n")[0]
            return True, "Sukses", {'uuid': parts}
                    
        elif "ERROR|" in output:
            reason = output.split("ERROR|")[1].split("\n")[0]
            return False, f"VPS: {reason}", {}
        else:
            return False, f"VPS Error: {error_msg if error_msg else output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HELPER: EKSEKUSI REMOTE GENERAL
# ======================================================
def eksekusi_remote(lokasi, command):
    target = SERVER_DATA.get(lokasi)
    if not target: return []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=20,            
            banner_timeout=200,    
            allow_agent=False, 
            look_for_keys=False
        )
        
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors='ignore').strip()
        client.close()
        
        if output:
            return output.split("\n")
        else:
            return []
            
    except Exception as e:
        print(f"❌ Error Remote {lokasi}: {e}")
        return []

# ======================================================
# HANDLER UTAMA: BELI VLESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_vless_"))
def buy_vless(call):
    try:
        uid = call.from_user.id
        try: lokasi = call.data.split("_")[2]
        except: return bot.answer_callback_query(call.id, "❌ Error Data")

        if lokasi not in HARGA_VLESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

        user_data = get_user_data(uid)
        if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

        role = str(user_data.get('role', 'user')).lower()
        saldo = int(user_data.get('balance', 0))

        if 'reseller' in role or 'owner' in role or str(uid) == str(ADMIN_ID):
            price = HARGA_VLESS[lokasi]["reseller"]
        else:
            price = HARGA_VLESS[lokasi]["user"]

        is_owner = str(uid) == str(ADMIN_ID) or 'owner' in role

        if not is_owner and saldo < price:
            kurang = price - saldo
            msg_error = f"⚠️ <b>SALDO TIDAK CUKUP</b>\nKurang: Rp {kurang:,}"
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
            return bot.send_message(call.message.chat.id, msg_error, parse_mode='HTML', reply_markup=markup)
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_user"))
        
        msg = bot.send_message(call.message.chat.id, 
            f"<b>🔮 BELI VLESS {lokasi.upper()}</b>\nMasukkan <b>Username</b>:", 
            parse_mode='HTML', reply_markup=m)
        
        bot.register_next_step_handler(msg, lambda m: vless_process(m, lokasi, price, is_owner))
    except Exception as e: bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def vless_process(m, lokasi, price, is_owner):
    if m.content_type != 'text': return
    u = m.text.strip()
    
    if not re.match("^[a-zA-Z0-9]+$", u):
        return bot.reply_to(m, "❌ <b>Username Invalid!</b>\nHanya boleh huruf dan angka.", parse_mode='HTML')
        
    if len(u) < 3: 
        return bot.reply_to(m, "❌ Username terlalu pendek (Min 3 karakter).")
    
    uid = m.from_user.id
    status = bot.reply_to(m, f"⏳ <b>Memproses Vless...</b>", parse_mode='HTML')
    
    # GUNAKAN THREADING AGAR BOT TIDAK HANG!
    threading.Thread(target=vless_execution, args=(m, u, uid, price, status, lokasi, is_owner)).start()

def vless_execution(m, u, uid, price, status_msg, lokasi, is_owner):
    try:
        quota_gb = "100" # Kalau mau unlimited ganti jadi "0"
        masa_aktif = "30"
        
        succ, info, res = create_vless_remote(u, quota_gb, masa_aktif, lokasi)
        
        if succ:
            if not is_owner:
                try:
                    add_balance(uid, -price, f"Beli Vless {lokasi.upper()} ({u})")
                    if get_user_data(uid).get('role') == 'reseller': increment_reseller_trx(uid)
                    sisa_saldo = f"{int(get_user_data(uid).get('balance', 0)):,}"
                except Exception as e:
                    bot.send_message(m.chat.id, f"❌ Error Update Saldo DB: {e}")
                    return
            else:
                sisa_saldo = "Unlimited"

            # Hapus pesan "Memproses..." dengan timeout agar tidak hang
            try: bot.delete_message(m.chat.id, status_msg.message_id, timeout=5)
            except: pass
            
            res_uuid = res.get('uuid')
            domain = SERVER_DATA.get(lokasi)['domain']
            now = datetime.now()
            exp_date = now + timedelta(days=int(masa_aktif)) 
            tgl_exp = exp_date.strftime("%d %b, %Y")
            
            try: save_vpn_created(uid, u, "VLESS", tgl_exp, res_uuid, domain)
            except: pass
            
            link_tls = gen_vless_link(f"{u}-TLS", domain, res_uuid, "tls")
            link_ntls = gen_vless_link(f"{u}-NTLS", domain, res_uuid, "none")
            link_grpc = gen_vless_link(f"{u}-GRPC", domain, res_uuid, "grpc")

            txt = f"""
========================================
🔮 <b>AKUN VLESS PREMIUM</b>
========================================
🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{u}</code>
Domain    : <code>{domain}</code>
UUID      : <code>{res_uuid}</code>
Expired   : <code>{tgl_exp}</code>
Limit IP  : 2 Device
Quota     : {quota_gb} GB

🔗 <b>LINK VLESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VLESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VLESS GRPC</b>
<code>{link_grpc}</code>
========================================
💰 Harga: Rp {price:,} | Sisa Saldo: {sisa_saldo}
"""
            # ======================================================
            # SISTEM AUTO-RETRY PENGIRIMAN PESAN
            # ======================================================
            try:
                # Coba kirim pesan (maksimal tunggu 15 detik)
                bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup(), timeout=15)
            except Exception:
                # Jika gagal/timeout, istirahat 1 detik lalu paksa kirim ulang!
                time.sleep(1)
                try: bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup(), timeout=15)
                except: pass
                
        else:
            try: bot.delete_message(m.chat.id, status_msg.message_id, timeout=5)
            except: pass
            
            try: bot.send_message(m.chat.id, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML', timeout=15)
            except: pass
            
    except Exception as e:
        try: bot.send_message(m.chat.id, f"❌ Error System: {e}", timeout=15)
        except: pass

# ==========================================
#  LIST & DELETE VLESS REMOTE (TEMA PREMIUM & POP-UP DETAIL)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vless_vps"))
def check_vless_vps(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        
        # Deteksi sumber panggilan
        if "del_vless" in parts[0]: 
            page = int(parts[3]) if len(parts) > 3 else 0
        else:
            page = int(parts[2]) if len(parts) > 2 else 0
    except: 
        lokasi = "sg"
        page = 0

    bot.answer_callback_query(call.id, f"Memuat data {lokasi.upper()}...")
    render_vless_page(call.message.chat.id, call.message.message_id, lokasi, page)

def render_vless_page(chat_id, message_id, lokasi, page=0):
    cmd = "grep '#& ' /etc/xray/config.json" 
    raw_lines = eksekusi_remote(lokasi, cmd)

    users = []
    seen = set()
    
    now_ts = time.time() 
    today = datetime.now().date()

    if raw_lines:
        for line in raw_lines:
            try:
                line = line.strip()
                parts = line.split()
                if len(parts) >= 3 and parts[0] == "#&":
                    u_name = parts[1]
                    u_exp_str = parts[2]

                    if u_name in seen: continue
                    seen.add(u_name)

                    try:
                        u_exp_date = datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                        sisa_hari = (u_exp_date - today).days
                        tgl_display = u_exp_date.strftime("%d %b %Y")
                    except:
                        sisa_hari = -999 
                        tgl_display = u_exp_str 

                    if sisa_hari >= 0:
                        status_icon = "✅ Aktif"
                        ket_hari = f"{sisa_hari} Hari"
                    else:
                        status_icon = "❌ Expired"
                        ket_hari = "DEAD ☠️"

                    users.append({
                        "u": u_name,
                        "exp": tgl_display,
                        "status": status_icon,
                        "sisa": sisa_hari,
                        "quota": "0.0",
                        "lim": "2"
                    })
            except: continue

    users.sort(key=lambda x: x['sisa'], reverse=True)

    per_page = 5
    total = len(users)
    total_pages = (total + per_page - 1) // per_page

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    cur = users[start:end]

    msg = f"🔮 <b>LIST VLESS PREMIUM ({lokasi.upper()})</b>\n"
    msg += f"📊 Total: {total} Akun | Hal: {page+1}/{total_pages if total_pages > 0 else 1}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    m = InlineKeyboardMarkup(row_width=5)

    if not users:
        msg += "<i>Belum ada akun VLess yang terdaftar.</i>\n"
    else:
        btn_row = []
        for index, u in enumerate(cur, start=1):
            day_txt = f"{u['sisa']} Hari" if u['sisa'] >= 0 else "DEAD ☠️" if u['sisa'] != -999 else "FORMAT ERROR"
            
            msg += f"<b>{index}. {u['u']}</b> {u['status']}\n"
            msg += f"   ⏳ Expired: <code>{u['exp']}</code> ({day_txt})\n"
            msg += f"   🎯 Limit  : {u['quota']}GB | {u['lim']} IP\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            
            # Tombol detail dengan angka
            btn_row.append(InlineKeyboardButton(f"👁️ {index}", callback_data=f"vls_det|{lokasi}|{u['u']}|{page}"))

        if btn_row:
            m.row(*btn_row)

    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"vls_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vless_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"vls_nav_rem|{lokasi}|{page+1}"))

    if nav: m.row(*nav)
    m.add(InlineKeyboardButton(f"🔙 KEMBALI KE DASHBOARD", callback_data=f"monitor_{lokasi}"))
    
    try:
        bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=m)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("vls_nav_rem"))
def nav_vless(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, page = call.data.split("|")
        render_vless_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    except: pass


# ==========================================
#  HANDLER DETAIL POP-UP VLESS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("vls_det"))
def detail_vless(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, user, page = call.data.split("|")
    except: return

    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # Ambil Expired dan UUID dari server
        cmd = f"""
        exp_raw=$(grep "#& {user} " /etc/xray/config.json | awk '{{print $3}}')
        [ -z "$exp_raw" ] && exp_raw="UNKNOWN"
        
        uuid=$(cat /etc/vless/{user} 2>/dev/null | grep -oP '(?<="id": ")[^"]*')
        if [ -z "$uuid" ]; then
            uuid=$(grep -A 10 "#& {user} " /etc/xray/config.json | grep -oP '(?<="id": ")[^"]*' | head -1)
        fi
        [ -z "$uuid" ] && uuid="UNKNOWN"
        
        echo "$exp_raw|$uuid"
        """
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_output = stdout.read().decode("utf-8").strip()
        client.close()
        
        exp_date_str = "UNKNOWN"
        uuid_str = "UNKNOWN"
        
        if "|" in raw_output:
            parts = raw_output.split("|")
            exp_date_str = parts[0]
            uuid_str = parts[1]

        if exp_date_str != "UNKNOWN":
            try:
                exp_obj = datetime.strptime(exp_date_str, "%Y-%m-%d")
                exp_date_str = exp_obj.strftime("%d %b %Y")
            except: pass

        domain_server = target.get('domain', target['ip'])
        limit = 2
        
        link_tls = "UUID Tidak Ditemukan"
        link_ntls = "UUID Tidak Ditemukan"
        link_grpc = "UUID Tidak Ditemukan"
        
        if uuid_str != "UNKNOWN":
            link_tls = gen_vless_link(f"{user}-TLS", domain_server, uuid_str, "tls")
            link_ntls = gen_vless_link(f"{user}-NTLS", domain_server, uuid_str, "none")
            link_grpc = gen_vless_link(f"{user}-GRPC", domain_server, uuid_str, "grpc")

        harga = HARGA_VLESS[lokasi]["user"] if lokasi in HARGA_VLESS else 0

        reply_msg = f"""
========================================
🔮 <b>DETAIL AKUN VLESS PREMIUM ({lokasi.upper()})</b>
========================================
🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{user}</code>
Domain    : <code>{domain_server}</code>
UUID      : <code>{uuid_str}</code>
Expired   : <code>{exp_date_str}</code>
Limit IP  : <code>{limit} Device</code>

🔗 <b>LINK VLESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VLESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VLESS GRPC</b>
<code>{link_grpc}</code>
========================================
💰 Harga: Rp {harga:,}
========================================
<i>Silakan pilih tindakan di bawah ini:</i>
"""
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton(f"🗑️ HAPUS AKUN INI", callback_data=f"del_vless|{lokasi}|{user}|{page}"))
        m.add(InlineKeyboardButton("🔙 KEMBALI KE LIST VLESS", callback_data=f"vls_nav_rem|{lokasi}|{page}"))
        
        bot.edit_message_text(reply_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)


# ==========================================
#  HANDLER HAPUS VLESS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("del_vless"))
def del_vless_remote(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except: return

    cmd = f"""
    sed -i "\|#& {user} |,\|}}|d" /etc/xray/config.json
    sed -i "\|### {user} |d" /etc/vless/.vless.db
    rm -f "/etc/kyt/limit/vless/ip/{user}"
    rm -f "/etc/fvstore/limit/vless/ip/{user}"
    rm -f "/etc/vless/{user}*"
    systemctl restart xray
    """
    
    eksekusi_remote(lokasi, cmd)
    bot.answer_callback_query(call.id, f"✅ User {user} berhasil dihapus!", show_alert=True)
    
    render_vless_page(call.message.chat.id, call.message.message_id, lokasi, int(page))