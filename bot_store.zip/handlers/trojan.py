import telebot
import paramiko
import urllib.parse
import re
from datetime import datetime, timedelta
import time

from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID
from database import add_balance, get_user_data, increment_reseller_trx, save_vpn_created
from utils_helper import get_back_markup

# ======================================================
# 1. KONFIGURASI HARGA (TROJAN)
# ======================================================
HARGA_TROJAN = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":   {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}

# ======================================================
# 2. KONFIGURASI SERVER
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "aws": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.net"
    }
}

# ======================================================
# HELPER: GENERATOR LINK TROJAN
# ======================================================
def gen_trojan_link(user, domain, password, type="ws"):
    safe_name = urllib.parse.quote(user)
    if type == "grpc":
        return f"trojan://{password}@{domain}:443?security=tls&type=grpc&serviceName=trojan-grpc#{safe_name}"
    else:
        return f"trojan://{password}@{domain}:443?security=tls&type=ws&path=%2Ftrojan#{safe_name}"

def create_trojan_remote(username, quota, masa_aktif, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15,
            look_for_keys=False,
            allow_agent=False
        )
        
        # =========================================================
        # FITUR BARU: AUTO-COPY SCRIPT KE VPS TARGET VIA SFTP
        # =========================================================
        # try:
        #     sftp = client.open_sftp()
        #     sftp.put('/usr/bin/addtr-bot', '/usr/bin/addtr-bot') 
        #     sftp.close()
        #     
        #     # Berikan izin eksekusi (chmod +x) pada file yang baru diupload
        #     client.exec_command("chmod +x /usr/bin/addtr-bot")
        # except Exception as e:
        #     print(f"Peringatan SFTP {lokasi}: Gagal copy script ({e})")
        
        # Eksekusi script dengan pengaman input (< /dev/null)
        cmd = f"bash /usr/bin/addtr-bot {username} {masa_aktif} {quota} 2"
        
        stdin, stdout, stderr = client.exec_command(cmd)
        
        # Tutup paksa pintu input dari sisi Python agar tidak hang
        stdin.close()
        
        # Beri batas waktu maksimal 15 detik
        channel = stdout.channel
        channel.settimeout(15.0)
        
        try:
            output = stdout.read().decode("utf-8", errors="ignore").strip()
            error_out = stderr.read().decode("utf-8", errors="ignore").strip()
        except Exception as e:
            client.close()
            return False, f"❌ GAGAL: Koneksi ke VPS {lokasi.upper()} terputus/Timeout.", {}
            
        client.close()

        print(f"DEBUG Output {lokasi}: {output}")
        print(f"DEBUG Error {lokasi}: {error_out}")

        if "SUCCESS|" in output:
            # Filter output untuk mengambil baris SUCCESS saja
            for line in output.split('\n'):
                if "SUCCESS|" in line:
                    parts = line.split("|")
                    u_uuid = parts[1] if len(parts) > 1 else "ERROR_NO_UUID"
                    return True, "Sukses", {'uuid': u_uuid}
                    
        elif "ERROR" in output or "already" in output.lower():
            return False, "Username sudah digunakan atau error.", {}
        else:
            err_msg = error_out if error_out else output
            return False, f"Gagal Script: {err_msg[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HELPER: EKSEKUSI REMOTE GENERAL
# ======================================================
def eksekusi_remote(lokasi, command):
    target = SERVER_DATA.get(lokasi)
    if not target: return []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=30,             # Ditambah
            banner_timeout=300,     # Ditambah    
            allow_agent=False, 
            look_for_keys=False
        )
        
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors='ignore').strip()
        client.close()
        
        if output: return output.split("\n")
        else: return []
            
    except Exception as e:
        print(f"❌ Error Remote {lokasi}: {e}")
        return []

# ======================================================
# HANDLER UTAMA: BELI TROJAN
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_trojan_"))
def buy_trojan(call):
    try:
        uid = call.from_user.id
        try: lokasi = call.data.split("_")[2]
        except: return bot.answer_callback_query(call.id, "❌ Error Data")

        if lokasi not in HARGA_TROJAN: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

        user_data = get_user_data(uid)
        if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

        role = str(user_data.get('role', 'user')).lower()
        saldo = int(user_data.get('balance', 0))

        if 'reseller' in role or 'owner' in role or str(uid) == str(ADMIN_ID):
            price = HARGA_TROJAN[lokasi]["reseller"]
        else:
            price = HARGA_TROJAN[lokasi]["user"]

        is_owner = str(uid) == str(ADMIN_ID) or 'owner' in role

        if not is_owner and saldo < price:
            kurang = price - saldo
            msg_error = f"⚠️ <b>SALDO TIDAK CUKUP</b>\nKurang: Rp {kurang:,}"
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
            return bot.send_message(call.message.chat.id, msg_error, parse_mode='HTML', reply_markup=markup)
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_user"))
        
        server_info = SERVER_DATA.get(lokasi, {"name": lokasi.upper()})
        msg = bot.send_message(call.message.chat.id, 
            f"<b>🐎 BELI TROJAN {server_info['name'].upper()}</b>\nMasukkan <b>Username</b>:", 
            parse_mode='HTML', reply_markup=m)
        
        bot.register_next_step_handler(msg, lambda m: trojan_process(m, lokasi, price, is_owner))
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def trojan_process(m, lokasi, price, is_owner):
    if m.content_type != 'text': return
    u = m.text.strip()
    
    if not re.match("^[a-zA-Z0-9]+$", u):
        return bot.reply_to(m, "❌ <b>Username Invalid!</b>\nHanya boleh huruf dan angka.", parse_mode='HTML')
        
    if len(u) < 3: 
        return bot.reply_to(m, "❌ Username terlalu pendek (Min 3 karakter).")
    
    uid = m.from_user.id
    status = bot.reply_to(m, f"⏳ <b>Memproses Trojan...</b>", parse_mode='HTML')
    trojan_execution(m, u, uid, price, status, lokasi, is_owner)

def trojan_execution(m, u, uid, price, status_msg, lokasi, is_owner):
    try:
        quota_gb = "100"
        masa_aktif = "30"

        succ, info, res = create_trojan_remote(u, quota_gb, masa_aktif, lokasi)
        
        if succ:
            if not is_owner:
                add_balance(uid, -price, f"Beli Trojan {lokasi.upper()} ({u})")
                if get_user_data(uid).get('role') == 'reseller': 
                    increment_reseller_trx(uid)
                sisa_saldo = f"{int(get_user_data(uid).get('balance', 0)):,}"
            else:
                sisa_saldo = "Unlimited"

            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            
            res_uuid = res.get('uuid') # Password trojan
            domain = SERVER_DATA.get(lokasi)['domain']
            now = datetime.now()
            exp_date = now + timedelta(days=int(masa_aktif))
            tgl_exp = exp_date.strftime("%d %b, %Y")
            
            try: save_vpn_created(uid, u, "TROJAN", tgl_exp, res_uuid, domain)
            except: pass

            link_ws = gen_trojan_link(u, domain, res_uuid, "ws")
            link_grpc = gen_trojan_link(u, domain, res_uuid, "grpc")

            txt = f"""
========================================
🐎 <b>AKUN TROJAN PREMIUM</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{u}</code>
Domain    : <code>{domain}</code>
Port TLS  : 443
Password  : <code>{res_uuid}</code>
Network   : WS / gRPC
Path WS   : /trojan
Service   : trojan-grpc

🔗 <b>LINK TROJAN WS</b>
<code>{link_ws}</code>

🔗 <b>LINK TROJAN GRPC</b>
<code>{link_grpc}</code>

📋 <b>INFORMASI TAMBAHAN</b>
Expired: <code>{tgl_exp}</code>
Quota: {quota_gb} GB
Limit IP: 2 Device

========================================
💰 Harga: Rp {price:,} | Sisa Saldo: {sisa_saldo}
"""
            # Buat markup kustom sesuai dengan navigasi bot Anda
            m_back = InlineKeyboardMarkup(row_width=1)
            
            # Jika ini Trojan SG, arahkan kembali ke folder SG
            if lokasi == "sg":
                m_back.add(InlineKeyboardButton("🔙 KEMBALI KE MENU SG", callback_data="folder_sg"))
            # Jika ini Trojan Indo, arahkan ke folder Indo
            elif lokasi == "indo":
                m_back.add(InlineKeyboardButton("🔙 KEMBALI KE MENU INDO", callback_data="folder_indo"))
                
            # Tombol tambahan untuk langsung ke menu utama
            m_back.add(InlineKeyboardButton("🏠 MENU UTAMA", callback_data="back_to_main_menu"))

            bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=m_back)
        else:
            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            bot.reply_to(m, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML')
            
    except Exception as e:
        bot.reply_to(m, f"❌ Error System: {e}")

# ======================================================
# MONITORING & LIST TROJAN (SINKRON CONFIG.JSON)
# ======================================================
def get_ssh_connection(lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return None
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        return client
    except: return None

def render_trojan_page(chat_id, message_id, lokasi, page=0):
    cmd = "grep '#! ' /etc/xray/config.json" 
    raw_lines = eksekusi_remote(lokasi, cmd)

    users = []
    seen = set()
    now_ts = time.time() 
    today = datetime.now().date()

    if raw_lines:
        for line in raw_lines:
            try:
                line = line.strip()
                parts = line.split()
                if len(parts) >= 3 and parts[0] == "#!":
                    u_name = parts[1]
                    u_exp_str = parts[2]

                    if u_name in seen: continue
                    seen.add(u_name)

                    try:
                        u_exp_date = datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                        sisa_hari = (u_exp_date - today).days
                        tgl_display = u_exp_date.strftime("%d %b %Y")
                    except:
                        sisa_hari = -999 
                        tgl_display = u_exp_str 

                    if sisa_hari >= 0:
                        status_icon = "✅ Active"
                        ket_hari = f"{sisa_hari} Hari"
                    else:
                        status_icon = "❌ Expired"
                        ket_hari = "DEAD ☠️"

                    users.append({
                        "name": u_name,
                        "exp_date": tgl_display,
                        "status": status_icon,
                        "ket": ket_hari,
                        "sort_val": sisa_hari
                    })
            except: continue

    users.sort(key=lambda x: x['sort_val'], reverse=True)

    per_page = 5
    total_items = len(users)
    total_pages = (total_items + per_page - 1) // per_page

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    sliced_data = users[start:end]

    msg = f"<b>🐎 LIST TROJAN ({lokasi.upper()})</b>\n"
    msg += f"Total: {total_items} User | Page: {page+1}/{total_pages}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    markup = InlineKeyboardMarkup()

    if not users:
        msg += "<i>Belum ada user Trojan.</i>\n"
    else:
        for u in sliced_data:
            msg += f"👤 <b>{u['name']}</b>\n"
            msg += f"🏳️ {u['status']} ({u['ket']})\n"
            msg += f"🎯 0.0GB | 2 IP\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            markup.add(InlineKeyboardButton(f"🗑️ Hapus {u['name']}", callback_data=f"trj_del_rem|{lokasi}|{u['name']}|{page}"))

    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️", callback_data=f"trj_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_trojan_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("➡️", callback_data=f"trj_nav_rem|{lokasi}|{page+1}"))

    if nav: markup.row(*nav)
    markup.add(InlineKeyboardButton(f"🔙 KEMBALI", callback_data=f"monitor_{lokasi}"))
    
    try: bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

# ======================================================
# MONITORING & LIST TROJAN (TEMA PREMIUM & DETAIL)
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("check_trojan_vps"))
def check_trojan_vps(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        
        # Deteksi sumber panggilan
        if "del_trojan" in parts[0]: 
            page = int(parts[3]) if len(parts) > 3 else 0
        else:
            page = int(parts[2]) if len(parts) > 2 else 0
    except: 
        lokasi = "sg"
        page = 0
    
    bot.answer_callback_query(call.id, f"Memuat Trojan {lokasi.upper()}...")
    render_trojan_page(call.message.chat.id, call.message.message_id, lokasi, page)

def render_trojan_page(chat_id, message_id, lokasi, page=0):
    cmd = "grep '#! ' /etc/xray/config.json" 
    raw_lines = eksekusi_remote(lokasi, cmd)

    users = []
    seen = set()
    
    import time
    from datetime import datetime
    now_ts = time.time() 
    today = datetime.now().date()

    if raw_lines:
        for line in raw_lines:
            try:
                line = line.strip()
                parts = line.split()
                if len(parts) >= 3 and parts[0] == "#!":
                    u_name = parts[1]
                    u_exp_str = parts[2]

                    if u_name in seen: continue
                    seen.add(u_name)

                    try:
                        u_exp_date = datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                        sisa_hari = (u_exp_date - today).days
                        tgl_display = u_exp_date.strftime("%d %b %Y")
                    except:
                        sisa_hari = -999 
                        tgl_display = u_exp_str 

                    if sisa_hari >= 0:
                        status_icon = "✅ Aktif"
                        ket_hari = f"{sisa_hari} Hari"
                    else:
                        status_icon = "❌ Expired"
                        ket_hari = "DEAD ☠️"

                    users.append({
                        "name": u_name,
                        "exp_date": tgl_display,
                        "status": status_icon,
                        "ket": ket_hari,
                        "sort_val": sisa_hari,
                        "quota": "0.0",
                        "lim": "2"
                    })
            except: continue

    users.sort(key=lambda x: x['sort_val'], reverse=True)

    per_page = 5
    total_items = len(users)
    total_pages = (total_items + per_page - 1) // per_page

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1

    start = page * per_page
    end = start + per_page
    sliced_data = users[start:end]

    msg = f"🐎 <b>LIST TROJAN PREMIUM ({lokasi.upper()})</b>\n"
    msg += f"📊 Total: {total_items} Akun | Hal: {page+1}/{total_pages if total_pages > 0 else 1}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    m = InlineKeyboardMarkup(row_width=5)

    if not users:
        msg += "<i>Belum ada akun Trojan yang terdaftar.</i>\n"
    else:
        btn_row = []
        for index, u in enumerate(sliced_data, start=1):
            msg += f"<b>{index}. {u['name']}</b> {u['status']}\n"
            msg += f"   ⏳ Expired: <code>{u['exp_date']}</code> ({u['ket']})\n"
            msg += f"   🎯 Limit  : {u['quota']}GB | {u['lim']} IP\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            
            # Tombol detail berderet
            btn_row.append(InlineKeyboardButton(f"👁️ {index}", callback_data=f"trj_det|{lokasi}|{u['name']}|{page}"))

        if btn_row:
            m.row(*btn_row)

    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"trj_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_trojan_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"trj_nav_rem|{lokasi}|{page+1}"))

    if nav: m.row(*nav)
    m.add(InlineKeyboardButton(f"🔙 KEMBALI KE DASHBOARD", callback_data=f"monitor_{lokasi}"))
    
    try: bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=m)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("trj_nav_rem"))
def nav_trojan(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, page = call.data.split("|")
        render_trojan_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    except: pass

# ==========================================
#  HANDLER DETAIL POP-UP TROJAN
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("trj_det"))
def detail_trojan(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, user, page = call.data.split("|")
    except: return

    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    from datetime import datetime
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        # Ambil Expired dan Password (UUID) Trojan dari server
        cmd = f"""
        exp_raw=$(grep "#! {user} " /etc/xray/config.json | awk '{{print $3}}')
        [ -z "$exp_raw" ] && exp_raw="UNKNOWN"
        
        # Coba cari password Trojan dari config.json
        uuid=$(grep -A 10 "#! {user} " /etc/xray/config.json | grep '"password":' | cut -d'"' -f4 | head -1)
        [ -z "$uuid" ] && uuid="UNKNOWN"
        
        echo "$exp_raw|$uuid"
        """
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_output = stdout.read().decode("utf-8").strip()
        client.close()
        
        exp_date_str = "UNKNOWN"
        uuid_str = "UNKNOWN"
        
        if "|" in raw_output:
            parts = raw_output.split("|")
            exp_date_str = parts[0]
            uuid_str = parts[1]

        # Format Tanggal
        if exp_date_str != "UNKNOWN":
            try:
                exp_obj = datetime.strptime(exp_date_str, "%Y-%m-%d")
                exp_date_str = exp_obj.strftime("%d %b %Y")
            except: pass

        domain_server = target.get('domain', target['ip'])
        limit = 2
        
        link_ws = "Password Tidak Ditemukan"
        link_grpc = "Password Tidak Ditemukan"
        
        if uuid_str != "UNKNOWN":
            link_ws = gen_trojan_link(user, domain_server, uuid_str, "ws")
            link_grpc = gen_trojan_link(user, domain_server, uuid_str, "grpc")

        harga = HARGA_TROJAN[lokasi]["user"] if lokasi in HARGA_TROJAN else 0

        reply_msg = f"""
========================================
🐎 <b>DETAIL AKUN TROJAN PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{user}</code>
Domain    : <code>{domain_server}</code>
Port TLS  : 443
Password  : <code>{uuid_str}</code>
Network   : WS / gRPC
Path WS   : /trojan
Service   : trojan-grpc

🔗 <b>LINK TROJAN WS</b>
<code>{link_ws}</code>

🔗 <b>LINK TROJAN GRPC</b>
<code>{link_grpc}</code>

📋 <b>INFORMASI TAMBAHAN</b>
Expired : <code>{exp_date_str}</code>
Quota   : Unlimited
Limit IP: <code>{limit} Device</code>

========================================
💰 Harga: Rp {harga:,}
========================================
<i>Silakan pilih tindakan di bawah ini:</i>
"""
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton(f"🗑️ HAPUS AKUN INI", callback_data=f"trj_del_rem|{lokasi}|{user}|{page}"))
        m.add(InlineKeyboardButton("🔙 KEMBALI KE LIST TROJAN", callback_data=f"trj_nav_rem|{lokasi}|{page}"))
        
        bot.edit_message_text(reply_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)

@bot.callback_query_handler(func=lambda call: call.data.startswith("trj_del_rem"))
def del_trojan(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except: return
        
    cmd = f"""
    sed -i "/^### {user} /d" /etc/trojan/.trojan.db
    sed -i "\|#! {user} |,\|}}|d" /etc/xray/config.json
    rm -f /etc/kyt/limit/trojan/ip/{user}
    rm -f /etc/trojan/{user}*
    systemctl restart xray
    """
    
    eksekusi_remote(lokasi, cmd)
    bot.answer_callback_query(call.id, f"✅ {user} Dihapus dari sistem!", show_alert=True)
    render_trojan_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
        
