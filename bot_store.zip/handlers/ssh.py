import telebot
import json
import paramiko
import os
import time
import datetime
from datetime import timedelta
from bot_init import bot
from config import ADMIN_ID
from database import get_user_data, add_balance, save_vpn_created
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# ======================================================
# 1. KONFIGURASI HARGA (Sesuai Config Anda)
# ======================================================
HARGA_SSH = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":   {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}

# ======================================================
# 2. KONFIGURASI SERVER (DATA BARU)
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "aws": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore aws", 
        "domain": "aws.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.net"
    }
}

# ======================================================
# SISTEM LIMIT TRIAL SSH (DATABASE JSON SEDERHANA)
# ======================================================
TRIAL_DB_FILE = "trial_history.json"

def load_trial_data():
    if not os.path.exists(TRIAL_DB_FILE):
        return {}
    with open(TRIAL_DB_FILE, 'r') as f:
        try: return json.load(f)
        except: return {}

def save_trial_data(data):
    with open(TRIAL_DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def check_trial_limit(user_id, role):
    is_owner = str(user_id) == str(ADMIN_ID) or 'owner' in str(role).lower()
    if is_owner:
        return True, "" # Owner bebas limit

    data = load_trial_data()
    user_str = str(user_id)

    if user_str in data:
        last_trial_str = data[user_str]['waktu']
        last_trial_date = datetime.datetime.strptime(last_trial_str, "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()

        if 'reseller' in str(role).lower():
            # Limit Reseller: 1 Hari (24 Jam)
            batas_waktu = last_trial_date + timedelta(days=1)
            if now < batas_waktu:
                sisa = batas_waktu - now
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                menit = sisa_detik // 60
                return False, f"⚠️ Limit Reseller: Anda sudah membuat trial. Coba lagi dalam {jam} jam {menit} menit."
        else:
            # Limit User Biasa: 3 Hari (72 Jam)
            batas_waktu = last_trial_date + timedelta(days=3)
            if now < batas_waktu:
                sisa = batas_waktu - now
                hari = sisa.days
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                return False, f"⚠️ Limit User: Anda hanya bisa trial 1x dalam 3 hari. Coba lagi dalam {hari} hari {jam} jam."

    return True, ""

def record_trial(user_id, username_telegram, username_ssh):
    data = load_trial_data()
    data[str(user_id)] = {
        "tg_username": username_telegram,
        "ssh_username": username_ssh,
        "waktu": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_trial_data(data)

# ======================================================
# HELPER: EKSEKUSI BASH (UPDATED FOR ZIVPN SYNC)
# ======================================================
def create_ssh_native(lokasi, username, password, days):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan di database bot."

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        # Hitung Tanggal Expired
        date_obj = datetime.date.today() + timedelta(days=days)
        exp_date = date_obj.strftime("%Y-%m-%d")
        
        # PERBAIKAN KONEKSI PARAMIKO
        client.connect(
            hostname=target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15, 
            banner_timeout=200, 
            look_for_keys=False, 
            allow_agent=False
        )
        
        client.get_transport().set_keepalive(10)
        cmd = f"""
        if id "{username}" &>/dev/null; then
            echo "ERROR: User {username} sudah ada!"
        else
            # 1. Buat User System
            useradd -e "{exp_date}" -s /bin/false -M "{username}" && \\
            echo "{username}:{password}" | chpasswd && \\
            
            # 2. Inject ke ZIVPN Config
            if [ -f /etc/zivpn/config.json ]; then
                if ! jq -e ".auth.config | index(\\"{username}\\")" /etc/zivpn/config.json > /dev/null; then
                    jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && \\
                    mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                fi
            fi && \\

            # 3. Restart Service ZiVPN
            systemctl restart zivpn && \\
            
            # 4. Indikator Sukses
            echo "SUCCESS"
            
            # 5. Log Database
            echo "### {username} {exp_date} {password}" >> /etc/ssh/.ssh.db 2>/dev/null
        fi
        """
        
        stdin, stdout, stderr = client.exec_command(cmd, timeout=45, get_pty=True)
        output = stdout.read().decode().strip()
        err_output = stderr.read().decode().strip() 
        client.close()

        if "SUCCESS" in output: 
            return True, f"Berhasil dibuat sampai {exp_date}"
        elif "ERROR" in output:
            return False, "Username sudah terpakai di server."
        else:
            return False, f"System Error:\n{err_output if err_output else output}"
            
    except paramiko.AuthenticationException:
        return False, "Gagal Login VPS: Password server salah!"
    except paramiko.SSHException as e:
        return False, f"SSH Error: Koneksi ditolak oleh server. ({e})"
    except Exception as e:
        return False, f"Koneksi Timeout/Error: {str(e)}"

# ======================================================
# HELPER: EKSEKUSI BASH UNTUK TRIAL (MENGGUNAKAN 'at')
# ======================================================
def create_ssh_trial_native(lokasi, username, password, minutes):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan di database bot."

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            hostname=target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15, 
            banner_timeout=200, 
            look_for_keys=False, 
            allow_agent=False
        )
        
        client.get_transport().set_keepalive(10)
        
        cmd = f"""
        if id "{username}" &>/dev/null; then
            echo "ERROR: User {username} sudah ada!"
        else
            # 1. Buat User System (Tanpa Expired Date)
            useradd -s /bin/false -M "{username}" && \\
            echo "{username}:{password}" | chpasswd && \\
            
            # 2. Inject ke ZIVPN Config
            if [ -f /etc/zivpn/config.json ]; then
                if ! jq -e ".auth.config | index(\\"{username}\\")" /etc/zivpn/config.json > /dev/null; then
                    jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && \\
                    mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                fi
            fi && \\

            # 3. Restart Service ZiVPN
            systemctl restart zivpn && \\
            
            # 4. JADWALKAN AUTO DELETE
            cat << 'EOF' | at now + {minutes} minutes
userdel -f "{username}"
if [ -f /etc/zivpn/config.json ]; then
    jq --arg u "{username}" 'del(.auth.config[] | select(. == $u))' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp
    mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
fi
systemctl restart zivpn
EOF

            # 5. Indikator Sukses
            echo "SUCCESS"
        fi
        """
        
        stdin, stdout, stderr = client.exec_command(cmd, timeout=45, get_pty=True)
        output = stdout.read().decode().strip()
        err_output = stderr.read().decode().strip()
        client.close()

        if "SUCCESS" in output: 
            return True, f"Berhasil dibuat untuk {minutes} menit ke depan."
        elif "ERROR" in output:
            return False, "Username sudah terpakai di server."
        else:
            return False, f"System Error (Pastikan 'at' sudah diinstall di VPS):\n{err_output if err_output else output}"
            
    except Exception as e:
        return False, f"Koneksi Timeout/Error: {str(e)}"

# ======================================================
# HANDLER: BATAL INPUT
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data == "cancel_input_ssh")
def cancel_ssh_input(call):
    bot.clear_step_handler_by_chat_id(chat_id=call.message.chat.id)
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_user"))
    bot.send_message(call.message.chat.id, "❌ Transaksi dibatalkan.", reply_markup=markup)

# ======================================================
# HANDLER UTAMA: INPUT MANUAL SSH (PREMIUM)
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_ssh_"))
def start_create_ssh_manual(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    try: lokasi = call.data.split("_")[2] 
    except: return bot.answer_callback_query(call.id, "❌ Error Data")

    if lokasi not in HARGA_SSH: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

    user_data = get_user_data(user_id)
    if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

    saldo = int(user_data.get('balance', 0))
    role = str(user_data.get('role', 'user')).lower()

    if 'reseller' in role or 'owner' in role or str(user_id) == str(ADMIN_ID):
        harga = HARGA_SSH[lokasi]["reseller"]
        tipe_user = "RESELLER ⚡"
    else:
        harga = HARGA_SSH[lokasi]["user"]
        tipe_user = "MEMBER 👤"
    
    is_owner = str(user_id) == str(ADMIN_ID) or 'owner' in role

    if not is_owner and saldo < harga:
        kurang = harga - saldo
        msg_error = (
            f"⚠️ <b>SALDO TIDAK CUKUP</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"💸 <b>Harga Produk:</b> Rp {harga:,}\n"
            f"💰 <b>Saldo Anda:</b> Rp {saldo:,}\n"
            f"❌ <b>Kekurangan:</b> Rp {kurang:,}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"<i>Silakan lakukan pengisian saldo terlebih dahulu.</i>"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        return bot.send_message(chat_id, msg_error, parse_mode='HTML', reply_markup=markup)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="cancel_input_ssh"))

    msg = bot.send_message(chat_id, 
        f"💎 <b>ORDER SSH {lokasi.upper()}</b>\n"
        f"👤 <b>Status:</b> {tipe_user}\n"
        f"💸 <b>Harga:</b> Rp {harga:,}\n"
        f"💰 <b>Saldo:</b> Rp {saldo:,}\n\n"
        f"👇 <b>Masukkan Username Baru:</b>\n"
        f"<i>(Ketik username, misal: user01)</i>", 
        parse_mode='HTML',
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, step_get_password, lokasi, harga, is_owner)

def step_get_password(message, lokasi, harga, is_owner):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    
    if not username.isalnum():
        msg = bot.reply_to(message, "❌ Username harus huruf/angka (tanpa spasi). Masukkan lagi:")
        return bot.register_next_step_handler(msg, step_get_password, lokasi, harga, is_owner)

    msg = bot.reply_to(message, "🔑 <b>Masukkan Password:</b>", parse_mode='HTML')
    bot.register_next_step_handler(msg, execute_create_ssh, lokasi, harga, is_owner, username)

def execute_create_ssh(message, lokasi, harga, is_owner, username):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    password = message.text.strip()
    user_id = message.from_user.id
    days = 30        
    limit = 3        

    if not is_owner:
        user_data = get_user_data(user_id)
        current_saldo = int(user_data.get('balance', 0))
        if current_saldo < harga:
            return bot.reply_to(message, "❌ Transaksi Gagal: Saldo tidak cukup saat memproses.")

    loading = bot.reply_to(message, "⏳ <b>Memproses di Server...</b>", parse_mode='HTML')

    sukses, response = create_ssh_native(lokasi, username, password, days)

    if sukses:
        server_info = SERVER_DATA[lokasi]
        domain_server = server_info.get('domain', server_info['ip'])
        exp_date_str = (datetime.date.today() + timedelta(days=days)).strftime("%d %b %Y")

        try:
            save_vpn_created(user_id, username, "SSH", exp_date_str, password, domain_server)
        except Exception as e:
            print(f"⚠️ Gagal simpan riwayat VPN: {e}")
        
        sisa_saldo = "Unlimited"
        if not is_owner:
            import time
            ref_id = f"SSH-{int(time.time())}"
            add_balance(
                user_id, 
                -harga, 
                f"Beli SSH {lokasi.upper()}", 
                ref_id=ref_id, 
                destination=username
            )
            sisa_saldo = f"Rp {int(get_user_data(user_id).get('balance', 0)):,}"

        try: bot.delete_message(message.chat.id, loading.message_id)
        except: pass
        
        reply_msg = (
            f"========================================\n"
            f"🌟 <b>AKUN SSH PREMIUM ({lokasi.upper()})</b>\n"
            f"========================================\n\n"
            f"🔹 <b>INFORMASI AKUN</b>\n"
            f"Username: <code>{username}</code>\n"
            f"Domain  : <code>{domain_server}</code>\n"
            f"Password: <code>{password}</code>\n"
            f"Expired : <code>{exp_date_str}</code>\n"
            f"IP Limit: <code>{limit} Device</code>\n\n"
            f"🔹 <b>PORT INFO</b>\n"
            f"SSH WS       : 80, 2082\n"
            f"SSH SSL      : 443\n"
            f"UDP GW       : 7100-7300\n"
            f"ZiVPN        : <code>{username}</code>\n\n"
            f"🔹UDP Costum   : \n"
            f"<code>{domain_server}</code>:1-65535@<code>{username}</code>:<code>{password}</code>\n\n"
            f"🔹ZIVPN FORMAT :\n"
            f"UDP SERVER   : <code>{domain_server}</code>\n"
            f"UDP PASSWORD : <code>{username}</code>\n\n"
            f"========================================\n\n"
            f"🔗 <b>PAYLOAD CONTOH</b>\n"
            f"<code>GET / HTTP/1.1[crlf]Host: {domain_server}[crlf]Upgrade: websocket[crlf][crlf]</code>\n\n"
            f"========================================\n"
            f"💰 Harga: Rp {harga:,}\n"
            f"💰 Sisa Saldo: {sisa_saldo}\n"
            f"========================================"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="switch_user"))
        bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
    else:
        bot.delete_message(message.chat.id, loading.message_id)
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        bot.reply_to(message, f"❌ <b>GAGAL MEMBUAT AKUN:</b>\n\n{response}\n\n<i>Silakan coba lagi atau hubungi Admin.</i>", parse_mode='HTML', reply_markup=markup)

# ======================================================
# HANDLER UTAMA: INPUT MANUAL SSH (TRIAL)
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("trial_ssh_"))
def menu_durasi_trial(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    user_data = get_user_data(user_id)
    if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")
    role = str(user_data.get('role', 'user')).lower()

    bisa_trial, pesan_error = check_trial_limit(user_id, role)
    if not bisa_trial:
        return bot.answer_callback_query(call.id, pesan_error, show_alert=True)

    try: lokasi = call.data.split("_")[2] 
    except: return bot.answer_callback_query(call.id, "❌ Error Data")

    if lokasi not in HARGA_SSH: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("⏱ 30 Menit", callback_data=f"runtrial_{lokasi}_30"),
        InlineKeyboardButton("⏱ 1 Jam", callback_data=f"runtrial_{lokasi}_60"),
        InlineKeyboardButton("⏱ 2 Jam", callback_data=f"runtrial_{lokasi}_120"),
        InlineKeyboardButton("⏱ 3 Jam", callback_data=f"runtrial_{lokasi}_180"),
        InlineKeyboardButton("❌ BATAL", callback_data="switch_user")
    )

    bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL SSH {lokasi.upper()}</b>\n\nSilakan pilih durasi trial yang ingin digunakan:", 
        parse_mode='HTML', 
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("runtrial_"))
def start_input_trial(call):
    chat_id = call.message.chat.id
    data = call.data.split("_")
    lokasi = data[1]
    durasi_menit = int(data[2])

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="cancel_input_ssh"))

    msg = bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL SSH {lokasi.upper()} ({durasi_menit} Menit)</b>\n\n"
        f"👇 <b>Masukkan Username Trial Baru:</b>\n"
        f"<i>(Ketik username, misal: coba01)</i>", 
        parse_mode='HTML',
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, step_get_password_trial, lokasi, durasi_menit)

def step_get_password_trial(message, lokasi, durasi_menit):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    
    if not username.isalnum():
        msg = bot.reply_to(message, "❌ Username harus huruf/angka (tanpa spasi). Masukkan lagi:")
        return bot.register_next_step_handler(msg, step_get_password_trial, lokasi, durasi_menit)

    msg = bot.reply_to(message, "🔑 <b>Masukkan Password Trial:</b>", parse_mode='HTML')
    bot.register_next_step_handler(msg, execute_create_trial, lokasi, durasi_menit, username)

def execute_create_trial(message, lokasi, durasi_menit, username):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    password = message.text.strip()
    user_id = message.from_user.id
    
    tg_username = message.from_user.username if message.from_user.username else "Tidak_ada"

    loading = bot.reply_to(message, "⏳ <b>Mempersiapkan Akun Trial di Server...</b>", parse_mode='HTML')

    sukses, response = create_ssh_trial_native(lokasi, username, password, durasi_menit)

    try: bot.delete_message(message.chat.id, loading.message_id)
    except: pass

    if sukses:
        record_trial(user_id, tg_username, username)

        server_info = SERVER_DATA[lokasi]
        domain_server = server_info.get('domain', server_info['ip'])
        limit_ip = 3 
        
        jam = durasi_menit // 60
        sisa_menit = durasi_menit % 60
        waktu_teks = f"{jam} Jam {sisa_menit} Menit" if jam > 0 else f"{durasi_menit} Menit"

        reply_msg = (
            f"========================================\n"
            f"🆓 <b>AKUN TRIAL SSH ({lokasi.upper()})</b>\n"
            f"========================================\n\n"
            f"◆ <b>INFORMASI AKUN</b>\n"
            f"Username: <code>{username}</code>\n"
            f"Domain  : <code>{domain_server}</code>\n"
            f"Password: <code>{password}</code>\n"
            f"Limit IP: <code>{limit_ip} Device</code>\n"
            f"Durasi  : <code>{waktu_teks} (Otomatis Dihapus)</code>\n\n"
            f"◆ <b>PORT INFO</b>\n"
            f"SSH WS     : 80, 2082\n"
            f"SSH SSL    : 443\n"
            f"UDP GW     : 7100-7300\n"
            f"ZiVPN      : <code>{username}</code>\n\n"
            f"◆ <b>UDP Costum</b>   : \n"
            f"<code>{domain_server}</code>:1-65535@<code>{username}</code>:<code>{password}</code>\n\n"
            f"◆ <b>ZIVPN FORMAT</b> :\n"
            f"UDP SERVER   : <code>{domain_server}</code>\n"
            f"UDP PASSWORD : <code>{username}</code>\n\n"
            f"========================================\n\n"
            f"🔗 <b>PAYLOAD CONTOH</b>\n"
            f"<code>GET / HTTP/1.1[crlf]Host: {domain_server}[crlf]Upgrade: websocket[crlf][crlf]</code>\n\n"
            f"========================================\n"
            f"⚠️ <i>Akun ini adalah trial dan akan otomatis terhapus dari server setelah batas waktu habis.</i>\n"
            f"========================================"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="switch_user"))
        bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        bot.reply_to(message, f"❌ <b>GAGAL MEMBUAT TRIAL:</b>\n\n{response}\n\n<i>Silakan coba lagi.</i>", parse_mode='HTML', reply_markup=markup)