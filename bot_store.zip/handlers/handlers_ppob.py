# handlers/handlers_ppob.py
import telebot
import requests
import json
import time
import logging
import re
from datetime import datetime
from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot.apihelper import ApiTelegramException
from database import get_user_data, add_balance, update_saldo, increment_reseller_trx, save_ppob_transaction, update_transaction_status, check_transaction_exists
from config import ADMIN_ID
import sqlite3

try:
    from orderkuota_service import get_okeconnect_price, request_orderkuota_trx, check_orderkuota_status
except ImportError:
    # Dummy handler jika file tidak ada
    def get_okeconnect_price(): return []
    def request_orderkuota_trx(a,b,c): return {'success': False, 'msg': 'Module Missing'}
    def check_orderkuota_status(a,b,c=None,d=None): return "Error Module"

# Konfigurasi Logger
logger = logging.getLogger(__name__)
MARKUP_MEMBER = 3000
MARKUP_RESELLER = 2000

# ==========================================
#  HELPER UTILS
# ==========================================
def sensor_pesan_error(pesan_asli):
    """Mengubah pesan error sensitif menjadi pesan umum."""
    pesan_lower = str(pesan_asli).lower()
    kata_terlarang = ["saldo", "balance", "not enough", "insufficient", "kurang", "limit", "deposit", "cutoff"]
    if any(word in pesan_lower for word in kata_terlarang):
        return "⚠️ Sedang Gangguan Pusat (Maintenance)"
    return pesan_asli

def parse_respon_server(raw_text):
    """Memecah respon server jadi SN, Harga, dan Info Sisa"""
    data = {'sn': '-', 'harga': '0', 'info_sisa': '-'}
    try:
        pattern = r"SN:\s*(.*?)\.\s*Hrg\s*([\d\.]+)\s*(.*)"
        match = re.search(pattern, raw_text, re.IGNORECASE | re.DOTALL)
        if match:
            data['sn'] = match.group(1).strip()
            data['harga'] = match.group(2).strip()
            data['info_sisa'] = match.group(3).strip()
        else:
            simple_sn = re.search(r"SN:\s*(.*?)(?:\.|$)", raw_text, re.IGNORECASE)
            if simple_sn: data['sn'] = simple_sn.group(1).strip()
    except Exception as e:
        print(f"Regex Error: {e}")
    return data

def format_sn_pln(sn_raw):
    """Memecah format SN PLN yang bersambung dengan garis miring menjadi baris yang rapi"""
    if not sn_raw or sn_raw == "-":
        return "<code>-</code>"
        
    if "/" not in sn_raw:
        # Jika bukan token PLN, kembalikan seperti biasa
        return f"<code>{sn_raw}</code>"
        
    parts = [p.strip() for p in sn_raw.split("/")]
    
    # Bagian pertama pasti Token utamanya
    token = parts[0]
    
    info_tambahan = ""
    if len(parts) > 1:
        nama = parts[1]
        info_tambahan += f"\n👤 <b>Nama :</b> <code>{nama}</code>"
    if len(parts) > 3:
        tarif_daya = f"{parts[2]} / {parts[3]}"
        info_tambahan += f"\n⚡ <b>Daya :</b> <code>{tarif_daya}</code>"
    elif len(parts) == 3: 
        info_tambahan += f"\n⚡ <b>Daya :</b> <code>{parts[2]}</code>"
        
    if len(parts) > 4:
        kwh = parts[4]
        info_tambahan += f"\n🔋 <b>Jml KWH:</b> <code>{kwh}</code>"
        
    return f"<code>{token}</code>{info_tambahan}"

def format_info_server(raw_text):
    """Fungsi khusus merapikan teks Info Server yang berantakan"""
    # 1. Hapus info saldo & harga asli (Keamanan)
    text = re.sub(r"Saldo\s+[\d\.,\s\-=\+]+(@\d{2}:\d{2})?", "", str(raw_text), flags=re.IGNORECASE)
    text = re.sub(r"(?i)(hrg|harga)\s*[:=]?\s*[\d\.,]+", "", text).strip()
    
    # 2. HAPUS DUPLIKAT SN DARI INFO SERVER (Karena sudah tampil rapi di atas)
    # Ini otomatis melenyapkan teks panjang bersambung dan peringatan "Trx ke-2" di ujungnya
    text = re.sub(r"(?i)SN:\s*.*", "", text).strip()
    
    # 3. Rapikan kode T# dan R# menjadi baris baru yang rapi
    text = re.sub(r"T#(\d+)", r"🔹 <b>Trx Pusat:</b> <code>\1</code>\n", text)
    text = re.sub(r"R#([\w\-]+)", r"🔹 <b>Ref Pusat:</b> <code>\1</code>\n", text)
    
    # 4. Beri baris baru & icon untuk keyword tertentu
    text = re.sub(r"(sudah pernah)", r"\n⚠️ \1", text, flags=re.IGNORECASE)
    text = re.sub(r"(status Sukses|status Gagal|status Pending|status Proses)", r"\n📊 \1", text, flags=re.IGNORECASE)
    
    # 5. Bersihkan titik atau koma "nganggur" yang tertinggal
    text = text.rstrip("., ")
    
    # 6. Bersihkan spasi ganda yang tersisa
    text = re.sub(r"\n\s+", "\n", text).strip()
    
    return text

def log_act(user, action, detail=""):
    try:
        username = user.username if user.username else "NoUsername"
        print(f"📝 [AKTIVITAS] ID:{user.id} | @{username} | {action} | {detail}")
    except:
        print(f"📝 [AKTIVITAS] ID:{user.id} | {action}")

# ==========================================
#  1. MENU UTAMA: PPOB
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "ppob_menu" or call.data == "ppob_orderkuota")
def ppob_okeconnect_main(call):
    try:
        log_act(call.from_user, "MEMBUKA MENU PPOB")
        bot.answer_callback_query(call.id)
        
        uid = call.from_user.id
        user = get_user_data(uid)
        if user:
            raw_balance = user.get('balance', 0)
            balance = int(raw_balance if raw_balance is not None else 0)
        else:
            balance = 0
        
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("🔴 TELKOMSEL", callback_data="oke_op|TELKOMSEL|1"),
            InlineKeyboardButton("🟡 INDOSAT", callback_data="oke_op|INDOSAT|1"),
            InlineKeyboardButton("🔵 XL", callback_data="oke_op|XL|1"),
            InlineKeyboardButton("👻 BY.U", callback_data="oke_op|BYU|1")
        )
        markup.row(
            InlineKeyboardButton("🟣 AXIS", callback_data="oke_op|AXIS|1"),
            InlineKeyboardButton("3️⃣ TRI", callback_data="oke_op|THREE|1"),
            InlineKeyboardButton("📶 SMARTFREN", callback_data="oke_op|SMARTFREN|1")
        )
        markup.row(
            InlineKeyboardButton("💡 PLN TOKEN", callback_data="oke_op|PLN|1"),
            InlineKeyboardButton("💎 GAMES", callback_data="oke_op|GAME|1"),
            InlineKeyboardButton("💳 E-MONEY", callback_data="oke_op|DANA|1")
        )
        markup.row(InlineKeyboardButton("🔍 CEK VALIDASI AKUN", callback_data="oke_op|DIGITAL_CHECK|1"))
        markup.row(InlineKeyboardButton("📱 PULSA (ALL OPR)", callback_data="oke_op|PULSA|1"))
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU UTAMA", callback_data="switch_owner"))
        
        msg = (f"🏪 <b>PPOB DIGITAL (MURAH)</b>\n"
               f"━━━━━━━━━━━━━━━━━━━━━\n"
               f"💰 <b>Saldo:</b> <code>Rp {balance:,}</code>\n"
               f"👇 <i>Pilih operator layanan:</i>")
    
        try:
            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except ApiTelegramException as e:
            if "message is not modified" in str(e):
                pass 
            else:
                logger.error(f"Error Oke Main (API): {e}")

    except Exception as e: 
        logger.error(f"Error Oke Main: {e}")

# ==========================================
#  2. LIST PRODUK PPOB
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("oke_op|"))
def ppob_oke_list_product(call):
    try:
        parts = call.data.split("|")
        operator, page = parts[1].upper(), int(parts[2])
        
        if page == 1: log_act(call.from_user, "MELIHAT HARGA PPOB", operator)
        
        all_data = get_okeconnect_price()
        if not all_data:
            return bot.edit_message_text("❌ Gagal mengambil data harga.", call.message.chat.id, call.message.message_id, reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_menu")))

        # --- LOGIKA FILTERING ---
        filtered = []
        for p in all_data:
            raw_kode = str(p.get('kode', '')).upper()
            raw_ket = str(p.get('keterangan', '')).upper()
            raw_kat = str(p.get('kategori', '')).upper()
            
            if operator == "DIGITAL_CHECK":
                if raw_kode.startswith("CEK"): filtered.append(p)
            elif operator == "PULSA":
                if "PULSA" in raw_kat or "PULSA" in raw_ket: filtered.append(p)
            elif operator == "PLN":
                if "PLN" in raw_kode: filtered.append(p)
            elif operator == "BYU":
                if "BYU" in raw_kat or "BY.U" in raw_kat or "BYU" in raw_ket: filtered.append(p)
            elif operator == "DANA":
                if any(x in raw_kat or x in raw_ket for x in ["DANA", "OVO", "GOPAY", "SHOPEE", "LINKAJA", "EMONEY", "BRIZZI", "TAPCASH", "FLAZZ"]):
                    filtered.append(p)
            else:
                if operator in (raw_kat + raw_ket): filtered.append(p)

        filtered.sort(key=lambda x: x['keterangan'])

        # Pagination
        LIMIT = 10
        total_items = len(filtered)
        total_pages = (total_items + LIMIT - 1) // LIMIT if total_items > 0 else 1
        page = max(1, min(page, total_pages))
        current_items = filtered[(page-1)*LIMIT : page*LIMIT]
        
        udata = get_user_data(call.from_user.id)
        markup_val = MARKUP_RESELLER if udata and str(udata.get('role')).lower() == 'reseller' else MARKUP_MEMBER
        display_op = "CEK VALIDASI AKUN" if operator == "DIGITAL_CHECK" else operator
        
        msg = f"✨ <b>DAFTAR PRODUK: {display_op}</b>\n📄 Halaman: {page} / {total_pages}\n━━━━━━━━━━━━━━━━━━━━━━\n\n"
        markup = InlineKeyboardMarkup(row_width=5)
        btns = []
        
        if not current_items:
            msg += "❌ <b>Produk tidak ditemukan / Kosong.</b>"
        else:
            for i, item in enumerate(current_items, 1):
                price = int(item['harga']) + markup_val
                raw_status = str(item.get('status', '1')) 
                
                if raw_status == '1':
                    status_icon, status_text = "🟢", "Tersedia"
                    btn_label = str(i)
                    cb_data = f"okebuy|{item['kode']}|{price}|{operator}"
                else:
                    status_icon, status_text = "🔴", "Gangguan"
                    btn_label, cb_data = "❌", "ignore"

                msg += f"<b>[{i}] {item['keterangan']}</b>\n🆔 <b>CODE:</b> <code>{item['kode']}</code>\n💰 <b>HARGA:</b> <b>Rp {price:,}</b>\n📊 <b>STATUS:</b> {status_icon} <i>{status_text}</i>\n─────────────────────\n"
                btns.append(InlineKeyboardButton(btn_label, callback_data=cb_data))
        
        markup.add(*btns)
        nav = []
        if page > 1: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"oke_op|{operator}|{page-1}"))
        nav.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
        if page < total_pages: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"oke_op|{operator}|{page+1}"))
        
        markup.row(*nav)
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="ppob_menu"))
        
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    
    except Exception as e:
        if "message is not modified" not in str(e):
            print(f"Error Edit Message: {e}")

# ==========================================
#  5. HANDLER INPUT DESTINASI
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("okebuy|"))
def ppob_input_dest(call):
    parts = call.data.split("|")
    kode, harga, op = parts[1], parts[2], parts[3]
    log_act(call.from_user, "KLIK BELI", f"{op} - {kode}")
    
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    if op.upper() == "PLN": prompt_text = "💡 <b>Kirim ID Pelanggan / Nomor Meter:</b>"
    else: prompt_text = "📱 <b>Kirim Nomor HP / Tujuan:</b>"

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"oke_op|{op}|1"))

    msg = bot.send_message(call.message.chat.id, f"🛒 <b>BELI {op}</b>\n📦 Kode: <code>{kode}</code>\n💰 Harga: Rp {int(harga):,}\n\n👇 {prompt_text}", parse_mode='HTML', reply_markup=markup)
    bot.register_next_step_handler(msg, oke_confirm, kode, harga, op)

def oke_confirm(message, kode, harga, op):
    try:
        dest = message.text.strip()
        if op != "DIGITAL_CHECK" and not dest.isdigit() and not dest.isalnum():
            msg = bot.reply_to(message, "❌ <b>Format Salah!</b>\nHanya boleh angka/huruf tanpa spasi.")
            return bot.register_next_step_handler(msg, oke_confirm, kode, harga, op)

        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("✅ BELI SEKARANG", callback_data=f"okefix|{kode}|{harga}|{dest}"))
        markup.add(InlineKeyboardButton("❌ BATAL", callback_data="ppob_menu"))

        bot.reply_to(message, f"⚠️ <b>KONFIRMASI PEMBELIAN</b>\n━━━━━━━━━━━━━━━━━━━━━━\n📦 Kode: {kode}\n🎯 Tujuan: <code>{dest}</code>\n💸 Harga: <b>Rp {int(harga):,}</b>\n━━━━━━━━━━━━━━━━━━━━━━\nPastikan data benar!", parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        logger.error(f"Error oke_confirm: {e}")
        bot.reply_to(message, "❌ Terjadi kesalahan sistem. Ulangi dari awal.")

# ==========================================
#  6. EKSEKUSI PEMBELIAN API
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("okefix|"))
def ppob_execute_oke(call):
    try:
        # 1. Parsing Data
        _, kode, harga, dest = call.data.split("|")
        harga, uid = int(harga), call.from_user.id
        
        try:
            bot.edit_message_text("⏳ <b>Sedang Memproses Transaksi...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        except:
            bot.send_message(call.message.chat.id, "⏳ <b>Sedang Memproses Transaksi...</b>", parse_mode='HTML')

        # 2. Generate Ref ID
        ref_id = f"TRX{int(time.time())}{uid}"
        deskripsi_trx = f"BELI {kode}"

        # 3. Potong Saldo User
        if str(uid) == str(ADMIN_ID): 
            berhasil_potong = True
        else: 
            berhasil_potong = update_saldo(
                uid, 
                -harga, 
                description=deskripsi_trx, 
                ref_id=ref_id, 
                dest=dest
            )

        if not berhasil_potong:
            try:
                return bot.edit_message_text("❌ <b>TRANSAKSI GAGAL</b>\nSaldo tidak mencukupi.", call.message.chat.id, call.message.message_id, parse_mode='HTML')
            except:
                return bot.send_message(call.message.chat.id, "❌ <b>TRANSAKSI GAGAL</b>\nSaldo tidak mencukupi.", parse_mode='HTML')
        
        # 4. Request ke API
        try:
            res = request_orderkuota_trx(kode, dest, ref_id)
        except Exception as e:
            res = {'success': False, 'msg': f"Error System: {str(e)}"}

        markup = InlineKeyboardMarkup()
        
        # 5. Cek Hasil
        if res['success']:
            server_id = res.get('server_id', '')
            parsed = parse_respon_server(res['msg'])
            sn_info = parsed['sn'] if parsed['sn'] != '-' else "Sedang Proses"
            
            # Update Status Database
            update_transaction_status(ref_id, "sukses", sn_info)
            
            status_header = "🎉 <b>TRANSAKSI SUKSES</b> 🎉" if "sukses" in res['msg'].lower() else "⏳ <b>TRANSAKSI DIPROSES</b> ⏳"
            display_harga = f"Rp {harga:,}".replace(",", ".")
            
            clean_msg = format_info_server(res['msg'])
            formatted_sn = format_sn_pln(parsed['sn'])
            
            # DESAIN STRUK SUKSES / PROSES
            msg_body = (
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🆔 <b>RefID :</b> <code>{ref_id}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🎟️ <b>SN/Token:</b>\n"
                f"{formatted_sn}\n\n"
                f"📦 <b>Produk :</b> {kode}\n"
                f"📱 <b>Tujuan :</b> <code>{dest}</code>\n"
                f"💰 <b>Harga  :</b> {display_harga}\n\n"
                f"📝 <b>Info Server:</b>\n"
                f"<i>{clean_msg}</i>"
            )
            
            markup.add(InlineKeyboardButton("🔄 Refresh Status", callback_data=f"cs|{server_id}|{ref_id}|{kode}|{dest}"))
            print(f"✅ [TRANSAKSI PPOB] SUKSES API | Ref:{ref_id}")

        else:
            # GAGAL -> REFUND
            status_header = "❌ <b>TRANSAKSI GAGAL</b> ❌"
            
            if str(uid) != str(ADMIN_ID):
                update_saldo(
                    uid, 
                    harga, 
                    description=f"REFUND {kode}", 
                    ref_id=f"REF-{ref_id}",
                    dest=dest
                )
            
            update_transaction_status(ref_id, "gagal", res['msg'])
            pesan_aman = format_info_server(sensor_pesan_error(res['msg']))
            
            # DESAIN STRUK GAGAL
            msg_body = (
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🆔 <b>RefID :</b> <code>{ref_id}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📦 <b>Produk :</b> {kode}\n"
                f"📱 <b>Tujuan :</b> <code>{dest}</code>\n\n"
                f"📝 <b>Keterangan:</b>\n"
                f"<i>{pesan_aman}</i>\n\n"
                f"💰 <i>Saldo telah dikembalikan otomatis.</i>"
            )

        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU PPOB", callback_data="ppob_menu"))
        
        try:
            bot.edit_message_text(f"{status_header}\n{msg_body}", call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except:
            bot.send_message(call.message.chat.id, f"{status_header}\n{msg_body}", parse_mode='HTML', reply_markup=markup)

    except Exception as e:
        print(f"CRITICAL ERROR PPOB: {e}")
        bot.send_message(call.message.chat.id, "❌ Terjadi kesalahan sistem fatal. Hubungi Admin.")

# ==========================================
#  7. HANDLER REFRESH STATUS (INLINE)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("cs|"))
def ppob_refresh_status_v2(call):
    try:
        parts = call.data.split("|")
        server_id = parts[1] if len(parts) > 1 else ""
        ref_id = parts[2] if len(parts) > 2 else ""
        kode_produk_val = parts[3] if len(parts) > 3 else None
        nomor_tujuan_val = parts[4] if len(parts) > 4 else None
        
        raw_response = check_orderkuota_status(
            ref_id, 
            nomor_tujuan=nomor_tujuan_val,
            kode_produk=kode_produk_val,
            server_id=server_id
        )
        
        status_lower = raw_response.lower()
        header = "⏳ <b>SEDANG DIPROSES</b> ⏳"
        is_failed = False
        
        if "sukses" in status_lower: 
            header = "🎉 <b>TRANSAKSI SUKSES</b> 🎉"
        elif any(x in status_lower for x in ["gagal", "salah", "stok habis", "tidak ditemukan"]): 
            header = "❌ <b>TRANSAKSI GAGAL</b> ❌"
            is_failed = True
        
        parsed = parse_respon_server(raw_response)
        if parsed['sn'] == '-' and "SN" in raw_response:
             try:
                 match_pln = re.search(r"SN\s*/?\s*Ref\s*[:\s]*([^\s]+)", raw_response, re.IGNORECASE)
                 if match_pln: parsed['sn'] = match_pln.group(1)
             except: pass

        from database import get_transaction_status, get_trx_amount_by_ref_id
        current_status = get_transaction_status(ref_id)
        
        refund_msg = ""
        # JIKA SUKSES
        if parsed['sn'] not in ['-', '', None] and "sukses" in status_lower:
             if current_status != 'sukses':
                 update_transaction_status(ref_id, "sukses", parsed['sn'])
        
        # JIKA GAGAL (DAN BELUM DI-REFUND)
        elif is_failed and current_status != 'gagal':
             update_transaction_status(ref_id, "gagal", raw_response[:50])
             amount = get_trx_amount_by_ref_id(ref_id)
             if amount > 0:
                 add_balance(
                     call.from_user.id, 
                     amount, 
                     f"REFUND {ref_id}", 
                     ref_id=f"REF-{ref_id}"
                 )
                 refund_msg = "\n\n💰 <i>Saldo telah dikembalikan otomatis.</i>"

        safe_response = format_info_server(raw_response)
        formatted_sn = format_sn_pln(parsed['sn'])
        
        # DESAIN STRUK REFRESH STATUS
        msg = (
            f"{header}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 <b>RefID :</b> <code>{ref_id}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🎟️ <b>SN/Token:</b>\n"
            f"{formatted_sn}\n\n"
            f"📦 <b>Produk :</b> {kode_produk_val if kode_produk_val else '-'}\n"
            f"📱 <b>Tujuan :</b> <code>{nomor_tujuan_val if nomor_tujuan_val else '-'}</code>\n\n"
            f"📝 <b>Info Server:</b>\n"
            f"<i>{safe_response}</i>"
            f"{refund_msg}\n\n"
            f"🕒 <i>Last Check: {datetime.now().strftime('%H:%M:%S')}</i>"
        )
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔄 Refresh Status", callback_data=call.data))
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="ppob_menu"))
        
        try: bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except ApiTelegramException as e: 
            if "message is not modified" in str(e): bot.answer_callback_query(call.id, "✅ Data belum berubah.")
            else: bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)
            
    except Exception as e:
        print(f"❌ Error CS V2: {e}")
        bot.answer_callback_query(call.id, "Gagal update status.")

# ==========================================
#  8. SEARCH PRODUK
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "search_product_menu")
def search_product_start(call):
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="menu_user")) 
    msg = bot.send_message(call.message.chat.id, "🔍 <b>PENCARIAN PRODUK</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nSilakan ketik <b>Nama Produk</b>, <b>Provider</b>, atau <b>Kode</b> yang dicari.\n\n<i>Contoh: 'Telkomsel 10', 'Dana 20', 'PLN', 'Pubg'</i>", parse_mode='HTML', reply_markup=markup)
    bot.register_next_step_handler(msg, process_search_product)

def get_search_results_data(keyword):
    results = []
    keyword = keyword.lower()
    
    try:
        oke_data = get_okeconnect_price() 
        if oke_data:
            for p in oke_data:
                if keyword in f"{p['kode']} {p['keterangan']} {p['kategori']}".lower():
                    results.append({'source': 'OKE', 'code': p['kode'], 'name': p['keterangan'], 'price': int(p['harga']), 'status': str(p['status']), 'callback': f"okebuy|{p['kode']}|{int(p['harga'])}|OKE"})
    except: pass
    
    results.sort(key=lambda x: x['price'])
    return results

def process_search_product(message):
    keyword = message.text.strip()
    if len(keyword) < 2: return bot.reply_to(message, "❌ Kata kunci terlalu pendek. Minimal 2 karakter.")
    loading = bot.reply_to(message, "⏳ <b>Sedang mencari...</b>", parse_mode='HTML')
    results = get_search_results_data(keyword)
    try: bot.delete_message(message.chat.id, loading.message_id)
    except: pass
    show_search_results(message.chat.id, keyword, results, 1, message_id=None)

@bot.callback_query_handler(func=lambda call: call.data.startswith("srcnav|"))
def search_pagination_handler(call):
    _, keyword, page_str = call.data.split("|")
    results = get_search_results_data(keyword)
    show_search_results(call.message.chat.id, keyword, results, int(page_str), message_id=call.message.message_id)

def show_search_results(chat_id, keyword, results, page, message_id=None):
    LIMIT = 10
    total_items = len(results)
    total_pages = (total_items + LIMIT - 1) // LIMIT if total_items > 0 else 1
    page = max(1, min(page, total_pages))
    current_items = results[(page-1)*LIMIT : page*LIMIT]
    
    user = get_user_data(chat_id)
    markup_price = MARKUP_RESELLER if user and str(user.get('role')).lower() == 'reseller' else MARKUP_MEMBER

    msg = f"🔍 <b>HASIL PENCARIAN: '{keyword}'</b>\n📄 Halaman {page} dari {total_pages}\n📊 Ditemukan: {total_items} produk\n━━━━━━━━━━━━━━━━━━━━━━\n"
    markup = InlineKeyboardMarkup(row_width=5)
    nums_btns = []

    if not current_items: 
        msg += "❌ <i>Produk tidak ditemukan.</i>"
    else:
        for i, item in enumerate(current_items, 1):
            final_price = item['price'] + markup_price
            
            is_available = item['status'] in ['1', 'available', 'active']
            stat_text = "✅ Ready" if is_available else "❌ Gangguan"

            msg += f"<b>{i}. {item['name']}</b>\n   🏷 <code>{item['code']}</code>\n   💰 <b>Rp {final_price:,}</b> | {stat_text}\n   ────────────────\n"
            
            btn_cb = item['callback'].replace(f"|{item['price']}|", f"|{final_price}|") if is_available else "ignore"
            nums_btns.append(InlineKeyboardButton(str(i) if is_available else "❌", callback_data=btn_cb))
    
    markup.add(*nums_btns)
    nav_btns = []
    if page > 1: nav_btns.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"srcnav|{keyword}|{page-1}"))
    nav_btns.append(InlineKeyboardButton(f"📑 {page}/{total_pages}", callback_data="ignore"))
    if page < total_pages: nav_btns.append(InlineKeyboardButton("Next ➡️", callback_data=f"srcnav|{keyword}|{page+1}"))
    markup.row(*nav_btns)
    markup.add(InlineKeyboardButton("🔍 CARI KATA KUNCI LAIN", callback_data="search_product_menu"))
    markup.add(InlineKeyboardButton("🔙 TUTUP", callback_data="menu_user"))

    if message_id:
        try: bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=markup)
        except: bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=markup)
    else: bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=markup)

# ==========================================
# 9. HANDLER CEK STATUS VIA CHAT (MANUAL)
# ==========================================
@bot.message_handler(func=lambda message: message.text.upper().startswith("TRX") or message.text.upper().startswith("R#"))
def handle_cek_transaksi_manual_ppob(message):
    input_text = message.text.strip()
    
    loading = bot.reply_to(message, "⏳ <b>Sedang Melacak Transaksi...</b>", parse_mode='HTML')

    try:
        if check_orderkuota_status:
            hasil_teks = check_orderkuota_status(input_text)
            hasil_teks = format_info_server(hasil_teks)
        else:
            hasil_teks = "❌ Modul Cek Status tidak aktif."

        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("❌ TUTUP / KEMBALI", callback_data="ppob_menu"))

        try: bot.delete_message(message.chat.id, loading.message_id) 
        except: pass
        
        bot.reply_to(
            message, 
            f"📊 <b>HASIL CEK TRANSAKSI</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<b>Input:</b> <code>{input_text}</code>\n\n"
            f"📝 <b>Respon Server:</b>\n"
            f"<i>{hasil_teks}</i>", 
            parse_mode='HTML', 
            reply_markup=markup
        )

    except Exception as e:
        try: bot.delete_message(message.chat.id, loading.message_id)
        except: pass
        bot.reply_to(message, f"❌ Error: {str(e)}")