import imaplib
import email
import re
import time
import threading
from email.header import decode_header
import sqlite3
import os

# --- KONFIGURASI EMAIL JAGO ---
EMAIL_AKUN = "dedenirwansyah1222@gmail.com"
EMAIL_PASS = "onty xdiy ngcf uqme"

# --- LOKASI DATABASE BOT ---
DB_PATH = "/root/bot_store/store_data.db"

def ambil_nominal_dari_teks(teks):
    # Hapus tag HTML jika ada (karena payload email bisa berupa HTML)
    teks = re.sub(r'<[^>]+>', ' ', teks)
    # Hapus spasi, koma, enter, dan karakter tersembunyi
    teks_bersih = teks.replace(' ', '').replace(',', '').replace('\n', '').replace('\r', '').replace('\xa0', '')
    
    # Cari semua pola 'rp' diikuti angka (meminimalisir salah ambil)
    matches = re.findall(r'rp\.?(\d{1,3}(?:\.\d{3})*)', teks_bersih, re.IGNORECASE)
    
    if matches:
        # Konversi semua kecocokan ke integer
        nominals = [int(m.replace('.', '')) for m in matches]
        # Ambil nominal terbesar untuk menghindari salah tangkap angka kecil (misal Bunga Rp 5 atau Biaya Admin Rp 0)
        return max(nominals)
        
    return 0

def update_saldo_jago(nominal_unik):
    # ----------------------------------------------------
    # 1. CEK KE DATABASE BOT PERTAMA (bot-store)
    # ----------------------------------------------------
    try:
        conn1 = sqlite3.connect("/root/bot_store/store_data.db")
        c1 = conn1.cursor()
        c1.execute("""
            SELECT id, user_id, amount, ref_id 
            FROM transactions 
            WHERE description = 'deposit_jago' AND UPPER(status) = 'PENDING' AND amount = ?
        """, (nominal_unik,))
        trx1 = c1.fetchone()
        
        if trx1:
            trx_id_db, user_id, amount, ref_id = trx1
            
            # HANYA UBAH STATUS JADI 'paid'
            c1.execute("UPDATE transactions SET status = 'paid' WHERE id = ?", (trx_id_db,))
            
            conn1.commit()
            conn1.close()
            print(f"[BOT-1 STORE] ✅ BERHASIL DETEKSI JAGO! Status TRX diubah jadi 'paid' untuk User ID {user_id}")
            return True
        conn1.close()
    except Exception as e:
        print(f"[BOT-1 STORE] Error DB: {e}")

    # ----------------------------------------------------
    # 2. JIKA GAGAL, CEK KE DATABASE BOT KEDUA (kyt)
    # ----------------------------------------------------
    try:
        conn2 = sqlite3.connect("/usr/bin/kyt/database.db")
        c2 = conn2.cursor()
        c2.execute("""
            SELECT id, user_id, amount, trx_id 
            FROM transactions 
            WHERE description = 'deposit_jago' AND UPPER(status) = 'PENDING' AND amount = ?
        """, (nominal_unik,))
        trx2 = c2.fetchone()
        
        if trx2:
            trx_id_db, user_id, amount, trx_id = trx2
            c2.execute("SELECT saldo FROM users WHERE user_id = ?", (user_id,))
            res = c2.fetchone()
            saldo_awal = res[0] if res else 0
            saldo_baru = saldo_awal + amount
            
            c2.execute("UPDATE transactions SET status = 'SUCCESS', description = 'Deposit Otomatis Bank Jago' WHERE id = ?", (trx_id_db,))
            c2.execute("UPDATE users SET saldo = ? WHERE user_id = ?", (saldo_baru, user_id))
            conn2.commit()
            conn2.close()
            print(f"[BOT-2 KYT] ✅ SUKSES! Saldo Rp {amount} masuk ke User ID {user_id}")
            return True
        conn2.close()
    except Exception as e:
        print(f"[BOT-2 KYT] Error DB: {e}")

    # ----------------------------------------------------
    # JIKA TIDAK ADA DI KEDUA BOT
    # ----------------------------------------------------
    print(f"[JAGO-DB] ⚠️ Nominal Rp {nominal_unik} tidak ditemukan di KEDUA bot.")
    return False

def cek_mutasi_jago():
    print("[JAGO] Memulai Background Task Pengecekan Bank Jago...")
    while True:
        try:
            mail = imaplib.IMAP4_SSL("imap.gmail.com")
            mail.login(EMAIL_AKUN, EMAIL_PASS)
            mail.select("inbox")

            # Cari email masuk dari Jago yang belum dibaca
            status, messages = mail.search(None, '(UNSEEN FROM "noreply@jago.com")')
            
            if status == "OK" and messages[0]:
                email_ids = messages[0].split()
                print(f"[JAGO] Ditemukan {len(email_ids)} mutasi Jago baru!")

                for e_id in email_ids:
                    res, msg_data = mail.fetch(e_id, "(RFC822)")
                    for response_part in msg_data:
                        if isinstance(response_part, tuple):
                            msg = email.message_from_bytes(response_part[1])
                            body = ""
                            
                            if msg.is_multipart():
                                for part in msg.walk():
                                    # Prioritaskan text/plain agar parsing angka lebih akurat tanpa elemen HTML
                                    if part.get_content_type() == "text/plain":
                                        body += part.get_payload(decode=True).decode(errors='ignore') + " "
                                    elif part.get_content_type() == "text/html" and not body:
                                        body += part.get_payload(decode=True).decode(errors='ignore') + " "
                            else:
                                body = msg.get_payload(decode=True).decode(errors='ignore')

                            body_lower = body.lower()
                            
                            # PASTIKAN EMAIL UANG MASUK & ABAIKAN BUNGA KANTONG / PAJAK
                            if ("menerima sejumlah uang" in body_lower or "uang masuk" in body_lower or "berhasil menerima" in body_lower) and "bunga" not in body_lower and "pajak" not in body_lower:
                                nominal = ambil_nominal_dari_teks(body_lower)
                                
                                if nominal > 0:
                                    print(f"[JAGO] Memproses Dana Masuk: Rp {nominal}")
                                    update_saldo_jago(nominal)
                                else:
                                    print("[JAGO] Nominal tidak berhasil terbaca dari isi email.")
                            else:
                                pass 

                    # Tandai email sudah dibaca
                    mail.store(e_id, '+FLAGS', '\\Seen')

            mail.logout()
            
        except Exception as e:
            print(f"[JAGO ERROR] Koneksi terputus/Error: {e}")

        time.sleep(60)

def start_jago_checker():
    t = threading.Thread(target=cek_mutasi_jago)
    t.daemon = True
    t.start()