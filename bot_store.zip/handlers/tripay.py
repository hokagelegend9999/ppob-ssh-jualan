import requests
import json

BASE_URL = "https://id.hokagelegend.net:81"

def get_saldo():
    return {'success': True, 'status': True, 'data': {'username': 'Hokage Store', 'balance': 0}}

def get_metode_pembayaran():
    return [
        {"kode": "QRIS", "nama": "QRIS (Semua E-Wallet)"},
        {"kode": "OVO", "nama": "OVO E-Wallet"}
    ]

def create_deposit(telegram_id, nominal, metode="QRIS"):
    try:
        print(f"\n[TRIPAY] Mencoba Topup: {nominal} via {metode}")
        url = f"{BASE_URL}/checkout.php"
        payload = {'nama_paket': 'Topup', 'harga_paket': nominal, 'telegram_id': telegram_id, 'method': metode, 'json_response': 1}
        r = requests.post(url, data=payload, timeout=15)
        res = r.json()
        if res.get('success'): res['status'] = True
        return res
    except Exception as e:
        return {"status": False, "message": str(e)}

def check_status(reference):
    try:
        url = f"{BASE_URL}/checkout.php?action=check_status&reference={reference}"
        r = requests.get(url, timeout=10)
        res = r.json()
        
        print(f"[DEBUG TRIPAY] Cek Status Ref {reference}: {res}")
        
        if res.get('success') == True:
            data = res.get('data', {})
            if isinstance(data, list) and len(data) > 0: data = data[0]
            
            status_tripay = data.get('status', 'UNPAID')
            mapped_status = 'success' if status_tripay == 'PAID' else 'pending'
            
            return {
                'status': True,
                'success': True,
                'data': {
                    'status': mapped_status,
                    'paidAmount': data.get('amount', 0),
                    'reference': data.get('reference', reference),
                    'customer': data.get('customer_name', 'Tidak Diketahui') # <- Ini tambahan untuk ID Telegram
                }
            }
        else:
            return {'status': False, 'message': res.get('message', 'Gagal dari API')}
            
    except Exception as e:
        print(f"[TRIPAY ERROR] Check Status: {e}")
        return {'status': False, 'message': str(e)}

def req_instant_deposit(id_deposit, action='true'):
    return {"status": False, "message": "Instant deposit tidak didukung."}
    
def create_transfer(ref_id, kode_bank, nomor_akun, nama_pemilik, nominal, note="Withdraw Admin"):
    return {"status": False, "message": "Withdraw belum diaktifkan."}
