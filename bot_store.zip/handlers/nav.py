import telebot
from telebot import types # Tambahan untuk markup pagination
from telebot.apihelper import ApiTelegramException 
import math # Tambahan untuk kalkulasi halaman
import os
from bot_init import bot, TEMP_VIEW
from config import ADMIN_ID
# PENTING: Tambahkan get_transaction_detail di import database Anda
from database import add_user, get_user_data, get_user_transaction_history, get_transaction_detail
from reports import handle_report_reseller, generate_excel_report

# ======================================================
# 1. IMPORT MENU (UPDATE: ganti indo2 jadi sg)
# ======================================================
from menus import (
    menu_user, 
    menu_admin, 
    menu_reseller, 
    menu_user_indo,
    menu_user_sg,
    menu_user_aws    
)
from utils_helper import get_back_markup

# ==========================================
# 2. FUNGSI BANTUAN: GENERATE KONTEN MENU
# ==========================================
def generate_menu_content(uid, first_name, username):
    """
    Fungsi pintar untuk menentukan Teks & Tombol berdasarkan Role & View Mode.
    """
    # 1. Ambil Data User Real dari Database
    user = get_user_data(uid)
    if not user:
        saldo = 0
        role = 'user'
    else:
        try:
            saldo = int(user.get('balance', 0))
            role = str(user.get('role', 'user')).lower()
        except:
            saldo = 0
            role = 'user'

    # 2. Cek Apakah User ini OWNER ASLI?
    is_real_owner = (str(uid) == str(ADMIN_ID)) or ('owner' in role)

    # 3. Tentukan Mode Tampilan (View Mode)
    if uid in TEMP_VIEW:
        view_mode = TEMP_VIEW[uid] # 'user', 'reseller', 'owner'
    else:
        view_mode = 'owner' if is_real_owner else role

    # 4. LOGIKA PEMBUATAN PESAN & TOMBOL
    
    # --- KASUS A: TAMPILAN OWNER (GOD MODE) ---
    if is_real_owner and (view_mode == 'owner' or 'owner' in view_mode):
        saldo_display = "♾️ UNLIMITED (Owner)"
        text = (
            f"👑 <b>PANEL OWNER (GOD MODE)</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👋 Halo, Bos <b>{first_name}</b>!\n"
            f"🆔 ID Akun: <code>{uid}</code>\n"
            f"👤 Username: @{username}\n"
            f"💰 <b>Saldo: {saldo_display}</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            f"🛡️ <i>Sebagai Owner, Anda memiliki akses penuh dan saldo tak terbatas.\n"
            f"Gunakan panel di bawah untuk mengelola bot.</i>"
        )
        markup = menu_admin(uid)

    # --- KASUS B: PREVIEW MODE (Owner melihat tampilan User) ---
    elif is_real_owner and view_mode == 'user':
        saldo_display = "♾️ UNLIMITED (Preview)"
        text = (
            f"👑 <b>PREVIEW MODE (OWNER)</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👋 Halo Bos <b>{first_name}</b>\n"
            f"💰 <b>Saldo: {saldo_display}</b>\n\n"
            f"<i>(Ini adalah tampilan menu yang dilihat Member biasa.)</i>\n"
            f"<i>(Tombol 'Daftar Reseller' aman, tidak akan memotong saldo Anda.)</i>"
        )
        markup = menu_user('user', is_owner_preview=True)

    # --- KASUS C: PREVIEW MODE (Owner melihat tampilan Reseller) ---
    elif is_real_owner and view_mode == 'reseller':
        saldo_display = "♾️ UNLIMITED (Preview)"
        
        # Teks Benefit untuk Preview
        benefit_reseller = (
            "<b>💎 KEUNTUNGAN RESELLER:</b>\n"
            "• 🚀 <b>SSH & Xray:</b> Harga User 13k ➡️ Harga Reseller <b>8k</b> <i>(Untung 5k/akun)</i>\n"
            "• 📱 <b>PULSA:</b> Harga User 10k ➡️ Harga Reseller <b>8k</b> <i>(Untung 2k/transaksi)</i>\n\n"
            "⚠️ <i>Pertahankan saldo Anda agar status Reseller tetap aktif!</i>"
        )
        
        text = (
            f"👑 <b>PREVIEW MODE (OWNER)</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👋 Halo Bos <b>{first_name}</b>\n"
            f"⚡ <b>Status: RESELLER VIEW</b>\n"
            f"💰 <b>Saldo: {saldo_display}</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            f"{benefit_reseller}"
        )
        markup = menu_reseller(is_owner_preview=True)

    # --- KASUS D: USER ASLI / RESELLER ASLI ---
    else:
        saldo_display = f"Rp {saldo:,}".replace(",", ".")
        
        # Header Teks & Pesan Tambahan
        if 'reseller' in view_mode:
            title = "⚡ RESELLER AREA"
            extra_msg = (
            "<b>💎 KEUNTUNGAN RESELLER:</b>\n"
            "• 🚀 <b>SSH & Xray:</b> Harga User 13k ➡️ Harga Reseller <b>8k</b> <i>(Untung 5k/akun)</i>\n"
            "• 📱 <b>PULSA:</b> Harga User 10k ➡️ Harga Reseller <b>8k</b> <i>(Untung 2k/transaksi)</i>\n\n"
            "⚠️ <i>Pertahankan saldo Anda agar status Reseller tetap aktif!</i>"
            )
        else:
            title = "👤 MEMBER AREA"
            extra_msg = (
                "🚀 <b>TINGKATKAN TRANSAKSI ANDA!</b>\n"
                "Segera lakukan ISI SALDO (Topup) agar bisa bertransaksi.\n\n"
                "🔥 <b>Peluang Keuntungan Reseller:</b>\n"
                "• 🌐 <b>SSH & Xray:</b> Harga User 13k ➡️ Harga Reseller <b>8k</b>\n"
                "• ⚡ <b>PULSA:</b> Harga User 10k ➡️ Harga Reseller <b>8k</b>\n\n"
                "🎁 <i>Semakin sering bertransaksi, semakin dekat kesempatan mendapatkan status dan benefit eksklusif di HOKAGE LEGEND!</i>"
            )

        text = (
            f"<b>{title}</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"👋 Selamat Datang, <b>{first_name}</b>!\n"
            f"🆔 ID Akun: <code>{uid}</code>\n"
            f"👤 Username: @{username}\n"
            f"💰 <b>Saldo Aktif: {saldo_display}</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"📢 <b>UPDATE FITUR: TRIAL SSH GRATIS!</b>\n"
            f"Kini tersedia fitur Trial SSH (30 Menit - 3 Jam) untuk test speed, ping, & payload.\n\n"
            f"<b>Aturan Limit Trial:</b>\n"
            f"🔹 <b>Member Biasa:</b> 1x setiap 3 Hari\n"
            f"🔹 <b>Reseller:</b> 1x setiap 1 Hari\n"
            f"<i>(Akun trial akan otomatis terhapus dari server saat waktu habis)</i>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            f"{extra_msg}"
        )

        # Markup Logic
        if 'reseller' in role: 
             if view_mode == 'user':
                 markup = menu_user(role, is_reseller_preview=True)
             else:
                 markup = menu_reseller()
        else:
            markup = menu_user(role)

    return text, markup

# --- 1. MENU UTAMA (/start atau /menu) ---
@bot.message_handler(commands=['start', 'menu'])
def start(m):
    add_user(m.from_user.id, m.from_user.first_name, m.from_user.username)
    
    # Reset tampilan ke mode asli saat /start
    if m.from_user.id in TEMP_VIEW: 
        del TEMP_VIEW[m.from_user.id]
        
    txt, mark = generate_menu_content(m.from_user.id, m.from_user.first_name, m.from_user.username)
    
    # BUNGKUS DENGAN TRY-EXCEPT AGAR ANTI CRASH
    try:
        bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=mark)
    except Exception as e:
        print(f"⚠️ Abaikan: Gagal mengirim menu start karena jaringan Telegram terputus - {e}")


# --- 2. SWITCH ROLE (Lihat Sebagai...) ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('switch_'))
def switch(call):
    try: bot.answer_callback_query(call.id)
    except: pass
    
    uid = call.from_user.id
    user_data = get_user_data(uid)
    
    # --- PERBAIKAN: Sabuk pengaman jika user_data kosong ---
    role = user_data.get('role', 'user') if user_data else 'user'
    
    # Logika Switching
    if str(uid) == str(ADMIN_ID) or 'owner' in role:
        if "reseller" in call.data and "back" not in call.data: 
            TEMP_VIEW[uid] = "reseller"
        elif "user" in call.data: 
            TEMP_VIEW[uid] = "user"
        else: # switch_owner
            if uid in TEMP_VIEW: del TEMP_VIEW[uid]

    elif role == 'reseller':
        if "user" in call.data:
            TEMP_VIEW[uid] = "user"
        elif "reseller" in call.data: # switch_reseller_back
            if uid in TEMP_VIEW: del TEMP_VIEW[uid]
            
    # Generate Tampilan Baru
    txt, mark = generate_menu_content(uid, call.from_user.first_name, call.from_user.username)
    
    try:
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, 
                              parse_mode='HTML', reply_markup=mark)
    except ApiTelegramException as e:
        if "message can't be edited" in str(e):
            pass # Ignore
        else:
            bot.send_message(call.message.chat.id, txt, parse_mode='HTML', reply_markup=mark)

# ======================================================
# HANDLER SUB-MENU (Folder Indo, SG, AWS)
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data in ["folder_sg", "folder_indo", "folder_aws"])
def sub_menu_handler(call):
    # Hilangkan icon loading (jam pasir) pada tombol
    try:
        bot.answer_callback_query(call.id)
    except:
        pass
    
    uid = call.from_user.id
    
    # Ambil data dan role user
    user_data = get_user_data(uid)
    current_role = user_data.get('role', 'user') if user_data else 'user'
    
    # Jika admin sedang memakai fitur "Lihat Sebagai", sesuaikan rolenya
    if uid in TEMP_VIEW:
        current_role = TEMP_VIEW[uid]

    # --- LOGIKA MEMBUKA FOLDER SERVER ---
    if call.data == "folder_indo":
        markup = menu_user_indo(role=current_role)
        text = (
            "🇮🇩 <b>SERVER INDONESIA</b>\n"
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            "Berikut layanan Server Indonesia:\n"
            "<i>Ping rendah & cocok untuk game/streaming lokal.</i>\n\n"
            "🎉 <b>UPDATE LAYANAN: SEMUA FITUR TRIAL AKTIF! 🚀</b>\n"
            "Kini Anda bisa menguji performa server secara gratis untuk layanan <b>SSH, VMESS, VLESS, & TROJAN</b> sebelum membeli!\n\n"
            "📌 <b>Ketentuan Limit Pembuatan:</b>\n"
            "🔹 <b>Member:</b> Maksimal 1x Trial / 3 Hari.\n"
            "🔹 <b>Reseller:</b> Maksimal 1x Trial / 1 Hari (24 Jam).\n\n"
            "💡 <i>Silakan klik tombol <b>⏱ TRIAL</b> pada masing-masing layanan di bawah ini untuk mencoba!</i>"
        )

    elif call.data == "folder_aws":
        markup = menu_user_aws(role=current_role)
        text = (
            "🇸🇬 <b>SERVER SINGAPORE (AWS)</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <b>Performa Premium & Anti Suspend</b>\n"
            "📌 <b>Silakan pilih layanan yang tersedia di bawah ini:</b>"
        )

    elif call.data == "folder_sg":
        markup = menu_user_sg(role=current_role)
        text = (
            "🇸🇬 <b>SERVER SINGAPORE (REGULAR)</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <b>Performa Cepat & Stabil</b>\n"
            "📌 <b>Silakan pilih layanan yang tersedia di bawah ini:</b>"
        )
        
    else:
        # Fallback aman jika terjadi sesuatu
        markup = None
        text = "⚠️ Menu tidak ditemukan."

    # --- TAMPILKAN MENU BARU ---
    try:
        bot.edit_message_text(
            text, 
            call.message.chat.id, 
            call.message.message_id, 
            parse_mode='HTML', 
            reply_markup=markup
        )
    except Exception as e:
        # Jika gagal edit, hapus pesan lama dan kirim baru
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except:
            pass
        bot.send_message(call.message.chat.id, text, parse_mode='HTML', reply_markup=markup)

# --- 3. TOMBOL KEMBALI (Global Back & Menu User) ---
@bot.callback_query_handler(func=lambda call: call.data in ["menu_back", "menu_user", "switch_reseller", "back_to_main_menu"])
def back(call):
    try: bot.answer_callback_query(call.id)
    except: pass
    
    bot.clear_step_handler_by_chat_id(call.message.chat.id)
    
    txt, mark = generate_menu_content(call.from_user.id, call.from_user.first_name, call.from_user.username)
    
    try: 
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except: 
        pass
        
    bot.send_message(call.message.chat.id, txt, parse_mode='HTML', reply_markup=mark)

# ========================================================
# HANDLER LAPORAN & EXCEL (Posisinya disatukan agar Rapi)
# ========================================================
@bot.callback_query_handler(func=lambda call: call.data == "report")
def report_callback(call):
    bot.answer_callback_query(call.id) 
    handle_report_reseller(bot, call)       

@bot.callback_query_handler(func=lambda call: call.data == "download_excel")
def send_excel_callback(call):
    bot.answer_callback_query(call.id, "Sedang menyiapkan file Excel, mohon tunggu...")
    
    try:
        # Panggil fungsi generate dari reports.py
        file_path = generate_excel_report(call.from_user.id)
        
        # --- TAMBAHAN: Buat tombol Kembali ---
        markup_doc = types.InlineKeyboardMarkup()
        markup_doc.add(types.InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_reseller"))
        
        with open(file_path, 'rb') as f:
            bot.send_document(
                call.message.chat.id, 
                f, 
                caption="📊 <b>Laporan Penjualan Anda sudah siap!</b>\n\n<i>Silakan unduh atau bagikan file Excel di atas.</i>",
                parse_mode="HTML",
                reply_markup=markup_doc
            )
    except Exception as e:
        print(f"Gagal mengirim Excel: {e}")
        bot.send_message(call.message.chat.id, "⚠️ Gagal membuat dokumen. Silakan coba lagi.")
    finally:
        if 'file_path' in locals() and os.path.exists(file_path):
            os.remove(file_path)

# ==============================================================
# --- 4. RIWAYAT TRANSAKSI USER (PISAH PEMBELIAN & SALDO) ---
# ==============================================================
ITEMS_PER_PAGE = 8

# A. MENU PILIHAN JENIS RIWAYAT
@bot.callback_query_handler(func=lambda call: call.data == "history_user")
def user_hist_menu(call):
    try: bot.answer_callback_query(call.id)
    except: pass
    
    msg = (
        "<b>📜 MENU RIWAYAT TRANSAKSI</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Silakan pilih jenis riwayat yang ingin Anda lihat:"
    )
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🛍 RIWAYAT PEMBELIAN", callback_data="uhist_buy_1"),
        types.InlineKeyboardButton("💳 RIWAYAT SALDO", callback_data="uhist_bal_1")
    )
    markup.add(types.InlineKeyboardButton("🔙 KEMBALI KE MENU UTAMA", callback_data="back_to_main_menu"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except ApiTelegramException:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)


# B. LIST RIWAYAT BERDASARKAN FILTER (PAGINATION)
@bot.callback_query_handler(func=lambda call: call.data.startswith("uhist_"))
def user_hist_list(call):
    try: bot.answer_callback_query(call.id)
    except: pass

    parts = call.data.split('_')
    hist_type = parts[1] # 'buy' atau 'bal'
    page = int(parts[2]) if len(parts) > 2 else 1
    
    uid = call.from_user.id
    raw_hs = get_user_transaction_history(uid)
    
    # --- LOGIKA FILTERING OTOMATIS ---
    filtered_hs = []
    for h in raw_hs:
        desc = str(h[1]).lower()
        
        # Kata kunci yang mendandakan transaksi Saldo
        is_balance = any(kw in desc for kw in ["deposit", "saldo", "refund", "koreksi", "topup"])
        
        if hist_type == "bal" and is_balance:
            filtered_hs.append(h)
        elif hist_type == "buy" and not is_balance:
            filtered_hs.append(h)
            
    title_text = "PEMBELIAN" if hist_type == "buy" else "SALDO"
    
    if not filtered_hs:
        msg_hist = f"<b>📜 RIWAYAT {title_text} ANDA</b>\n━━━━━━━━━━━━━━━━━━━━\n📭 Belum ada riwayat {title_text.lower()}."
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 KEMBALI PILIH RIWAYAT", callback_data="history_user"))
        try: bot.edit_message_text(msg_hist, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        except: pass
        return

    total_pages = math.ceil(len(filtered_hs) / ITEMS_PER_PAGE)
    start_idx = (page - 1) * ITEMS_PER_PAGE
    end_idx = start_idx + ITEMS_PER_PAGE
    current_items = filtered_hs[start_idx:end_idx]

    msg_hist = f"<b>📜 RIWAYAT {title_text} ({page}/{total_pages})</b>\n"
    if hist_type == "buy":
        msg_hist += "<i>Klik tombol nomor di bawah untuk melihat detail akun/SN</i>\n"
    msg_hist += "━━━━━━━━━━━━━━━━━━━━\n\n"

    markup = types.InlineKeyboardMarkup(row_width=4)
    num_buttons = []
    
    for i, h in enumerate(current_items, start=start_idx + 1):
        date_str = str(h[0])
        prod_name = str(h[1])
        
        # Format angka menjadi + atau - agar intuitif
        try:
            amt = int(h[2])
            sign = "+" if amt > 0 else "-"
            price = f"{sign}Rp {abs(amt):,}".replace(",", ".")
        except:
            price = str(h[2])
            
        ref_id = str(h[8]) 

        msg_hist += f"{i}. <b>{prod_name}</b>\n   └ 📅 {date_str} | {price}\n"
        
        # Tombol angka hanya bisa diklik, memanggil trx_detail_
        num_buttons.append(types.InlineKeyboardButton(f"{i}", callback_data=f"trx_detail_{ref_id}"))

    markup.add(*num_buttons)

    nav_buttons = []
    if page > 1:
        nav_buttons.append(types.InlineKeyboardButton("⬅️ Prev", callback_data=f"uhist_{hist_type}_{page-1}"))
    if page < total_pages:
        nav_buttons.append(types.InlineKeyboardButton("Next ➡️", callback_data=f"uhist_{hist_type}_{page+1}"))
    
    if nav_buttons:
        markup.row(*nav_buttons)
    
    markup.row(types.InlineKeyboardButton("🔙 KEMBALI PILIH RIWAYAT", callback_data="history_user"))

    try:
        bot.edit_message_text(msg_hist, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except ApiTelegramException:
        pass


# ==============================================================
# --- 5. DETAIL TRANSAKSI (FULL & FIX PPOB) ---
# ==============================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("trx_detail_"))
def view_trx_detail(call):
    try: bot.answer_callback_query(call.id)
    except: pass
    
    ref_id = call.data.replace("trx_detail_", "")
    
    import sqlite3
    import re
    import datetime
    
    try:
        conn = sqlite3.connect("store_data.db")
        c = conn.cursor()
        res = c.execute("""
            SELECT date, description, amount, sn, destination, status 
            FROM transactions 
            WHERE ref_id=?
        """, (ref_id,)).fetchone()
        
        if not res:
            conn.close()
            bot.answer_callback_query(call.id, "❌ Detail tidak ditemukan.", show_alert=True)
            return
            
        date_str, desc, amount, sn, dest, status = res
        desc_lower = str(desc).lower()
        
        trx_type = "ppob" 
        if "deposit" in desc_lower or "saldo" in desc_lower or "koreksi" in desc_lower or "refund" in desc_lower:
            trx_type = "deposit"
        elif any(vpn in desc_lower for vpn in ["vless", "vmess", "trojan", "ssh", "udp", "xray"]):
            trx_type = "vpn"

        d = {
            'type': trx_type,
            'product_name': desc,
            'price': abs(int(amount)),
            'date': date_str,
            'status': str(status).upper(),
            'sn': sn,
            'destination': dest,
            'vpn_username': '-', 'vpn_password': '-', 'vpn_domain': '-', 'vpn_protocol': '-', 'vpn_expired': '-'
        }

        if trx_type == "vpn":
            # 1. Coba ambil dari Deskripsi dulu
            match = re.search(r'\((.*?)\)', desc)
            if match:
                username_vpn = match.group(1).strip()
            # 2. Fallback: Ambil dari Tujuan (Destination)
            elif dest and str(dest).strip() != '-':
                username_vpn = str(dest).strip()
            else:
                username_vpn = None

            if username_vpn:
                d['vpn_username'] = username_vpn
                
                try:
                    d_str = date_str.split(" ")[0] 
                    created_dt = datetime.datetime.strptime(d_str, "%Y-%m-%d")
                    exp_dt = created_dt + datetime.timedelta(days=30)
                    d['vpn_expired'] = exp_dt.strftime("%d %b %Y")
                except Exception:
                    d['vpn_expired'] = "30 Hari (Cek VPS)"

                vpn_res = c.execute("""
                    SELECT protocol, exp_date, password, domain, created_at 
                    FROM vpn_history WHERE username=? ORDER BY id DESC LIMIT 1
                """, (username_vpn,)).fetchone()
                
                if vpn_res:
                    d['vpn_protocol'] = vpn_res[0]
                    if vpn_res[1] and vpn_res[1] != '-': d['vpn_expired'] = vpn_res[1]
                    d['vpn_password'] = vpn_res[2]
                    d['vpn_domain'] = vpn_res[3]
                    if vpn_res[4] and vpn_res[4] != '-':
                        d['date'] = vpn_res[4]

        conn.close()
        
    except Exception as e:
        print(f"Error detail menu user: {e}")
        bot.answer_callback_query(call.id, "Terjadi kesalahan.", show_alert=True)
        return

    # === TAMPILAN OUTPUT BERDASARKAN JENIS TRANSAKSI ===
    trx_type = d.get('type')
    prod_name = d.get('product_name', 'Produk')
    price = f"Rp {int(d.get('price', 0)):,}".replace(",", ".")
    date_str = d.get('date', '-')
    status = d.get('status', 'SUKSES')

    if trx_type == "deposit":
        detail_text = (
            f"<b>💳 DETAIL DEPOSIT / SALDO</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📝 <b>Keterangan:</b> {prod_name}\n"
            f"💰 <b>Nominal:</b> {price}\n"
            f"📅 <b>Tanggal:</b> {date_str}\n"
            f"📊 <b>Status:</b> {status}\n"
            f"🧾 <b>Ref ID:</b> <code>{ref_id}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"<i>Saldo Anda telah otomatis diperbarui.</i>"
        )

    elif trx_type == "vpn":
        v_user = d.get('vpn_username', '-')
        v_pass = d.get('vpn_password', '-')
        v_dom = d.get('vpn_domain', '-')
        v_prot = str(d.get('vpn_protocol', 'VPN')).upper()
        v_exp = d.get('vpn_expired', '-')
        
        if v_pass == '-':
            acc_info = (f"👤 <b>Username:</b> <code>{v_user}</code>\n⚠️ <i>Data UUID/Password tidak tersimpan karena ini transaksi lama.</i>")
        else:
            is_indo = "id." in str(v_dom).lower() or "indo" in str(prod_name).lower()
            
            ip_vps = "103.150.226.10" if is_indo else "IP_VPS_SG_ANDA"
            isp_vps = "AS133800 PT Biznet Gio Nusantara" if is_indo else "ISP_SG_ANDA"
            loc_vps = "Jakarta" if is_indo else "Singapore"
            ns_vps = "ns.hokagelegend.web.id"
            pub_key = "7fbd1f8aa0abfe15a7903e837f78aba39cf61d36f183bd604daa2fe4ef3b7b59" if is_indo else "PUB_KEY_SG_ANDA"

            if v_prot == "SSH":
                acc_info = (
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🔵 <b>DETAIL AKUN SSH & ZIVPN</b> 🔵\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➤ <b>Domain</b>        : <code>{v_dom}</code>\n"
                    f"➤ <b>Username</b>      : <code>{v_user}</code>\n"
                    f"➤ <b>Password</b>      : <code>{v_pass}</code>\n"
                    f"➤ <b>ZIVPN Token</b>   : <code>{v_user}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➤ <b>Limit Ip</b>       : 2 Device\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➤ <b>IP</b>             : <code>{ip_vps}</code>\n"
                    f"➤ <b>Limit Quota</b>   : 0 GB\n"
                    f"➤ <b>Host Slowdns</b>  : <code>{ns_vps}</code>\n"
                    f"➤ <b>Isp</b>            : {isp_vps}\n"
                    f"➤ <b>Location</b>       : {loc_vps}\n"
                    f"➤ <b>Port OpenSSH</b>  : 443, 80, 22\n"
                    f"➤ <b>Port DNS</b>      : 443, 53, 22\n"
                    f"➤ <b>Port SSH UDP</b>  : 1-65535\n"
                    f"➤ <b>Port ZIVPN</b>    : 5667\n"
                    f"➤ <b>Port Dropbear</b> : 443, 109\n"
                    f"➤ <b>Port SSH WS</b>   : 80, 8080, 8880, 2082\n"
                    f"➤ <b>Port OVPN SSL</b> : 443\n"
                    f"➤ <b>Port OVPN TCP</b> : 443, 1194\n"
                    f"➤ <b>Port OVPN UDP</b> : 2200\n"
                    f"➤ <b>BadVPN UDP</b>    : 7100, 7200, 7300\n"
                    f"➤ <b>Pub Key</b>       : <code>{pub_key}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>𝗣𝗮𝘆𝗹𝗼𝗮𝗱 𝗪𝗲𝗯𝘀𝗼𝗰𝗸𝗲𝘁 :</b>\n"
                    f"<code>GET / HTTP/1.1[crlf]host: {v_dom}[crlf]Upgrade: Websocket[crlf][crlf]</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>𝗣𝗮𝘆𝗹𝗼𝗮𝗱 𝗦𝗦𝗟 / 𝗧𝗟𝗦 :</b>\n"
                    f"<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {v_dom}[crlf]Upgrade: websocket[crlf][crlf]</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>OVPN Download</b>   : https://{v_dom}:81/\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>Berakhir Pada</b>      : <code>{v_exp}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<i>TERIMAKASIH SUDAH BERBELANJA DI HOKAGE LEGEND</i>"
                )
            elif v_prot == "VMESS":
                import json
                import base64
                def gen_vmess(net, port, path, tls):
                    j = {
                        "v": "2", "ps": v_user, "add": v_dom, "port": str(port), 
                        "id": v_pass, "aid": "0", "net": net, "path": path, 
                        "type": "none", "host": v_dom, "tls": tls
                    }
                    b64 = base64.b64encode(json.dumps(j, separators=(',', ':')).encode('utf-8')).decode('utf-8')
                    return f"vmess://{b64}"
                
                link_tls = gen_vmess("ws", 443, "/vmess", "tls")
                link_ws = gen_vmess("ws", 80, "/vmess", "none")
                link_grpc = gen_vmess("grpc", 443, "vmess-grpc", "tls")

                acc_info = (
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🟢 <b>VMESS XRAY</b> 🟢\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➤ <b>Remarks</b>      : <code>{v_user}</code>\n"
                    f"➤ <b>Domain</b>       : <code>{v_dom}</code>\n"
                    f"➤ <b>User Quota</b>   : 0 GB\n"
                    f"➤ <b>User Ip</b>      : <code>{ip_vps}</code>\n"
                    f"➤ <b>Port TLS</b>     : 443, 8443\n"
                    f"➤ <b>Port WS</b>      : 80, 8880, 8080, 2082\n"
                    f"➤ <b>Key</b>          : <code>{v_pass}</code>\n"
                    f"➤ <b>Locations</b>    : {loc_vps}\n"
                    f"➤ <b>ISP</b>          : {isp_vps}\n"
                    f"➤ <b>AlterId</b>      : 0\n"
                    f"➤ <b>Security</b>     : auto\n"
                    f"➤ <b>Network</b>      : ws\n"
                    f"➤ <b>Path</b>         : /vmess\n"
                    f"➤ <b>Dynamic Path</b> : yourbug/vmess\n"
                    f"➤ <b>ServiceName</b>  : vmess-grpc\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>Link TLS       :</b>\n<code>{link_tls}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>Link WS        :</b>\n<code>{link_ws}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>Link GRPC      :</b>\n<code>{link_grpc}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>OpenClash      :</b>\nhttps://{v_dom}:81/vmess-{v_user}.txt\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>Expiry</b>         : <code>{v_exp}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<i>Terimakasih Telah Menggunakan</i>\n"
                    f"<i>Script Credit</i>\n"
                    f"<i>HOKAGE</i>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                )
            elif v_prot in ["VLESS", "TROJAN", "XRAY"]:
                acc_info = (
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🔵 <b>DETAIL AKUN {v_prot}</b> 🔵\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➤ <b>Domain</b>        : <code>{v_dom}</code>\n"
                    f"➤ <b>Username</b>      : <code>{v_user}</code>\n"
                    f"➤ <b>UUID/Pass</b>     : <code>{v_pass}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➤ <b>Port TLS</b>      : 443\n"
                    f"➤ <b>Port NTLS</b>     : 80\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<b>Berakhir Pada</b>      : <code>{v_exp}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"<i>*Note: Untuk link config lengkap,\n"
                    f"silakan cek riwayat chat saat awal pembelian.</i>\n\n"
                    f"<i>TERIMAKASIH SUDAH BERBELANJA DI HOKAGE LEGEND</i>"
                )
            else:
                acc_info = (
                    f"👤 <b>Username:</b> <code>{v_user}</code>\n"
                    f"🔑 <b>Password:</b> <code>{v_pass}</code>\n"
                    f"🌐 <b>Domain:</b> <code>{v_dom}</code>\n"
                )

        detail_text = (
            f"<b>📄 DETAIL TRANSAKSI VPN</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📦 <b>Produk:</b> {prod_name}\n"
            f"💰 <b>Harga:</b> {price}\n"
            f"📅 <b>Dibuat:</b> {date_str}\n"
            f"🧾 <b>Ref ID:</b> <code>{ref_id}</code>\n\n"
            f"{acc_info}"
        )

    else: 
        # === BLOK INI YANG SEBELUMNYA HILANG (PPOB) ===
        sn = d.get('sn', '-')
        dest = d.get('destination', '-')
        if not sn or sn == '-': sn = 'Pending / Belum ada SN'
        
        detail_text = (
            f"<b>📄 DETAIL PEMBELIAN PPOB</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📦 <b>Produk:</b> {prod_name}\n"
            f"💰 <b>Harga:</b> {price}\n"
            f"📱 <b>Tujuan:</b> <code>{dest}</code>\n"
            f"📅 <b>Tanggal:</b> {date_str}\n"
            f"📊 <b>Status:</b> {status}\n"
            f"🧾 <b>Ref ID:</b> <code>{ref_id}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🔑 <b>SN / Keterangan:</b>\n<code>{sn}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"<i>Terima kasih telah bertransaksi.</i>"
        )

    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🗑 HAPUS RIWAYAT", callback_data=f"del_trx_{ref_id}"))
    markup.add(types.InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data="history_user"))
    
    try:
        bot.edit_message_text(detail_text, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except ApiTelegramException:
        pass

# ==============================================================
# --- 6. FUNGSI HAPUS RIWAYAT (USER ONLY) ---
# ==============================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("del_trx_"))
def delete_trx_history(call):
    ref_id = call.data.replace("del_trx_", "")
    uid = call.from_user.id
    
    import sqlite3
    try:
        conn = sqlite3.connect("store_data.db")
        c = conn.cursor()
        
        # SANGAT AMAN: Kita pastikan user_id juga cocok agar tidak bisa hapus riwayat orang lain
        c.execute("DELETE FROM transactions WHERE ref_id=? AND user_id=?", (ref_id, uid))
        
        # Cek apakah ada data yang berhasil dihapus
        if c.rowcount > 0:
            conn.commit()
            # Tampilkan Pop-up Notifikasi Sukses
            bot.answer_callback_query(call.id, "✅ Riwayat berhasil dihapus secara permanen!", show_alert=True)
            
            # Hapus pesan detail transaksi (agar tidak nyangkut)
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass
            
            # Opsional: Otomatis memunculkan kembali menu riwayat
            msg = "<b>📜 MENU RIWAYAT TRANSAKSI</b>\n━━━━━━━━━━━━━━━━━━━━\nSilakan pilih jenis riwayat yang ingin Anda lihat:"
            markup = types.InlineKeyboardMarkup(row_width=2)
            markup.add(
                types.InlineKeyboardButton("🛍 RIWAYAT PEMBELIAN", callback_data="uhist_buy_1"),
                types.InlineKeyboardButton("💳 RIWAYAT SALDO", callback_data="uhist_bal_1")
            )
            markup.add(types.InlineKeyboardButton("🔙 KEMBALI KE MENU UTAMA", callback_data="back_to_main_menu"))
            bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)
            
        else:
            bot.answer_callback_query(call.id, "❌ Riwayat tidak ditemukan atau sudah dihapus.", show_alert=True)
            
        conn.close()
        
    except Exception as e:
        print(f"Error Delete History: {e}")
        bot.answer_callback_query(call.id, "❌ Terjadi kesalahan sistem saat menghapus.", show_alert=True)