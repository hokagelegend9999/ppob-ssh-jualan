import telebot
import paramiko
import math
import time
import os
import zipfile
import json
import smtplib
import sqlite3
import requests
import socket
from datetime import date as DateClass, datetime as DateTimeClass
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import datetime
from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import (
    ADMIN_ID, DOMAIN_HOST_SG,DOMAIN_HOST_ID,
    SMTP_SERVER, SMTP_PORT, SMTP_EMAIL, SMTP_PASSWORD, RECIPIENT_EMAIL
)
from database import get_all_transactions, update_transaction_status, DB_NAME, add_balance, get_user_data, increment_reseller_trx
import concurrent.futures

# Coba import OkeConnect (Safe Import)
try:
    from orderkuota_service import get_okeconnect_profile, check_orderkuota_status, buy_okeconnect_product
except ImportError:
    get_okeconnect_profile = None
    check_orderkuota_status = None
    buy_okeconnect_product = None

# DATA SERVER
SERVER_DATA = {
    "sg": { "name": "SINGAPORE AWS", "domain": "aws.hokage.web.id", "ip": "13.229.105.238", "user": "root", "pass": "azzam2016" },
    "sgdo2": { "name": "SINGAPORE AWS", "domain": "aws.hokage.web.id", "ip": "13.229.105.238", "user": "root", "pass": "azzam2016" },
    "sgdo3": { "name": "AWS SINGAPORE", "domain": "aws.hokage.web.id", "ip": "13.229.105.238", "user": "root", "pass": "azzam2016" },
    "indo": { "name": "Indonesia Private", "domain": "id.hokagelegend.net", "ip": "103.150.226.10", "user": "root", "pass": "azzam2016" }
}

PATH_BRIDGE = "/root/bot_store/kyt/modules/bridge.py"
def auto_repair_bridge(target):
    """
    Fungsi untuk otomatis mensinkronkan seluruh isi folder modules
    dari server bot ke VPS target via SFTP.
    """
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=15)
        
        # Dapatkan path folder /root/bot_store/kyt/modules
        folder_path = os.path.dirname(PATH_BRIDGE)
        
        # 1. Pastikan folder tujuan tersedia di VPS target
        client.exec_command(f"mkdir -p {folder_path}")
        
        # 2. Upload SEMUA file .py dari server bot ke VPS target
        sftp = client.open_sftp()
        
        # Baca isi direktori lokal bot
        for item in os.listdir(folder_path):
            if item.endswith(".py"):
                local_file = os.path.join(folder_path, item)
                remote_file = f"{folder_path}/{item}"
                
                # Upload file
                sftp.put(local_file, remote_file)
                # Beri izin eksekusi
                client.exec_command(f"chmod +x {remote_file}")
                
        sftp.close()
        client.close()
        return True
        
    except Exception as e:
        print(f"❌ Gagal Auto-Repair di {target['ip']}: {e}")
        return False

        
def eksekusi_remote(lokasi, command):
    target = SERVER_DATA.get(lokasi)
    if not target: return []

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15,            
            banner_timeout=15,   
            allow_agent=False, 
            look_for_keys=False
        )
        
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors='ignore').strip() 
        err_out = stderr.read().decode("utf-8", errors='ignore').strip() # TANGKAP ERROR LINUX
        client.close()
        
        if output:
            return output.split("\n")
        elif err_out:
            return [f"⚠️ BASH ERROR:\n{err_out}"] # TAMPILKAN ERROR KE TELEGRAM
        else:
            return []
            
    except Exception as e:
        print(f"❌ Error Remote {lokasi}: {e}")
        return [f"❌ Koneksi Error: {e}"]
def get_vps_system_only(lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return f"❌ Config {lokasi} Error"

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # Timeout 4 detik cukup
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=5,           
            banner_timeout=5,
            allow_agent=False, 
            look_for_keys=False
        )

        # Command: Ambil OS, Uptime, RAM, ISP (Tanpa hitung user)
        cmd = """
        os=$(grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')
        upt=$(uptime -p | sed 's/up //')
        ram_u=$(free -m | awk 'NR==2{print $3}')
        ram_t=$(free -m | awk 'NR==2{print $2}')
        # Cek cache ISP/City biar cepat, fallback ke curl
        isp=$(cat /root/.info/.isp 2>/dev/null || curl -s --max-time 1 ipinfo.io/org || echo "-")
        city=$(cat /root/.info/.city 2>/dev/null || curl -s --max-time 1 ipinfo.io/city || echo "-")
        
        echo "$os|$upt|$ram_u|$ram_t|$isp|$city"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8").strip()
        client.close()
        
        if "|" in output:
            d = output.split("|")
            # d[0]=OS, d[1]=Uptime, d[2]=RAM_U, d[3]=RAM_T, d[4]=ISP, d[5]=City
            
            return f"""
<b>💻 VPS {lokasi.upper()} ({d[0]})</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» SYSTEM INFORMATION</b>
🌐 IP: <code>{target['ip']}</code>
🎯 Domain: <code>{target['domain']}</code>
🏢 ISP: {d[4]}
📍 Loc: {d[5]}
💾 RAM: {d[2]}MB / {d[3]}MB
⏰ Uptime: {d[1]}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"""
        else:
            return f"⚠️ <b>{lokasi.upper()}:</b> Gagal parsing data."
            
    except Exception as e:
        return f"❌ <b>{lokasi.upper()} OFFLINE / ERROR</b>\n<code>{str(e)[:50]}</code>"
        
@bot.callback_query_handler(func=lambda call: call.data == "check_vps_menu")
def check_vps_menu(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Fitur khusus Owner!")

    # 1. Loading Message
    bot.edit_message_text(
        "🚀 <b>CONNECTING TO SERVERS...</b>\n"
        "<i>Sedang mengambil data server secara paralel (kecepatan tinggi)...</i>",
        call.message.chat.id, call.message.message_id, parse_mode='HTML'
    )

    # 2. Ambil Data BERSAMAAN (Paralel) agar tidak lemot
    results = {}
    server_list = ["indo"]
    
    # Memerintahkan 4 pekerja untuk mengecek server di waktu yang sama
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        future_to_vps = {executor.submit(get_vps_system_only, loc): loc for loc in server_list}
        for future in concurrent.futures.as_completed(future_to_vps):
            loc = future_to_vps[future]
            try:
                results[loc] = future.result()
            except Exception as exc:
                results[loc] = f"❌ {loc.upper()} Error: {exc}"

    # Mengambil hasil yang sudah dikerjakan pekerja
    info_sg = results.get("sg", "❌ Error")#
    info_sg2 = results.get("sgdo2", "❌ Error")#
    info_sg3 = results.get("sgdo3", "❌ Error")#
    info_indo = results.get("indo", "❌ Error")

    # 3. Gabungkan Pesan
    full_msg = f"{info_indo}"
    
    # 4. Buat Tombol Manage
    markup = InlineKeyboardMarkup()
    #markup.row(
    #    InlineKeyboardButton("🇸🇬 MANAGE SG AWS", callback_data="monitor_sg"),
    #    InlineKeyboardButton("🇸🇬 MANAGE SG AWS", callback_data="monitor_sgdo2") 
    #)
    markup.row(
        #InlineKeyboardButton("🇸🇬 MANAGE SG AWS", callback_data="monitor_sgdo3"), 
        InlineKeyboardButton("🇮🇩 MANAGE INDO", callback_data="monitor_indo")
    )
    markup.add(InlineKeyboardButton("🔄 REFRESH SEMUA", callback_data="check_vps_menu"))
    markup.add(InlineKeyboardButton("⚙️ SYSTEM BOT & BACKUP", callback_data="setting_menu"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))
    
    # 5. Tampilkan hasilnya (dengan pengaman timeout)
    try:
        bot.edit_message_text(full_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        print(f"⚠️ Abaikan Error Edit VPS: {e}")

# ==========================================
#  HANDLER DASHBOARD (FIXED: SINKRONISASI TOTAL KE CONFIG.JSON)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data in ["monitor_sg", "monitor_sgdo2", "monitor_sgdo3", "monitor_indo"])
def show_dashboard(call):
    if str(call.from_user.id) != str(ADMIN_ID): return

    lokasi = call.data.replace("monitor_", "")
    target = SERVER_DATA.get(lokasi)
    
    if not target:
        return bot.answer_callback_query(call.id, f"❌ Data {lokasi} tidak ditemukan!", show_alert=True)
    
    bot.answer_callback_query(call.id, f"⏳ Mengambil Data {lokasi.upper()}...", show_alert=False)

    stats = {"ssh": "0", "vmess": "0", "vless": "0", "trojan": "0"}
    
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=8)
        
        # === COMMAND SINKRONISASI TOTAL ===
        cmd = """
        c_ssh=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)
        c_vmess=$(grep "### " "/etc/xray/config.json" 2>/dev/null | awk '{print $2}' | sort | uniq | wc -l)
        c_vless=$(grep "#& " "/etc/xray/config.json" 2>/dev/null | awk '{print $2}' | sort | uniq | wc -l)
        c_trojan=$(grep "#! " "/etc/xray/config.json" 2>/dev/null | awk '{print $2}' | sort | uniq | wc -l)
        echo "$c_ssh|$c_vmess|$c_vless|$c_trojan"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd, timeout=5)
        output = stdout.read().decode("utf-8").strip()
        client.close()
        
        if "|" in output:
            data = output.split("|")
            stats = {
                "ssh": data[0].strip(), 
                "vmess": data[1].strip(), 
                "vless": data[2].strip(), 
                "trojan": data[3].strip()
            }
            
    except Exception as e:
        print(f"Error Stats {lokasi}: {e}")

    # Tampilan Dashboard
    msg = f"""
<b>⚙️ MANAGE VPS ({lokasi.upper()})</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» USER STATISTICS</b>
👤 <b>SSH User    :</b> <code>{stats['ssh']}</code> Akun
⚡ <b>VMess User  :</b> <code>{stats['vmess']}</code> Akun
🔮 <b>VLess User  :</b> <code>{stats['vless']}</code> Akun
🐎 <b>Trojan User :</b> <code>{stats['trojan']}</code> Akun
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Silakan pilih menu di bawah untuk mengelola user server <b>{lokasi.upper()}</b>.</i>
"""

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(InlineKeyboardButton("⚡ CEK STATUS SERVICE", callback_data=f"srv_check_status|{lokasi}"))
    markup.add(
        InlineKeyboardButton(f"📂 SSH ({stats['ssh']})", callback_data=f"menu_ssh_vps|{lokasi}"), 
        InlineKeyboardButton(f"📂 VMESS ({stats['vmess']})", callback_data=f"menu_vmess_vps|{lokasi}")
    )
    markup.add(
        InlineKeyboardButton(f"📂 VLESS ({stats['vless']})", callback_data=f"menu_vless_vps|{lokasi}"),
        InlineKeyboardButton(f"📂 TROJAN ({stats['trojan']})", callback_data=f"menu_trojan_vps|{lokasi}")
    )
    markup.add(InlineKeyboardButton("🔙 KEMBALI DASHBOARD", callback_data="check_vps_menu"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

# ==========================================
# 2. HANDLER CEK SERVICE (BRIDGE) - FIXED VERSION
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("srv_check_status"))
def check_service_status(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try: lokasi = call.data.split("|")[1]
    except: lokasi = "sg"
    
    bot.answer_callback_query(call.id, f"⏳ Checking {lokasi.upper()}...", show_alert=False)
    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    raw_out = ""
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        cmd = f"python3 {PATH_BRIDGE} system check_service"
        stdin, stdout, stderr = client.exec_command(cmd)
        
        raw_out = stdout.read().decode("utf-8", errors="ignore").strip()
        err_out = stderr.read().decode("utf-8", errors="ignore").strip()
        client.close()

        # --- SISTEM AUTO-REPAIR DIMULAI DI SINI ---
        butuh_repair = False
        if "No such file or directory" in err_out and "bridge.py" in err_out:
            butuh_repair = True
        elif "File service_lib.py tidak ditemukan" in raw_out or "ERROR|" in raw_out:
            butuh_repair = True

        if butuh_repair:
            bot.edit_message_text(f"🛠 <b>Auto-Repair:</b> Sinkronisasi module system ke {lokasi.upper()}...", call.message.chat.id, call.message.message_id, parse_mode='HTML')
            
            if auto_repair_bridge(target):
                # Jika sukses sinkronisasi, konek ulang dan eksekusi command lagi
                client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
                stdin, stdout, stderr = client.exec_command(cmd)
                raw_out = stdout.read().decode("utf-8", errors="ignore").strip()
                err_out = stderr.read().decode("utf-8", errors="ignore").strip()
                client.close()
            else:
                raise Exception("Gagal melakukan Auto-Repair sinkronisasi modul VPS.")
        # ------------------------------------------

        # Tangkap error VPS jika masih ada masalah lain
        if err_out and not raw_out:
            raise Exception(f"VPS Error: {err_out}")

        if raw_out and "|" in raw_out and not raw_out.startswith("ERROR"):
            d = raw_out.split("|")
            
            def icon(stat):
                return "<code>ON</code> ✅" if stat == "ON" else "<code>OFF</code> ❌"

            msg = (
                f"<b>🖥 SYSTEM INFORMATION</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"💻 <b>OS     :</b> <code>{d[0]}</code>\n"
                f"🌐 <b>IP     :</b> <code>{d[1]}</code>\n"
                f"🎯 <b>Domain :</b> <code>{d[2]}</code>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
                f"<b>⚙️ SERVICE STATUS ({lokasi.upper()})</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"🟢 <b>SSH / OVPN</b>\n"
                f"├ SSH Service    : {icon(d[3])}\n"
                f"├ Dropbear       : {icon(d[4])}\n"
                f"├ OpenVPN        : {icon(d[5])}\n"
                f"└ Haproxy        : {icon(d[6])}\n\n"
                
                f"🔵 <b>XRAY / ZiVPN</b>\n"
                f"├ Xray Core      : {icon(d[7])}\n"
                f"└ Websocket      : {icon(d[8])}\n\n"
                
                f"🟠 <b>UDP & LAINNYA</b>\n"
                f"├ Nginx Web      : {icon(d[8])}\n"
                f"├ ZiVPN Tunnel   : {icon(d[9])}\n" # Menggunakan d[9]
                f"├ UDP Custom     : {icon(d[10])}\n" # Menggunakan d[10]
                f"└ Crontab        : {icon(d[11])}\n" # Menggunakan d[11]
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            )

            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 REFRESH STATUS", callback_data=f"srv_check_status|{lokasi}"))
            markup.add(InlineKeyboardButton("🔙 DASHBOARD", callback_data=f"monitor_{lokasi}"))
            
            bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
        else:
            raise Exception(f"Format respon salah. Respon: {raw_out[:100]}")

    except Exception as e:
        error_display = str(raw_out)[:500] if raw_out else str(e)[:500]
        m_err = InlineKeyboardMarkup()
        m_err.add(InlineKeyboardButton("🔄 COBA LAGI", callback_data=call.data))
        m_err.add(InlineKeyboardButton("🔙 DASHBOARD", callback_data=f"monitor_{lokasi}"))
        bot.edit_message_text(f"❌ <b>GAGAL MENGAMBIL DATA</b>\n\n<code>{error_display}</code>", 
                              call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m_err)


# Helper cepat untuk cek status VPS (Hanya cek Port 22 SSH)
def quick_check_online(ip):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1.5) # Timeout cepat 1.5 detik agar bot tidak lemot
        result = sock.connect_ex((ip, 22))
        sock.close()
        return "🟢" if result == 0 else "🔴"
    except:
        return "🔴"

@bot.callback_query_handler(func=lambda call: call.data == "setting_menu")
def setting_menu(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    # 1. Pesan Loading (Opsional, agar user tau bot sedang bekerja)
    try:
        bot.edit_message_text("⏳ <b>Checking Server Status...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    except: pass

    # 2. Cek Status VPS (Realtime)
    #stat_sg   = quick_check_online(SERVER_DATA['sg']['ip'])
    #stat_sg3  = quick_check_online(SERVER_DATA['sgdo3']['ip'])
    #stat_sg2  = quick_check_online(SERVER_DATA['sgdo2']['ip'])
    stat_indo = quick_check_online(SERVER_DATA['indo']['ip'])

    # 3. Cek Saldo OkeConnect
    saldo_oke = "Rp 0"
    if get_okeconnect_profile:
        try: saldo_oke = get_okeconnect_profile()
        except: pass


    # 5. Susun Pesan dengan Indikator Warna
    msg = (f"🎛 <b>CONTROL PANEL ADMIN</b>\n"
           f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
           #f"🇸🇬 <code>SG DIGITAL OCEAN :</code> {stat_sg} <code>{SERVER_DATA['sg']['domain']}</code>\n"
           #f"🇸🇬 <code>SG AWS SIDNEY  :</code> {stat_sg2} <code>{SERVER_DATA['sgdo2']['domain']}</code>\n"
           #f"🇸🇬 <code>SG3 AWS AMAZONE    :</code> {stat_sg3} <code>{SERVER_DATA['sgdo3']['domain']}</code>\n"
           f"🇮🇩 <code>INDO BIZNET    :</code> {stat_indo} <code>{SERVER_DATA['indo']['domain']}</code>\n"
           f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
           f"💰 <b>INFO SALDO SERVER</b>\n"
           f"🏦 <b>OkeConnect:</b> {saldo_oke}\n\n"
           f"🌊 <b>Saldo Gateway</b>\n"
           f"🕒 <i>Updated: {datetime.datetime.now().strftime('%H:%M:%S')}</i>")
    
    # 6. Susun Tombol
    m = InlineKeyboardMarkup(row_width=2)
    m.add(InlineKeyboardButton("🔄 REFRESH DATA", callback_data="setting_menu"))
    m.add(
        InlineKeyboardButton("📜 Riwayat OkeConnect", callback_data="oke_admin_history"),
        InlineKeyboardButton("🕵️ Cek Status Oke", callback_data="oke_admin_check_status")
    )
    m.add(InlineKeyboardButton("💳 Riwayat Topup Saldo", callback_data="admin_topup_history"))
    m.row(InlineKeyboardButton("💾 BACKUP DATABASE", callback_data="srv_backup"), 
          InlineKeyboardButton("🔁 RESTART BOT", callback_data="srv_restart"))
    
    m.add(InlineKeyboardButton("🔙 KEMBALI KE OWNER", callback_data="switch_owner"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=m)

# ==========================================
# 7. FITUR PPOB
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "oke_admin_history")
def admin_oke_history(call):
    try:
        bot.answer_callback_query(call.id, "🔄 Mengambil Data...")
        all_trx = get_all_transactions(limit=50) 
        data = []
        if all_trx:
            for row in all_trx:
                tgl, desc, amt, stt, ref, dest, sn, src = "-", "-", 0, "-", "-", "-", "-", "-"
                if len(row) == 8: tgl, ref, desc, sn, dest, amt, src, stt = row
                elif len(row) == 7: tgl, desc, amt, stt, ref, dest, sn = row
                elif len(row) == 5: tgl, desc, amt, stt, ref = row
                else: continue

                is_oke = "OKE" in str(desc).upper() or "OKE" in str(ref).upper()
                if len(row) == 8 and str(src).upper() == "OKE": is_oke = True

                if is_oke:
                    if str(stt).lower() in ["pending", "proses"] and check_orderkuota_status:
                        try:
                            latest_status = check_orderkuota_status(ref)
                            status_str = str(latest_status).lower()
                            new_stt = None
                            if "sukses" in status_str: new_stt = "sukses"
                            elif "gagal" in status_str: new_stt = "gagal"
                            if new_stt:
                                stt = new_stt
                                update_transaction_status(ref, new_stt, sn)
                        except: pass
                    
                    clean_prov = str(desc).replace("Beli ", "").replace(" (OKE)", "")
                    data.append({'tgl': tgl, 'prov': clean_prov, 'amt': amt, 'stt': stt, 'ref': ref, 'dest': dest, 'sn': sn})
        
        data = data[:10]
    except Exception as e:
        data = []
        print(f"❌ Error History: {e}")

    msg = "<b>📜 RIWAYAT TRANSAKSI OKECONNECT</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not data: msg += "<i>Belum ada data transaksi.</i>"
    else:
        for i, item in enumerate(data, 1):
            s = str(item['stt']).lower()
            icon = "✅" if "sukses" in s else "❌" if "gagal" in s else "⏳"
            msg += f"<b>{i}. {item['tgl']}</b>\n🆔 {item['ref']}\n📦 {item['prov']}\n📱 {item['dest']}\n🎟 {item['sn']}\n📊 {icon} {item['stt']}\n────────────────\n"

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔄 REFRESH", callback_data="oke_admin_history"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="setting_menu"))
    try: bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "oke_admin_check_status")
def admin_oke_check_ask(call):
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data="setting_menu"))
    msg = bot.send_message(call.message.chat.id, "🕵️ <b>CEK STATUS TRANSAKSI</b>\nMasukkan RefID/SN/Tujuan:", parse_mode='HTML', reply_markup=markup)
    bot.register_next_step_handler(msg, admin_oke_check_process)

def admin_oke_check_process(message):
    try:
        input_data = message.text.strip()
        
        # Kirim pesan loading
        status_msg = bot.send_message(message.chat.id, f"⏳ Cek: {input_data}...", parse_mode='HTML')
        
        respon_server = "Gagal"
        if check_orderkuota_status:
            try: 
                respon_server = str(check_orderkuota_status(input_data))
            except Exception as e: 
                respon_server = f"Error: {e}"
        
        # ==========================================
        # [MODIFIKASI] TAMBAHAN TOMBOL KEMBALI
        # ==========================================
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔄 Cek Lagi", callback_data="oke_admin_check_status"))
        markup.add(InlineKeyboardButton("🔙 Kembali ke Menu", callback_data="setting_menu"))
        
        # Edit pesan loading menjadi hasil + tombol
        bot.edit_message_text(
            f"📊 <b>HASIL CEK</b>\n"
            f"Input: {input_data}\n"
            f"Respon: <code>{respon_server}</code>", 
            message.chat.id, 
            status_msg.message_id, 
            parse_mode='HTML',
            reply_markup=markup  # <--- Tombol dimasukkan di sini
        )
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error System: {e}")
        
# ==========================================
#  HANDLER RIWAYAT TOPUP (GOPAY, JAGO, MANUAL)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "admin_topup_history")
def admin_topup_history_dates(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try:
        bot.edit_message_text("⏳ <i>Mengambil data riwayat deposit...</i>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    except: pass

    dates_set = set()
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        # Query Aman Tanpa JOIN agar tidak terjadi Error Column
        c.execute("SELECT date FROM transactions WHERE description LIKE '%deposit%' OR description LIKE '%topup%' OR description LIKE '%saldo%' OR description LIKE '%refund%' OR ref_id LIKE 'GOPAY-%' OR ref_id LIKE 'JAGO-%' OR ref_id LIKE 'REF-%' OR ref_id LIKE 'ADM-INJ-%' ORDER BY date DESC LIMIT 2000")
        rows = c.fetchall()
        conn.close()
        
        for row in rows:
            tgl = row[0]
            date_only = str(tgl).split(" ")[0]
            if date_only and date_only != "-":
                dates_set.add(date_only)
    except Exception as e:
        print(f"Error read DB: {e}")
    
    # 🌟 KUNCI WAKTU KE INDONESIA (WIB / UTC+7) 🌟
    now_wib = datetime.datetime.utcnow() + datetime.timedelta(hours=7)
    today_str = now_wib.strftime("%Y-%m-%d")
    
    # Memaksa tombol hari ini selalu muncul
    dates_set.add(today_str) 
    
    dates_list = sorted(list(dates_set), reverse=True)[:16] 
    
    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
    btns = []
    
    bulan_indo = {"01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr", "05": "Mei", "06": "Jun", "07": "Jul", "08": "Agt", "09": "Sep", "10": "Okt", "11": "Nov", "12": "Des"}
    
    for d in dates_list:
        d_clean = d.strip()
        try:
            y, m, day = d_clean.split("-")
            btn_txt = f"📅 {day} {bulan_indo[m]} {y}" 
        except:
            btn_txt = f"📅 {d_clean}"
            
        # 🌟 LOGIKA ICON HARI INI PASTI MUNCUL 🌟
        if d_clean == today_str:
            btn_txt = f"🟢 {btn_txt} (HARI INI)"
            
        btns.append(telebot.types.InlineKeyboardButton(btn_txt, callback_data=f"tp_date|{d_clean}"))
        
    markup.add(*btns)
    markup.add(telebot.types.InlineKeyboardButton("🔄 REFRESH DATA", callback_data="admin_topup_history"))
    markup.add(telebot.types.InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="setting_menu"))
    
    msg = (
        "💳 <b>RIWAYAT DEPOSIT SALDO</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Silakan pilih tanggal di bawah ini untuk melihat detail riwayat pengisian saldo:"
    )
        
    try: bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("tp_date|"))
def admin_topup_detail_date(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    selected_date = call.data.split("|")[1].strip()
    
    hari_indo = {"Monday": "Senin", "Tuesday": "Selasa", "Wednesday": "Rabu", "Thursday": "Kamis", "Friday": "Jumat", "Saturday": "Sabtu", "Sunday": "Minggu"}
    bulan_indo_full = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}
    
    try:
        dt = datetime.datetime.strptime(selected_date, "%Y-%m-%d")
        nama_hari = hari_indo[dt.strftime("%A")]
        y, m, d = selected_date.split("-")
        judul_tgl = f"{nama_hari}, {d} {bulan_indo_full[m]} {y}"
    except:
        judul_tgl = selected_date
        nama_hari = ""

    bot.answer_callback_query(call.id, f"Memuat riwayat {judul_tgl}...")
    
    data = []
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        
        # Kembali ke Query Aman
        c.execute("SELECT user_id, ref_id, amount, status, date, source, description FROM transactions WHERE date LIKE ? AND (description LIKE '%deposit%' OR description LIKE '%topup%' OR description LIKE '%saldo%' OR description LIKE '%refund%' OR ref_id LIKE 'GOPAY-%' OR ref_id LIKE 'JAGO-%' OR ref_id LIKE 'REF-%' OR ref_id LIKE 'ADM-INJ-%') ORDER BY date DESC", (f"{selected_date}%",))
        
        rows = c.fetchall()
        conn.close()
        
        for row in rows:
            user_id, ref, amt, stt, tgl, src, desc = row
            desc_lower = str(desc).lower()
            ref_upper = str(ref).upper()
            
            metode = "MANUAL / ADMIN"
            if "gopay" in desc_lower or ref_upper.startswith("GOPAY-"):
                metode = "QRIS GOPAY"
            elif "jago" in desc_lower or ref_upper.startswith("JAGO-"):
                metode = "BANK JAGO"
            elif "refund" in desc_lower or "pengembalian" in desc_lower or ref_upper.startswith("REF-"):
                metode = "REFUND SALDO SISTEM"
            elif "tripay" in desc_lower:
                metode = "TRIPAY (Lama)"

            jam = str(tgl).split(" ")[1] if " " in str(tgl) else str(tgl)
            
            # 🌟 LOGIKA AMAN MENGAMBIL USERNAME DARI FUNGSI BAWAANMU 🌟
            username_str = "<i>(Tanpa Username)</i>"
            try:
                from database import get_user_data_complete
                udata = get_user_data_complete(user_id)
                # udata adalah list/tuple: [u_id, nama, saldo, role, username]
                if udata:
                    db_name = udata[1] if len(udata) > 1 else None
                    db_uname = udata[4] if len(udata) > 4 else None
                    
                    if db_uname and str(db_uname).strip() not in ["None", "", "-"]:
                        username_str = f"@{str(db_uname).replace('@', '')}"
                    elif db_name and str(db_name).strip() not in ["None", "", "-"]:
                        username_str = f"({db_name})"
            except Exception as ex:
                pass
            
            data.append({
                'jam': jam,
                'user_id': user_id,
                'username': username_str,
                'ref': ref,
                'amt': amt,
                'stt': stt,
                'metode': metode,
                'hari': nama_hari
            })
    except Exception as e:
        print(f"Error fetch detail date: {e}")
    
    msg = f"💳 <b>DATA DEPOSIT</b>\n📅 {judul_tgl}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not data:
        msg += "<i>Tidak ada transaksi masuk di hari ini.</i>"
    else:
        for i, item in enumerate(data, 1):
            s = str(item['stt']).lower()
            icon = "✅" if "sukses" in s or "paid" in s or "completed" in s else "❌" if "gagal" in s or "expired" in s or "canceled" in s else "⏳"
            
            try: amount_val = int(item['amt'])
            except: amount_val = 0
            nominal_str = f"+Rp {amount_val:,}" if amount_val > 0 else f"-Rp {abs(amount_val):,}"
            
            msg += (
                f"<b>{i}. {item['jam']}</b> | Hari {item['hari']}\n"
                f"👤 <b>User:</b> <code>{item['user_id']}</code> | {item['username']}\n"
                f"🆔 <b>Ref:</b> <code>{item['ref']}</code>\n"
                f"🏦 <b>Metode:</b> {item['metode']}\n"
                f"💰 <b>{nominal_str}</b>\n"
                f"📊 Status: {icon} <b>{item['stt'].upper()}</b>\n"
                f"────────────────\n"
            )
            
    markup = telebot.types.InlineKeyboardMarkup()
    markup.add(telebot.types.InlineKeyboardButton("🔄 REFRESH HALAMAN", callback_data=f"tp_date|{selected_date}"))
    markup.add(telebot.types.InlineKeyboardButton("🔙 KEMBALI KE TANGGAL", callback_data="admin_topup_history"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except: pass
    
def send_email_backup(zip_filename):
    try:
        msg = MIMEMultipart()
        msg['From'] = SMTP_EMAIL
        msg['To'] = RECIPIENT_EMAIL
        # PERBAIKAN datetime
        msg['Subject'] = f"Backup Bot {datetime.datetime.now()}"
        
        with open(zip_filename, "rb") as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f"attachment; filename= {zip_filename}")
            msg.attach(part)
        
        # --- PERBAIKAN LOGIKA KONEKSI ---
        if SMTP_PORT == 465:
            server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, timeout=10)
        else:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10)
            server.starttls() # Penting untuk port 587
            
        server.login(SMTP_EMAIL, SMTP_PASSWORD)
        server.sendmail(SMTP_EMAIL, RECIPIENT_EMAIL, msg.as_string())
        server.quit()
        return True, "Terkirim"
    except Exception as e:
        return False, str(e)

@bot.callback_query_handler(func=lambda call: call.data == "srv_backup")
def backup_handler(call):
    chat_id = call.message.chat.id
    
    # Pesan tunggu
    wait = bot.send_message(chat_id, "⏳ <b>Memproses Backup...</b>", parse_mode='HTML')
    
    zname = ""
    try:
        # 1. Membuat file ZIP (PERBAIKAN datetime)
        zname = f"Backup_Bot_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.zip"
        with zipfile.ZipFile(zname, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk('.'):
                for file in files:
                    # Filter file yang mau di backup
                    if file.endswith(('.py', '.db', '.json', '.txt')) and not file.startswith('Backup_'):
                        zipf.write(os.path.join(root, file))
        
        # 2. Mengirim Email
        is_sent, status_msg = send_email_backup(zname)
        status_icon = "✅" if is_sent else "⚠️"
        
        # 3. MEMBUAT TOMBOL KEMBALI (Updated)
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="setting_menu"))

        # 4. Mengirim File ke Telegram dengan Tombol (PERBAIKAN datetime)
        with open(zname, 'rb') as f:
            caption_text = (
                f"📦 <b>BACKUP SYSTEM SELESAI</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"{status_icon} <b>Status Email:</b> {status_msg}\n"
                f"📅 <b>Waktu:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            bot.send_document(
                chat_id, 
                f, 
                caption=caption_text, 
                parse_mode='HTML', 
                reply_markup=markup 
            )
        
        # Hapus pesan tunggu
        bot.delete_message(chat_id, wait.message_id)

    except Exception as e:
        # Jika error coding/permissions
        markup_err = InlineKeyboardMarkup()
        markup_err.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="setting_menu"))
        bot.edit_message_text(f"❌ <b>Error Backup:</b> {e}", chat_id, wait.message_id, parse_mode='HTML', reply_markup=markup_err)
    
    finally:
        # Bersihkan file zip lokal
        if zname and os.path.exists(zname): os.remove(zname)

@bot.callback_query_handler(func=lambda call: call.data == "srv_restart")
def restart_bot(call):
    bot.answer_callback_query(call.id, "♻️ Restarting Bot...")
    with open("restart_state.json", "w") as f:
        json.dump({"chat_id": call.message.chat.id, "message_id": call.message.message_id}, f)
    import subprocess
    subprocess.Popen(["systemctl", "restart", "bot-store"])

@bot.callback_query_handler(func=lambda call: call.data.startswith("oke_confirm"))
def oke_confirm(call):
    try:
        parts = call.data.split("|")
        if len(parts) < 4: return bot.answer_callback_query(call.id, "❌ Data tidak valid.", show_alert=True)
        code = parts[1]
        dest = parts[2]
        price = int(parts[3])
        ref_id = parts[4] if len(parts) > 4 else f"TRX-{int(time.time())}"
        
        uid = call.from_user.id
        user_data = get_user_data(uid)
        
        if user_data['balance'] < price:
            return bot.answer_callback_query(call.id, "⚠️ Saldo tidak cukup!", show_alert=True)
            
        bot.answer_callback_query(call.id, "⏳ Memproses transaksi...")
        bot.edit_message_text(f"🔄 <b>Mengirim Order...</b>\n📦 {code} -> {dest}", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        
        try:
            if buy_okeconnect_product:
                status, sn, info_res = buy_okeconnect_product(code, dest, ref_id)
            else:
                status, sn, info_res = False, "", "Service PPOB Off."
        except Exception as e:
            status, sn, info_res = False, "", f"Error API: {str(e)}"

        if status:
            add_balance(uid, -price, f"Beli {code} {dest}")
            increment_reseller_trx(uid)
            msg = f"✅ <b>SUKSES!</b>\n📦 {code}\n📱 {dest}\n🎟 SN: <code>{sn}</code>"
        else:
            msg = f"❌ <b>GAGAL</b>\n📦 {code}\n⚠️ {info_res}"
                    
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML')
        try: bot.delete_message(call.message.chat.id, call.message.message_id)
        except: pass

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error: {e}")
        
        
# ==========================================
# 3. HANDLER SUB-MENU PROTOKOL (SSH, VMESS, VLESS, TROJAN)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith(("menu_ssh_vps|", "menu_vmess_vps|", "menu_vless_vps|", "menu_trojan_vps|")))
def manage_protocol_menu(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try:
        # Memisahkan action (misal: menu_vmess_vps) dan lokasi (misal: sgdo2)
        action_full, lokasi = call.data.split("|")
        prot_code = action_full.split("_")[1] # Otomatis mengambil kata vmess, vless, trojan, atau ssh
    except ValueError:
        return bot.answer_callback_query(call.id, "❌ Data callback tidak valid!")

    target = SERVER_DATA.get(lokasi)
    if not target: 
        return bot.answer_callback_query(call.id, f"❌ Server {lokasi.upper()} tidak ditemukan!", show_alert=True)

    # Deteksi otomatis protokol apa yang sedang diklik
    if prot_code == "ssh":
        prot_name = "SSH & OpenVPN"
    elif prot_code == "vmess":
        prot_name = "Xray VMess"
    elif prot_code == "vless":
        prot_name = "Xray VLess"
    elif prot_code == "trojan":
        prot_name = "Xray Trojan"
    else:
        return bot.answer_callback_query(call.id, "❌ Protokol tidak dikenali!")

    # Format Pesan Sub-Menu
    msg = (
        f"⚙️ <b>MANAGE {prot_name.upper()} ({lokasi.upper()})</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"🌐 <b>IP Server :</b> <code>{target['ip']}</code>\n"
        f"🎯 <b>Domain    :</b> <code>{target['domain']}</code>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"<i>Silakan pilih tindakan untuk mengelola user {prot_name}:</i>"
    )

    # Susun Tombol Aksi (Create, Renew, Delete, Cek)
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("➕ CREATE USER", callback_data=f"add_{prot_code}|{lokasi}"),
        InlineKeyboardButton("🔄 RENEW USER", callback_data=f"renew_{prot_code}|{lokasi}")
    )
    markup.add(
        InlineKeyboardButton("❌ DELETE USER", callback_data=f"del_{prot_code}|{lokasi}"),
        InlineKeyboardButton("👥 CEK USER LOGIN", callback_data=f"cek_{prot_code}|{lokasi}")
    )
    markup.add(InlineKeyboardButton("🔙 KEMBALI DASHBOARD", callback_data=f"monitor_{lokasi}"))

    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)
    except Exception as e:
        print(f"Error edit menu protokol: {e}")
        
# ==========================================
# 4. HANDLER EKSEKUSI PROTOKOL (ADD, RENEW, DEL, CEK)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.split("|")[0].startswith(("add_", "del_", "renew_", "cek_")))
def action_protocol_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    try:
        action_full, lokasi = call.data.split("|")
        action, protocol = action_full.split("_") 
    except ValueError:
        return bot.answer_callback_query(call.id, "❌ Data callback tidak valid!")

    target = SERVER_DATA.get(lokasi)
    if not target:
        return bot.answer_callback_query(call.id, "❌ Server tidak ditemukan di konfigurasi!")

    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id

    # Tombol kembali default ke sub-menu protokol (bukan dashboard utama)
    markup_cancel = InlineKeyboardMarkup().add(InlineKeyboardButton("🔙 KEMBALI", callback_data=f"menu_{protocol}_vps|{lokasi}"))

    if action == "add":
        msg = bot.send_message(chat_id, f"➕ <b>CREATE {protocol.upper()}</b> ({target['name']})\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👉 <i>Masukkan Username Baru:</i>", parse_mode='HTML', reply_markup=markup_cancel)
        bot.register_next_step_handler(msg, ask_pass_or_quota, protocol, lokasi, target)
        
    elif action == "del":
        load_msg = bot.send_message(chat_id, f"⏳ <i>Mengambil daftar user {protocol.upper()} dari VPS...</i>", parse_mode='HTML')
        
        # Mengambil list user berdasarkan protokol langsung dari VPS
        if protocol == "ssh":
            cmd_get_users = "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd"
        elif protocol == "vmess":
            cmd_get_users = "grep '### ' /etc/xray/config.json 2>/dev/null | awk '{print $2}' | sort | uniq"
        elif protocol == "vless":
            cmd_get_users = "grep '#& ' /etc/xray/config.json 2>/dev/null | awk '{print $2}' | sort | uniq"
        elif protocol == "trojan":
            cmd_get_users = "grep '#! ' /etc/xray/config.json 2>/dev/null | awk '{print $2}' | sort | uniq"

        output = eksekusi_remote(lokasi, cmd_get_users)
        bot.delete_message(chat_id, load_msg.message_id)

        if not output or (len(output) == 1 and "ERROR" in output[0].upper()):
            bot.send_message(chat_id, f"❌ Gagal mengambil daftar user.\n<pre>{output[0] if output else 'Tidak ada respon'}</pre>", parse_mode='HTML', reply_markup=markup_cancel)
            return

        users = [u.strip() for u in output if u.strip()]
        if not users:
            bot.send_message(chat_id, f"ℹ️ Tidak ada user {protocol.upper()} di server ini.", reply_markup=markup_cancel)
            return

        # Tampilkan list user sebagai tombol inline
        markup = InlineKeyboardMarkup(row_width=2)
        btns = []
        for u in users:
            cb_data = f"delx|{protocol}|{lokasi}|{u}"
            btns.append(InlineKeyboardButton(f"👤 {u}", callback_data=cb_data))
        
        markup.add(*btns)
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data=f"menu_{protocol}_vps|{lokasi}"))

        bot.send_message(chat_id, f"❌ <b>DELETE {protocol.upper()}</b> ({target['name']})\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👇 <i>Pilih User yang akan dihapus:</i>", parse_mode='HTML', reply_markup=markup)
        
    elif action == "renew":
        msg = bot.send_message(chat_id, f"🔄 <b>RENEW {protocol.upper()}</b> ({target['name']})\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👉 <i>Masukkan Username yang akan diperpanjang:</i>", parse_mode='HTML', reply_markup=markup_cancel)
        bot.register_next_step_handler(msg, ask_renew_days, protocol, lokasi, target)
        
    elif action == "cek":
        load_msg = bot.send_message(chat_id, f"⏳ <i>Sedang mengecek user {protocol.upper()} yang sedang login...</i>", parse_mode='HTML')
        
        if protocol == "ssh":
            cmd = "echo 'User Login:'; netstat -tnpa 2>/dev/null | grep ESTABLISHED | grep -w '22\\|109\\|143' | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | awk '{print $2\" [\"$1\" Koneksi]\"}'"
        else:
            cmd = f"python3 {PATH_BRIDGE} {protocol} cek"
            
        output = eksekusi_remote(lokasi, cmd)
        hasil = "\n".join(output) if output else "Tidak ada user login / Modul tidak merespon."
        
        bot.delete_message(chat_id, load_msg.message_id)
        # Menambahkan markup_cancel ke balasan agar muncul tombol kembali walau gagal
        bot.send_message(chat_id, f"👥 <b>CEK LOGIN {protocol.upper()} ({target['name']})</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<pre>{hasil}</pre>", parse_mode='HTML', reply_markup=markup_cancel)

# ==========================================
# HANDLER DELETE VIA TOMBOL INLINE (SEMUA PROTOKOL)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("delx|"))
def process_delete_inline(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    parts = call.data.split("|")
    protocol = parts[1]
    lokasi = parts[2]
    username = parts[3]
    
    bot.answer_callback_query(call.id, f"Menghapus {username}...")
    load_msg = bot.edit_message_text(f"⏳ <b>Menghapus akun {username} ({protocol.upper()})...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    
    if protocol == "ssh":
        cmd = f"""
        if id "{username}" &>/dev/null; then
            userdel -f "{username}"
            if [ -f /etc/zivpn/config.json ]; then
                jq --arg u "{username}" 'del(.auth.config[] | select(. == $u))' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                systemctl restart zivpn
            fi
            echo "✅ SUCCESS: Akun {username} berhasil dihapus."
        else
            echo "❌ ERROR: Akun {username} tidak ditemukan!"
        fi
        """
    elif protocol == "vmess":
        cmd = f"""
        sed -i "/^### {username} /d" /etc/vmess/.vmess.db 2>/dev/null
        sed -i "\\|### {username} |,\|}}|d" /etc/xray/config.json
        rm -f /etc/fvstore/limit/vmess/ip/{username} 2>/dev/null
        rm -f /etc/vmess/{username} 2>/dev/null
        systemctl restart xray
        echo "✅ SUCCESS: Akun VMESS {username} dihapus."
        """
    elif protocol == "vless":
        cmd = f"""
        sed -i "/^#& {username} /d" /etc/vless/.vless.db 2>/dev/null
        sed -i "\\|#& {username} |,\|}}|d" /etc/xray/config.json
        rm -f /etc/fvstore/limit/vless/ip/{username} 2>/dev/null
        rm -f /etc/vless/{username} 2>/dev/null
        systemctl restart xray
        echo "✅ SUCCESS: Akun VLESS {username} dihapus."
        """
    elif protocol == "trojan":
        cmd = f"""
        sed -i "/^### {username} /d" /etc/trojan/.trojan.db 2>/dev/null
        sed -i "\\|#! {username} |,\|}}|d" /etc/xray/config.json
        rm -f /etc/fvstore/limit/trojan/ip/{username} 2>/dev/null
        rm -f /etc/trojan/{username} 2>/dev/null
        systemctl restart xray
        echo "✅ SUCCESS: Akun TROJAN {username} dihapus."
        """
    
    output = eksekusi_remote(lokasi, cmd)
    hasil = "\n".join(output) if output else "Tidak ada respon balik dari VPS."
    
    markup = InlineKeyboardMarkup().add(InlineKeyboardButton("🔙 KEMBALI", callback_data=f"menu_{protocol}_vps|{lokasi}"))
    bot.edit_message_text(f"🗑 <b>EKSEKUSI HAPUS SELESAI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<pre>{hasil}</pre>", call.message.chat.id, load_msg.message_id, parse_mode='HTML', reply_markup=markup)

# ==========================================
# HANDLER DELETE VIA TOMBOL INLINE (FITUR BARU)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("delx|"))
def process_delete_inline(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    parts = call.data.split("|")
    protocol = parts[1]
    lokasi = parts[2]
    username = parts[3]
    
    bot.answer_callback_query(call.id, f"Menghapus {username}...")
    
    load_msg = bot.edit_message_text(f"⏳ <b>Menghapus akun {username} ({protocol.upper()})...</b>", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    
    if protocol == "ssh":
        cmd = f"""
        if id "{username}" &>/dev/null; then
            userdel -f "{username}"
            
            if [ -f /etc/zivpn/config.json ]; then
                jq --arg u "{username}" 'del(.auth.config[] | select(. == $u))' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                systemctl restart zivpn
            fi
            echo "✅ SUCCESS: Akun {username} berhasil dihapus dari server."
        else
            echo "❌ ERROR: Akun {username} tidak ditemukan!"
        fi
        """
    else:
        cmd = f"python3 {PATH_BRIDGE} {protocol} del {username}"
        
    output = eksekusi_remote(lokasi, cmd)
    hasil = "\n".join(output) if output else "Tidak ada respon balik."
    
    markup = InlineKeyboardMarkup().add(InlineKeyboardButton("🔙 KEMBALI DASHBOARD", callback_data=f"monitor_{lokasi}"))
    bot.edit_message_text(f"🗑 <b>EKSEKUSI HAPUS SELESAI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<pre>{hasil}</pre>", call.message.chat.id, load_msg.message_id, parse_mode='HTML', reply_markup=markup)

# ==========================================
# FUNGSI-FUNGSI LANJUTAN (NEXT STEP HANDLERS)
# ==========================================

# --- PROSES CREATE USER ---
def ask_pass_or_quota(message, protocol, lokasi, target):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    markup_cancel = InlineKeyboardMarkup().add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data=f"monitor_{lokasi}"))
    
    if protocol == "ssh":
        msg = bot.reply_to(message, f"🔑 <b>Masukkan Password untuk {username}:</b>", parse_mode='HTML', reply_markup=markup_cancel)
        bot.register_next_step_handler(msg, ask_active_days, username, protocol, lokasi, target, "password")
    else:
        msg = bot.reply_to(message, f"📊 <b>Masukkan Quota (GB) untuk {username}:</b>\n<i>Ketik angka saja (Misal: 10)</i>", parse_mode='HTML', reply_markup=markup_cancel)
        bot.register_next_step_handler(msg, ask_active_days, username, protocol, lokasi, target, "quota")

def ask_active_days(message, username, protocol, lokasi, target, step_type):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    pass_or_quota = message.text.strip()
    markup_cancel = InlineKeyboardMarkup().add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data=f"monitor_{lokasi}"))
    
    msg = bot.reply_to(message, f"📆 <b>Masa Aktif (Hari) untuk {username}:</b>\n<i>Ketik angka saja (Misal: 30)</i>", parse_mode='HTML', reply_markup=markup_cancel)
    bot.register_next_step_handler(msg, execute_create, username, pass_or_quota, protocol, lokasi, target)

def execute_create(message, username, pass_or_quota, protocol, lokasi, target):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    hari = message.text.strip()
    if not hari.isdigit():
        return bot.reply_to(message, "❌ Gagal: Hari harus berupa angka murni!")
        
    load_msg = bot.reply_to(message, f"⏳ <b>Membuat akun {protocol.upper()} di {target['name']}...</b>", parse_mode='HTML')
    
    if protocol == "ssh":
        cmd = f"""
        exp_date=$(date -d "+{hari} days" +"%Y-%m-%d")
        if id "{username}" &>/dev/null; then
            echo "❌ ERROR: User {username} sudah ada di VPS!"
        else
            useradd -e "$exp_date" -s /bin/false -M "{username}"
            echo "{username}:{pass_or_quota}" | chpasswd
            
            if [ -f /etc/zivpn/config.json ]; then
                if ! jq -e ".auth.config | index(\\"{username}\\")" /etc/zivpn/config.json > /dev/null 2>&1; then
                    jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                    systemctl restart zivpn
                fi
            fi
            echo "SUCCESS"
        fi
        """
        output = eksekusi_remote(lokasi, cmd)
        hasil = "\n".join(output) if output else ""

        bot.delete_message(message.chat.id, load_msg.message_id)

        if "SUCCESS" in hasil:
            domain_server = target.get('domain', target['ip'])
            exp_date_str = (datetime.date.today() + datetime.timedelta(days=int(hari))).strftime("%d %b %Y")
            
            reply_msg = f"""
========================================
🌟 <b>AKUN SSH PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Username: <code>{username}</code>
Domain  : <code>{domain_server}</code>
Password: <code>{pass_or_quota}</code>
Expired : <code>{exp_date_str}</code>
IP Limit: <code>3 Device</code>

🔹 <b>PORT INFO</b>
SSH WS       : 80, 2082
SSH SSL      : 443
UDP GW       : 7100-7300
ZiVPN        : <code>{username}</code>

🔹UDP Costum   : 
<code>{domain_server}</code>:1-65535@<code>{username}</code>:<code>{pass_or_quota}</code>

🔹ZIVPN FORMAT :
UDP SERVER   : <code>{domain_server}</code>
UDP PASSWORD : <code>{username}</code>


========================================

🔗 <b>PAYLOAD CONTOH</b>
<code>GET / HTTP/1.1[crlf]Host: {domain_server}[crlf]Upgrade: websocket[crlf][crlf]</code>

========================================
💰 Harga: Rp 0 (Admin Menu)
========================================
"""
            markup = InlineKeyboardMarkup().add(InlineKeyboardButton("🔙 KEMBALI DASHBOARD", callback_data=f"monitor_{lokasi}"))
            bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
        else:
            bot.send_message(message.chat.id, f"❌ <b>GAGAL EKSEKUSI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<pre>{hasil}</pre>", parse_mode='HTML')
    else:
        cmd = f"python3 {PATH_BRIDGE} {protocol} add {username} {pass_or_quota} {hari}"
        output = eksekusi_remote(lokasi, cmd)
        hasil = "\n".join(output) if output else "Gagal mengeksekusi script."
        
        bot.delete_message(message.chat.id, load_msg.message_id)
        bot.send_message(message.chat.id, f"✅ <b>EKSEKUSI SELESAI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<pre>{hasil}</pre>", parse_mode='HTML')


# --- PROSES RENEW USER ---
def ask_renew_days(message, protocol, lokasi, target):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    markup_cancel = InlineKeyboardMarkup().add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data=f"monitor_{lokasi}"))
    msg = bot.reply_to(message, f"📆 <b>Berapa Hari Perpanjangan untuk {username}?</b>\n<i>Ketik angka saja (Misal: 30)</i>", parse_mode='HTML', reply_markup=markup_cancel)
    bot.register_next_step_handler(msg, execute_renew, username, protocol, lokasi, target)

def execute_renew(message, username, protocol, lokasi, target):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    hari = message.text.strip()
    if not hari.isdigit():
        return bot.reply_to(message, "❌ Gagal: Hari harus berupa angka murni!")
        
    load_msg = bot.reply_to(message, f"⏳ <b>Memperpanjang akun {username}...</b>", parse_mode='HTML')
    
    if protocol == "ssh":
        cmd = f"""
        if id "{username}" &>/dev/null; then
            exp_lama=$(chage -l "{username}" | grep "Account expires" | awk -F": " '{{print $2}}')
            
            if [ "$exp_lama" == "never" ] || [ -z "$exp_lama" ]; then
                exp_baru=$(date -d "+{hari} days" +"%Y-%m-%d")
            else
                exp_baru=$(date -d "$exp_lama + {hari} days" +"%Y-%m-%d")
            fi
            
            chage -E "$exp_baru" "{username}"
            echo "✅ SUCCESS: Masa aktif {username} diperpanjang sampai $exp_baru."
        else
            echo "❌ ERROR: Akun {username} tidak ditemukan!"
        fi
        """
    else:
        cmd = f"python3 {PATH_BRIDGE} {protocol} renew {username} {hari}"
        
    output = eksekusi_remote(lokasi, cmd)
    hasil = "\n".join(output) if output else "Tidak ada respon balik."
    
    bot.delete_message(message.chat.id, load_msg.message_id)
    bot.send_message(message.chat.id, f"🔄 <b>EKSEKUSI PERPANJANG</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<pre>{hasil}</pre>", parse_mode='HTML')