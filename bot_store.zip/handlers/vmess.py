import threading
import datetime
import telebot
import paramiko
import json
import base64
import re
from bot_init import bot
from config import ADMIN_ID
from database import get_user_data, add_balance, increment_reseller_trx, save_vpn_created
from utils_helper import get_back_markup
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import uuid
# ======================================================
# 1. KONFIGURASI HARGA
# ======================================================
HARGA_VMESS = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":   {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}

# ======================================================
# 2. KONFIGURASI SERVER
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "aws": {
        "ip": "13.229.105.238",  # IP Server SG Baru
        "user": "root", 
        "pass": "azzam2016",      # Password Server SG
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.net"
    }
}

# ======================================================
# HELPER: GENERATE LINK (TETAP DI PYTHON)
# ======================================================
def gen_vmess_link(name, domain, uuid, type="tls"):
    port = "443" if type != "none" else "80"
    net = "grpc" if type == "grpc" else "ws"
    path = "vmess-grpc" if type == "grpc" else "/vmess"
    tls = "tls" if type != "none" else "none"
    type_net = "gun" if type == "grpc" else "none"

    config = {
        "v": "2", "ps": name, "add": domain, "port": port, "id": uuid, "aid": "0",
        "net": net, "type": type_net, "host": domain, "path": path, "tls": tls
    }
    return f"vmess://{base64.b64encode(json.dumps(config).encode()).decode()}"

# ======================================================
# HELPER: EKSEKUSI SCRIPT "BRIDGE" DI VPS (VMESS) - FINAL MATCH
# ======================================================
def create_vmess_remote(username, quota, masa_aktif, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)
    new_uuid = str(uuid.uuid4())

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=10,
            look_for_keys=False,
            allow_agent=False
        )
        
        # COMMAND DIRECT XRAY (Perbaikan Tanda Kutip & Escaping)
        cmd = f"""
        # 1. Cek Duplikat
        if grep -qw "{safe_username}" /etc/xray/config.json; then
            echo "ERROR|Username sudah ada"
            exit 0
        fi
        
        # 2. Hitung Tanggal (Format YYYY-MM-DD)
        exp=$(date -d "{masa_aktif} days" +"%Y-%m-%d")
        
        # 3. Inject ke config.json (Menggunakan Double Quotes agar aman dari bentrok Python vs Bash)
        sed -i "/#vmess$/a\### {safe_username} $exp\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"alterId\\": 0,\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        sed -i "/#vmessgrpc$/a\### {safe_username} $exp\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"alterId\\": 0,\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        
        # 4. Limit IP (Folder fvstore sesuai script kamu)
        mkdir -p /etc/fvstore/limit/vmess/ip
        echo "2" > /etc/fvstore/limit/vmess/ip/{safe_username}
        
        # 5. Limit Quota
        if [ ! -e /etc/vmess ]; then mkdir -p /etc/vmess; fi
        if [ "{quota}" != "0" ]; then
            limit_bytes=$(({quota} * 1024 * 1024 * 1024))
            echo "$limit_bytes" > /etc/vmess/{safe_username}
        fi
        
        # 6. Simpan Database Internal (Format: ### user exp uuid quota ip)
        sed -i "/\\b{safe_username}\\b/d" /etc/vmess/.vmess.db 2>/dev/null
        echo "### {safe_username} $exp {new_uuid} {quota} 2" >> /etc/vmess/.vmess.db
        
        # 7. Restart Xray & Cron (Persis scriptmu)
        systemctl restart xray > /dev/null 2>&1
        service cron restart > /dev/null 2>&1
        
        # 8. Output Wajib
        echo "SUCCESS|{new_uuid}"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        
        output = stdout.read().decode("utf-8", errors="ignore").strip()
        error_msg = stderr.read().decode("utf-8", errors="ignore").strip()
        client.close()

        print(f"--- DEBUG DIRECT VMESS MATCH {lokasi.upper()} ---")
        print(f"STDOUT: {output}")
        if error_msg: print(f"STDERR: {error_msg}")
        print(f"-------------------")

        if "SUCCESS|" in output:
            parts = output.split("SUCCESS|")[1].split("\n")[0]
            return True, "Sukses", {'uuid': parts}
                    
        elif "ERROR|" in output:
            reason = output.split("ERROR|")[1].split("\n")[0]
            return False, f"VPS: {reason}", {}
        else:
            return False, f"VPS Error: {error_msg if error_msg else output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HANDLER UTAMA (TRANSAKSI)
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("buy_vmess_"))
def buy_vmess(call):
    try:
        uid = call.from_user.id
        try: lokasi = call.data.split("_")[2]
        except: return bot.answer_callback_query(call.id, "❌ Error Data")

        if lokasi not in HARGA_VMESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

        user_data = get_user_data(uid)
        if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")

        role = str(user_data.get('role', 'user')).lower()
        saldo = int(user_data.get('balance', 0))

        if 'reseller' in role or 'owner' in role or str(uid) == str(ADMIN_ID):
            price = HARGA_VMESS[lokasi]["reseller"]
            tipe_user = "RESELLER ⚡"
        else:
            price = HARGA_VMESS[lokasi]["user"]
            tipe_user = "MEMBER 👤"

        is_owner = str(uid) == str(ADMIN_ID) or 'owner' in role

        if not is_owner and saldo < price:
            kurang = price - saldo
            msg_error = f"⚠️ <b>SALDO TIDAK CUKUP</b>\nKurang: Rp {kurang:,}"
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"))
            return bot.send_message(call.message.chat.id, msg_error, parse_mode='HTML', reply_markup=markup)
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton("❌ BATAL", callback_data="switch_user"))
        
        msg = bot.send_message(call.message.chat.id, 
            f"<b>⚡ BELI VMESS {lokasi.upper()}</b>\nMasukkan <b>Username</b>:", 
            parse_mode='HTML', reply_markup=m)
        
        bot.register_next_step_handler(msg, lambda m: vmess_process(m, lokasi, price, is_owner))
    except Exception as e: bot.send_message(call.message.chat.id, f"❌ Error: {e}")

def vmess_process(m, lokasi, price, is_owner):
    if m.content_type != 'text': return
    u = m.text.strip()
    if not u.isalnum() or len(u) < 3: return bot.reply_to(m, "❌ Username Invalid (Min 3 huruf/angka)")
    
    uid = m.from_user.id
    status = bot.reply_to(m, f"⏳ <b>Memproses...</b>", parse_mode='HTML')
    
    # KUNCI PERBAIKAN: Gunakan Threading agar bot tidak nge-hang saat proses ssh berlangsung
    threading.Thread(target=vmess_execution, args=(m, u, uid, price, status, lokasi, is_owner)).start()

def vmess_execution(m, u, uid, price, status_msg, lokasi, is_owner):
    try:
        quota_gb = "0" 
        masa_aktif = "30"
        
        succ, info, res = create_vmess_remote(u, quota_gb, masa_aktif, lokasi)
        
        if succ:
            if not is_owner:
                try:
                    add_balance(uid, -price, f"Beli Vmess {lokasi.upper()} ({u})")
                    if get_user_data(uid).get('role') == 'reseller': increment_reseller_trx(uid)
                    sisa_saldo = f"{int(get_user_data(uid).get('balance', 0)):,}"
                except Exception as e:
                    bot.reply_to(m, f"❌ Error Update Saldo DB: {e}")
                    return
            else:
                sisa_saldo = "Unlimited"

            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            
            res_uuid = res.get('uuid')
            domain = SERVER_DATA.get(lokasi)['domain']
            now = datetime.datetime.now()
            exp_date = now + datetime.timedelta(days=int(masa_aktif))
            tgl_exp = exp_date.strftime("%d %b, %Y")
            
            try: save_vpn_created(uid, u, "VMESS", tgl_exp, res_uuid, domain)
            except: pass
            
            link_tls = gen_vmess_link(f"{u}-TLS", domain, res_uuid, "tls")
            link_ntls = gen_vmess_link(f"{u}-NTLS", domain, res_uuid, "none")
            link_grpc = gen_vmess_link(f"{u}-GRPC", domain, res_uuid, "grpc")

            tampilan_kuota = "Unlimited" if quota_gb == "0" else f"{quota_gb} GB"

            txt = f"""
========================================
⚡ <b>AKUN VMESS PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{u}</code>
Domain    : <code>{domain}</code>
Port TLS  : 443
Port NTLS : 80
Port GRPC : 443
UUID      : <code>{res_uuid}</code>
AlterId   : 0
Network   : WS / gRPC
Path      : /vmess
ServiceName: vmess-grpc

🔗 <b>LINK VMESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VMESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VMESS GRPC</b>
<code>{link_grpc}</code>

📋 <b>INFORMASI TAMBAHAN</b>
Expired: <code>{tgl_exp}</code>
Quota: {tampilan_kuota}
Limit IP: 2 Device

========================================
💰 Harga: Rp {price:,} | Sisa Saldo: {sisa_saldo}
"""
            bot.send_message(m.chat.id, txt, parse_mode='HTML', reply_markup=get_back_markup())
        else:
            try: bot.delete_message(m.chat.id, status_msg.message_id)
            except: pass
            bot.reply_to(m, f"❌ <b>GAGAL:</b> {info}", parse_mode='HTML')
            
    except Exception as e:
        bot.reply_to(m, f"❌ Error System Thread: {e}")

# ======================================================
# MONITORING & DELETE (TETAP MENGGUNAKAN SSH DIRECT)
# ======================================================
def get_ssh_connection_monitor(lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return None
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        return client
    except Exception: return None

# ==========================================
#  MENU LIST VMESS ADMIN (TEMA PREMIUM DENGAN DETAIL)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("check_vmess_vps"))
def start_cek_vmess(call): 
    if str(call.from_user.id) != str(ADMIN_ID): return
    try: 
        parts = call.data.split("|")
        lokasi = parts[1]
        page = int(parts[2]) if len(parts) > 2 else 0
    except: 
        lokasi = "sg"
        page = 0
    bot.answer_callback_query(call.id, f"Memuat data {lokasi.upper()}...")
    render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, page)

def render_vmess_page(chat_id, message_id, lokasi, page=0):
    target = SERVER_DATA.get(lokasi)
    if not target: return
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    users = []
    
    import datetime 
    today = datetime.date.today() 

    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        cmd = "grep '### ' /etc/xray/config.json"
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_data = stdout.read().decode("utf-8").strip()
        client.close()
        
        seen = set()
        if raw_data:
            for line in raw_data.split("\n"):
                line = line.strip()
                parts = line.split()
                
                if len(parts) >= 2 and parts[0] == "###":
                    u_name = parts[1]
                    
                    if u_name in seen: continue
                    seen.add(u_name)
                    
                    u_exp_str = "ERROR"
                    sisa_hari = -999
                    status_text = "UNKNOWN"
                    status_icon = "⚠️"
                    
                    if len(parts) >= 3:
                        u_exp_str = parts[2]
                        try:
                            u_exp_date = datetime.datetime.strptime(u_exp_str, "%Y-%m-%d").date()
                            sisa_hari = (u_exp_date - today).days
                            status_icon = "✅ Aktif" if sisa_hari >= 0 else "❌ Expired"
                            u_exp_str = u_exp_date.strftime("%d %b %Y")
                        except: pass

                    users.append({
                        "u": u_name, 
                        "exp": u_exp_str, 
                        "sisa": sisa_hari, 
                        "icon": status_icon, 
                        "quota": "0.0", 
                        "lim": "2"
                    })
                    
    except Exception as e: 
        bot.send_message(chat_id, f"❌ Error Reading Config: {e}")
        return

    users.sort(key=lambda x: x['sisa'], reverse=True)
    
    per_page = 5
    total = len(users)
    total_pages = (total + per_page - 1) // per_page
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    
    start = page * per_page
    end = start + per_page
    cur = users[start:end]
    
    msg = f"⚡ <b>LIST VMESS PREMIUM ({lokasi.upper()})</b>\n"
    msg += f"📊 Total: {total} Akun | Hal: {page+1}/{total_pages if total_pages > 0 else 1}\n"
    msg += f"━━━━━━━━━━━━━━━━━━\n"
    
    m = InlineKeyboardMarkup(row_width=5)
    
    if not users:
        msg += "<i>Belum ada akun VMess yang terdaftar.</i>\n"
    else:
        btn_row = []
        for index, u in enumerate(cur, start=1):
            day_txt = f"{u['sisa']} Hari" if u['sisa'] >= 0 else "DEAD ☠️" if u['sisa'] != -999 else "FORMAT ERROR"
            
            msg += f"<b>{index}. {u['u']}</b> {u['icon']}\n"
            msg += f"   ⏳ Expired: <code>{u['exp']}</code> ({day_txt})\n"
            msg += f"   🎯 Limit  : {u['quota']}GB | {u['lim']} IP\n"
            msg += f"━━━━━━━━━━━━━━━━━━\n"
            
            btn_row.append(InlineKeyboardButton(f"👁️ {index}", callback_data=f"vms_det|{lokasi}|{u['u']}|{page}"))
        
        if btn_row:
            m.row(*btn_row)
    
    nav = []
    if page > 0: nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"vms_nav_rem|{lokasi}|{page-1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"check_vmess_vps|{lokasi}|0"))
    if page < total_pages - 1: nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"vms_nav_rem|{lokasi}|{page+1}"))
    
    if nav: m.row(*nav)
    m.add(InlineKeyboardButton(f"🔙 KEMBALI KE DASHBOARD", callback_data=f"monitor_{lokasi}"))
    
    try: bot.edit_message_text(msg, chat_id, message_id, parse_mode='HTML', reply_markup=m)
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("vms_nav_rem"))
def nav_vmess(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, page = call.data.split("|")
        render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
    except: pass

# ==========================================
#  HANDLER DETAIL POP-UP VMESS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("vms_det"))
def detail_vmess(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        _, lokasi, user, page = call.data.split("|")
    except: return

    target = SERVER_DATA.get(lokasi)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    import datetime 
    
    try:
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        cmd = f"""
        exp_raw=$(grep "### {user} " /etc/xray/config.json | awk '{{print $3}}')
        [ -z "$exp_raw" ] && exp_raw="UNKNOWN"
        
        uuid=$(cat /etc/vmess/{user} 2>/dev/null | grep -oP '(?<="id": ")[^"]*')
        if [ -z "$uuid" ]; then
            uuid=$(grep -A 10 "### {user} " /etc/xray/config.json | grep -oP '(?<="id": ")[^"]*' | head -1)
        fi
        [ -z "$uuid" ] && uuid="UNKNOWN"
        
        echo "$exp_raw|$uuid"
        """
        stdin, stdout, stderr = client.exec_command(cmd)
        raw_output = stdout.read().decode("utf-8").strip()
        client.close()
        
        exp_date_str = "UNKNOWN"
        uuid_str = "UNKNOWN"
        
        if "|" in raw_output:
            parts = raw_output.split("|")
            exp_date_str = parts[0]
            uuid_str = parts[1]

        if exp_date_str != "UNKNOWN":
            try:
                exp_obj = datetime.datetime.strptime(exp_date_str, "%Y-%m-%d")
                exp_date_str = exp_obj.strftime("%d %b %Y")
            except: pass

        domain_server = target.get('domain', target['ip'])
        limit = 2
        
        link_tls = "UUID Tidak Ditemukan"
        link_ntls = "UUID Tidak Ditemukan"
        link_grpc = "UUID Tidak Ditemukan"
        
        if uuid_str != "UNKNOWN":
            link_tls = gen_vmess_link(f"{user}-TLS", domain_server, uuid_str, "tls")
            link_ntls = gen_vmess_link(f"{user}-NTLS", domain_server, uuid_str, "none")
            link_grpc = gen_vmess_link(f"{user}-GRPC", domain_server, uuid_str, "grpc")

        harga = HARGA_VMESS[lokasi]["user"] if lokasi in HARGA_VMESS else 0

        reply_msg = f"""
========================================
⚡ <b>DETAIL AKUN VMESS PREMIUM ({lokasi.upper()})</b>
========================================

🔹 <b>INFORMASI AKUN</b>
Remarks   : <code>{user}</code>
Domain    : <code>{domain_server}</code>
Port TLS  : 443
Port NTLS : 80
Port GRPC : 443
UUID      : <code>{uuid_str}</code>
AlterId   : 0
Network   : WS / gRPC
Path      : /vmess
Service   : vmess-grpc

🔗 <b>LINK VMESS TLS</b>
<code>{link_tls}</code>

🔗 <b>LINK VMESS NON-TLS</b>
<code>{link_ntls}</code>

🔗 <b>LINK VMESS GRPC</b>
<code>{link_grpc}</code>

📋 <b>INFORMASI TAMBAHAN</b>
Expired : <code>{exp_date_str}</code>
Quota   : Unlimited
Limit IP: <code>{limit} Device</code>

========================================
💰 Harga: Rp {harga:,}
========================================
<i>Silakan pilih tindakan di bawah ini:</i>
"""
        
        m = InlineKeyboardMarkup()
        m.add(InlineKeyboardButton(f"🗑️ HAPUS AKUN INI", callback_data=f"vms_del_rem|{lokasi}|{user}|{page}"))
        m.add(InlineKeyboardButton("🔙 KEMBALI KE LIST VMESS", callback_data=f"vms_nav_rem|{lokasi}|{page}"))
        
        bot.edit_message_text(reply_msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Error: {e}", show_alert=True)

# ==========================================
#  HANDLER HAPUS VMESS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("vms_del_rem"))
def del_vmess(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    try:
        parts = call.data.split("|")
        lokasi = parts[1]
        user = parts[2]
        page = parts[3]
    except:
        return bot.answer_callback_query(call.id, "Data Error", show_alert=True)
        
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        target = SERVER_DATA.get(lokasi)
        client.connect(target['ip'], username=target['user'], password=target['pass'], timeout=10)
        
        cmd = f"""
        sed -i "/^### {user} /d" /etc/vmess/.vmess.db
        sed -i "\|### {user} |,\|}}|d" /etc/xray/config.json
        rm -f /etc/vmess/{user}*
        rm -f /etc/kyt/limit/vmess/ip/{user}
        systemctl restart xray
        """
        
        client.exec_command(cmd)
        client.close()
        
        bot.answer_callback_query(call.id, f"✅ {user} Dihapus dari sistem!", show_alert=True)
        render_vmess_page(call.message.chat.id, call.message.message_id, lokasi, int(page))
        
    except Exception as e: 
        bot.answer_callback_query(call.id, f"Error: {str(e)[:50]}", show_alert=True)
        
        
 # ======================================================
# SISTEM LIMIT TRIAL VMESS (DATABASE JSON TERPISAH)
# ======================================================
TRIAL_VMESS_DB = "trial_vmess_history.json"

def load_trial_vmess_data():
    import os, json
    if not os.path.exists(TRIAL_VMESS_DB): return {}
    with open(TRIAL_VMESS_DB, 'r') as f:
        try: return json.load(f)
        except: return {}

def save_trial_vmess_data(data):
    import json
    with open(TRIAL_VMESS_DB, 'w') as f:
        json.dump(data, f, indent=4)

def check_trial_vmess_limit(user_id, role):
    is_owner = str(user_id) == str(ADMIN_ID) or 'owner' in str(role).lower()
    if is_owner: return True, "" # Owner bebas limit

    data = load_trial_vmess_data()
    user_str = str(user_id)

    if user_str in data:
        import datetime
        last_trial_str = data[user_str]['waktu']
        last_trial_date = datetime.datetime.strptime(last_trial_str, "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()

        if 'reseller' in str(role).lower():
            batas_waktu = last_trial_date + datetime.timedelta(days=1) # Limit 1 Hari
            if now < batas_waktu:
                sisa = batas_waktu - now
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                menit = sisa_detik // 60
                return False, f"⚠️ Limit Reseller: Anda sudah membuat trial VMess. Coba lagi dalam {jam} jam {menit} menit."
        else:
            batas_waktu = last_trial_date + datetime.timedelta(days=3) # Limit 3 Hari
            if now < batas_waktu:
                sisa = batas_waktu - now
                hari = sisa.days
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                return False, f"⚠️ Limit User: Anda hanya bisa trial VMess 1x dalam 3 hari. Coba lagi dalam {hari} hari {jam} jam."
    return True, ""

def record_trial_vmess(user_id, username_telegram, vmess_remark):
    import datetime
    data = load_trial_vmess_data()
    data[str(user_id)] = {
        "tg_username": username_telegram,
        "vmess_remark": vmess_remark,
        "waktu": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_trial_vmess_data(data)

# ======================================================
# HELPER: EKSEKUSI BASH UNTUK TRIAL VMESS (PAKAI 'at')
# ======================================================
def create_vmess_trial_remote(username, minutes, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    import re, uuid, paramiko
    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)
    new_uuid = str(uuid.uuid4())

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15,
            look_for_keys=False,
            allow_agent=False
        )
        
        # Script Bash: Inject config -> Restart Xray -> Jadwalkan Delete dengan 'at'
        cmd = f"""
        if grep -qw "{safe_username}" /etc/xray/config.json; then
            echo "ERROR|Username sudah ada"
            exit 0
        fi
        
        # 1. Inject ke config.json
        sed -i "/#vmess$/a\### {safe_username} TRIAL\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"alterId\\": 0,\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        sed -i "/#vmessgrpc$/a\### {safe_username} TRIAL\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"alterId\\": 0,\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        
        # 2. Limit IP
        mkdir -p /etc/fvstore/limit/vmess/ip
        echo "2" > /etc/fvstore/limit/vmess/ip/{safe_username}
        
        # 3. Restart Xray
        systemctl restart xray > /dev/null 2>&1
        
        # 4. JADWALKAN AUTO DELETE DALAM X MENIT MENGGUNAKAN 'at'
        cat << 'EOF' | at now + {minutes} minutes
sed -i "/^### {safe_username} /d" /etc/vmess/.vmess.db
sed -i "\|### {safe_username} |,\|}}|d" /etc/xray/config.json
rm -f /etc/vmess/{safe_username}*
rm -f /etc/fvstore/limit/vmess/ip/{safe_username}
systemctl restart xray
EOF

        echo "SUCCESS|{new_uuid}"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8", errors="ignore").strip()
        client.close()

        if "SUCCESS|" in output:
            parts = output.split("SUCCESS|")[1].split("\n")[0]
            return True, "Sukses", {'uuid': parts}
        elif "ERROR|" in output:
            reason = output.split("ERROR|")[1].split("\n")[0]
            return False, f"VPS: {reason}", {}
        else:
            return False, f"System Error (Pastikan 'at' diinstall): {output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}

# ======================================================
# HANDLER: PILIH DURASI TRIAL VMESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("trial_vmess_"))
def menu_durasi_trial_vmess(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    user_data = get_user_data(user_id)
    if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")
    role = str(user_data.get('role', 'user')).lower()

    bisa_trial, pesan_error = check_trial_vmess_limit(user_id, role)
    if not bisa_trial:
        return bot.answer_callback_query(call.id, pesan_error, show_alert=True)

    try: lokasi = call.data.split("_")[2] 
    except: return bot.answer_callback_query(call.id, "❌ Error Data")

    if lokasi not in HARGA_VMESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("⏱ 30 Menit", callback_data=f"runtrialv_{lokasi}_30"),
        InlineKeyboardButton("⏱ 1 Jam", callback_data=f"runtrialv_{lokasi}_60"),
        InlineKeyboardButton("⏱ 2 Jam", callback_data=f"runtrialv_{lokasi}_120"),
        InlineKeyboardButton("⏱ 3 Jam", callback_data=f"runtrialv_{lokasi}_180"),
        InlineKeyboardButton("❌ BATAL", callback_data="switch_user")
    )

    bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL VMESS {lokasi.upper()}</b>\n\nSilakan pilih durasi trial yang ingin digunakan:", 
        parse_mode='HTML', 
        reply_markup=markup
    )

# ======================================================
# HANDLER: INPUT USERNAME TRIAL VMESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("runtrialv_"))
def start_input_trial_vmess(call):
    chat_id = call.message.chat.id
    data = call.data.split("_")
    lokasi = data[1]
    durasi_menit = int(data[2])

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="switch_user"))

    msg = bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL VMESS {lokasi.upper()} ({durasi_menit} Menit)</b>\n\n"
        f"👇 <b>Masukkan Remarks/Username Trial Baru:</b>\n"
        f"<i>(Hanya huruf/angka, misal: cbtrial01)</i>", 
        parse_mode='HTML',
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, step_get_username_trial_vmess, lokasi, durasi_menit)

def step_get_username_trial_vmess(message, lokasi, durasi_menit):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    
    if not username.isalnum() or len(username) < 3:
        msg = bot.reply_to(message, "❌ Remarks Invalid (Min 3 huruf/angka tanpa spasi). Masukkan lagi:")
        return bot.register_next_step_handler(msg, step_get_username_trial_vmess, lokasi, durasi_menit)

    uid = message.from_user.id
    tg_username = message.from_user.username if message.from_user.username else "Tidak_ada"
    status_msg = bot.reply_to(message, "⏳ <b>Mempersiapkan Akun Trial VMess di Server...</b>", parse_mode='HTML')

    # Eksekusi dengan Threading agar bot tidak macet
    import threading
    threading.Thread(target=execute_create_trial_vmess, args=(message, username, uid, tg_username, durasi_menit, lokasi, status_msg)).start()

# ======================================================
# STEP 3: EKSEKUSI TRIAL VMESS (THREAD)
# ======================================================
def execute_create_trial_vmess(message, username, uid, tg_username, durasi_menit, lokasi, status_msg):
    sukses, info, res = create_vmess_trial_remote(username, durasi_menit, lokasi)

    try: bot.delete_message(message.chat.id, status_msg.message_id)
    except: pass

    if sukses:
        record_trial_vmess(uid, tg_username, username)

        res_uuid = res.get('uuid')
        domain = SERVER_DATA.get(lokasi)['domain']
        limit_ip = 2 
        
        jam = durasi_menit // 60
        sisa_menit = durasi_menit % 60
        waktu_teks = f"{jam} Jam {sisa_menit} Menit" if jam > 0 else f"{durasi_menit} Menit"

        link_tls = gen_vmess_link(f"{username}-TLS", domain, res_uuid, "tls")
        link_ntls = gen_vmess_link(f"{username}-NTLS", domain, res_uuid, "none")
        link_grpc = gen_vmess_link(f"{username}-GRPC", domain, res_uuid, "grpc")

        reply_msg = (
            f"========================================\n"
            f"🆓 <b>AKUN TRIAL VMESS ({lokasi.upper()})</b>\n"
            f"========================================\n\n"
            f"◆ <b>INFORMASI AKUN</b>\n"
            f"Remarks   : <code>{username}</code>\n"
            f"Domain    : <code>{domain}</code>\n"
            f"Port TLS  : 443\n"
            f"Port NTLS : 80\n"
            f"Port GRPC : 443\n"
            f"UUID      : <code>{res_uuid}</code>\n"
            f"AlterId   : 0\n"
            f"Network   : WS / gRPC\n"
            f"Path      : /vmess\n"
            f"Service   : vmess-grpc\n"
            f"Limit IP  : {limit_ip} Device\n"
            f"Durasi    : <code>{waktu_teks} (Otomatis Dihapus)</code>\n\n"
            f"🔗 <b>LINK VMESS TLS</b>\n"
            f"<code>{link_tls}</code>\n\n"
            f"🔗 <b>LINK VMESS NON-TLS</b>\n"
            f"<code>{link_ntls}</code>\n\n"
            f"🔗 <b>LINK VMESS GRPC</b>\n"
            f"<code>{link_grpc}</code>\n\n"
            f"========================================\n"
            f"⚠️ <i>Akun ini adalah trial dan akan otomatis terhapus dari server setelah batas waktu habis.</i>\n"
            f"========================================"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="switch_user"))
        bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        bot.send_message(message.chat.id, f"❌ <b>GAGAL MEMBUAT TRIAL VMESS:</b>\n\n{info}\n\n<i>Silakan coba lagi.</i>", parse_mode='HTML', reply_markup=markup)