import time
import threading
import urllib.parse
import os
import random
import sqlite3
import telebot
import datetime
from bot_init import bot
from config import ADMIN_ID
from database import DB_NAME
from utils_helper import get_back_markup

# --- ANTI-CRASH IMPORT ---
try:
    from config import WA_ADMIN, TG_ADMIN
except ImportError:
    WA_ADMIN = "6287726917005"
    TG_ADMIN = "HookageLegend"

# ==========================================
# 🏦 INFO REKENING & MERCHANT
# ==========================================
NAMA_BANK = "Bank Jago"
NO_REKENING = "102214120746"
NAMA_PEMILIK = "DEDEN IRWANSYAH"
NAMA_MERCHANT = "Hokage Legend Store"
QRIS_PATH = "/root/bot_store/bayar/qris.jpg"

# --- TOPUP MENU ---
@bot.callback_query_handler(func=lambda call: call.data == "topup")
def topup_menu(call):
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    msg = (
        "<b>💸 PILIH METODE DEPOSIT</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Silakan pilih cara pembayaran yang Anda inginkan:\n\n"
        "🤖 <b>OTOMATIS (QRIS GOPAY)</b>\n"
        "• Scan QRIS (All E-Wallet & M-Banking)\n"
        "• Proses Otomatis (1-3 Menit)\n"
        "• Bebas Biaya Admin\n\n"
        "🤖 <b>OTOMATIS (BANK JAGO)</b>\n"
        "• Transfer via M-Banking / E-Wallet\n"
        "• Proses Otomatis (1-3 Menit)\n"
        "• Bebas Biaya Admin\n\n"
        "👤 <b>MANUAL (Transfer Admin)</b>\n"
        "• Chat Admin & Kirim Bukti\n"
        "• Proses Tergantung Admin Online"
    )
    
    m = telebot.types.InlineKeyboardMarkup(row_width=1)
    m.add(telebot.types.InlineKeyboardButton("🤖 OTOMATIS (QRIS GOPAY)", callback_data="topup_qris"))
    m.add(telebot.types.InlineKeyboardButton("🤖 OTOMATIS (BANK JAGO)", callback_data="topup_jago"))
    m.add(telebot.types.InlineKeyboardButton("👤 MANUAL (CHAT ADMIN)", callback_data="topup_manual"))
    m.add(telebot.types.InlineKeyboardButton("🔙 KEMBALI", callback_data="menu_back"))
    
    bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=m)

# ==========================================
# 🟩 FUNGSI DATABASE UMUM
# ==========================================
def catat_trx_deposit(user_id, total_bayar, ref_id, source):
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        c.execute("""
            INSERT INTO transactions (user_id, amount, description, status, ref_id, date, source)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (user_id, total_bayar, f'deposit_{source.lower()}', 'pending', ref_id, now, source))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error Save DB: {e}")
        return False

def check_trx_status(ref_id):
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT status FROM transactions WHERE ref_id = ?", (ref_id,))
        res = c.fetchone()
        conn.close()
        if res: return res[0]
        return 'not_found'
    except: return 'error'

# ==========================================
# 🟢 1. MODUL QRIS GOPAY (OTOMATIS)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "topup_qris")
def topup_qris_start(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    m = telebot.types.InlineKeyboardMarkup()
    m.add(telebot.types.InlineKeyboardButton("❌ BATAL", callback_data="topup"))
    msg = bot.send_message(call.message.chat.id, 
        "<b>🤖 DEPOSIT OTOMATIS (QRIS GOPAY)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "✅ <i>Bebas Biaya Admin (100% Masuk Saldo)</i>\n"
        "🔹 Min: Rp 1.000\n"
        "🔹 Max: Rp 5.000.000\n\n"
        "✍️ <b>Masukkan Nominal Deposit:</b>\n"
        "Contoh: <code>20000</code>", 
        parse_mode='HTML', reply_markup=m)
    bot.register_next_step_handler(msg, process_topup_qris)

def process_topup_qris(message):
    try:
        input_text = message.text.replace('.', '').replace(',', '').strip()
        if input_text.startswith('/'): return 
        if not input_text.isdigit(): return bot.reply_to(message, "❌ Nominal harus angka.")
            
        nominal = int(input_text)
        if nominal < 1000: return bot.reply_to(message, "❌ Minimal Deposit Rp 1.000")
            
        uid = message.from_user.id
        msg_wait = bot.reply_to(message, "⏳ <b>Membuat Tagihan QRIS Unik...</b>", parse_mode='HTML')

        kode_unik = random.randint(11, 499)
        total_bayar = nominal + kode_unik
        ref_id = f"GOPAY-{int(time.time())}"
        
        if not catat_trx_deposit(uid, total_bayar, ref_id, 'GOPAY'):
            try: bot.delete_message(message.chat.id, msg_wait.message_id)
            except: pass
            return bot.reply_to(message, "❌ Gagal membuat tagihan di Database.")

        try: bot.delete_message(message.chat.id, msg_wait.message_id)
        except: pass

        teks_tagihan = (
            f"<b>💳 TAGIHAN DEPOSIT QRIS GOPAY</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🏪 Merchant: <b>{NAMA_MERCHANT}</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"💵 <b>TOTAL TRANSFER :</b>\n"
            f"👉 <code>{total_bayar}</code> 👈 <i>(Ketuk untuk copy)</i>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ <b>PENTING:</b>\n"
            f"<i>1. Simpan gambar QRIS di atas lalu Scan melalui E-Wallet Anda.</i>\n"
            f"<i>2. Masukkan nominal <b>WAJIB</b> sama persis (<b>{total_bayar}</b>). Jangan dibulatkan!</i>\n\n"
            f"🔄 <b>Status: Menunggu Pembayaran...</b>"
        )
        
        markup = telebot.types.InlineKeyboardMarkup()
        markup.add(telebot.types.InlineKeyboardButton("🔄 CEK STATUS", callback_data=f"chk_trx_{ref_id}"))
        markup.add(telebot.types.InlineKeyboardButton("❌ BATAL / TUTUP", callback_data="topup"))
        
        if os.path.exists(QRIS_PATH):
            with open(QRIS_PATH, 'rb') as f:
                sent_msg = bot.send_photo(message.chat.id, f, caption=teks_tagihan, parse_mode='HTML', reply_markup=markup)
        else:
            sent_msg = bot.send_message(message.chat.id, "⚠️ Gambar QRIS Admin Belum Diupload.\n\n" + teks_tagihan, parse_mode='HTML', reply_markup=markup)
        
        t = threading.Thread(target=monitor_deposit_loop, args=(message.chat.id, uid, ref_id, sent_msg.message_id, total_bayar, True))
        t.daemon = True
        t.start()

    except Exception as e:
        bot.reply_to(message, f"❌ Error System: {e}")


# ==========================================
# 🔵 2. MODUL BANK JAGO (OTOMATIS)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "topup_jago")
def topup_jago_start(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    m = telebot.types.InlineKeyboardMarkup()
    m.add(telebot.types.InlineKeyboardButton("❌ BATAL", callback_data="topup"))
    msg = bot.send_message(call.message.chat.id, 
        "<b>🤖 DEPOSIT OTOMATIS (BANK JAGO)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "✅ <i>Bebas Biaya Admin (100% Masuk Saldo)</i>\n"
        "🔹 Min: Rp 10.000\n"
        "🔹 Max: Rp 5.000.000\n\n"
        "✍️ <b>Masukkan Nominal Deposit:</b>\n"
        "Contoh: <code>20000</code>", 
        parse_mode='HTML', reply_markup=m)
    bot.register_next_step_handler(msg, process_topup_jago)

def process_topup_jago(message):
    try:
        input_text = message.text.replace('.', '').replace(',', '').strip()
        if input_text.startswith('/'): return 
        if not input_text.isdigit(): return bot.reply_to(message, "❌ Nominal harus angka.")
            
        nominal = int(input_text)
        if nominal < 10000: return bot.reply_to(message, "❌ Minimal Deposit Rp 10.000")
            
        uid = message.from_user.id
        msg_wait = bot.reply_to(message, "⏳ <b>Membuat Tagihan Unik...</b>", parse_mode='HTML')

        kode_unik = random.randint(11, 499)
        total_bayar = nominal + kode_unik
        ref_id = f"JAGO-{int(time.time())}"
        
        if not catat_trx_deposit(uid, total_bayar, ref_id, 'JAGO'):
            try: bot.delete_message(message.chat.id, msg_wait.message_id)
            except: pass
            return bot.reply_to(message, "❌ Gagal membuat tagihan di Database.")

        try: bot.delete_message(message.chat.id, msg_wait.message_id)
        except: pass

        teks_tagihan = (
            f"<b>💳 TAGIHAN DEPOSIT BANK JAGO</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🏦 Bank Tujuan : <b>{NAMA_BANK}</b>\n"
            f"👤 Atas Nama   : <b>{NAMA_PEMILIK}</b>\n"
            f"📝 No. Rekening:\n"
            f"👉 <code>{NO_REKENING}</code> 👈 <i>(Ketuk untuk copy)</i>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"💵 <b>TOTAL TRANSFER :</b>\n"
            f"👉 <code>{total_bayar}</code> 👈 <i>(Ketuk untuk copy)</i>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ <b>PENTING:</b>\n"
            f"<i>Transfer <b>WAJIB</b> sama persis hingga 3 digit terakhir (<b>{total_bayar}</b>) agar saldo masuk otomatis 1-3 menit. Jangan dibulatkan!</i>\n\n"
            f"🔄 <b>Status: Menunggu Pembayaran...</b>"
        )
        
        markup = telebot.types.InlineKeyboardMarkup()
        markup.add(telebot.types.InlineKeyboardButton("🔄 CEK STATUS", callback_data=f"chk_trx_{ref_id}"))
        markup.add(telebot.types.InlineKeyboardButton("❌ BATAL / TUTUP", callback_data="topup"))
        
        sent_msg = bot.send_message(message.chat.id, teks_tagihan, parse_mode='HTML', reply_markup=markup)
        
        t = threading.Thread(target=monitor_deposit_loop, args=(message.chat.id, uid, ref_id, sent_msg.message_id, total_bayar, False))
        t.daemon = True
        t.start()

    except Exception as e:
        bot.reply_to(message, f"❌ Error System: {e}")

# ==========================================
# ⚙️ BACKGROUND MONITOR & SALDO INJECTOR
# ==========================================

# Fungsi krusial untuk menambah saldo dan mencegah double-claim
def proses_tambah_saldo(user_id, amount, ref_id):
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        
        # Cek status saat ini, pastikan masih 'paid' dari Webhook
        c.execute("SELECT status FROM transactions WHERE ref_id = ?", (ref_id,))
        res = c.fetchone()
        
        if res and res[0] == 'paid':
            # 1. Tambahkan saldo ke tabel users (MENGGUNAKAN KOLOM 'balance')
            c.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
            
            # 2. Ubah status jadi 'completed' agar tidak double-claim
            c.execute("UPDATE transactions SET status = 'completed' WHERE ref_id = ?", (ref_id,))
            
            conn.commit()
            conn.close()
            return True # Berhasil nambah
            
        conn.close()
        return False # Transaksi sudah 'completed' sebelumnya / bukan 'paid'
    except Exception as e:
        print(f"❌ Error Tambah Saldo DB: {e}")
        return False


def monitor_deposit_loop(chat_id, user_id, ref_id, message_id, amount_to_add, is_photo):
    start_time = time.time()
    
    print(f"⏳ [TAGIHAN BARU] UserID: {user_id} | Ref: {ref_id} | Nominal: Rp {amount_to_add:,} | Menunggu pembayaran...")
    
    while time.time() - start_time < 1800: # Timeout 30 Menit
        status = check_trx_status(ref_id)
        
        # PHP Webhook mengubah status ke 'paid'
        if status == 'paid' or status == 'completed':
            
            # Jika masih paid, eksekusi penambahan saldo!
            if status == 'paid':
                berhasil_nambah = proses_tambah_saldo(user_id, amount_to_add, ref_id)
            else:
                berhasil_nambah = True # Status sudah completed oleh request lain

            if berhasil_nambah:
                print(f"✅ [UANG MASUK!] UserID: {user_id} | Ref: {ref_id} | Saldo Rp {amount_to_add:,} BERHASIL DITAMBAHKAN!")
                
                try:
                    success_text = f"✅ <b>PEMBAYARAN DITERIMA!</b>\n━━━━━━━━━━━━━━━━━━\n💰 Saldo Masuk: <b>Rp {amount_to_add:,}</b>\n━━━━━━━━━━━━━━━━━━\nTerima kasih telah topup."
                    if is_photo:
                        bot.edit_message_caption(chat_id=chat_id, message_id=message_id, caption=success_text, parse_mode='HTML', reply_markup=get_back_markup())
                    else:
                        bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=success_text, parse_mode='HTML', reply_markup=get_back_markup())
                except: pass
                
                bot.send_message(chat_id, f"🎉 <b>DEPOSIT SUKSES!</b>\nSaldo Rp {amount_to_add:,} telah ditambahkan ke akun Anda.", parse_mode='HTML', reply_markup=get_back_markup())
            break 
            
        elif status in ['failed', 'expired', 'canceled']:
            print(f"❌ [TAGIHAN EXPIRED/BATAL] Ref: {ref_id} | Nominal: Rp {amount_to_add:,} tidak dibayar.")
            
            try:
                fail_text = f"❌ <b>TAGIHAN DIBATALKAN / KADALUARSA</b>\nSilakan buat request baru."
                if is_photo:
                    bot.edit_message_caption(chat_id=chat_id, message_id=message_id, caption=fail_text, parse_mode='HTML', reply_markup=get_back_markup())
                else:
                    bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=fail_text, parse_mode='HTML', reply_markup=get_back_markup())
            except: pass
            break 
            
        time.sleep(15)

# --- MANUAL CHECK (CEK TOMBOL JAGO & QRIS) ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('chk_trx_'))
def manual_check_deposit(call):
    ref_id = call.data.replace('chk_trx_', '')
    bot.answer_callback_query(call.id, "🔄 Mengecek database sistem...", show_alert=False)
    
    status = check_trx_status(ref_id)
    
    if status == 'paid' or status == 'completed':
        user_id = call.from_user.id
        
        # Ambil nominal dari database untuk ditambahkan
        try:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute("SELECT amount FROM transactions WHERE ref_id = ?", (ref_id,))
            res = c.fetchone()
            amount_to_add = res[0] if res else 0
            conn.close()
        except:
            amount_to_add = 0

        # Jika masih paid (belum terproses background), tambahkan saldonya!
        if status == 'paid':
            proses_tambah_saldo(user_id, amount_to_add, ref_id)

        bot.answer_callback_query(call.id, "✅ SUKSES! Saldo sudah ditambahkan.", show_alert=True)
        try:
            success_text = f"✅ <b>PEMBAYARAN DITERIMA!</b>\n━━━━━━━━━━━━━━━━━━\n💰 Saldo Masuk: <b>Rp {amount_to_add:,}</b>\n━━━━━━━━━━━━━━━━━━\nTerima kasih telah topup."
            if call.message.content_type == 'photo':
                bot.edit_message_caption(chat_id=call.message.chat.id, message_id=call.message.message_id, caption=success_text, parse_mode='HTML', reply_markup=get_back_markup())
            else:
                bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text=success_text, parse_mode='HTML', reply_markup=get_back_markup())
        except: pass
        
    elif status == 'pending':
        bot.answer_callback_query(call.id, "⏳ STATUS: BELUM DIBAYAR (Tunggu 1-3 menit setelah transfer)", show_alert=True)
    else:
        bot.answer_callback_query(call.id, f"❌ Transaksi tidak ditemukan / {status}", show_alert=True)

# ==========================================
# 🔴 3. MODUL MANUAL (TF ADMIN)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "topup_manual")
def topup_manual_start(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    m = telebot.types.InlineKeyboardMarkup()
    m.add(telebot.types.InlineKeyboardButton("❌ BATAL", callback_data="topup"))
    msg = bot.send_message(call.message.chat.id, "<b>👤 DEPOSIT MANUAL (ADMIN)</b>\n━━━━━━━━━━━━━━━━━━━━\n⚠️ <i>Metode ini membutuhkan konfirmasi manual dari Admin.</i>\n\n✍️ <b>Masukkan Nominal Deposit:</b>\nContoh: <code>50000</code>", parse_mode='HTML', reply_markup=m)
    bot.register_next_step_handler(msg, process_topup_manual)

def process_topup_manual(message):
    try:
        input_text = message.text.replace('.', '').replace(',', '').strip()
        if not input_text.isdigit(): return bot.reply_to(message, "❌ Nominal harus angka.")
        amt = int(input_text)
        if amt < 1000: return bot.reply_to(message, "❌ Min Rp 1.000")
        uid = message.from_user.id
        pesan_konfirmasi = f"Halo Admin, saya mau deposit Manual.\n🆔 ID: {uid}\n💰 Nominal: Rp {amt:,}"
        wa_link = f"https://wa.me/{WA_ADMIN}?text={urllib.parse.quote(pesan_konfirmasi)}"
        tg_link = f"https://t.me/{TG_ADMIN}"
        m = telebot.types.InlineKeyboardMarkup()
        m.add(telebot.types.InlineKeyboardButton("✅ KONFIRMASI WA", url=wa_link))
        m.add(telebot.types.InlineKeyboardButton("✅ KONFIRMASI TG", url=tg_link))
        m.add(telebot.types.InlineKeyboardButton("🔙 KEMBALI", callback_data="menu_back"))
        caption = (f"<b>💳 PEMBAYARAN MANUAL</b>\n━━━━━━━━━━━━━━━━━━\n💰 Nominal: <b>Rp {amt:,}</b>\n━━━━━━━━━━━━━━━━━━\n1. Scan QRIS di atas / Transfer ke Admin.\n2. Klik Tombol Konfirmasi di bawah.\n3. Kirim bukti transfer ke Admin.")
        if os.path.exists(QRIS_PATH): 
            with open(QRIS_PATH, 'rb') as f: bot.send_photo(message.chat.id, f, caption=caption, parse_mode='HTML', reply_markup=m)
        else: bot.send_message(message.chat.id, "⚠️ QRIS Admin Belum Diupload.\n" + caption, parse_mode='HTML', reply_markup=m)
    except Exception as e: bot.reply_to(message, f"❌ Error: {e}")