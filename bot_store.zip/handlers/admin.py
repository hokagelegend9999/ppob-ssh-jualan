import sys
import os
import sqlite3
import pandas as pd
from dotenv import load_dotenv
from datetime import datetime
import telebot
import json
import subprocess
import html
import re

from bot_init import bot
from menus import menu_admin, menu_user, menu_user_sg, menu_user_aws
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ForceReply, Message

from database import (
    get_user_data_complete, 
    update_saldo, 
    update_user_role, 
    get_suspicious_users_list, 
    get_user_data, 
    add_balance, 
    find_user,
    get_user_transaction_history,
    update_transaction_status    
)
from handlers import handlers_vps, handlers_ppob, handlers_payment
import handlers.users
from config import ADMIN_ID

BUG_FILE = "bug_notes.json"
DB_NAME = "store_data.db"
broadcast_msg_id = None

DEFAULT_BUGS = {
    "🔵 XL / AXIS": [],
    "🔴 TELKOMSEL": [],
    "🟡 INDOSAT": [],
    "🟣 SMARTFREN": [],
    "⚫ TRI / THREE": [],
    "⚪ LAINNYA": []
}

try:
    from orderkuota_service import check_orderkuota_status
except ImportError:
    check_orderkuota_status = None


def load_bugs():
    if not os.path.exists(BUG_FILE):
        return DEFAULT_BUGS
    try:
        with open(BUG_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, list):
                return {**DEFAULT_BUGS, "⚪ LAINNYA": data}
            for k in DEFAULT_BUGS:
                if k not in data:
                    data[k] = []
            return data
    except:
        return DEFAULT_BUGS

def save_bugs(bugs):
    with open(BUG_FILE, "w") as f:
        json.dump(bugs, f, indent=4)

# --- 1. MENU UTAMA: PILIH PROVIDER ---
@bot.callback_query_handler(func=lambda call: call.data == "show_bug_info")
def handler_bug_categories(call):
    markup = InlineKeyboardMarkup(row_width=2)
    bugs = load_bugs()
    
    btns = []
    for provider in bugs.keys():
        count = len(bugs[provider])
        btns.append(InlineKeyboardButton(f"{provider} ({count})", callback_data=f"bug_cat|{provider}"))
        
    markup.add(*btns)
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    
    msg = "🐛 <b>PILIH KATEGORI PROVIDER</b>\n"
    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg += "<i>Silakan pilih provider untuk melihat daftar Bug / Payload:</i>"
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode="HTML", reply_markup=markup)

# --- 2. SUB-MENU: TAMPILKAN BUG PER PROVIDER ---
@bot.callback_query_handler(func=lambda call: call.data.startswith("bug_cat|"))
def handler_show_provider_bug(call):
    provider = call.data.split("|")[1]
    bugs_dict = load_bugs()
    bug_list = bugs_dict.get(provider, [])
    
    msg = f"🐛 <b>INFO BUG {provider}</b>\n"
    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    if not bug_list:
        msg += "<i>Belum ada catatan bug untuk provider ini.</i>\n"
    else:
        for i, bug in enumerate(bug_list, 1):
            msg += f"<b>{i}.</b> <code>{bug}</code>\n\n"
            
    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg += "<i>ℹ️ Catatan di atas dapat berubah sewaktu-waktu sesuai update provider.</i>"
    
    markup = InlineKeyboardMarkup(row_width=2)
    
    if str(call.from_user.id) == str(ADMIN_ID):
        markup.add(
            InlineKeyboardButton("➕ Tambah Noted", callback_data=f"bug_add|{provider}"),
            InlineKeyboardButton("❌ Hapus Noted", callback_data=f"bug_del_ask|{provider}")
        )
        
    markup.add(InlineKeyboardButton("🔙 PILIH PROVIDER LAIN", callback_data="show_bug_info"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except:
        pass

# --- 3. TAMBAH BUG PER PROVIDER ---
@bot.callback_query_handler(func=lambda call: call.data.startswith("bug_add|"))
def handler_add_bug_ask(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    provider = call.data.split("|")[1]
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"bug_cat|{provider}"))
    
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    msg = bot.send_message(
        call.message.chat.id, 
        f"📝 <b>Tambah Noted untuk {provider}:</b>\n\n"
        "Kirimkan teks Bug / Payload sekarang:", 
        parse_mode="HTML", 
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_add_bug, provider)

def process_add_bug(message, provider):
    if not message.text or message.text == "/start": return
    
    bugs = load_bugs()
    if provider not in bugs: bugs[provider] = []
    bugs[provider].append(message.text)
    save_bugs(bugs)
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton(f"🔙 Lihat Bug {provider}", callback_data=f"bug_cat|{provider}"))
    
    bot.send_message(message.chat.id, f"✅ <b>Noted ditambahkan ke {provider}!</b>", parse_mode="HTML", reply_markup=markup)

# --- 4. HAPUS BUG PER PROVIDER ---
@bot.callback_query_handler(func=lambda call: call.data.startswith("bug_del_ask|"))
def handler_del_bug_ask(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    provider = call.data.split("|")[1]
    
    bugs_dict = load_bugs()
    bug_list = bugs_dict.get(provider, [])
    
    if not bug_list:
        return bot.answer_callback_query(call.id, "❌ Tidak ada noted untuk dihapus.")
        
    markup = InlineKeyboardMarkup(row_width=1)
    for i, bug in enumerate(bug_list):
        btn_text = f"❌ {bug[:25]}..." if len(bug) > 25 else f"❌ {bug}"
        markup.add(InlineKeyboardButton(btn_text, callback_data=f"bug_del_exec|{provider}|{i}"))
    
    markup.add(InlineKeyboardButton("🔙 BATAL", callback_data=f"bug_cat|{provider}"))
    
    bot.edit_message_text(
        f"🗑 <b>Pilih noted {provider} yang ingin dihapus:</b>", 
        call.message.chat.id, call.message.message_id, 
        parse_mode="HTML", reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("bug_del_exec|"))
def handler_del_bug_exec(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    parts = call.data.split("|")
    provider = parts[1]
    idx = int(parts[2])
    
    bugs_dict = load_bugs()
    
    if provider in bugs_dict and 0 <= idx < len(bugs_dict[provider]):
        bugs_dict[provider].pop(idx)
        save_bugs(bugs_dict)
        bot.answer_callback_query(call.id, "✅ Noted dihapus!")
        
    handler_del_bug_ask(call)

@bot.callback_query_handler(func=lambda call: call.data == "admin_panel")
def back_to_owner_menu(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        try:
            markup = menu_user(role="user") 
            if call.message.content_type == 'text':
                bot.edit_message_text(
                    "🏠 <b>MENU UTAMA</b>\nSilakan pilih layanan:",
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=markup,
                    parse_mode="HTML"
                )
            else:
                try: bot.delete_message(call.message.chat.id, call.message.message_id)
                except: pass
                bot.send_message(call.message.chat.id, "🏠 <b>MENU UTAMA</b>\nSilakan pilih layanan:", reply_markup=markup, parse_mode="HTML")
        except Exception as e:
            bot.send_message(call.message.chat.id, "Ketik /start untuk ke menu utama.")
        return

    first_name = call.from_user.first_name
    username = call.from_user.username
    uid = call.from_user.id

    text = (
        f"👑 <b>PANEL OWNER (GOD MODE)</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"👋 Halo, Bos <b>{first_name}</b>!\n"
        f"🆔 ID Akun: <code>{uid}</code>\n"
        f"👤 Username: @{username}\n"
        f"💰 <b>Saldo: ♾️ UNLIMITED (Owner)</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"🛡️ <i>Sebagai Owner, Anda memiliki akses penuh dan saldo tak terbatas.\n"
        f"Gunakan panel di bawah untuk mengelola bot.</i>"
    )

    markup = menu_admin(uid)
    
    try:
        if call.message.content_type == 'text':
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
        else:
            try: bot.delete_message(call.message.chat.id, call.message.message_id)
            except: pass
            bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
    except Exception as e:
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "back_to_main_menu")
def handler_back_main_menu_global(call):
    markup = menu_user(role="user")
    
    try:
        bot.edit_message_text(
            "🏠 <b>MENU UTAMA</b>\nSilakan pilih layanan:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode="HTML"
        )
    except Exception as e:
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except:
            pass
        
        bot.send_message(
            call.message.chat.id,
            "🏠 <b>MENU UTAMA</b>\nSilakan pilih layanan:",
            reply_markup=markup,
            parse_mode="HTML"
        )

# ==========================================
# 2. HANDLER MANAJEMEN SALDO (TAMBAH/KURANG)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("add_saldo|") or call.data.startswith("min_saldo|"))
def action_manage_saldo(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")
    
    action, target_id = call.data.split("|")
    mode = "TAMBAH" if action == "add_saldo" else "POTONG"
    
    try: bot.delete_message(call.message.chat.id, call.message.message_id)
    except: pass
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 BATAL / KEMBALI", callback_data=f"back_to_detail|{target_id}"))

    msg = bot.send_message(
        call.message.chat.id,
        f"💰 **{mode} SALDO USER**\n"
        f"Target ID: `{target_id}`\n\n"
        f"Masukkan nominal (Angka saja):\n"
        f"Contoh: `50000`",
        parse_mode="Markdown",
        reply_markup=markup 
    )
    
    bot.register_next_step_handler(msg, process_update_saldo, target_id, mode)

def process_update_saldo(message, target_id, mode):
    try:
        text_input = message.text.strip().replace(".", "").replace(",", "")
        
        if not text_input.isdigit():
            return bot.send_message(message.chat.id, "❌ Nominal harus berupa angka! Ulangi dari awal.")
            
        nominal = int(text_input)
        amount = nominal if mode == "TAMBAH" else -nominal
        
        success_balance = update_saldo(target_id, amount)
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Kembali ke Panel", callback_data="admin_panel"))

        if success_balance is not False:
            bot.send_message(
                message.chat.id,
                f"✅ **BERHASIL DIUPDATE!**\n\n"
                f"👤 Target: `{target_id}`\n"
                f"💵 Nominal: {'+' if amount > 0 else ''}Rp {nominal:,}\n"
                f"💰 Sisa Saldo: **Rp {success_balance:,}**\n"
                f"🔒 Status: **VALID & AMAN**",
                parse_mode="Markdown",
                reply_markup=markup
            )
            try:
                pesan = f"💰 Saldo Anda telah {'ditambahkan' if amount > 0 else 'dipotong'} oleh Admin sebesar **Rp {nominal:,}**"
                bot.send_message(target_id, pesan, parse_mode="Markdown")
            except: pass
        else:
            bot.send_message(message.chat.id, "❌ **GAGAL UPDATE!**\nDatabase menolak transaksi (Security Alert) atau saldo user tidak cukup.", reply_markup=markup)
            
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error: {e}")  

@bot.callback_query_handler(func=lambda call: call.data.startswith("back_to_detail|"))
def back_to_user_detail_handler(call):
    try:
        bot.clear_step_handler_by_chat_id(call.message.chat.id)
        _, target_id = call.data.split("|")
        
        try: bot.delete_message(call.message.chat.id, call.message.message_id)
        except: pass
        
        dummy_msg = Message(
            message_id=call.message.message_id, 
            from_user=call.from_user, 
            date=call.message.date, 
            chat=call.message.chat, 
            content_type="text", 
            options={}, 
            json_string=""
        )
        dummy_msg.text = target_id
        
        process_find_user_detail(dummy_msg)
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error Back: {e}")
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Panel Owner", callback_data="admin_panel"))
        bot.send_message(call.message.chat.id, "Kembali ke menu utama.", reply_markup=markup)

# ==========================================
# 3. HANDLER CEK USER DETAIL
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "check_user_by_id_menu")
def ask_user_id_detail(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    try:
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except:
        pass

    msg = bot.send_message(
        call.message.chat.id,
        "🔎 **MODE CEK USER DETAIL**\n\n"
        "Silakan balas pesan ini dengan **ID Telegram** user yang ingin dicek.\n"
        "Contoh: `1234567890`",
        parse_mode="Markdown",
        reply_markup=ForceReply(selective=True)
    )
    bot.register_next_step_handler(msg, process_find_user_detail)

def process_find_user_detail(message):
    try:
        target_id = message.text.strip()

        if not target_id.isdigit():
            msg = bot.send_message(message.chat.id, "❌ **ID harus berupa angka!**\nSilakan input ulang:", reply_markup=ForceReply())
            return bot.register_next_step_handler(msg, process_find_user_detail)

        user = get_user_data_complete(target_id)

        if not user:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔄 Cari Lagi", callback_data="check_user_by_id_menu"))
            markup.add(InlineKeyboardButton("🔙 Menu Owner", callback_data="admin_panel"))
            
            return bot.send_message(
                message.chat.id, 
                f"❌ User dengan ID `{target_id}` tidak ditemukan di database.", 
                parse_mode="Markdown", 
                reply_markup=markup
            )

        u_id = user[0]
        u_username = f"@{user[1]}" if user[1] else "Tanpa Username"
        u_saldo = user[2]
        u_role = user[3]
        
        saldo_fmt = "{:,}".format(u_saldo).replace(",", ".")

        text_detail = (
            f"👤 **DETAIL USER DITEMUKAN**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 ID: `{u_id}`\n"
            f"👤 Username: {u_username}\n"
            f"💰 Saldo: **Rp {saldo_fmt}**\n"
            f"🔰 Role: **{u_role.upper()}**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"👇 _Pilih aksi untuk user ini:_"
        )

        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("➕ Tambah Saldo", callback_data=f"add_saldo|{u_id}"),
            InlineKeyboardButton("➖ Potong Saldo", callback_data=f"min_saldo|{u_id}")
        )
        markup.add(
            InlineKeyboardButton("📜 Cek Riwayat", callback_data=f"history_by_id|{u_id}"),
            InlineKeyboardButton("🔄 Reset Sesi", callback_data=f"reset_session|{u_id}")
        )
        
        if u_role.lower() == "user":
            markup.add(InlineKeyboardButton("⬆️ Up ke Reseller", callback_data=f"up_reseller|{u_id}"))
        elif u_role.lower() == "reseller":
            markup.add(InlineKeyboardButton("⬇️ Down ke User", callback_data=f"down_user|{u_id}"))

        markup.add(InlineKeyboardButton("🔙 Kembali ke Menu Owner", callback_data="admin_panel"))

        bot.send_message(message.chat.id, text_detail, parse_mode="Markdown", reply_markup=markup)

    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Terjadi kesalahan: {e}")
        
# ==========================================
#  HANDLER FORCE GAGAL & REFUND MANUAL OLEH ADMIN
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("force_fail|"))
def handler_force_fail(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        parts = call.data.split("|")
        ref_id = parts[1]
        target_id = parts[2]
        
        conn = sqlite3.connect("store_data.db")
        c = conn.cursor()
        c.execute("SELECT status, amount FROM transactions WHERE ref_id = ?", (ref_id,))
        data_trx = c.fetchone()
        conn.close()

        if not data_trx:
            return bot.answer_callback_query(call.id, "❌ Transaksi tidak ditemukan di Database!", show_alert=True)

        status_lama = str(data_trx[0]).lower()
        if status_lama == "gagal":
            return bot.answer_callback_query(call.id, "⚠️ Transaksi ini SUDAH berstatus GAGAL sebelumnya!", show_alert=True)

        update_transaction_status(ref_id, "gagal", "Digagalkan Manual oleh Admin")

        amount = abs(int(data_trx[1]))
        refund_msg = ""
        if amount > 0:
            add_balance(target_id, amount, f"REFUND MANUAL {ref_id}", ref_id=f"REF-{ref_id}")
            refund_msg = f"\n💰 Saldo Rp {amount:,} di-refund ke User."

        bot.answer_callback_query(call.id, f"✅ Sukses! Transaksi dibatalkan.{refund_msg}", show_alert=True)

        call.data = f"hist_{target_id}_1"
        try:
            from handlers.users.admin_saldo import detail_user_history
            detail_user_history(call)
        except: pass

    except Exception as e:
        bot.answer_callback_query(call.id, f"❌ Error Action: {str(e)}", show_alert=True)

# ==========================================
#  HANDLER TOMBOL IGNORE (AGAR TIDAK ERROR)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "ignore")
def handler_ignore_button(call):
    bot.answer_callback_query(call.id)

@bot.callback_query_handler(func=lambda call: call.data.startswith("cp|"))
def handler_copy_sn_admin(call):
    try:
        parts = call.data.split("|")
        sn_text = "|".join(parts[2:])
        bot.answer_callback_query(call.id, f"🔑 SN: {sn_text}", show_alert=True)
    except: pass

# --- HANDLER SHORTCUT SALDO (DARI DASHBOARD) ---
@bot.callback_query_handler(func=lambda call: "saldo_add_shortcut" in call.data)
def shortcut_add_saldo(call):
    from handlers.users.admin_saldo import process_saldo_add_step2
    target_id = call.data.split("|")[1]
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"hist_{target_id}_1"))
    
    msg = bot.send_message(
        call.message.chat.id, 
        f"➕ <b>ISI SALDO MANUAL (SHORTCUT)</b>\nTarget ID: <code>{target_id}</code>\n\nMasukkan Nominal (Angka saja):", 
        parse_mode='HTML',
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_add_step2, target_id)

@bot.callback_query_handler(func=lambda call: "saldo_min_shortcut" in call.data)
def shortcut_deduct_saldo(call):
    from handlers.users.admin_saldo import process_saldo_deduct_step2
    target_id = call.data.split("|")[1]
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL", callback_data=f"hist_{target_id}_1"))
    
    msg = bot.send_message(
        call.message.chat.id, 
        f"➖ <b>POTONG SALDO MANUAL (SHORTCUT)</b>\nTarget ID: <code>{target_id}</code>\n\nMasukkan Nominal Potongan:", 
        parse_mode='HTML',
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, process_saldo_deduct_step2, target_id)

# ==========================================
# 4. HANDLER BACKUP DATABASE & SOURCE CODE
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "backup_db")
def export_database_handler(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    markup_back = InlineKeyboardMarkup()
    markup_back.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))

    msg = None 

    try:
        msg = bot.send_message(call.message.chat.id, "⏳ <b>Sedang memproses FULL BACKUP...</b>\nMohon tunggu...", parse_mode='HTML')
        
        today = datetime.now().strftime("%Y-%m-%d_%H-%M")
        excel_filename = f"Backup_Store_{today}.xlsx"
        zip_filename = f"FULL_BACKUP_BOT_{today}.zip"

        # --------------------------------------------------------
        # A. KIRIM FILE DATABASE ASLI (.DB)
        if os.path.exists(DB_NAME):
            with open(DB_NAME, 'rb') as f:
                bot.send_document(
                    call.message.chat.id, 
                    f, 
                    caption=f"🗄 <b>DATABASE RAW ({today})</b>\nFile ini untuk restore jika bot error.",
                    parse_mode='HTML'
                )
        else:
            bot.send_message(call.message.chat.id, "❌ File database asli tidak ditemukan!")

        # --------------------------------------------------------
        # B. EXPORT KE EXCEL (.XLSX)
        conn = sqlite3.connect(DB_NAME)
        
        with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
            try:
                df_users = pd.read_sql_query("SELECT * FROM users", conn)
                if 'user_id' in df_users.columns:
                    df_users['user_id'] = df_users['user_id'].astype(str)
                df_users.to_excel(writer, sheet_name='Users', index=False)
            except Exception as e:
                print(f"Gagal export sheet Users: {e}")

            try:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='transactions'")
                if cursor.fetchone():
                    df_trx = pd.read_sql_query("SELECT * FROM transactions", conn)
                    for col in ['user_id', 'id', 'ref_id', 'sn']:
                        if col in df_trx.columns:
                            df_trx[col] = df_trx[col].astype(str)
                            
                    df_trx.to_excel(writer, sheet_name='Transaksi', index=False)
            except Exception as e:
                print(f"Gagal export sheet Transaksi: {e}")
        
        conn.close()

        if os.path.exists(excel_filename):
            with open(excel_filename, 'rb') as f:
                bot.send_document(
                    call.message.chat.id, 
                    f, 
                    caption=f"📊 <b>LAPORAN EXCEL ({today})</b>\nData user dan transaksi agar mudah dibaca.",
                    parse_mode='HTML'
                )
            os.remove(excel_filename)
        
        # --------------------------------------------------------
        # C. ZIP FOLDER BOT + SERVICE SYSTEMD
        try: bot.edit_message_text(f"⏳ <b>Mengompres Folder & Service...</b>", call.message.chat.id, msg.message_id, parse_mode='HTML')
        except: pass
        
        command = f"zip -r {zip_filename} /root/bot_store /etc/systemd/system/bot-store.service /etc/systemd/system/webhook-store.service /usr/bin/addss-bot /usr/bin/addssh-bot /usr/bin/addtr-bot /usr/bin/addvless-bot /usr/bin/addws-bot -x '*/venv/*' '*/__pycache__/*' '*/.git/*' '*.zip' '*.xlsx'"
        
        try:
            subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
            
            if os.path.exists(zip_filename):
                with open(zip_filename, 'rb') as f:
                    bot.send_document(
                        call.message.chat.id,
                        f,
                        caption=f"📦 <b>FULL SOURCE + SERVICE ({today})</b>\n\n✅ <b>Isi Backup:</b>\n1. Folder /root/bot_store\n2. Service Bot Telegram\n3. Service Webhook\n4. File /usr/bin/ (addss, addssh, addtr, addvless, addws)\n\n<i>Simpan file ini untuk pindah VPS!</i>",
                        parse_mode='HTML',
                        timeout=300
                    )
                os.remove(zip_filename)
            else:
                bot.send_message(call.message.chat.id, "❌ Gagal membuat file ZIP (File output tidak ditemukan).")
                
        except subprocess.CalledProcessError as e:
            err_msg = str(e.output.decode('utf-8')) if e.output else str(e)
            bot.send_message(call.message.chat.id, f"❌ <b>Error ZIP:</b>\nPastikan 'zip' terinstall (apt install zip).\n\nLog: {err_msg}", parse_mode='HTML')

        try: bot.delete_message(call.message.chat.id, msg.message_id)
        except: pass

        bot.send_message(
            call.message.chat.id, 
            "✅ <b>BACKUP LENGKAP SELESAI!</b>\nSemua data telah diamankan.", 
            parse_mode='HTML', 
            reply_markup=markup_back
        )

    except Exception as e:
        try: 
            if msg: bot.delete_message(call.message.chat.id, msg.message_id)
        except: pass
        
        bot.reply_to(call.message, f"❌ Gagal Backup Total: {e}", reply_markup=markup_back)
        print(f"Error Backup: {e}")

# ==========================================
# 5. SISTEM BROADCAST
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "broadcast_all")
def start_broadcast(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak!", show_alert=True)

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATALKAN", callback_data="admin_panel"))
    
    msg = bot.edit_message_text(
        "📢 <b>MODE BROADCAST AKTIF</b>\n\n"
        "Silakan kirim pesan (Teks, Gambar, Video, atau GIF) yang akan disebar ke semua member.",
        call.message.chat.id, 
        call.message.message_id, 
        parse_mode='HTML', 
        reply_markup=markup
    )
    bot.register_next_step_handler(msg, show_broadcast_preview)

def show_broadcast_preview(message):
    global broadcast_msg_id 
    
    if message.text == "/cancel": 
        bot.send_message(message.chat.id, "✅ Broadcast dibatalkan.")
        return

    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("✅ KIRIM SEKARANG", callback_data="confirm_broadcast"), 
        InlineKeyboardButton("❌ BATAL", callback_data="admin_panel")
    )

    bot.send_message(message.chat.id, "👇 <b>PRATINJAU PESAN ANDA:</b>", parse_mode='HTML')
    
    broadcast_msg_id = message.message_id
    
    bot.copy_message(
        chat_id=message.chat.id, 
        from_chat_id=message.chat.id, 
        message_id=message.message_id, 
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data == "confirm_broadcast")
def final_send_broadcast(call):
    global broadcast_msg_id
    
    if not broadcast_msg_id: 
        return bot.answer_callback_query(call.id, "❌ Pesan kadaluarsa, ulangi broadcast.", show_alert=True)
    
    try:
        conn = sqlite3.connect(DB_NAME)
        users = conn.cursor().execute("SELECT user_id FROM users").fetchall()
        conn.close()
    except Exception as e:
        return bot.send_message(call.message.chat.id, f"❌ Error Database: {e}")
    
    total_users = len(users)
    if total_users == 0:
        return bot.send_message(call.message.chat.id, "❌ Tidak ada user di database.")

    status_msg = bot.send_message(call.message.chat.id, f"🚀 <b>Memulai Broadcast ke {total_users} user...</b>", parse_mode='HTML')
    
    success = 0
    failed = 0
    processed = 0
    
    markup_user = InlineKeyboardMarkup()
    markup_user.add(InlineKeyboardButton("🏠 MENU UTAMA", callback_data="back_to_main_menu"))

    for u in users:
        processed += 1
        user_id = u[0]
        
        try:
            bot.copy_message(
                chat_id=user_id, 
                from_chat_id=call.message.chat.id, 
                message_id=broadcast_msg_id, 
                reply_markup=markup_user
            )
            success += 1
        except Exception:
            failed += 1
        
        if processed % 15 == 0 or processed == total_users:
            percent = int((processed / total_users) * 100)
            bar_length = 10
            filled_length = int(bar_length * processed // total_users)
            bar = "█" * filled_length + "░" * (bar_length - filled_length)
            
            text_progress = (
                f"🚀 <b>STATUS BROADCAST</b>\n"
                f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                f"📊 Progress: <b>{percent}%</b>\n"
                f"<code>[{bar}]</code>\n\n"
                f"✅ Berhasil : <b>{success}</b>\n"
                f"❌ Gagal    : <b>{failed}</b>\n"
                f"👥 Total    : <b>{processed}/{total_users}</b>"
            )
            
            try:
                bot.edit_message_text(
                    text_progress, 
                    call.message.chat.id, 
                    status_msg.message_id, 
                    parse_mode='HTML'
                )
            except: 
                pass

    try: bot.delete_message(call.message.chat.id, status_msg.message_id)
    except: pass
    
    final_report = (
        f"✅ <b>BROADCAST SELESAI!</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"📨 Terkirim : <b>{success}</b>\n"
        f"🚫 Gagal    : <b>{failed}</b>\n"
        f"👥 Total    : <b>{total_users}</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    )
    
    markup_back = InlineKeyboardMarkup()
    markup_back.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="admin_panel"))
    
    bot.send_message(call.message.chat.id, final_report, parse_mode='HTML', reply_markup=markup_back)
    
    broadcast_msg_id = None


# ==========================================
# 7. VPS SERVICE UTILS
# ==========================================
def get_service_status(service_name):
    try:
        result = subprocess.run(
            ["systemctl", "is-active", service_name], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
        status = result.stdout.strip()
        
        if status == "active" or status == "running":
            return "🟢 Online"
        else:
            return "🔴 Offline"
    except:
        return "🔴 Error"

def get_system_info():
    try:
        os_name = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | tr -d '\"'", shell=True).decode().strip()
    except:
        os_name = "Unknown Linux"

    try:
        ip_vps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        ip_vps = "Unknown IP"

    try:
        if os.path.exists("/etc/xray/domain"):
            with open("/etc/xray/domain", "r") as f:
                domain = f.read().strip()
        else:
            domain = "-"
    except:
        domain = "-"
        
    return os_name, ip_vps, domain

@bot.callback_query_handler(func=lambda call: call.data == "vps_service_detail")
def show_vps_service_detail(call):
    if str(call.from_user.id) != str(ADMIN_ID):
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    bot.answer_callback_query(call.id, "🔄 Memeriksa service...")
    bot.send_chat_action(call.message.chat.id, 'typing')

    os_name, ip_vps, domain = get_system_info()

    ssh_stat = get_service_status("ssh")
    dropbear_stat = get_service_status("dropbear")
    haproxy_stat = get_service_status("haproxy")
    xray_stat = get_service_status("xray") 
    nginx_stat = get_service_status("nginx")
    cron_stat = get_service_status("cron")
    fail2ban_stat = get_service_status("fail2ban")
    openvpn_stat = get_service_status("openvpn")
    
    udp1 = get_service_status("udp-mini-1")
    udp2 = get_service_status("udp-mini-2")
    udp3 = get_service_status("udp-mini-3")
    
    ws_stat = get_service_status("ws") 
    udp_custom = get_service_status("udp-custom")

    msg = (
        f"<b>🖥 SYSTEM INFORMATION</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"💻 <b>OS      :</b> <code>{os_name}</code>\n"
        f"🌐 <b>IP      :</b> <code>{ip_vps}</code>\n"
        f"🎯 <b>Domain :</b> <code>{domain}</code>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"<b>⚙️ SERVICE STATUS</b>\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"🟢 <b>SSH / OVPN</b>\n"
        f"├ SSH Service    : {ssh_stat}\n"
        f"├ Dropbear       : {dropbear_stat}\n"
        f"├ OpenVPN        : {openvpn_stat}\n"
        f"└ Haproxy        : {haproxy_stat}\n\n"
        f"🔵 <b>XRAY / TUNNEL</b>\n"
        f"├ Xray Core      : {xray_stat}\n"
        f"├ (Vmess/Vless/Trojan/Shadowsocks)\n"
        f"└ Websocket      : {ws_stat}\n\n"
        f"🟠 <b>UDP & LAINNYA</b>\n"
        f"├ Nginx Web      : {nginx_stat}\n"
        f"├ UDP Custom     : {udp_custom}\n"
        f"├ BadVPN 7100    : {udp1}\n"
        f"├ BadVPN 7200    : {udp2}\n"
        f"├ BadVPN 7300    : {udp3}\n"
        f"├ Crontab        : {cron_stat}\n"
        f"└ Fail2Ban       : {fail2ban_stat}\n"
        f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    )

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔄 Refresh Status", callback_data="vps_service_detail"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="check_vps_menu"))

    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=markup)

# ==========================================
#  HANDLER CEK PROVIDER (WAJIB ADA DI ADMIN.PY)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("cek_provider|"))
def handler_cek_provider_realtime_admin(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        data = call.data.split("|")
        
        if len(data) < 4:
            return bot.answer_callback_query(call.id, "❌ Data transaksi rusak.")
            
        ref_id = data[1]
        tujuan = data[2]
        kode_produk = data[3]
        target_user_id = data[4] if len(data) > 4 else None
        
        bot.answer_callback_query(call.id, "⏳ Menghubungi Server Pusat...")

        try:
            from orderkuota_service import check_orderkuota_status
            # Import tambahan fungsi perapih teks dari handlers_ppob
            from handlers.handlers_ppob import format_info_server, parse_respon_server, format_sn_pln
            
            hasil_cek_raw = check_orderkuota_status(
                ref_id=ref_id, 
                nomor_tujuan=tujuan, 
                kode_produk=kode_produk
            )
            
            # 1. Ekstrak SN sebelum dihapus oleh formatter
            parsed_data = parse_respon_server(hasil_cek_raw)
            sn_display = format_sn_pln(parsed_data['sn']) if parsed_data['sn'] != '-' else "<code>-</code>"
            
            # 2. Format Info Server (yang akan menghapus teks SN ganda)
            hasil_cek = format_info_server(hasil_cek_raw)
            
        except ImportError:
            hasil_cek = "❌ Error: File orderkuota_service.py tidak ditemukan."
            sn_display = "<code>-</code>"
        except Exception as e:
            hasil_cek = f"❌ Error System: {str(e)}"
            sn_display = "<code>-</code>"

        if "SN" in str(hasil_cek_raw) and "Sedang Proses" not in str(hasil_cek_raw):
            try:
                import re
                match = re.search(r"SN:?\s*([A-Za-z0-9\/]+)", str(hasil_cek_raw))
                if match:
                    real_sn = match.group(1)
                    update_transaction_status(ref_id, "sukses", real_sn)
            except: pass

        # Desain ulang hasil dengan kolom SN/Token khusus
        msg_text = (
            f"📡 <b>HASIL CEK STATUS PROVIDER</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 RefID : <code>{ref_id}</code>\n"
            f"📱 Tujuan : <code>{tujuan}</code>\n"
            f"📦 Kode  : {kode_produk}\n\n"
            f"🎟️ <b>SN/Token:</b>\n"
            f"{sn_display}\n\n"
            f"📝 <b>Respon Server Pusat:</b>\n"
            f"<i>{hasil_cek}</i>"
        )

        markup = InlineKeyboardMarkup()
        
        if "tidak ditemukan" in str(hasil_cek).lower():
             markup.add(InlineKeyboardButton("⚠️ CEK ULANG", callback_data=f"cek_provider|{ref_id}|{tujuan}|{kode_produk}|{target_user_id}"))

        if target_user_id:
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data=f"hist_{target_user_id}_1"))
        else:
            markup.add(InlineKeyboardButton("🔙 TUTUP / KEMBALI", callback_data="admin_panel"))

        bot.send_message(call.message.chat.id, msg_text, parse_mode="HTML", reply_markup=markup)

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error Handler: {str(e)}")
        
# ==========================================
#  HANDLER CEK PROVIDER (SMART CHECK + AUTO REFUND)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("chk|"))
def handler_check_provider_smart(call):
    if str(call.from_user.id) != str(ADMIN_ID): 
        return bot.answer_callback_query(call.id, "❌ Akses Ditolak")

    try:
        parts = call.data.split("|")
        ref_id = parts[1]
        target_id = parts[2]
        
        bot.answer_callback_query(call.id, "⏳ Melacak Transaksi...")
        loading_msg = bot.send_message(call.message.chat.id, "📡 <b>Menghubungi Server Pusat...</b>", parse_mode='HTML')

        history = get_user_transaction_history(target_id)
        trx_found = None
        if history:
            for item in history:
                if str(item[8]) == str(ref_id): 
                    trx_found = item
                    break
        
        if not trx_found:
            try: bot.delete_message(call.message.chat.id, loading_msg.message_id)
            except: pass
            return bot.send_message(call.message.chat.id, "❌ Transaksi tidak ditemukan di database bot.")

        tujuan = trx_found[4] if trx_found[4] not in [None, "None"] else "-"
        deskripsi = trx_found[1]
        status_lama = str(trx_found[3]).lower()
        
        try:
            clean_desc = deskripsi.replace("pembelian", "").replace("Pembelian", "").strip().upper()
            parts_desc = clean_desc.split()
            guess_code = "CEK"
            for p in parts_desc:
                if any(c.isdigit() for c in p) and p.isupper():
                    guess_code = p
                    break
            if guess_code == "CEK" and len(parts_desc) > 1: guess_code = parts_desc[1]
        except: guess_code = "CEK"

        # --- LOGIKA SMART CHECKER ---
        hasil_cek = "Menunggu..."
        provider_used = "UNKNOWN"
        status_asli_provider = "pending"
        sn_display = "<code>-</code>" # Default kosong

        try:
            from orderkuota_service import check_orderkuota_status
            # Import tambahan fungsi perapih teks dari handlers_ppob
            from handlers.handlers_ppob import format_info_server, parse_respon_server, format_sn_pln
            
            tanggal_asli = trx_found[0] 
            
            hasil_cek_raw = check_orderkuota_status(ref_id, tujuan, guess_code, tanggal=tanggal_asli)
            
            # 1. Ekstrak SN sebelum dihapus formatter
            parsed_data = parse_respon_server(hasil_cek_raw)
            if parsed_data['sn'] != '-':
                sn_display = format_sn_pln(parsed_data['sn'])
            
            # 2. Format Info Server (menghapus SN ganda)
            hasil_cek = format_info_server(hasil_cek_raw)
            provider_used = "OKECONNECT"
            
            if any(x in str(hasil_cek).lower() for x in ["tidak ada", "tidak ditemukan"]):
                status_asli_provider = "pending" 
                
        except ImportError:
            hasil_cek = "Module OkeConnect Missing"
            status_asli_provider = "error_api"

        try: bot.delete_message(call.message.chat.id, loading_msg.message_id)
        except: pass

        update_status = None
        update_note = None
        status_icon = "⚠️"

        if status_asli_provider == "error_api" or "tidak ditemukan" in str(hasil_cek).lower():
            status_icon = "⚠️"
            update_note = "Cek manual di web Pusat"
            update_status = None 
        
        elif status_asli_provider == "sukses" or ("sukses" in str(hasil_cek).lower() and "gagal" not in str(hasil_cek).lower()):
            update_status = "sukses"
            status_icon = "✅"
            try:
                import re
                match = re.search(r"SN(?:\s*\/|:|=)?\s*([A-Za-z0-9\/\-\.]+)", str(hasil_cek_raw))
                update_note = match.group(1) if match else "Sukses"
            except: update_note = "Sukses Manual"

        elif status_asli_provider == "gagal" or any(x in str(hasil_cek).lower() for x in ["gagal", "stok habis"]):
            update_status = "gagal"
            status_icon = "❌"
            update_note = str(hasil_cek)[:100]

        # --- UPDATE DB & AUTO REFUND ---
        db_report = "⚠️ Database tidak diubah (Aman dari Bug)"
        
        if update_status:
            update_transaction_status(ref_id, update_status, update_note)
            
            if update_status == 'gagal' and status_lama != 'gagal':
                nominal_asli = int(trx_found[2]) 
                refund_amount = abs(nominal_asli) 
                if refund_amount > 0:
                    add_balance(target_id, refund_amount, f"REFUND {ref_id}", ref_id=f"REF-{ref_id}")
                    db_report = f"✅ Status: GAGAL | 💰 <b>REFUND SUKSES: Rp {refund_amount:,}</b>"
            else:
                db_report = f"✅ Database diupdate: <b>{update_status.upper()}</b>"

        # Tampilan pesan yang sudah ditambah kolom SN/Token
        msg_text = (
            f"<b>📡 LIVE CHECKER RESULT ({provider_used})</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<b>📦 INFO TRANSAKSI</b>\n"
            f"├ 🆔 RefID : <code>{ref_id}</code>\n"
            f"├ 🎯 Tujuan: <code>{tujuan}</code>\n"
            f"└ 🏷 Kode  : <code>{guess_code}</code>\n\n"
            f"🎟️ <b>SN/Token:</b>\n"
            f"{sn_display}\n\n"
            f"<b>📝 RESPON SERVER PUSAT</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{status_icon}\n<i>{hasil_cek}</i>\n\n"
            f"<b>⚙️ SYSTEM ACTION:</b>\n"
            f"└ {db_report}"
        )

        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE RIWAYAT", callback_data=f"hist_{target_id}_1"))
        bot.send_message(call.message.chat.id, msg_text, parse_mode="HTML", reply_markup=markup)

    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error System: {str(e)}")

# ==========================================
# 8. SISTEM MENU MULTI-SERVER (INDO & SINGAPORE)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "menu_vps_select")
def handler_select_server_region(call):
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("🇮🇩 SERVER INDONESIA", callback_data="region_indo"),
        InlineKeyboardButton("🇸🇬 SERVER SINGAPORE", callback_data="region_sg"),
        InlineKeyboardButton("🇸🇬 SERVER SINGAPORE AWS", callback_data="region_aws")
    )
    markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="back_to_main_menu"))
    
    bot.edit_message_text(
        "🌍 <b>PILIH LOKASI SERVER</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Silakan pilih lokasi server yang tersedia untuk performa terbaik Anda:",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data == "region_indo")
def handler_region_indo(call):
    try:
        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("☁️ SSH OVPN", callback_data="buy_ssh"),
            InlineKeyboardButton("🟣 VMess", callback_data="buy_vmess"),
            InlineKeyboardButton("🔵 VLess", callback_data="buy_vless"),
            InlineKeyboardButton("🟠 Trojan", callback_data="buy_trojan")
        )
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="menu_vps_select"))
        
        bot.edit_message_text(
            "🇮🇩 <b>SERVER INDONESIA</b>\nSilakan pilih layanan:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )
    except Exception as e:
        bot.send_message(call.message.chat.id, f"Error Menu Indo: {e}")

@bot.callback_query_handler(func=lambda call: call.data in ["buy_ssh_sg", "buy_vmess_sg", "buy_vless_sg", "buy_trojan_sg"])
def handler_process_buy_sg(call):
    jenis = call.data.replace("buy_", "").replace("_sg", "").upper()
    bot.answer_callback_query(call.id, f"🇸🇬 Memilih {jenis} Singapore...")
    
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("⏳ Trial (Gratis)", callback_data=f"deal_sg_trial|{jenis}"),
        InlineKeyboardButton("📅 30 Hari (VIP)", callback_data=f"deal_sg_30|{jenis}")
    )
    markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="region_sg"))
    
    bot.edit_message_text(
        f"🇸🇬 <b>ORDER {jenis} SINGAPORE</b>\n"
        f"Pilih durasi layanan:",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data in ["buy_ssh_aws", "buy_vmess_aws", "buy_vless_aws", "buy_trojan_aws"])
def handler_process_buy_aws(call):
    jenis = call.data.replace("buy_", "").replace("_aws", "").upper()
    bot.answer_callback_query(call.id, f"🇸🇬 Memilih {jenis} Singapore...")
    
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("⏳ Trial (Gratis)", callback_data=f"deal_aws_trial|{jenis}"),
        InlineKeyboardButton("📅 30 Hari (VIP)", callback_data=f"deal_sg_30|{jenis}")
    )
    markup.add(InlineKeyboardButton("🔙 Kembali", callback_data="region_aws"))
    
    bot.edit_message_text(
        f"🇸🇬 <b>ORDER {jenis} SINGAPORE</b>\n"
        f"Pilih durasi layanan:",
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("deal_aws_"))
def handler_deal_aws(call):
    try:
        _, mode, jenis = call.data.split("_")[1].split("|")
        jenis = call.data.split("|")[1]
        mode = call.data.split("|")[0].replace("deal_aws_", "") 
        
        user_id = call.from_user.id
        
        bot.send_message(call.message.chat.id, 
                         f"⚙️ <b>Memproses {jenis} Server Singapore...</b>\n"
                         f"⏳ Durasi: {mode}\n\n"
                         f"<i>(Silakan tambahkan logic koneksi ke IP Server Singapore di bagian ini pada code Python Anda)</i>", 
                         parse_mode='HTML')
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error SG Handler: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith("deal_sg_"))
def handler_deal_sg(call):
    try:
        _, mode, jenis = call.data.split("_")[1].split("|")
        jenis = call.data.split("|")[1]
        mode = call.data.split("|")[0].replace("deal_sg_", "")
        
        user_id = call.from_user.id
        
        bot.send_message(call.message.chat.id, 
                         f"⚙️ <b>Memproses {jenis} Server Singapore...</b>\n"
                         f"⏳ Durasi: {mode}\n\n"
                         f"<i>(Silakan tambahkan logic koneksi ke IP Server Singapore di bagian ini pada code Python Anda)</i>", 
                         parse_mode='HTML')
        
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ Error SG Handler: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "back_to_owner")
def back_owner_bridge(call):
    back_to_owner_menu(call)

# ==========================================
# FITUR DARURAT: SET STATUS MANUAL + AUTO REFUND
# ==========================================
@bot.message_handler(commands=['setstatus'])
def manual_set_status(message):
    if str(message.from_user.id) != str(ADMIN_ID): 
        return
        
    parts = message.text.split(" ", 3)
    if len(parts) < 4:
        pesan = (
            "❌ <b>Format Salah!</b>\n\n"
            "Gunakan format:\n<code>/setstatus [RefID] [sukses/gagal] [SN/Keterangan]</code>\n\n"
            "Contoh Gagal:\n<code>/setstatus TRX123 gagal Saldo direfund</code>"
        )
        return bot.reply_to(message, pesan, parse_mode='HTML')
        
    ref_id = parts[1]
    status_baru = parts[2].lower()
    sn_atau_ket = parts[3]
    
    if status_baru not in ['sukses', 'gagal']:
        return bot.reply_to(message, "❌ Status hanya boleh diisi <b>sukses</b> atau <b>gagal</b>.", parse_mode='HTML')
    
    try:
        import sqlite3
        from database import update_transaction_status, get_transaction_status, add_balance
        
        status_lama = get_transaction_status(ref_id)
        
        update_transaction_status(ref_id, status_baru, sn_atau_ket)
        
        refund_msg = ""
        if status_baru == "gagal" and status_lama != "gagal":
            conn = sqlite3.connect("store_data.db")
            c = conn.cursor()
            c.execute("SELECT user_id, amount FROM transactions WHERE ref_id = ?", (ref_id,))
            data_trx = c.fetchone()
            conn.close()
            
            if data_trx:
                uid = data_trx[0]
                amount = abs(int(data_trx[1]))
                
                if amount > 0:
                    add_balance(uid, amount, f"REFUND MANUAL {ref_id}", ref_id=f"REF-{ref_id}")
                    refund_msg = f"\n\n💰 <b>SALDO Rp {amount:,} TELAH OTOMATIS DI-REFUND KE USER {uid}</b>"
        
        icon = "✅" if status_baru == "sukses" else "❌"
        sukses_msg = (
            f"{icon} <b>DATABASE BERHASIL DIUPDATE!</b>\n"
            f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            f"🆔 RefID : <code>{ref_id}</code>\n"
            f"📊 Status: <b>{status_baru.upper()}</b>\n"
            f"📝 Ket   : <code>{sn_atau_ket}</code>{refund_msg}"
        )
        
        markup = telebot.types.InlineKeyboardMarkup()
        markup.add(telebot.types.InlineKeyboardButton("🔙 KEMBALI KE PANEL ADMIN", callback_data="admin_panel"))
        
        bot.reply_to(message, sukses_msg, parse_mode='HTML', reply_markup=markup)
        
    except Exception as e:
        bot.reply_to(message, f"❌ Gagal update database: {e}")

# ======================================================
# SISTEM LIMIT TRIAL VLESS (DATABASE JSON TERPISAH)
# ======================================================
TRIAL_VLESS_DB = "trial_vless_history.json"

def load_trial_vless_data():
    import os, json
    if not os.path.exists(TRIAL_VLESS_DB): return {}
    with open(TRIAL_VLESS_DB, 'r') as f:
        try: return json.load(f)
        except: return {}

def save_trial_vless_data(data):
    import json
    with open(TRIAL_VLESS_DB, 'w') as f:
        json.dump(data, f, indent=4)

def check_trial_vless_limit(user_id, role):
    is_owner = str(user_id) == str(ADMIN_ID) or 'owner' in str(role).lower()
    if is_owner: return True, ""

    data = load_trial_vless_data()
    user_str = str(user_id)

    if user_str in data:
        from datetime import datetime, timedelta
        last_trial_str = data[user_str]['waktu']
        last_trial_date = datetime.strptime(last_trial_str, "%Y-%m-%d %H:%M:%S")
        now = datetime.now()

        if 'reseller' in str(role).lower():
            batas_waktu = last_trial_date + timedelta(days=1)
            if now < batas_waktu:
                sisa = batas_waktu - now
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                menit = sisa_detik // 60
                return False, f"⚠️ Limit Reseller: Anda sudah membuat trial VLess. Coba lagi dalam {jam} jam {menit} menit."
        else:
            batas_waktu = last_trial_date + timedelta(days=3)
            if now < batas_waktu:
                sisa = batas_waktu - now
                hari = sisa.days
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                return False, f"⚠️ Limit User: Anda hanya bisa trial VLess 1x dalam 3 hari. Coba lagi dalam {hari} hari {jam} jam."
    return True, ""

def record_trial_vless(user_id, username_telegram, vless_remark):
    from datetime import datetime
    data = load_trial_vless_data()
    data[str(user_id)] = {
        "tg_username": username_telegram,
        "vless_remark": vless_remark,
        "waktu": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_trial_vless_data(data)

# ======================================================
# HELPER: EKSEKUSI BASH UNTUK TRIAL VLESS (PAKAI 'at')
# ======================================================
def create_vless_trial_remote(username, minutes, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    import re, uuid, paramiko
    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)
    new_uuid = str(uuid.uuid4())

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15,
            look_for_keys=False,
            allow_agent=False
        )
        
        cmd = f"""
        if grep -qw "{safe_username}" /etc/xray/config.json; then
            echo "ERROR|Username sudah ada"
            exit 0
        fi
        
        sed -i "/#vless$/a\#& {safe_username} TRIAL\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        sed -i "/#vlelessgrpc$/a\#& {safe_username} TRIAL\\n}},{{\\"id\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        
        mkdir -p /etc/fvstore/limit/vless/ip
        echo "2" > /etc/fvstore/limit/vless/ip/{safe_username}
        mkdir -p /etc/kyt/limit/vless/ip
        echo "2" > /etc/kyt/limit/vless/ip/{safe_username}
        
        systemctl restart xray > /dev/null 2>&1
        
        cat << 'EOF' | at now + {minutes} minutes
sed -i "\|#& {safe_username} |,\|}}|d" /etc/xray/config.json
rm -f /etc/fvstore/limit/vless/ip/{safe_username}
rm -f /etc/kyt/limit/vless/ip/{safe_username}
rm -f /etc/vless/{safe_username}*
systemctl restart xray
EOF

        echo "SUCCESS|{new_uuid}"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8", errors="ignore").strip()
        client.close()

        if "SUCCESS|" in output:
            parts = output.split("SUCCESS|")[1].split("\n")[0]
            return True, "Sukses", {'uuid': parts}
        elif "ERROR|" in output:
            reason = output.split("ERROR|")[1].split("\n")[0]
            return False, f"VPS: {reason}", {}
        else:
            return False, f"System Error (Pastikan 'at' diinstall): {output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}
# ======================================================
# TAMBAHKAN VARIABEL INI AGAR TIDAK ERROR (NameError)
# ======================================================
HARGA_VLESS = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":  {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}
# ======================================================
# DATA SERVER UNTUK KONEKSI TRIAL VLESS
# ======================================================
SERVER_DATA = {
    "sg": {
        "ip": "13.229.105.238",
        "user": "root", 
        "pass": "azzam2016",
        "name": "🇸🇬 Singapore", 
        "domain": "aws.hokage.web.id"
    },
    "aws": {
        "ip": "13.229.105.238",
        "user": "root", 
        "pass": "azzam2016",
        "name": "🇸🇬 Singapore aws", 
        "domain": "aws.hokage.web.id"
    },
    "indo": {
        "ip": "103.150.226.10", 
        "user": "root", 
        "pass": "azzam2016", 
        "name": "🇮🇩 Indonesia", 
        "domain": "id.hokagelegend.net"
    }
}

# ======================================================
# HELPER: GENERATE LINK VLESS UNTUK TRIAL
# ======================================================
def gen_vless_link(name, domain, uuid, type="tls"):
    import base64
    port = "443" if type != "none" else "80"
    path = "vless-grpc" if type == "grpc" else "/vless"
    security = "tls" if type != "none" else "none"
    
    if type == "grpc":
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=grpc&serviceName={path}#{name}"
    else:
        return f"vless://{uuid}@{domain}:{port}?security={security}&encryption=none&type=ws&path={path}#{name}"
# ======================================================
# HANDLER: PILIH DURASI TRIAL VLESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("trial_vless_"))
def menu_durasi_trial_vless(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    user_data = get_user_data(user_id)
    if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")
    role = str(user_data.get('role', 'user')).lower()

    bisa_trial, pesan_error = check_trial_vless_limit(user_id, role)
    if not bisa_trial:
        return bot.answer_callback_query(call.id, pesan_error, show_alert=True)

    try: lokasi = call.data.split("_")[2] 
    except: return bot.answer_callback_query(call.id, "❌ Error Data")

    if lokasi not in HARGA_VLESS: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("⏱ 30 Menit", callback_data=f"runtrialvl_{lokasi}_30"),
        InlineKeyboardButton("⏱ 1 Jam", callback_data=f"runtrialvl_{lokasi}_60"),
        InlineKeyboardButton("⏱ 2 Jam", callback_data=f"runtrialvl_{lokasi}_120"),
        InlineKeyboardButton("⏱ 3 Jam", callback_data=f"runtrialvl_{lokasi}_180"),
        InlineKeyboardButton("❌ BATAL", callback_data="switch_user")
    )

    bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL VLESS {lokasi.upper()}</b>\n\nSilakan pilih durasi trial yang ingin digunakan:", 
        parse_mode='HTML', 
        reply_markup=markup
    )

# ======================================================
# HANDLER: INPUT USERNAME TRIAL VLESS
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("runtrialvl_"))
def start_input_trial_vless(call):
    chat_id = call.message.chat.id
    data = call.data.split("_")
    lokasi = data[1]
    durasi_menit = int(data[2])

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="switch_user"))

    msg = bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL VLESS {lokasi.upper()} ({durasi_menit} Menit)</b>\n\n"
        f"👇 <b>Masukkan Remarks/Username Trial Baru:</b>\n"
        f"<i>(Hanya huruf/angka, misal: coba01)</i>", 
        parse_mode='HTML',
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, step_get_username_trial_vless, lokasi, durasi_menit)

def step_get_username_trial_vless(message, lokasi, durasi_menit):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    
    import re
    if not re.match("^[a-zA-Z0-9]+$", username) or len(username) < 3:
        msg = bot.reply_to(message, "❌ Remarks Invalid (Min 3 huruf/angka tanpa spasi). Masukkan lagi:")
        return bot.register_next_step_handler(msg, step_get_username_trial_vless, lokasi, durasi_menit)

    uid = message.from_user.id
    tg_username = message.from_user.username if message.from_user.username else "Tidak_ada"
    status_msg = bot.reply_to(message, "⏳ <b>Mempersiapkan Akun Trial VLess di Server...</b>", parse_mode='HTML')

    import threading
    threading.Thread(target=execute_create_trial_vless, args=(message, username, uid, tg_username, durasi_menit, lokasi, status_msg)).start()

# ======================================================
# STEP 3: EKSEKUSI TRIAL VLESS (THREAD)
# ======================================================
def execute_create_trial_vless(message, username, uid, tg_username, durasi_menit, lokasi, status_msg):
    sukses, info, res = create_vless_trial_remote(username, durasi_menit, lokasi)

    try: bot.delete_message(message.chat.id, status_msg.message_id)
    except: pass

    if sukses:
        record_trial_vless(uid, tg_username, username)

        res_uuid = res.get('uuid')
        domain = SERVER_DATA.get(lokasi)['domain']
        limit_ip = 2 
        
        jam = durasi_menit // 60
        sisa_menit = durasi_menit % 60
        waktu_teks = f"{jam} Jam {sisa_menit} Menit" if jam > 0 else f"{durasi_menit} Menit"

        link_tls = gen_vless_link(f"{username}-TLS", domain, res_uuid, "tls")
        link_ntls = gen_vless_link(f"{username}-NTLS", domain, res_uuid, "none")
        link_grpc = gen_vless_link(f"{username}-GRPC", domain, res_uuid, "grpc")

        reply_msg = (
            f"========================================\n"
            f"🆓 <b>AKUN TRIAL VLESS ({lokasi.upper()})</b>\n"
            f"========================================\n\n"
            f"◆ <b>INFORMASI AKUN</b>\n"
            f"Remarks   : <code>{username}</code>\n"
            f"Domain    : <code>{domain}</code>\n"
            f"UUID      : <code>{res_uuid}</code>\n"
            f"Limit IP  : {limit_ip} Device\n"
            f"Durasi    : <code>{waktu_teks} (Otomatis Dihapus)</code>\n\n"
            f"🔗 <b>LINK VLESS TLS</b>\n"
            f"<code>{link_tls}</code>\n\n"
            f"🔗 <b>LINK VLESS NON-TLS</b>\n"
            f"<code>{link_ntls}</code>\n\n"
            f"🔗 <b>LINK VLESS GRPC</b>\n"
            f"<code>{link_grpc}</code>\n\n"
            f"========================================\n"
            f"⚠️ <i>Akun ini adalah trial dan akan otomatis terhapus dari server setelah batas waktu habis.</i>\n"
            f"========================================"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="switch_user"))
        bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        bot.send_message(message.chat.id, f"❌ <b>GAGAL MEMBUAT TRIAL VLESS:</b>\n\n{info}\n\n<i>Silakan coba lagi.</i>", parse_mode='HTML', reply_markup=markup)

# ======================================================
# SISTEM LIMIT TRIAL TROJAN (DATABASE JSON TERPISAH)
# ======================================================
TRIAL_TROJAN_DB = "trial_trojan_history.json"

def load_trial_trojan_data():
    import os, json
    if not os.path.exists(TRIAL_TROJAN_DB): return {}
    with open(TRIAL_TROJAN_DB, 'r') as f:
        try: return json.load(f)
        except: return {}

def save_trial_trojan_data(data):
    import json
    with open(TRIAL_TROJAN_DB, 'w') as f:
        json.dump(data, f, indent=4)

def check_trial_trojan_limit(user_id, role):
    is_owner = str(user_id) == str(ADMIN_ID) or 'owner' in str(role).lower()
    if is_owner: return True, ""

    data = load_trial_trojan_data()
    user_str = str(user_id)

    if user_str in data:
        from datetime import datetime, timedelta
        last_trial_str = data[user_str]['waktu']
        last_trial_date = datetime.strptime(last_trial_str, "%Y-%m-%d %H:%M:%S")
        now = datetime.now()

        if 'reseller' in str(role).lower():
            batas_waktu = last_trial_date + timedelta(days=1)
            if now < batas_waktu:
                sisa = batas_waktu - now
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                menit = sisa_detik // 60
                return False, f"⚠️ Limit Reseller: Anda sudah membuat trial Trojan. Coba lagi dalam {jam} jam {menit} menit."
        else:
            batas_waktu = last_trial_date + timedelta(days=3)
            if now < batas_waktu:
                sisa = batas_waktu - now
                hari = sisa.days
                jam, sisa_detik = divmod(sisa.seconds, 3600)
                return False, f"⚠️ Limit User: Anda hanya bisa trial Trojan 1x dalam 3 hari. Coba lagi dalam {hari} hari {jam} jam."
    return True, ""

def record_trial_trojan(user_id, username_telegram, trojan_remark):
    from datetime import datetime
    data = load_trial_trojan_data()
    data[str(user_id)] = {
        "tg_username": username_telegram,
        "trojan_remark": trojan_remark,
        "waktu": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_trial_trojan_data(data)

# ======================================================
# HELPER: EKSEKUSI BASH UNTUK TRIAL TROJAN (PAKAI 'at')
# ======================================================
def create_trojan_trial_remote(username, minutes, lokasi):
    target = SERVER_DATA.get(lokasi)
    if not target: return False, "Server tidak ditemukan", {}

    import re, uuid, paramiko
    safe_username = re.sub(r'[^a-zA-Z0-9]', '', username)
    new_uuid = str(uuid.uuid4())

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(
            target['ip'], 
            username=target['user'], 
            password=target['pass'], 
            timeout=15,
            look_for_keys=False,
            allow_agent=False
        )
        
        # Script Bash: Inject config -> Restart Xray -> Jadwalkan Delete dengan 'at'
        cmd = f"""
        if grep -qw "{safe_username}" /etc/xray/config.json; then
            echo "ERROR|Username sudah ada"
            exit 0
        fi
        
        # 1. Inject ke config.json (Format Trojan #! )
        sed -i "/#trojanws$/a\#! {safe_username} TRIAL\\n}},{{\\"password\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        sed -i "/#trojangrpc$/a\#! {safe_username} TRIAL\\n}},{{\\"password\\": \\"{new_uuid}\\",\\"email\\": \\"{safe_username}\\"" /etc/xray/config.json
        
        # 2. Limit IP
        mkdir -p /etc/kyt/limit/trojan/ip
        echo "2" > /etc/kyt/limit/trojan/ip/{safe_username}
        
        # 3. Restart Xray
        systemctl restart xray > /dev/null 2>&1
        
        # 4. JADWALKAN AUTO DELETE DALAM X MENIT MENGGUNAKAN 'at'
        cat << 'EOF' | at now + {minutes} minutes
sed -i "\|#! {safe_username} |,\|}}|d" /etc/xray/config.json
rm -f /etc/kyt/limit/trojan/ip/{safe_username}
rm -f /etc/trojan/{safe_username}*
systemctl restart xray
EOF

        echo "SUCCESS|{new_uuid}"
        """
        
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode("utf-8", errors="ignore").strip()
        client.close()

        if "SUCCESS|" in output:
            parts = output.split("SUCCESS|")[1].split("\n")[0]
            return True, "Sukses", {'uuid': parts}
        elif "ERROR|" in output:
            reason = output.split("ERROR|")[1].split("\n")[0]
            return False, f"VPS: {reason}", {}
        else:
            return False, f"System Error (Pastikan 'at' diinstall): {output[:50]}", {}

    except Exception as e:
        return False, f"SSH Error: {str(e)}", {}
# ======================================================
# TAMBAHKAN VARIABEL INI AGAR TIDAK ERROR (NameError)
# ======================================================
HARGA_TROJAN = {
    "sg":   {"user": 15000, "reseller": 10000},
    "aws":  {"user": 15000, "reseller": 10000},
    "indo": {"user": 13000, "reseller": 8000}
}
# ======================================================
# HELPER: GENERATOR LINK TROJAN UNTUK TRIAL
# ======================================================
def gen_trojan_link(user, domain, password, type="ws"):
    import urllib.parse
    safe_name = urllib.parse.quote(user)
    if type == "grpc":
        return f"trojan://{password}@{domain}:443?security=tls&type=grpc&serviceName=trojan-grpc#{safe_name}"
    else:
        return f"trojan://{password}@{domain}:443?security=tls&type=ws&path=%2Ftrojan#{safe_name}"
# ======================================================
# HANDLER: PILIH DURASI TRIAL TROJAN
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("trial_trojan_"))
def menu_durasi_trial_trojan(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    user_data = get_user_data(user_id)
    if not user_data: return bot.answer_callback_query(call.id, "❌ User tidak ditemukan")
    role = str(user_data.get('role', 'user')).lower()

    bisa_trial, pesan_error = check_trial_trojan_limit(user_id, role)
    if not bisa_trial:
        return bot.answer_callback_query(call.id, pesan_error, show_alert=True)

    try: lokasi = call.data.split("_")[2] 
    except: return bot.answer_callback_query(call.id, "❌ Error Data")

    if lokasi not in HARGA_TROJAN: return bot.answer_callback_query(call.id, "❌ Lokasi tidak valid")

    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("⏱ 30 Menit", callback_data=f"runtrialtr_{lokasi}_30"),
        InlineKeyboardButton("⏱ 1 Jam", callback_data=f"runtrialtr_{lokasi}_60"),
        InlineKeyboardButton("⏱ 2 Jam", callback_data=f"runtrialtr_{lokasi}_120"),
        InlineKeyboardButton("⏱ 3 Jam", callback_data=f"runtrialtr_{lokasi}_180"),
        InlineKeyboardButton("❌ BATAL", callback_data="switch_user")
    )

    bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL TROJAN {lokasi.upper()}</b>\n\nSilakan pilih durasi trial yang ingin digunakan:", 
        parse_mode='HTML', 
        reply_markup=markup
    )

# ======================================================
# HANDLER: INPUT USERNAME TRIAL TROJAN
# ======================================================
@bot.callback_query_handler(func=lambda call: call.data.startswith("runtrialtr_"))
def start_input_trial_trojan(call):
    chat_id = call.message.chat.id
    data = call.data.split("_")
    lokasi = data[1]
    durasi_menit = int(data[2])

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="switch_user"))

    msg = bot.send_message(
        chat_id, 
        f"🆓 <b>TRIAL TROJAN {lokasi.upper()} ({durasi_menit} Menit)</b>\n\n"
        f"👇 <b>Masukkan Remarks/Username Trial Baru:</b>\n"
        f"<i>(Hanya huruf/angka, misal: coba01)</i>", 
        parse_mode='HTML',
        reply_markup=markup
    )
    
    bot.register_next_step_handler(msg, step_get_username_trial_trojan, lokasi, durasi_menit)

def step_get_username_trial_trojan(message, lokasi, durasi_menit):
    if message.text == '/cancel': return bot.reply_to(message, "❌ Dibatalkan.")
    username = message.text.strip()
    
    import re
    if not re.match("^[a-zA-Z0-9]+$", username) or len(username) < 3:
        msg = bot.reply_to(message, "❌ Remarks Invalid (Min 3 huruf/angka tanpa spasi). Masukkan lagi:")
        return bot.register_next_step_handler(msg, step_get_username_trial_trojan, lokasi, durasi_menit)

    uid = message.from_user.id
    tg_username = message.from_user.username if message.from_user.username else "Tidak_ada"
    status_msg = bot.reply_to(message, "⏳ <b>Mempersiapkan Akun Trial Trojan di Server...</b>", parse_mode='HTML')

    import threading
    threading.Thread(target=execute_create_trial_trojan, args=(message, username, uid, tg_username, durasi_menit, lokasi, status_msg)).start()

# ======================================================
# STEP 3: EKSEKUSI TRIAL TROJAN (THREAD)
# ======================================================
def execute_create_trial_trojan(message, username, uid, tg_username, durasi_menit, lokasi, status_msg):
    sukses, info, res = create_trojan_trial_remote(username, durasi_menit, lokasi)

    try: bot.delete_message(message.chat.id, status_msg.message_id)
    except: pass

    if sukses:
        record_trial_trojan(uid, tg_username, username)

        res_uuid = res.get('uuid')
        domain = SERVER_DATA.get(lokasi)['domain']
        limit_ip = 2 
        
        jam = durasi_menit // 60
        sisa_menit = durasi_menit % 60
        waktu_teks = f"{jam} Jam {sisa_menit} Menit" if jam > 0 else f"{durasi_menit} Menit"

        link_ws = gen_trojan_link(username, domain, res_uuid, "ws")
        link_grpc = gen_trojan_link(username, domain, res_uuid, "grpc")

        reply_msg = (
            f"========================================\n"
            f"🆓 <b>AKUN TRIAL TROJAN ({lokasi.upper()})</b>\n"
            f"========================================\n\n"
            f"◆ <b>INFORMASI AKUN</b>\n"
            f"Remarks   : <code>{username}</code>\n"
            f"Domain    : <code>{domain}</code>\n"
            f"Port TLS  : 443\n"
            f"Password  : <code>{res_uuid}</code>\n"
            f"Network   : WS / gRPC\n"
            f"Path WS   : /trojan\n"
            f"Service   : trojan-grpc\n"
            f"Limit IP  : {limit_ip} Device\n"
            f"Durasi    : <code>{waktu_teks} (Otomatis Dihapus)</code>\n\n"
            f"🔗 <b>LINK TROJAN WS</b>\n"
            f"<code>{link_ws}</code>\n\n"
            f"🔗 <b>LINK TROJAN GRPC</b>\n"
            f"<code>{link_grpc}</code>\n\n"
            f"========================================\n"
            f"⚠️ <i>Akun ini adalah trial dan akan otomatis terhapus dari server setelah batas waktu habis.</i>\n"
            f"========================================"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Menu Utama", callback_data="switch_user"))
        bot.send_message(message.chat.id, reply_msg, parse_mode='HTML', reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 KEMBALI", callback_data="switch_user"))
        bot.send_message(message.chat.id, f"❌ <b>GAGAL MEMBUAT TRIAL TROJAN:</b>\n\n{info}\n\n<i>Silakan coba lagi.</i>", parse_mode='HTML', reply_markup=markup)

# ==========================================
# LETAKKAN DEFAULT CALLBACK DI SINI (MUTLAK PALING BAWAH)
# ==========================================
@bot.callback_query_handler(func=lambda call: True)
def default_callback(call):
    handled_prefixes = [
        'ppob_', 'show_bug', 'add_bug', 'del_bug', 
        'vps_', 'srv_', 'check_vps', 'ssh_', 'vmess_', 'vless_', 'trojan_',
        'folder_indo', 'buy_ssh', 'buy_vmess', 'buy_vless', 'buy_trojan',
        'list_', 'hist_', 'saldo_', 'manual_', 'broadcast', 'deal_',
        'check_user', 'history_by_id', 'reset_session', 
        'add_saldo', 'min_saldo', 'up_reseller', 'down_user', 
        'back_to_detail', 'switch_owner', 'switch_user', 'switch_reseller',
        'admin_panel', 'backup_db', 'audit_', 'manage_saldo', 'owner_wd_menu',
        'wd_', 'cek_profil', 'topup', 'register_reseller', 'history_user',
        'menu_back_main', 'setting_menu',
        'cek_provider', 'chk', 'bug_',
        
        # --- PASTIKAN BAGIAN INI ADA ---
        'trial_ssh_', 'runtrial_', 'cancel_input_ssh',
        'trial_vmess_', 'runtrialv_',
        'trial_vless_', 'runtrialvl_'
        'trial_trojan_', 'runtrialtr_'
    ]
    
    if any(call.data.startswith(p) for p in handled_prefixes): 
        return

    bot.answer_callback_query(call.id, "⚠️ Fitur belum tersedia / Maintenance")

if __name__ == "__main__":
    print("Bot Admin Modules Loaded...")