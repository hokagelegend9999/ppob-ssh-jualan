# handlers_payment.py
import telebot
import requests
import time
from bot_init import bot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID
from utils_helper import get_back_markup

# --- KONFIGURASI TAMPILAN ---
LINE_SEP = "━━━━━━━━━━━━━━━━━━━━━━━━━━"

# --- KONFIGURASI AKUN TETAP (WD OWNER) ---
FIXED_DESTINATION = {
    "name": "DEDEN IRWANSYAH",
    "bank": "MANDIRI",
    "rek": "1640002915488"
}

# --- TOMBOL BATAL UNIVERSAL ---
def get_cancel_markup():
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("❌ BATAL / KEMBALI", callback_data="cancel_wd_process"))
    return m

# --- HANDLER: BATAL PROSES ---
@bot.callback_query_handler(func=lambda call: call.data == "cancel_wd_process")
def cancel_wd_process(call):
    # Hapus step handler agar bot tidak menunggu input lagi
    bot.clear_step_handler_by_chat_id(call.message.chat.id)
    
    msg = (
        "<b>🚫 TRANSAKSI DIBATALKAN</b>\n"
        f"{LINE_SEP}\n"
        "Proses input telah dibatalkan oleh pengguna.\n"
        "Silakan pilih menu kembali."
    )
    # Kembali ke menu WD
    m = InlineKeyboardMarkup()
    m.add(InlineKeyboardButton("🔙 Menu Transfer", callback_data="owner_wd_menu"))
    
    try:
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except:
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', reply_markup=m)

# --- WITHDRAW / TRANSFER MENU UTAMA ---
@bot.callback_query_handler(func=lambda call: call.data == "owner_wd_menu")
def wd_menu_start(call):
    if str(call.from_user.id) != str(ADMIN_ID): return
    
    # [UPDATE: SKIP IF OLD QUERY]
    try:
        bot.answer_callback_query(call.id, "Memuat menu transfer...")
    except: pass # Abaikan jika query too old

    # Desain Menu Utama
    text = (
        "<b>💸 TRANSFER DANA & WITHDRAW</b>\n"
        f"{LINE_SEP}\n"
        "Silakan pilih metode transfer yang diinginkan:\n\n"
        "🚀 <b>Transfer Kilat:</b> Ke rekening utama owner.\n"
        "✍️ <b>Input Manual:</b> Input Bank/E-Wallet lain.\n"
        f"{LINE_SEP}"
    )

    m = InlineKeyboardMarkup()
    # Tombol 1: Ke Akun Tetap
    btn_text = f"🚀 KE {FIXED_DESTINATION['name'][:10]}.." 
    m.add(InlineKeyboardButton(btn_text, callback_data="wd_fixed_start"))
    # Tombol 2: Manual
    m.add(InlineKeyboardButton("✍️ INPUT MANUAL", callback_data="wd_input_bank"))
    # Tombol Kembali
    m.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_owner"))
    
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode='HTML', reply_markup=m)
    except:
        bot.send_message(call.message.chat.id, text, parse_mode='HTML', reply_markup=m)

# ==========================================
# FLOW 1: TRANSFER KILAT (AKUN TETAP)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "wd_fixed_start")
def wd_fixed_step1(call):
    # Desain Info Rekening Tujuan
    info = (
        f"<b>🏦 Bank Tujuan :</b> <code>{FIXED_DESTINATION['bank']}</code>\n"
        f"<b>💳 No. Rek      :</b> <code>{FIXED_DESTINATION['rek']}</code>\n"
        f"<b>👤 Atas Nama    :</b> <code>{FIXED_DESTINATION['name']}</code>"
    )
    
    text = (
        "<b>⚡ TRANSFER KILAT</b>\n"
        f"{LINE_SEP}\n"
        f"{info}\n"
        f"{LINE_SEP}\n\n"
        "💰 <b>Silakan Masukkan NOMINAL Transfer:</b>\n"
        "<i>(Contoh: 50000 atau 100000)</i>"
    )
    
    # Kirim pesan baru agar step handler bersih
    msg = bot.send_message(call.message.chat.id, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_fixed_step2_confirm)

def wd_fixed_step2_confirm(message):
    try:
        if message.text.lower() == 'batal':
            bot.reply_to(message, "🚫 Proses dibatalkan.")
            return

        nom = int(message.text.replace(".", "").replace(",", ""))
        
        # --- MINIMAL 5000 ---
        if nom < 5000:
            msg = bot.reply_to(message, "❌ <b>Error:</b> Minimal transfer adalah Rp 5.000!", parse_mode='HTML', reply_markup=get_cancel_markup())
            return bot.register_next_step_handler(msg, wd_fixed_step2_confirm)
            
    except ValueError:
        msg = bot.reply_to(message, "⚠️ <b>Error:</b> Harap masukkan hanya angka.\nSilakan input ulang nominal:", parse_mode='HTML', reply_markup=get_cancel_markup())
        return bot.register_next_step_handler(msg, wd_fixed_step2_confirm)

    kode = FIXED_DESTINATION['bank']
    akun = FIXED_DESTINATION['rek']
    nama = FIXED_DESTINATION['name']

    show_confirmation(message.chat.id, kode, akun, nom, nama)

# ==========================================
# FLOW 2: TRANSFER MANUAL (STEP BY STEP)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == "wd_input_bank")
def wd_step1_bank(call):
    text = (
        "<b>🏦 INPUT DATA MANUAL - STEP 1/4</b>\n"
        f"{LINE_SEP}\n"
        "Masukkan <b>KODE BANK</b> tujuan.\n"
        "<i>(Contoh: DANA, OVO, 014, 002)</i>"
    )
    msg = bot.send_message(call.message.chat.id, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step2_number)

def wd_step2_number(message):
    kode = message.text.strip().upper()
    text = (
        "<b>💳 INPUT DATA MANUAL - STEP 2/4</b>\n"
        f"{LINE_SEP}\n"
        f"Bank Selected: <b>{kode}</b>\n\n"
        "Masukkan <b>NOMOR REKENING / E-WALLET</b> tujuan:"
    )
    msg = bot.reply_to(message, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step3_nominal, kode)

def wd_step3_nominal(message, kode):
    akun = message.text.strip()
    text = (
        "<b>💰 INPUT DATA MANUAL - STEP 3/4</b>\n"
        f"{LINE_SEP}\n"
        f"Bank: {kode}\nRek : {akun}\n\n"
        "Masukkan <b>NOMINAL</b> transfer:"
    )
    msg = bot.reply_to(message, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step4_name, kode, akun)

def wd_step4_name(message, kode, akun):
    try: 
        nom = int(message.text.replace(".","").replace(",",""))
        
        # --- MINIMAL 5000 ---
        if nom < 5000:
            msg = bot.reply_to(message, "❌ <b>Minimal transfer Rp 5.000</b>. Input nominal ulang:", parse_mode='HTML', reply_markup=get_cancel_markup())
            return bot.register_next_step_handler(msg, wd_step4_name, kode, akun)
            
    except: 
        msg = bot.reply_to(message, "⚠️ Angka tidak valid. Input nominal ulang:", reply_markup=get_cancel_markup())
        return bot.register_next_step_handler(msg, wd_step4_name, kode, akun)
        
    text = (
        "<b>👤 INPUT DATA MANUAL - STEP 4/4</b>\n"
        f"{LINE_SEP}\n"
        f"Nominal: Rp {nom:,}\n\n"
        "Masukkan <b>NAMA PEMILIK REKENING</b> (untuk validasi):"
    )
    msg = bot.reply_to(message, text, parse_mode='HTML', reply_markup=get_cancel_markup())
    bot.register_next_step_handler(msg, wd_step5_exec, kode, akun, nom)

def wd_step5_exec(message, kode, akun, nom):
    nama = message.text.strip()
    show_confirmation(message.chat.id, kode, akun, nom, nama)

# ==========================================
# FUNGSI KONFIRMASI & EKSEKUSI (MOCKUP TRANSAKSI)
# ==========================================
def show_confirmation(chat_id, kode, akun, nom, nama):
    # Tampilan Konfirmasi Mewah
    text = (
        "<b>⚠️ KONFIRMASI TRANSAKSI</b>\n"
        f"{LINE_SEP}\n"
        "Mohon cek kembali data berikut:\n\n"
        f"<b>🏦 Bank Tujuan :</b> <code>{kode}</code>\n"
        f"<b>💳 No. Rek      :</b> <code>{akun}</code>\n"
        f"<b>👤 Atas Nama    :</b> <code>{nama}</code>\n"
        f"<b>💰 Nominal      :</b> <code>Rp {nom:,}</code>\n"
        f"{LINE_SEP}\n"
        "<i>Pastikan data sudah benar sebelum mengirim.</i>"
    )
    
    m = InlineKeyboardMarkup()
    
    # Potong nama maksimal 15 karakter khusus untuk callback_data
    nama_singkat = str(nama)[:15] 
    callback_data = f"wd_fix|{kode}|{akun}|{nom}|{nama_singkat}"
    
    # Pengaman panjang karakter telegram
    if len(callback_data) > 64:
        callback_data = callback_data[:64]
    
    m.add(InlineKeyboardButton("✅ KIRIM SEKARANG", callback_data=callback_data))
    m.add(InlineKeyboardButton("❌ BATALKAN", callback_data="cancel_wd_process"))
    
    import time
    max_retries = 3
    
    for attempt in range(max_retries):
        try:
            bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=m)
            break 
            
        except Exception as e:
            err_str = str(e)
            if "RemoteDisconnected" in err_str or "Connection aborted" in err_str:
                if attempt < max_retries - 1:
                    time.sleep(0.5) 
                    continue 
                    
            try:
                bot.send_message(chat_id, f"❌ Gagal memproses konfirmasi: <code>{err_str}</code>", parse_mode='HTML')
            except:
                pass
            break

@bot.callback_query_handler(func=lambda call: call.data.startswith("wd_fix|"))
def wd_process_api(call):
    if str(call.from_user.id) != str(ADMIN_ID): return

    try:
        parts = call.data.split("|")
        kode = parts[1]
        akun = parts[2]
        nom = parts[3]
        nama = parts[4] if len(parts) > 4 else "Owner"
        
        # Karena modul atlantic sudah dihapus, transaksi ini diasumsikan berhasil diproses secara internal.
        bot.delete_message(call.message.chat.id, call.message.message_id)
        
        ref_id = f"TRF-{int(time.time())}"
        
        struk_sukses = (
            f"🎉 <b>TRANSAKSI SUKSES</b> 🎉\n"
            f"{LINE_SEP}\n"
            f"🆔 <b>RefID :</b> <code>{ref_id}</code>\n"
            f"{LINE_SEP}\n"
            f"🏦 <b>Bank     :</b> {kode}\n"
            f"📱 <b>Tujuan   :</b> <code>{akun}</code>\n"
            f"👤 <b>Penerima :</b> <code>{nama}</code>\n"
            f"💰 <b>Nominal  :</b> Rp {int(nom):,}\n\n"
            f"📝 <b>Info Sistem:</b>\n"
            f"<i>Transaksi tercatat secara manual.</i>"
        )
        
        m = InlineKeyboardMarkup()
        m.row(
            InlineKeyboardButton("🔙 Menu Utama", callback_data="owner_wd_menu"),
            InlineKeyboardButton("🗑 Hapus", callback_data="close_message")
        )
        
        bot.send_message(call.message.chat.id, struk_sukses, parse_mode='HTML', reply_markup=m)
            
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ <b>Error System:</b>\n{str(e)}", parse_mode='HTML')