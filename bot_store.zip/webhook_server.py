from flask import Flask, request, jsonify
import logging
import requests # Ditambahkan untuk melakukan request ke Okeconnect
import config # Pastikan file config.py Anda di-import untuk mengambil data
from database import add_balance, update_transaction_status, check_transaction_exists
from bot_init import bot # Import bot untuk kirim notifikasi

# Setup Flask
app = Flask(__name__)

# Konfigurasi Logging (Agar kelihatan kalau ada data masuk)
logging.basicConfig(level=logging.INFO)

# ======================================================
#  JALUR API UNTUK APLIKASI ANDROID (BARU)
# ======================================================
@app.route('/api/saldo', methods=['GET'])
def cek_saldo_okeconnect():
    url = "https://h2h.okeconnect.com/trx/balance"
    
    # Mengambil data dari config.py dengan aman
    params = {
        "memberID": config.OKECONNECT_MEMBER_ID,
        "pin": config.OKECONNECT_PIN,
        "password": config.OKECONNECT_PASSWORD
    }
    
    try:
        response = requests.get(url, params=params)
        return response.text, response.status_code
    except Exception as e:
        print(f"⚠️ Error API Cek Saldo: {e}")
        return f"Error VPS: {str(e)}", 500

# ======================================================
#  JALUR API UNTUK TRANSAKSI (ORDER PRODUK)
# ======================================================
@app.route('/api/transaksi', methods=['GET'])
def transaksi_okeconnect():
    url = "https://h2h.okeconnect.com/trx"
    
    # Menerima data pesanan dari aplikasi Android
    product = request.args.get('product')
    dest = request.args.get('dest')
    refID = request.args.get('refID')
    
    # Menggabungkan data pesanan Android dengan kredensial rahasia VPS
    params = {
        "memberID": config.OKECONNECT_MEMBER_ID,
        "pin": config.OKECONNECT_PIN,
        "password": config.OKECONNECT_PASSWORD,
        "product": product,
        "dest": dest,
        "refID": refID
    }
    
    try:
        response = requests.get(url, params=params)
        return response.text, response.status_code
    except Exception as e:
        print(f"⚠️ Error API Transaksi: {e}")
        return f"Error VPS: {str(e)}", 500

# ======================================================
#  JALUR API UNTUK DAFTAR PRODUK (DIPERBARUI)
# ======================================================
@app.route('/api/produk', methods=['GET'])
def daftar_produk_okeconnect():
    try:
        url = config.OKECONNECT_PRICE_URL
        response = requests.get(url)
        data_json = response.json()
        
        # PINTAR: Jika Okeconnect membungkusnya dalam Object (misal {"data": [...]})
        # Kita bongkar dan ambil daftar isinya saja agar Android tidak error!
        if isinstance(data_json, dict):
            for key in data_json:
                if isinstance(data_json[key], list):
                    return jsonify(data_json[key]), 200
                    
        # Jika dari sananya sudah berupa daftar langsung
        return jsonify(data_json), 200
    except Exception as e:
        print(f"⚠️ Error API Produk: {e}")
        return jsonify([{"keterangan": "Error Server VPS", "harga": "0"}]), 500
        
# ======================================================
#  JALUR API UNTUK TRANSAKSI OPEN DENOM (NOMINAL BEBAS)
# ======================================================
@app.route('/api/transaksi_open', methods=['GET'])
def transaksi_open_okeconnect():
    url = "https://h2h.okeconnect.com/trx"
    
    product = request.args.get('product')
    dest = request.args.get('dest')
    refID = request.args.get('refID')
    qty = request.args.get('qty') # Ini adalah Nominal
    
    params = {
        "memberID": config.OKECONNECT_MEMBER_ID,
        "pin": config.OKECONNECT_PIN,
        "password": config.OKECONNECT_PASSWORD,
        "product": product,
        "dest": dest,
        "refID": refID,
        "qty": qty
    }
    
    try:
        response = requests.get(url, params=params)
        return response.text, response.status_code
    except Exception as e:
        print(f"⚠️ Error API Transaksi Open Denom: {e}")
        return f"Error VPS: {str(e)}", 500

# ======================================================
#  JALUR API UNTUK CALLBACK (MENERIMA LAPORAN DARI OKECONNECT)
# ======================================================
@app.route('/api/callback', methods=['GET'])
def callback_okeconnect():
    # Menangkap parameter GET yang dikirim oleh Okeconnect
    refid = request.args.get('refid')
    message = request.args.get('message')
    
    # Menampilkan laporan di log terminal VPS agar mudah dipantau
    print("\n" + "="*50)
    print(f"🔔 [CALLBACK MASUK DARI OKECONNECT]")
    print(f"RefID   : {refid}")
    print(f"Message : {message}")
    print("="*50 + "\n")
    
    # ---------------------------------------------------------
    # DI SINI NANTINYA TEMPAT ANDA MENAMBAHKAN LOGIKA LANJUTAN:
    # 1. Update status Sukses/Gagal di Database
    # 2. Tembak API Bot Telegram untuk kirim notifikasi otomatis
    # ---------------------------------------------------------
    
    # Memberikan balasan HTTP 200 OK agar Okeconnect tahu laporan sudah kita terima 
    # (Jika tidak dibalas, Okeconnect biasanya akan mengirim ulang laporannya terus-menerus)
    return jsonify({
        "status": "success",
        "refid": refid,
        "message": "Callback diterima dengan baik oleh server HOKAGE"
    }), 200
    
# ======================================================
#  JALUR API UNTUK CEK STATUS TRANSAKSI
# ======================================================
@app.route('/api/cek_status', methods=['GET'])
def cek_status_okeconnect():
    url = "https://h2h.okeconnect.com/trx"
    
    product = request.args.get('product')
    dest = request.args.get('dest')
    refID = request.args.get('refID')
    qty = request.args.get('qty', '') # Ambil qty jika ada
    
    params = {
        "memberID": config.OKECONNECT_MEMBER_ID,
        "pin": config.OKECONNECT_PIN,
        "password": config.OKECONNECT_PASSWORD,
        "product": product,
        "dest": dest,
        "refID": refID,
        "check": "1"  # <--- INI KUNCI UTAMANYA: 1 berarti CEK STATUS
    }
    
    if qty:
        params['qty'] = qty
        
    try:
        response = requests.get(url, params=params)
        return response.text, response.status_code
    except Exception as e:
        print(f"⚠️ Error API Cek Status: {e}")
        return f"Error VPS: {str(e)}", 500

# ======================================================
#  JALUR PENERIMA WEBHOOK 
# ======================================================
@app.route('/webhook_server.py', methods=['POST'])
def atlantic_callback():
    try:
        # 1. Terima Data dari Atlantic
        data = request.get_json(silent=True) or request.form
        
        print(f"📩 [WEBHOOK] Data Masuk: {data}")
        
        if not data:
            return jsonify({'status': False, 'msg': 'No Data'}), 400

        # 2. Ambil Variabel Penting
        trx_id = data.get('id') or data.get('ref_id') or data.get('trx_id')
        status = str(data.get('status')).lower()
        sn = data.get('sn') or data.get('message') or "-"
        
        if not trx_id:
             return jsonify({'status': False, 'msg': 'No Trx ID'}), 400

        # 3. Proses Logika
        if status == 'sukses' or status == 'success':
            print(f"✅ Webhook: Trx {trx_id} SUKSES. SN: {sn}")
            # update_transaction_status(trx_id, 'sukses', sn) 
            
        elif status == 'gagal' or status == 'failed' or status == 'error':
            print(f"❌ Webhook: Trx {trx_id} GAGAL. Melakukan Refund...")
            # current_status = get_trx_status(trx_id)
            # if current_status == 'gagal': return jsonify({'status': True, 'msg': 'Already Refunded'})
            
            # update_transaction_status(trx_id, 'gagal', sn)
            # user_id, nominal = get_trx_detail(trx_id) 
            # add_balance(user_id, nominal, f"Refund Otomatis {trx_id}", ref_id=f"REF-{trx_id}")

        return jsonify({'status': True, 'msg': 'Callback Received'})

    except Exception as e:
        print(f"⚠️ Error Webhook: {e}")
        return jsonify({'status': False, 'msg': 'Error System'}), 500

if __name__ == '__main__':
    # Jalankan Server di Port 8070 (Sesuai Gambar)
    print("🚀 Webhook Server & API Android Berjalan di Port 8070...")
    # host='0.0.0.0' agar bisa diakses dari luar VPS
    app.run(host='0.0.0.0', port=8070)