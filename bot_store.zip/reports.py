import datetime
import sqlite3
import pandas as pd
import os
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# Lokasi database Anda
DB_NAME = "/root/bot_store/store_data.db"

def fetch_reseller_report(user_id):
    """Mengambil dan memilah data transaksi dari database SQLite."""
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    c = conn.cursor()
    c.execute("""
        SELECT description, destination, amount 
        FROM transactions 
        WHERE user_id = ? AND amount < 0 AND status = 'sukses'
    """, (user_id,))
    rows = c.fetchall()
    conn.close()

    data = {
        'indo_count': 0, 'indo_saldo': 0,
        'sg_count': 0,   'sg_saldo': 0,
        'aws_count': 0,  'aws_saldo': 0,
        'ppob_count': 0, 'ppob_saldo': 0
    }

    for row in rows:
        desc = str(row[0]).lower()
        dest = str(row[1]).lower()
        amount = abs(row[2])
        is_vpn = any(vpn in desc for vpn in ["ssh", "vless", "vmess", "trojan", "xray"])
        
        if is_vpn:
            if "aws" in desc or "aws" in dest:
                data['aws_count'] += 1; data['aws_saldo'] += amount
            elif "sg" in desc or "sg" in dest or "singapore" in dest:
                data['sg_count'] += 1; data['sg_saldo'] += amount
            else:
                data['indo_count'] += 1; data['indo_saldo'] += amount
        else:
            if "deposit" not in desc and "saldo" not in desc:
                data['ppob_count'] += 1; data['ppob_saldo'] += amount
    return data

def generate_excel_report(user_id):
    """Mengambil data dari DB dan menyusunnya ke Excel."""
    conn = sqlite3.connect(DB_NAME)
    query = "SELECT date, description, destination, amount, status FROM transactions WHERE user_id = ?"
    df = pd.read_sql_query(query, conn, params=(user_id,))
    
    query_vpn = "SELECT username, protocol, exp_date, domain, created_at FROM vpn_history WHERE reseller_id = ?"
    df_vpn = pd.read_sql_query(query_vpn, conn, params=(user_id,))
    conn.close()

    file_path = f"Laporan_{user_id}.xlsx"
    with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Semua Transaksi', index=False)
        df_vpn.to_excel(writer, sheet_name='Riwayat Akun VPN', index=False)
        
    return file_path

def handle_report_reseller(bot, call):
    """Menyusun teks laporan dan menampilkan tombol."""
    user_id = call.from_user.id
    report_data = fetch_reseller_report(user_id)
    
    # Kalkulasi
    total_trx_vpn = report_data['indo_count'] + report_data['sg_count'] + report_data['aws_count']
    total_saldo_vpn = report_data['indo_saldo'] + report_data['sg_saldo'] + report_data['aws_saldo']
    total_semua_trx = total_trx_vpn + report_data['ppob_count']
    total_semua_saldo = total_saldo_vpn + report_data['ppob_saldo']

    waktu_laporan = datetime.datetime.now().strftime("%d %B %Y - %H:%M WIB")

    teks_laporan = (
        "📊 <b>LAPORAN LENGKAP PENJUALAN RESELLER</b> 📊\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>ID:</b> <code>{user_id}</code>\n"
        f"📅 <b>Waktu:</b> {waktu_laporan}\n\n"
        "🚀 <b>RINCIAN PENJUALAN SSH & XRAY:</b>\n"
        f"┣ 🇮🇩 INDO : <b>{report_data['indo_count']}</b> Akun (Rp {report_data['indo_saldo']:,})\n"
        f"┣ 🇸🇬 SGDO : <b>{report_data['sg_count']}</b> Akun (Rp {report_data['sg_saldo']:,})\n"
        f"┗ 🇸🇬 AWS  : <b>{report_data['aws_count']}</b> Akun (Rp {report_data['aws_saldo']:,})\n"
        f"<b>Total VPN: {total_trx_vpn} Trx | Terpakai: Rp {total_saldo_vpn:,}</b>\n\n"
        "📱 <b>RINCIAN PENJUALAN PPOB:</b>\n"
        f"┗ Total: <b>{report_data['ppob_count']}</b> Trx\n"
        f"<b>Terpakai: Rp {report_data['ppob_saldo']:,}</b>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📈 <b>AKUMULASI KESELURUHAN:</b>\n"
        f"🔹 <b>Total Transaksi:</b> {total_semua_trx} Trx\n"
        f"🔻 <b>Total Saldo Keluar:</b> Rp {total_semua_saldo:,}\n\n"
        "💡 <i>Terus tingkatkan penjualan Anda!</i>"
    ).replace(',', '.')

    # Tombol Download Excel ditambahkan di sini
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("📥 DOWNLOAD EXCEL", callback_data="download_excel"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="switch_reseller"))

    try:
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=teks_laporan,
            parse_mode="HTML",
            reply_markup=markup
        )
    except Exception as e:
        print(f"Error edit message di report reseller: {e}")