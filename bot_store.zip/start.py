import time
import logging
import os
import json
import socket
import math
from telebot import apihelper 
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton 
from handlers.jago_checker import start_jago_checker
import handlers.topup_handler

# =========================================================
#  🛡️ KONFIGURASI KONEKSI (EDIT DI SINI)
# =========================================================
apihelper.ENABLE_MIDDLEWARE = False 

# 2. SINKRONISASI TIMEOUT (STANDAR TELEGRAM)
apihelper.CONNECT_TIMEOUT = 20
apihelper.READ_TIMEOUT = 90 

# 3. SETTING PROXY (MATIKAN SAJA, KITA TIDAK BUTUH)
apihelper.proxy = {'https': 'socks5://127.0.0.1:40000'} 

# =========================================================

# BARU SETELAH ITU IMPORT BOT
from bot_init import bot
from database import update_user_activity
from background_tasks import start_background_tasks

# --- IMPORT MODULE HANDLERS ---
import handlers.handlers_ppob       
import handlers.users
import handlers.ssh
import handlers.vmess
import handlers.vless
import handlers.trojan
import handlers.nav                
import handlers.admin        
import handlers.handlers_vps


if __name__ == "__main__":
    print("🚀 BOT STARTED (DIRECT CONNECTION - ANTI STUCK)!")
    
    # Cek Status Restart
    if os.path.exists("restart_state.json"):
        try:
            with open("restart_state.json", "r") as f:
                data = json.load(f)
            chat_id = data.get('chat_id')
            msg_id = data.get('message_id')
            try: bot.delete_message(chat_id, msg_id)
            except: pass
            
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔙 KEMBALI KE PANEL", callback_data="switch_owner"))
            bot.send_message(chat_id, "✅ <b>BOT ONLINE KEMBALI!</b>", parse_mode='HTML', reply_markup=markup)
            os.remove("restart_state.json")
        except: pass

    # Background Tasks
    try:
        start_background_tasks()
        start_jago_checker()  # <--- MESIN JAGO DINYALAKAN DI SINI
        print("✅ Background Tasks & Jago Checker: Running...")
    except Exception as e:
        print(f"⚠️ Warning Background Tasks: {e}")
    
    # Bersihkan webhook sebelum mulai
    try:
        bot.remove_webhook()
        time.sleep(1)
    except: pass

    # Loop Utama
    while True:
        try:
            print("📡 Menghubungkan ke Telegram...")
            bot.infinity_polling(timeout=60, long_polling_timeout=60, skip_pending=True)
        except KeyboardInterrupt:
            print("\n⛔ Bot stop manual.")
            break
        except Exception as e:
            err_str = str(e).lower()
            
            # Perbaiki library math yang hilang
            if "math" in err_str:
                global math
                import math
            
            # JIKA ERROR KARENA TIMEOUT/DIPUTUS, LANGSUNG RECONNECT INSTAN!
            if "timed out" in err_str or "connection aborted" in err_str or "remotedisconnected" in err_str:
                continue 
            
            # Jika error lain yang parah, baru jeda 3 detik
            logging.error(f"Polling Error: {e}")
            print(f"❌ Error Jaringan, Reconnecting dalam 3s... ({e})")
            time.sleep(3)
