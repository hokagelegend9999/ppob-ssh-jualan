import requests
import logging
import time
import re # Wajib import re untuk sensor kata
from config import (
    OKECONNECT_MEMBER_ID, 
    OKECONNECT_PIN, 
    OKECONNECT_PASSWORD, 
    OKECONNECT_TRX_URL,
    OKECONNECT_PRICE_URL
)

# --- KONFIGURASI CACHE (ANTI-LIMIT) ---
_PRICE_CACHE = []               
_LAST_FETCH_TIME = 0            
CACHE_DURATION = 3600           

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
}

# ==========================================
#  HELPER: SENSOR SALDO (PENTING!)
# ==========================================
def clean_provider_message(text):
    """
    Menghapus informasi saldo dari respon provider agar aman dilihat user.
    Mengubah: '...status Sukses. Saldo 100.000' -> '...status Sukses.'
    """
    if not text: return ""
    try:
        # Regex untuk mencari pola: "Sal/Saldo/Sisa Saldo" diikuti angka dan titik/koma
        # (?i) = Case insensitive (huruf besar/kecil dianggap sama)
        clean_text = re.sub(r"(?i)(?:sisa\s*)?sal(?:do)?\s*[:\.]?\s*[\d\.,]+", "", str(text))
        
        # Hapus sisa-sisa karakter aneh di akhir kalimat jika ada
        return clean_text.strip(" .-,")
    except:
        return text

# ==========================================
# 1. AMBIL DAFTAR HARGA
# ==========================================
def get_okeconnect_price(force_update=False):
    global _PRICE_CACHE, _LAST_FETCH_TIME
    
    current_time = time.time()
    is_expired = (current_time - _LAST_FETCH_TIME) > CACHE_DURATION
    
    if _PRICE_CACHE and not is_expired and not force_update:
        return _PRICE_CACHE

    try:
        print(f"[PPOB] 🔄 Update Harga dari Server... (Last: {int(current_time - _LAST_FETCH_TIME)}s ago)")
        response = requests.get(OKECONNECT_PRICE_URL, headers=HEADERS, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, list):
                _PRICE_CACHE = data          
                _LAST_FETCH_TIME = current_time
                print(f"[PPOB] ✅ Berhasil update {len(data)} produk.")
                return data
            else:
                return _PRICE_CACHE 
        elif response.status_code == 429:
            return _PRICE_CACHE
        else:
            return _PRICE_CACHE
            
    except Exception as e:
        logging.error(f"[PPOB] Error Connection: {e}")
        return _PRICE_CACHE

# ==========================================
# 2. PROSES BELI PRODUK (WRAPPER)
# ==========================================
def buy_okeconnect_product(kode_produk, nomor_tujuan, ref_id):
    """
    Fungsi Utama Pembelian.
    Return: (Status_Boolean, SN/ServerID, Pesan_Info_Aman)
    """
    try:
        # Panggil fungsi request internal
        res = request_orderkuota_trx(kode_produk, nomor_tujuan, ref_id)
        
        success = res.get('success', False)
        msg_raw = res.get('msg', 'No Response')
        server_id = res.get('server_id', '-')
        
        # [SENSOR] Bersihkan pesan dari saldo sebelum dikirim ke handler
        msg_clean = clean_provider_message(msg_raw)
        
        # SN sementara diisi Server ID jika sukses, atau pesan error jika gagal
        sn_or_info = server_id if success else msg_clean
        
        return success, sn_or_info, msg_clean

    except Exception as e:
        return False, "", f"System Error: {str(e)}"

# ==========================================
# 3. KIRIM REQUEST TRANSAKSI (CORE)
# ==========================================
def request_orderkuota_trx(kode_produk, nomor_tujuan, ref_id):
    params = {
        'memberID': OKECONNECT_MEMBER_ID,
        'pin': OKECONNECT_PIN,
        'password': OKECONNECT_PASSWORD,
        'product': kode_produk,
        'dest': nomor_tujuan,
        'refID': ref_id
    }
    
    result = {
        "success": False,
        "msg": "",
        "server_id": None,
        "raw": ""
    }

    try:
        print(f"[PPOB] 🚀 Mengirim Trx: {kode_produk} -> {nomor_tujuan} (Ref: {ref_id})")
        response = requests.get(OKECONNECT_TRX_URL, params=params, headers=HEADERS, timeout=60)
        text_respon = response.text
        
        # Kita simpan raw response untuk log admin (bisa dilihat via console)
        # Tapi result['msg'] nanti akan disensor di fungsi wrapper
        print(f"[PPOB] 📩 Respon Server: {text_respon}")
        
        result["raw"] = text_respon
        result["msg"] = text_respon 
        
        # Tangkap ID Transaksi (T#123 atau ID:123)
        match = re.search(r"(?:T\#|ID)[\s:]*(\d+)", text_respon, re.IGNORECASE)
        
        if match:
            server_id = match.group(1)
            result["success"] = True
            result["server_id"] = server_id
            print(f"[PPOB] ✅ Transaksi Sukses! Server ID: {server_id}")
        else:
            # Fallback Check Text
            text_upper = text_respon.upper()
            if "BERHASIL" in text_upper or "DIPROSES" in text_upper or "SUKSES" in text_upper:
                result["success"] = True
                print("[PPOB] ⚠️ Transaksi dianggap masuk (No ID Found).")
            elif "GAGAL" in text_upper or "SALAH" in text_upper or "CUKUP" in text_upper:
                result["success"] = False
            else:
                # Ambigu -> Anggap Sukses Pending
                result["success"] = True 
                result["msg"] += " (Cek Manual)"
        
        return result

    except requests.exceptions.Timeout:
        result["msg"] = "TIMEOUT (Sedang Diproses, Cek Status Berkala)"
        return result
    except Exception as e:
        logging.error(f"[PPOB] Error Trx: {e}")
        result["msg"] = f"ERROR SISTEM: {str(e)}"
        return result

# ==========================================
# 4. CEK STATUS TRANSAKSI (DENGAN SENSOR)
# ==========================================
def check_orderkuota_status(ref_id, nomor_tujuan=None, kode_produk=None, server_id=None, tanggal=None):
    """
    [FIXED] Mengecek status transaksi ke OkConnect menggunakan metode Check=1
    Ditambah support parameter tanggal agar bisa cek transaksi history lama.
    Dan menyensor saldo dari pesan balasan.
    """
    params = {
        'memberID': OKECONNECT_MEMBER_ID,
        'pin': OKECONNECT_PIN,
        'password': OKECONNECT_PASSWORD, 
        'refID': ref_id,
        'check': '1' # WAJIB: Penanda mode cek status
    }
    
    # Tambahkan parameter opsional jika ada
    if kode_produk and kode_produk != "CEK": params['product'] = kode_produk
    if nomor_tujuan and nomor_tujuan != "-": params['dest'] = nomor_tujuan
    
    # --- [BARU] FORMAT & TAMBAHKAN PARAMETER TANGGAL ---
    if tanggal and tanggal != "-":
        try:
            from datetime import datetime
            # Asumsi format tanggal dari database bot adalah YYYY-MM-DD HH:MM:SS
            # Kita potong 10 karakter pertama untuk mengambil "YYYY-MM-DD"
            str_date = str(tanggal)[:10] 
            dt_obj = datetime.strptime(str_date, "%Y-%m-%d")
            # Okeconnect meminta format DD/MM/YYYY
            params['tgl'] = dt_obj.strftime("%d/%m/%Y")
        except Exception as e:
            print(f"[PPOB] Gagal format tanggal '{tanggal}': {e}")
    # ----------------------------------------------------

    try:
        tgl_print = params.get('tgl', 'Hari ini')
        print(f"[PPOB] 🔎 Cek Status Ref: {ref_id} (Tgl API: {tgl_print})...")
        response = requests.get(OKECONNECT_TRX_URL, params=params, headers=HEADERS, timeout=15)
        text_respon = response.text.strip()
        
        # [SENSOR] Bersihkan pesan sebelum diproses lebih lanjut
        text_aman = clean_provider_message(text_respon)
        
        # --- LOGIKA PARSING RESPON ---
        if not text_respon or "<html" in text_respon:
            return "Error: Respon Provider Tidak Valid"
            
        res_lower = text_respon.lower()
        
        # 1. Jika Respon 'Tidak Ada Transaksi' -> GAGAL
        if "tidak ada" in res_lower or "tidak ditemukan" in res_lower:
            return f"GAGAL: Transaksi Tidak Ditemukan di Pusat ({text_aman})"
            
        # 2. Jika Respon 'Gagal' lain
        if "gagal" in res_lower or "stok habis" in res_lower or "salah" in res_lower:
            return f"GAGAL: {text_aman}"

        # 3. Kembalikan teks yang sudah disensor (Aman untuk user)
        return text_aman

    except requests.exceptions.Timeout:
        return "TIMEOUT (Koneksi Provider Lambat)"
    except Exception as e:
        logging.error(f"[PPOB] Error Cek Status: {e}")
        return f"Error System: {str(e)}"

# ==========================================
# 5. CEK PROFIL / SALDO (ADMIN ONLY)
# ==========================================
def get_okeconnect_profile():
    # Fungsi ini khusus admin panel, jadi tidak perlu disensor
    url_balance = "https://h2h.okeconnect.com/balance"
    params = {
        'memberID': OKECONNECT_MEMBER_ID,
        'pin': OKECONNECT_PIN,
        'password': OKECONNECT_PASSWORD
    }
    
    try:
        response = requests.get(url_balance, params=params, headers=HEADERS, timeout=10)
        text_respon = response.text

        if "Saldo" in text_respon or "Sisa" in text_respon:
            return text_respon
        elif "Gagal" in text_respon:
            return f"Error Provider: {text_respon}"
        else:
            return text_respon 

    except Exception as e:
        return "Error Profile"