import sqlite3
from datetime import datetime
import re

def konversi_tanggal_manual(date_str):
    bulan_map = {
        'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
        'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
        'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
    }
    try:
        clean_date = date_str.replace(",", "").strip()
        match = re.search(r'(\d{1,2})\s+([a-zA-Z]{3})\s+(\d{4})', clean_date)
        if match:
            day = match.group(1).zfill(2)
            month_name = match.group(2).capitalize()
            year = match.group(3)
            month_num = bulan_map.get(month_name, '01')
            dt_obj = datetime.strptime(f"{year}-{month_num}-{day}", "%Y-%m-%d")
            return dt_obj, f"{year}-{month_num}-{day}", f"{day} {month_name}, {year}"
        return None, None, None
    except:
        return None, None, None

conn = sqlite3.connect('store_data.db')
cursor = conn.cursor()
cursor.execute("SELECT username, protocol, exp_date, password FROM vpn_history")
rows = cursor.fetchall()

today = datetime.now()
valid_users = {}

# Filter data
for row in rows:
    user, proto, exp_raw, pwd = row
    dt_obj, tgl_iso, tgl_disp = konversi_tanggal_manual(exp_raw)
    
    # Hanya ambil SSH yang belum expired
    if dt_obj and dt_obj > today and proto.upper() == "SSH":
        # Simpan data, dan pastikan 'dt' ikut disimpan buat pembanding
        if user not in valid_users or dt_obj > valid_users[user]['dt']:
            valid_users[user] = {
                'dt': dt_obj, 
                'iso': tgl_iso, 
                'disp': tgl_disp, 
                'pwd': pwd
            }

with open("restore_ssh_clean.sh", "w") as f_ssh:
    f_ssh.write("#!/bin/bash\n\n")
    for user, data in valid_users.items():
        f_ssh.write(f"userdel -f {user} 2>/dev/null\n")
        f_ssh.write(f"useradd -e {data['iso']} -s /bin/false -m {user} 2>/dev/null\n")
        f_ssh.write(f"echo -e '{data['pwd']}\\n{data['pwd']}\\n' | passwd {user} &> /dev/null\n")
        f_ssh.write(f"echo '#ssh# {user} {data['pwd']} 0 2 {data['disp']}' >> /etc/ssh/.ssh.db\n")
    
    f_ssh.write("\nsystemctl restart ssh\n")
    f_ssh.write("echo '✅ RESTORE BERSIH SELESAI!'\n")

print(f"Selesai! Berhasil memfilter {len(valid_users)} user aktif.")