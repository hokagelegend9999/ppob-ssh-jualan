import sys
import os
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from reports import handle_report_reseller



PRICES = {
    "sg": {
        "ssh":  {"user": 15000, "reseller": 10000},
        "xray": {"user": 15000, "reseller": 10000}
    },
    "aws": {
        "ssh":  {"user": 15000, "reseller": 10000},
        "xray": {"user": 15000, "reseller": 10000}
    },
    "indo": {
        "ssh":  {"user": 13000, "reseller": 8000},
        "xray": {"user": 13000, "reseller": 8000}
    }
}

def fmt_price(price):
    return f"{int(price/1000)}k"

# ==========================================
# 3. MENU OWNER
# ==========================================
def menu_admin(user_id):
    markup = InlineKeyboardMarkup(row_width=2)

    markup.add(
        InlineKeyboardButton("👑 PANEL UTAMA", callback_data="admin_panel"),
        InlineKeyboardButton("💰 SALDO", callback_data="manage_saldo")
    ) 
    markup.add(
        InlineKeyboardButton("💸 TRANSFER / WD", callback_data="owner_wd_menu"),
        InlineKeyboardButton("📂 BACKUP DATABASE", callback_data="backup_db")
    )
    
    # "CEK USER (DETAIL)" dan "Cek Riwayat User" digabungkan dalam 1 baris agar rapi.
    markup.add(
        InlineKeyboardButton("🆔 CEK USER (DETAIL)", callback_data="check_user_by_id_menu"),
        InlineKeyboardButton("🔎 Cek Riwayat User", callback_data="check_user_history")
    )
    
    # Tombol AUDIT SALDO ILEGAL sudah dihapus dari sini
    
    markup.add(InlineKeyboardButton("🔍 CEK USER VPS", callback_data="check_vps_menu"))
    markup.add(InlineKeyboardButton("💼 List Reseller", callback_data="list_reseller|1"))
    markup.add(InlineKeyboardButton("📢 BROADCAST PESAN", callback_data="broadcast_all"))
    markup.add(
        InlineKeyboardButton("➕ Angkat Reseller", callback_data="manual_add_reseller"),
        InlineKeyboardButton("⚙️ SETTING SERVER", callback_data="setting_menu")
    )
    markup.add(
        InlineKeyboardButton("👁️ Lihat sbg RESELLER", callback_data="switch_reseller"),
        InlineKeyboardButton("👁️ Lihat sbg USER", callback_data="switch_user")
    )
    return markup

# ==========================================
# 4. MENU RESELLER
# ==========================================
def menu_reseller(is_owner_preview=False):
    markup = InlineKeyboardMarkup(row_width=2)
    
    # ---> TAMBAHKAN TOMBOL SG DI SINI <---
    markup.row(
        InlineKeyboardButton("🇮🇩 INDO (SSH/XRAY)", callback_data="folder_indo")
        #InlineKeyboardButton("🇸🇬 SG AWS (SSH/XRAY)", callback_data="folder_sg
        #InlineKeyboardButton("🇸🇬 SG AWS (SSH/XRAY)", callback_data="folder_aws")
    )
    
    # --- USER MANAGEMENT ---
    markup.add(
        InlineKeyboardButton("👥 Buat User", callback_data="create_user"),
        InlineKeyboardButton("📜 List Akun SSH & XRAY", callback_data="reseller_my_list")
    )

    # --- REPORT ---
    markup.add(
        InlineKeyboardButton("📊 Laporan Transaksi", callback_data="report")
    )
    
    # --- PPOB ---
    markup.add(
        InlineKeyboardButton("📱 Pulsa Murah (OKE)", callback_data="ppob_menu")
    )

    markup.add(
        InlineKeyboardButton("🔍 Cari Produk (Semua)", callback_data="search_product_menu")
    )
    
    # --- SWITCH MODE ---
    markup.add(
        InlineKeyboardButton("👁️ Mode User (Cek Harga Jual)", callback_data="switch_user")
    )
    
    if is_owner_preview:
        markup.add(
            InlineKeyboardButton("🔙 Kembali ke Owner", callback_data="switch_owner")
        )
        
    return markup

# ==========================================
# 5. MENU USER UTAMA
# ==========================================
def menu_user(role, is_owner_preview=False, is_reseller_preview=False):
    markup = InlineKeyboardMarkup(row_width=2)
    
    # ---> TAMBAHKAN TOMBOL SG DI SINI <---
    markup.row(
        InlineKeyboardButton("🇮🇩 INDONESIA (SSH/XRAY)", callback_data="folder_indo")
        #InlineKeyboardButton("🇸🇬 SINGAPORE AWS AMAZONE (SSH/XRAY)", callback_data="folder_sg")
        #InlineKeyboardButton("🇸🇬 SINGAPORE AWS AMAZONE (SSH/XRAY)", callback_data="folder_aws")
    )
    
    # --- 3 TOMBOL PPOB ---
    markup.add(
        InlineKeyboardButton("📱 PULSA MURAH (OKE)", callback_data="ppob_menu")
    )

    markup.add(InlineKeyboardButton("🔍 CARI PRODUK (ALL)", callback_data="search_product_menu"))
    
    # --- TAMBAHAN TOMBOL INFO BUG ---
    markup.add(InlineKeyboardButton("🐛 INFO BUG PROVIDER", callback_data="show_bug_info"))
    
    if 'reseller' not in role:
        markup.add(InlineKeyboardButton("💼 DAFTAR RESELLER (50k)", callback_data="register_reseller"))
    
    markup.add(
        InlineKeyboardButton("➕ ISI SALDO", callback_data="topup"),
        InlineKeyboardButton("📜 RIWAYAT", callback_data="history_user")
    )
    
    if is_owner_preview:
        markup.add(
            InlineKeyboardButton("👁️ Lihat sbg RESELLER", callback_data="switch_reseller"),
            InlineKeyboardButton("🔙 KEMBALI OWNER", callback_data="switch_owner")
        )
    elif is_reseller_preview:
        markup.add(InlineKeyboardButton("🔙 KEMBALI KE RESELLER", callback_data="switch_reseller_back"))
        
    return markup

# ==========================================
# 7. SUB-MENU SINGAPORE
# ==========================================
def menu_user_sg(role):
    markup = InlineKeyboardMarkup(row_width=2)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"
    
    h_ssh = PRICES["sg"]["ssh"][kategori]
    h_xray = PRICES["sg"]["xray"][kategori]
    
    txt_ssh = fmt_price(h_ssh)
    txt_xray = fmt_price(h_xray)
    
    # Menambahkan tombol Beli dan Trial secara berdampingan
    markup.row(
        InlineKeyboardButton(f"🇸🇬 SSH SG ({txt_ssh})", callback_data="buy_ssh_sg"),
        InlineKeyboardButton("⏱ TRIAL SSH", callback_data="trial_ssh_sg")
    )
    markup.add(
        InlineKeyboardButton(f"⚡ VMESS SG ({txt_xray})", callback_data="buy_vmess_sg"),
        InlineKeyboardButton(f"🛡️ VLESS SG ({txt_xray})", callback_data="buy_vless_sg")
    )
    markup.add(InlineKeyboardButton(f"🐎 TROJAN SG ({txt_xray})", callback_data="buy_trojan_sg"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    return markup
    
# ==========================================
# 8. SUB-MENU AWS (Perbaikan Label & Tambah Trial)
# ==========================================
def menu_user_aws(role):
    markup = InlineKeyboardMarkup(row_width=2)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"
    
    h_ssh = PRICES["aws"]["ssh"][kategori]
    h_xray = PRICES["aws"]["xray"][kategori]
    
    txt_ssh = fmt_price(h_ssh)
    txt_xray = fmt_price(h_xray)
    
    # Menambahkan tombol Beli dan Trial secara berdampingan (Label diperbaiki)
    markup.row(
        InlineKeyboardButton(f"☁️ SSH AWS ({txt_ssh})", callback_data="buy_ssh_aws"),
        InlineKeyboardButton("⏱ TRIAL SSH", callback_data="trial_ssh_aws")
    )
    markup.add(
        InlineKeyboardButton(f"⚡ VMESS AWS ({txt_xray})", callback_data="buy_vmess_aws"),
        InlineKeyboardButton(f"🛡️ VLESS AWS ({txt_xray})", callback_data="buy_vless_aws")
    )
    markup.add(InlineKeyboardButton(f"🐎 TROJAN AWS ({txt_xray})", callback_data="buy_trojan_aws"))
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    return markup

# ==========================================
# 9. SUB-MENU INDONESIA
# ==========================================
def menu_user_indo(role):
    markup = InlineKeyboardMarkup(row_width=2)
    kategori = "reseller" if "reseller" in role or "owner" in role else "user"

    h_ssh = PRICES["indo"]["ssh"][kategori]
    h_xray = PRICES["indo"]["xray"][kategori]

    txt_ssh = fmt_price(h_ssh)
    txt_xray = fmt_price(h_xray)

    # 1. Baris SSH
    markup.row(
        InlineKeyboardButton(f"🇮🇩 SSH INDO ({txt_ssh})", callback_data="buy_ssh_indo"),
        InlineKeyboardButton("⏱ TRIAL SSH", callback_data="trial_ssh_indo")
    )
    
    # 2. Baris VMESS (Dipisahkan menggunakan row)
    markup.row(
        InlineKeyboardButton(f"⚡ VMESS INDO ({txt_xray})", callback_data="buy_vmess_indo"),
        InlineKeyboardButton("⏱ TRIAL VMESS", callback_data="trial_vmess_indo")
    )
    
    # 3. Baris VLESS (Dipisahkan menggunakan row)
    markup.row(
        InlineKeyboardButton(f"🛡️ VLESS INDO ({txt_xray})", callback_data="buy_vless_indo"),
        InlineKeyboardButton("⏱ TRIAL VLESS", callback_data="trial_vless_indo")
    )
    
    # 4. Baris Trojan (Dipisahkan menggunakan row agar sejajar)
    markup.row(
        InlineKeyboardButton(f"🐎 TROJAN INDO ({txt_xray})", callback_data="buy_trojan_indo"),
        InlineKeyboardButton("⏱ TRIAL TROJAN", callback_data="trial_trojan_indo")
    )
    
    # 5. Baris Kembali
    markup.add(InlineKeyboardButton("🔙 KEMBALI KE MENU", callback_data="back_to_main_menu"))
    
    return markup



    

    
